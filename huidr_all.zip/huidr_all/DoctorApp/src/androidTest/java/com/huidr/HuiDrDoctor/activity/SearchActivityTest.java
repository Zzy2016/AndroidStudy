package com.huidr.HuiDrDoctor.activity;


import androidx.test.espresso.contrib.RecyclerViewActions;
import androidx.test.espresso.intent.rule.IntentsTestRule;

import com.huidr.HuiDrDoctor.debug.R;

import org.junit.Rule;
import org.junit.Test;

import static androidx.test.espresso.Espresso.onView;
import static androidx.test.espresso.action.ViewActions.click;
import static androidx.test.espresso.action.ViewActions.typeText;
import static androidx.test.espresso.assertion.ViewAssertions.matches;
import static androidx.test.espresso.intent.Intents.intended;
import static androidx.test.espresso.intent.matcher.ComponentNameMatchers.hasShortClassName;
import static androidx.test.espresso.intent.matcher.IntentMatchers.hasComponent;
import static androidx.test.espresso.intent.matcher.IntentMatchers.toPackage;
import static androidx.test.espresso.matcher.RootMatchers.withDecorView;
import static androidx.test.espresso.matcher.ViewMatchers.isDisplayed;
import static androidx.test.espresso.matcher.ViewMatchers.withId;
import static androidx.test.espresso.matcher.ViewMatchers.withText;
import static org.hamcrest.Matchers.allOf;
import static org.hamcrest.Matchers.is;
import static org.hamcrest.Matchers.not;


/**
 * @author: Administrator
 * @date: 2020-03-13
 */

public class SearchActivityTest {
//    @Rule
//    public ActivityTestRule<SearchActivity> rule = new ActivityTestRule<>(SearchActivity.class);


    @Rule
    public IntentsTestRule<SearchActivity> rule1 = new IntentsTestRule<>(SearchActivity.class);

    /*
     * cl_his  搜索历史
     * cl_empty 空态页
     * srl_layout 搜索结果
     *
     * */

    /*
    * 输入异常
    *
    * */
    @Test
    public void testSearch() throws InterruptedException {

        onView(withId(R.id.et_search)).perform(typeText(" "));
        onView(withId(R.id.image_search)).perform(click());
        onView(withText("请重新输入")).inRoot(withDecorView(not(rule1.getActivity().getWindow().getDecorView()))).check(matches(isDisplayed()));
        onView(withId(R.id.cl_his)).check(matches(is(isDisplayed())));
        Thread.sleep(2000);


        onView(withId(R.id.et_search)).perform(typeText("   "));
        onView(withId(R.id.image_search)).perform(click());
        onView(withText("请重新输入")).inRoot(withDecorView(not(rule1.getActivity().getWindow().getDecorView()))).check(matches(isDisplayed()));
        onView(withId(R.id.cl_his)).check(matches(isDisplayed()));

        onView(withId(R.id.rv_his_search)).perform(RecyclerViewActions.actionOnItemAtPosition(0, click()));
        onView(withId(R.id.rv_his_search)).check(matches(not(isDisplayed())));
        onView(withId(R.id.srl_layout)).check(matches(isDisplayed()));


        onView(withId(R.id.image_clear)).perform(click());
        onView(withId(R.id.rv_his_search)).check(matches(isDisplayed()));
        onView(withId(R.id.srl_layout)).check(matches(not(isDisplayed())));
        onView(withId(R.id.et_search)).check(matches(withText("")));
    }

    /*
    * 点击搜搜结果列表
    * */
    @Test
    public void testIntent() throws InterruptedException {
        onView(withId(R.id.rv_his_search)).perform(RecyclerViewActions.actionOnItemAtPosition(0, click()));
        onView(withId(R.id.rv_search)).check(matches(isDisplayed()));
        onView(withId(R.id.rv_search)).perform(RecyclerViewActions.actionOnItemAtPosition(0, click()));
        Thread.sleep(1000);
        intended(allOf(hasComponent(hasShortClassName(".WebActivity")),toPackage("com.huidr.HuiDrDoctor.activity")));
    }
}