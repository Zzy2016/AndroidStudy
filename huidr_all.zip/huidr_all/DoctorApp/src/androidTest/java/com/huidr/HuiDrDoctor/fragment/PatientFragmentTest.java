package com.huidr.HuiDrDoctor.fragment;

/**
 * @author: Administrator
 * @date: 2020-03-11
 */


public class PatientFragmentTest {

//    @Rule
//    public ActivityTestRule<MainActivity> rule = new ActivityTestRule<>(MainActivity.class);
//
//    //    点击最近查看
//    @Test
//    public void testRecent() {
//        onView(withId(R.id.ll_1)).perform(click());
//        onView(withId(R.id.tv_title)).check(matches(withText("最近查看")));
//    }
//
//    //    点击住院患者
//    @Test
//    public void testInhos() {
//        onView(withId(R.id.ll_2)).perform(click());
//        onView(withId(R.id.tv_title)).check(matches(withText("住院患者")));
//    }
//
//    //    点击随访患者
//    @Test
//    public void testVisit() {
//        onView(withId(R.id.ll_2)).perform(click());
//        onView(withId(R.id.tv_title)).check(matches(withText("住院患者")));
//    }
//
//    //    点击关注患者
//    @Test
//    public void testAttent() {
//        onView(withId(R.id.ll_2)).perform(click());
//        onView(withId(R.id.tv_title)).check(matches(withText("住院患者")));
//    }
//
//    //    点击全部患者
//    @Test
//    public void testAll() {
//        onView(withId(R.id.ll_2)).perform(click());
//        onView(withId(R.id.tv_title)).check(matches(withText("住院患者")));
//    }
//
//    //点击搜索图标
//    @Test
//    public void testIntent() {
//        onView(withId(R.id.image_search)).check((ViewAssertion) click());
//    }
//
//    //测试患者池图标
//    public void testTitle() {
//        onView(withId(R.id.tv_app)).check(matches(withText("患者池")));
//    }
}