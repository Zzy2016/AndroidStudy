package com.huidr.HuiDrDoctor.activity;

import androidx.test.espresso.contrib.RecyclerViewActions;
import androidx.test.espresso.intent.rule.IntentsTestRule;
import androidx.test.ext.junit.runners.AndroidJUnit4;

import com.huidr.HuiDrDoctor.debug.R;

import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;

import static androidx.test.espresso.Espresso.onView;
import static androidx.test.espresso.action.ViewActions.click;
import static androidx.test.espresso.action.ViewActions.typeText;
import static androidx.test.espresso.assertion.ViewAssertions.matches;
import static androidx.test.espresso.intent.Intents.intended;
import static androidx.test.espresso.intent.matcher.ComponentNameMatchers.hasShortClassName;
import static androidx.test.espresso.intent.matcher.IntentMatchers.hasComponent;
import static androidx.test.espresso.intent.matcher.IntentMatchers.toPackage;
import static androidx.test.espresso.matcher.RootMatchers.withDecorView;
import static androidx.test.espresso.matcher.ViewMatchers.isDisplayed;
import static androidx.test.espresso.matcher.ViewMatchers.withId;
import static androidx.test.espresso.matcher.ViewMatchers.withText;
import static org.hamcrest.Matchers.allOf;
import static org.hamcrest.Matchers.containsString;
import static org.hamcrest.Matchers.not;


/**
 * @author: Administrator
 * @date: 2020-03-11
 */

@RunWith(AndroidJUnit4.class)

public class MainActivityTest {

//    @Rule
//    public ActivityTestRule<MainActivity> rule = new ActivityTestRule<>(MainActivity.class);

    @Rule
    public IntentsTestRule<MainActivity> rule = new IntentsTestRule<>(MainActivity.class);


    /*
     * 测试患者池搜索
     * */
    @Test
    public void testPatientSearch() throws InterruptedException {

        onView(withId(R.id.tab_follow)).perform(click());
        Thread.sleep(2000);
        onView(withId(R.id.tv_app)).check(matches(withText("患者池")));
        onView(withId(R.id.image_search)).perform(click());
        Thread.sleep(2000);

        onView(withId(R.id.et_search)).perform(typeText(""));
        onView(withId(R.id.image_search)).perform(click());

//        onView(withText("请重新输入")).inRoot(withDecorView(not(rule1.getActivity().getWindow().getDecorView()))).check(matches(isDisplayed()));
        onView(withText("请重新输入")).
                inRoot(withDecorView(not(rule.getActivity().getWindow().getDecorView()))).
                check(matches(isDisplayed()));

        onView(withId(R.id.et_search)).perform(typeText("   123  "));
        onView(withId(R.id.image_search)).perform(click());
        onView(withId(R.id.rv_search)).check(matches(not(isDisplayed())));
        onView(withId(R.id.rv_his_search)).check(matches(not(isDisplayed())));
        onView(withId(R.id.cl_empty)).check(matches(isDisplayed()));
    }


    /*
     * 测试联系人搜索
     * */
    @Test
    public void testContractSearch() throws InterruptedException {

        onView(withId(R.id.tab_friend)).perform(click());
        Thread.sleep(2000);
        onView(withId(R.id.tv_app)).check(matches(withText("联系人")));
        onView(withId(R.id.image_search)).perform(click());
        Thread.sleep(2000);
        onView(withId(R.id.et_search)).perform(typeText(""));
        onView(withId(R.id.image_search)).perform(click());
        onView(withText("请重新输入")).
                inRoot(withDecorView(not(rule.getActivity().getWindow().getDecorView()))).
                check(matches(isDisplayed()));
        onView(withId(R.id.et_search)).perform(typeText("qweasd"));
        onView(withId(R.id.rv_search)).check(matches(isDisplayed()));

        onView(withId(R.id.image_clear)).perform(click());
        onView(withId(R.id.cl_his)).check(matches(isDisplayed()));


        onView(withId(R.id.rv_his_search)).perform(RecyclerViewActions.actionOnItemAtPosition(3, click()));
//        onView(withId(R.id.rv_search)).check(matches(isDisplayed()));

//        onView(withId(R.id.rv_his_search)).perform(RecyclerViewActions.actionOnItemAtPosition(3,click()));

//        onView(withId(R.id.rv_his_search)).perform(RecyclerViewActions.actionOnItemAtPosition(1,click()));


    }

    /*
     * 测试我的
     * */
    @Test
    public void testMy() throws InterruptedException {
        onView(withId(R.id.tab_me)).perform(click());
        Thread.sleep(1000);
        onView(withText("我的账户")).perform(click());
        intended(allOf(hasComponent(hasShortClassName(".WebActivity")), toPackage("com.huidr.HuiDrDoctor.activity")));
        Thread.sleep(3000);
    }

    //    测试快捷恢复
    @Test
    public void testReply() throws InterruptedException {
        onView(withId(R.id.tab_me)).perform(click());
        Thread.sleep(1000);
        onView(withText("快捷回复")).perform(click());

    }

    //    测试我的收藏
    @Test
    public void testColl() throws InterruptedException {
        onView(withId(R.id.tab_me)).perform(click());
        Thread.sleep(1000);
        onView(withText("我的收藏")).perform(click());

    }

    //    测试荟医助手
    @Test
    public void testHelp() throws InterruptedException {
        onView(withId(R.id.tab_me)).perform(click());
        Thread.sleep(1000);
        onView(withText("荟医助手")).perform(click());

    }

    //    测试随访报到
    @Test
    public void testReg() throws InterruptedException {
        onView(withId(R.id.tab_me)).perform(click());
        Thread.sleep(1000);
        onView(withText(containsString("随访报到"))).perform(click());

    }

    //    测试设置
    @Test
    public void testSet() throws InterruptedException {
        onView(withId(R.id.tab_me)).perform(click());
        Thread.sleep(1000);
        onView(withText("设置")).perform(click());

    }

    //    测试消息按钮Tab
    @Test
    public void testBtn1() {
        onView(withId(R.id.tab_message)).perform(click());
        onView(withId(R.id.tab_message)).check(matches(withText("消息")));
    }

    //    测试患者池Tab
    @Test
    public void testBtn2() throws InterruptedException {
        onView(withId(R.id.tab_follow)).perform(click());
//        onView(withId(R.id.tab_follow)).check(matches(withText("患者池")));

        Thread.sleep(2000);
        onView(withId(R.id.tv_app)).check(matches(withText("患者池")));
        Thread.sleep(1000);
        onView(withId(R.id.ll_1)).check(matches(not(isDisplayed())));
        onView(withId(R.id.tv_title)).check(matches(withText("最近查看")));
        Thread.sleep(1000);
        onView(withId(R.id.ll_2)).perform(click());
        onView(withId(R.id.tv_title)).check(matches(withText("住院患者")));

    }


    @Test
    public void testInHos() throws Exception {
        onView(withId(R.id.tab_follow)).perform(click());
        Thread.sleep(2000);
        onView(withId(R.id.ll_2)).perform(click());
        onView(withId(R.id.tv_title)).check(matches(withText("住院患者")));

    }

    //    测试联系人Tab
    @Test
    public void testBtn3() {
        onView(withId(R.id.tab_friend)).perform(click());
        onView(withId(R.id.tab_friend)).check(matches(withText("联系人")));
    }

    //    测试设置Tab
    @Test
    public void testBtn4() {
        onView(withId(R.id.tab_me)).perform(click());
//        onView(withId(R.id.tab_me)).check(matches(withText("我的")));
        onView(withId(R.id.image_doctor_head)).check(matches(isDisplayed()));
    }

//    查找试图   onView()

    /*
     * 测试首页搜索
     * */
    @Test
    public void testHomeSearch() throws InterruptedException {
        onView(withId(R.id.tab_message)).perform(click());
        Thread.sleep(2000);
        onView(withId(R.id.image_search)).perform(click());
        onView(withId(R.id.et_search)).perform(typeText(" "), click());
        Thread.sleep(2000);

        onView(withId(R.id.image_search)).perform(click());

        onView(withText("请重新输入")).inRoot(withDecorView(not(rule.getActivity().getWindow().getDecorView()))).check(matches(isDisplayed()));

    }


    /*
     *快捷回复
     *iv_enter  保存按钮
     *et_content  输入框
     * */
    @Test
    public void testFastReply() throws InterruptedException {
        onView(withId(R.id.tab_me)).perform(click());

        Thread.sleep(1000);

        onView(withId(R.id.ll_receive)).perform(click());

        onView(withId(R.id.iv_enter)).perform(click());//输入框为空时点击保存

        onView(withText("请输入内容")).
                inRoot(withDecorView(not(rule.getActivity().getWindow().getDecorView()))).check(matches(isDisplayed()));

        Thread.sleep(500);

//        onView(withId(R.id.et_content)).perform(typeText("这是一条数据"));
//        onView(withId(R.id.iv_enter)).perform(click());
//
//        Thread.sleep(3000);

    }


    //    快捷回复添加内容  et_content
    @Test
    public void testFastReplyAddItem() throws InterruptedException {

        onView(withId(R.id.tab_me)).perform(click());
        Thread.sleep(1000);

        onView(withId(R.id.ll_receive)).perform(click());
        Thread.sleep(2000);

        onView(withId(R.id.et_content)).perform(typeText("123"));

        onView(withId(R.id.iv_enter)).perform(click());

        Thread.sleep(3000);
    }


}