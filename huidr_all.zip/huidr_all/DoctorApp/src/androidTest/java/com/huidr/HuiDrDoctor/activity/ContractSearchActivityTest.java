package com.huidr.HuiDrDoctor.activity;


import androidx.test.espresso.intent.rule.IntentsTestRule;

import org.junit.Rule;

/**
 * @author: Administrator
 * @date: 2020-03-13
 */

public class ContractSearchActivityTest {

    @Rule
    public IntentsTestRule<ContractSearchActivity> rule = new IntentsTestRule<>(ContractSearchActivity.class);






}