package com.huidr.HuiDrDoctor.module.home;

import java.util.List;

public class PatientsModel {

    /**
     * status : 0
     * page : 1
     * totalPage : 1
     * retValue : [48,1542,1850,3777,33526,34016,34151,45828,45833,45845,45846,45887,46121,46145,46622,47300,47726,48031,48639,48659,48801,48999,49009,49037,49060,49071,49461,49566,49735,49799,50141,50765,51024,51236,51266,51296,51301,51311,51493,51505,51508,51509,51521,51597,51706,51722,51748,51753,51775,51849,52014,52046,52159,52161,52235,52271,52327,52344,52366,52454,52504,52527,52564,52659,54997,55544,57070,57428,60164,60385,60439,60452,61508,61567,61609,62074,62147,62232,62398,62444,64511,64532,68186,68541,68608,68623,68627,68638,69634,69882,69883,69886,69889,69907,70090,84001,85458,85781,85840,85845,85951,85980,86014,86015,86016,86017,86018,86377,86378,86380,86381,86382,100137,141024]
     */

    private int status;
    private int page;
    private int totalPage;
    private List<Integer> retValue;

    public int getStatus() {
        return status;
    }

    public void setStatus(int status) {
        this.status = status;
    }

    public int getPage() {
        return page;
    }

    public void setPage(int page) {
        this.page = page;
    }

    public int getTotalPage() {
        return totalPage;
    }

    public void setTotalPage(int totalPage) {
        this.totalPage = totalPage;
    }

    public List<Integer> getRetValue() {
        return retValue;
    }

    public void setRetValue(List<Integer> retValue) {
        this.retValue = retValue;
    }
}
