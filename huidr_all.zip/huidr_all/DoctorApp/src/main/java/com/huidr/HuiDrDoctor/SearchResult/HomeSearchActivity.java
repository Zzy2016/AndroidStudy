package com.huidr.HuiDrDoctor.SearchResult;

import android.content.SharedPreferences;
import android.os.Bundle;


import androidx.appcompat.app.AppCompatActivity;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.KeyEvent;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.alibaba.fastjson.JSONObject;
import com.google.gson.Gson;
import com.huidr.HuiDrDoctor.activity.main.Consult.utils.PostAndGet;
import com.huidr.HuiDrDoctor.debug.BuildConfig;
import com.huidr.HuiDrDoctor.debug.R;
import com.huidr.HuiDrDoctor.module.home.FastLoginModel;
import com.huidr.HuiDrDoctor.util.ThreadPoolManager;

import java.util.regex.Pattern;

import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;
import jiguang.chat.utils.oss.SharedPreferenciesUtil;

public class HomeSearchActivity extends AppCompatActivity implements View.OnClickListener, SearchHisFragment.CallBackValue, DoctorSearchFragment.DoctorInterface, PatientSearchFragment.PatientInterface {


    private TextView tvCancel;//取消
    private ImageView imageSearchHome;//搜索
    private ImageView imageClearHome;//删除输入内容
    private EditText etInputHome;//
    //    private TabLayout tabTitleHome;
    private FragmentManager fragmentManager;
    private FragmentTransaction fragmentTransaction;

    private InputMethodManager inputMethodManager;

    private PatientSearchFragment patientSearchFragment;
    private DoctorSearchFragment doctorSearchFragment;


    private boolean isFollow;
    private FastLoginModel fastLoginModel;
    private Gson gson;

    public void getFollowState() {
        ThreadPoolManager.getInstance().execute(new Runnable() {
            @Override
            public void run() {
                String path = BuildConfig.baseUrl + "hospital/doctorUser/fastLogin";
                SharedPreferences sPreferences = getSharedPreferences("updateDownload", 0);
                String nowVersion = sPreferences.getString("version", "0");
                JSONObject jsonObject = new JSONObject();
                jsonObject.put("osName", "Android");
                jsonObject.put("version", nowVersion);
                String result = PostAndGet.doHttpPost(path, jsonObject);
                Log.e("医生信息--", result);
                if (result.equals("")) {

                } else {
                    fastLoginModel = gson.fromJson(result, FastLoginModel.class);
                    isFollow = fastLoginModel.getRetValue().isIsFollowup();

                }

            }
        });
    }


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home_search);
        gson = new Gson();
        fastLoginModel = new FastLoginModel();
        getFollowState();
        inputMethodManager = (InputMethodManager) getSystemService(INPUT_METHOD_SERVICE);
        initView();
    }

    public void hideImm() {
        if (inputMethodManager != null) {
            inputMethodManager.hideSoftInputFromWindow(etInputHome.getWindowToken(), 0);
        }
    }

    public void initView() {

        tvCancel = (TextView) findViewById(R.id.tv_cancel);
        imageSearchHome = (ImageView) findViewById(R.id.image_search_home);
        imageClearHome = (ImageView) findViewById(R.id.image_clear_home);
        etInputHome = (EditText) findViewById(R.id.et_input_home);

//        tabTitleHome = (TabLayout) findViewById(R.id.tab_title_home);

        tvCancel.setOnClickListener(this);
        imageSearchHome.setOnClickListener(this);
        imageClearHome.setOnClickListener(this);

//        tabTitleHome.addTab(tabTitleHome.newTab().setText("患者"));
//        tabTitleHome.addTab(tabTitleHome.newTab().setText("医生"));

        etInputHome.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {
                if (etInputHome.getText().toString().length() > 0) {
                    imageClearHome.setVisibility(View.VISIBLE);
                } else {
                    imageClearHome.setVisibility(View.GONE);
                }
            }
        });

        /*返回true，保留软键盘。false，隐藏软键盘*/
        etInputHome.setOnEditorActionListener(new TextView.OnEditorActionListener() {
            @Override
            public boolean onEditorAction(TextView v, int actionId, KeyEvent event) {

                if (actionId == 3) {//
                    if (etInputHome.getText().toString().length() > 0) {
                        Pattern pattern = Pattern.compile("^\\s*$");
                        if (pattern.matcher(etInputHome.getText().toString()).matches()) {
                            Toast.makeText(HomeSearchActivity.this, "请重新输入", Toast.LENGTH_LONG).show();
                            etInputHome.setText("");
                        } else {
//                            tabTitleHome.getTabAt(0).select();
                            switchFragment(1, etInputHome.getText().toString());
//                            tabTitleHome.setVisibility(View.VISIBLE);
                        }
                    }
                    return true;
                } else {
                    return false;
                }

            }
        });

        switchFragment(0, null);

    }


    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.tv_cancel:
                finish();
                break;
            case R.id.image_search_home:
                checkKey();
                break;
            case R.id.image_clear_home:
                etInputHome.setText("");
                imageClearHome.setVisibility(View.GONE);
//                tabTitleHome.setVisibility(View.GONE);
                switchFragment(0, null);
                break;
        }

    }

    public void checkKey() {
        if (etInputHome.getText().toString().length() > 0) {
            Pattern pattern = Pattern.compile("^\\s*$");
            if (pattern.matcher(etInputHome.getText().toString()).matches()) {
                Toast.makeText(HomeSearchActivity.this, "请重新输入", Toast.LENGTH_LONG).show();
                etInputHome.setText("");
            } else {
                Log.e("开始搜索", "开始搜索");

                switchFragment(1, etInputHome.getText().toString());
//                tabTitleHome.getTabAt(0).select();
//                tabTitleHome.setVisibility(View.VISIBLE);
                hideImm();
            }
        }
    }


    /*切换Fragment*/
    public void switchFragment(int index, String key) {
        if (fragmentManager == null) {
            fragmentManager = getSupportFragmentManager();
        }
        fragmentTransaction = fragmentManager.beginTransaction();
        switch (index) {
            case 0:
                fragmentTransaction.replace(R.id.fl_content_home, new SearchHisFragment()).commit();
                break;
            case 1:
                hideImm();
                patientSearchFragment = new PatientSearchFragment();
                Bundle bundle = new Bundle();
                bundle.putString("key", key);
                bundle.putBoolean("isFollow", isFollow);
                patientSearchFragment.setArguments(bundle);
                fragmentTransaction.replace(R.id.fl_content_home, patientSearchFragment).commit();
                break;
            case 2:
                doctorSearchFragment = new DoctorSearchFragment();
                Bundle bundle1 = new Bundle();
                bundle1.putString("key", key);
                doctorSearchFragment.setArguments(bundle1);
                fragmentTransaction.replace(R.id.fl_content_home, doctorSearchFragment).commit();
                break;
        }
    }

    @Override
    public void sendMessageValue(String value) {
        Log.e("搜索历史", value);
        etInputHome.setText(value);
        switchFragment(1, value);
//        tabTitleHome.setVisibility(View.VISIBLE);
//        tabTitleHome.getTabAt(0).select();
        hideImm();
    }

    /*跳转全部联系人*/
    @Override
    public void doFinish() {
        SharedPreferenciesUtil.putData("currentId", 2);
        finish();
    }


    /*跳转 联系人 申请/添加*/
    @Override
    public void doAddContract() {
        SharedPreferenciesUtil.putData("currentId", 2);
        SharedPreferenciesUtil.putData("friendIndex", 3);
        finish();
    }


    /*跳转全部患者*/
    @Override
    public void doFinishPatient() {
        SharedPreferenciesUtil.putData("currentId", 1);
        finish();
    }

    /*跳转 患者池 随访患者*/
    @Override
    public void doAddFollow() {
        SharedPreferenciesUtil.putData("currentId", 3);
        finish();
    }

    /*切换医生*/
    @Override
    public void switchDoctor() {
        switchFragment(2, etInputHome.getText().toString());
    }

    /*切换患者*/
    @Override
    public void switchPatient() {
        switchFragment(1, etInputHome.getText().toString());
    }


}
