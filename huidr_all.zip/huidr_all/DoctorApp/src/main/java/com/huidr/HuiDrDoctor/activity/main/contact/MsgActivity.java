package com.huidr.HuiDrDoctor.activity.main.contact;

import android.os.Bundle;
import android.os.Handler;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.DividerItemDecoration;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.ajguan.library.EasyRefreshLayout;
import com.chad.library.adapter.base.BaseQuickAdapter;
import com.chad.library.adapter.base.BaseViewHolder;
import com.huidr.HuiDrDoctor.debug.R;
import com.huidr.lib.commom.util.Toast;

import java.util.ArrayList;
import java.util.List;

import static org.litepal.LitePalApplication.getContext;

public class MsgActivity extends AppCompatActivity implements View.OnClickListener {

    private ImageView imgActivityLeft;

    private RelativeLayout rlMsg, rlCou;
    private TextView tvMsg, tvCou, tvMsgIndi, tvCouIndi;

    private LinearLayout llMsg, llCou;

    private EasyRefreshLayout erlMsg, erlCou;
    private RecyclerView msgList, couList;
    private LinearLayout llEmptyMsg, llEmptyCou;

    private MsgAdapter msgAdapter, couAdapter;//消息动态 图文咨询

    private List<String> listMsg, listCou;//  消息 图文咨询
    private int pageMsg = 1, pageCou = 1;//消息 图文咨询
    private boolean isLoadAll1, isLoadAll2;//消息 图文咨询

    private boolean select = true;  //true 消息 false 图文咨询

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_msg);
        initData();
        initView();
    }


    public void initData() {
        listMsg = new ArrayList<>();
        listCou = new ArrayList<>();

        for (int i = 0; i < 102; i++) {
            listMsg.add("系统消息" + i);
            // listCou.add("图文咨询" + i);
        }

        msgAdapter = new MsgAdapter(R.layout.item_msg_layout, null);
        couAdapter = new MsgAdapter(R.layout.item_msg_layout, null);

        msgAdapter.setNewData(getMsgByPage(1, 1));
        couAdapter.setNewData(getMsgByPage(1, 2));

    }

    public void initView() {

        imgActivityLeft = (ImageView) findViewById(R.id.img_activity_left);
        imgActivityLeft.setOnClickListener(this);

        rlMsg = (RelativeLayout) findViewById(R.id.rl_msg);
        rlMsg.setOnClickListener(this);

        rlCou = (RelativeLayout) findViewById(R.id.rl_cou);

        rlCou.setOnClickListener(this);

        tvMsg = (TextView) findViewById(R.id.tv_msg);
        tvCou = (TextView) findViewById(R.id.tv_cou);


        tvMsgIndi = (TextView) findViewById(R.id.tv_msg_indi);
        tvCouIndi = (TextView) findViewById(R.id.tv_cou_indi);

        llMsg = (LinearLayout) findViewById(R.id.ll_msg);
        llCou = (LinearLayout) findViewById(R.id.ll_cou);

        erlMsg = (EasyRefreshLayout) findViewById(R.id.sys_msg_easy_refresh);
        erlCou = (EasyRefreshLayout) findViewById(R.id.cou_easy_refresh);

        msgList = (RecyclerView) findViewById(R.id.sys_msg_recyclerview);
        couList = (RecyclerView) findViewById(R.id.cou_recyclerview);

        llEmptyMsg = (LinearLayout) findViewById(R.id.ll_emprt_msg);
        llEmptyCou = (LinearLayout) findViewById(R.id.ll_emprt_cou);

        msgList.setAdapter(msgAdapter);
        couList.setAdapter(couAdapter);
        if(couAdapter.getData().size()==0){
            llEmptyCou.setVisibility(View.VISIBLE);
        }

        msgList.setLayoutManager(new LinearLayoutManager(this));
        couList.setLayoutManager(new LinearLayoutManager(this));
        msgList.addItemDecoration(new DividerItemDecoration(this, DividerItemDecoration.VERTICAL));
        couList.addItemDecoration(new DividerItemDecoration(this, DividerItemDecoration.VERTICAL));


        refreshBtn();
        llMsg.bringToFront();

        erlMsg.addEasyEvent(new EasyRefreshLayout.EasyEvent() {
            @Override
            public void onLoadMore() {

                new Handler().postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        if (!isLoadAll1) {
                            pageMsg++;
                            int position = msgAdapter.getData().size();
                            msgAdapter.getData().addAll(getMsgByPage(pageMsg, 1));
                            msgList.scrollToPosition(position);
                            erlMsg.closeLoadView();
                        } else {
                            erlMsg.closeLoadView();
                            Toast.getInstance(getContext()).show("已加载全部", 0);
                        }

                    }
                }, 500);


            }

            @Override
            public void onRefreshing() {


                new Handler().postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        /*
                         * 此处应当重新读取数据库全部数据
                         * */
                        pageMsg = 1;
                        msgAdapter.setNewData(getMsgByPage(1, 1));
                        isLoadAll1 = false;

                    }
                }, 1000);
                erlMsg.refreshComplete();
            }
        });

        erlCou.addEasyEvent(new EasyRefreshLayout.EasyEvent() {
            @Override
            public void onLoadMore() {

                new Handler().postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        if (!isLoadAll2) {
                            pageCou++;
                            int position = couAdapter.getData().size();
                            couAdapter.getData().addAll(getMsgByPage(pageCou, 2));
                            couList.scrollToPosition(position);

                        } else {
                            Toast.getInstance(getContext()).show("已加载全部", 0);
                        }

                    }
                }, 500);

                erlCou.closeLoadView();
            }

            @Override
            public void onRefreshing() {
                new Handler().postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        /*
                         * 此处应当重新读取数据库全部数据
                         * */
                        pageCou = 1;
                        couAdapter.setNewData(getMsgByPage(1, 2));
                        isLoadAll2 = false;

                    }
                }, 1000);
                erlCou.refreshComplete();
            }
        });
    }


    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.img_activity_left:
                finish();
                break;
            case R.id.rl_msg:
                llMsg.bringToFront();
                select = true;
                refreshBtn();
                break;
            case R.id.rl_cou:
                llCou.bringToFront();
                select = false;
                refreshBtn();
                break;
        }
    }

    public void refreshBtn() {
        if (!select) {
            tvMsg.setTextColor(getResources().getColor(R.color.title_msg));
            tvCou.setTextColor(getResources().getColor(R.color.black));

            tvMsgIndi.setVisibility(View.INVISIBLE);
            tvCouIndi.setVisibility(View.VISIBLE);

        } else {
            tvMsg.setTextColor(getResources().getColor(R.color.black));
            tvCou.setTextColor(getResources().getColor(R.color.title_msg));
            tvMsgIndi.setVisibility(View.VISIBLE);
            tvCouIndi.setVisibility(View.INVISIBLE);
        }
    }


    private class MsgAdapter extends BaseQuickAdapter<String, BaseViewHolder> {
        public MsgAdapter(int layoutResId, @Nullable List<String> data) {
            super(layoutResId, data);
        }

        @Override
        protected void convert(BaseViewHolder helper, String item) {
            ((TextView) helper.getView(R.id.tv_name)).setText(item);
        }
    }


    public List<String> getMsgByPage(int page, int type) {
        List<String> list = new ArrayList<>();
        List<String> allList = new ArrayList<>();

        if (type == 1) {
            allList = listMsg;
        } else {
            allList = listCou;
        }

        if (allList.size() > 0) {
            if (allList.size() >= (page * 20)) {
                list.addAll(allList.subList((page - 1) * 20, page * 20));
            } else {
                list.addAll(allList.subList((page - 1) * 20, allList.size()));
                if (type == 1) {
                    isLoadAll1 = true;
                } else {
                    isLoadAll2 = true;
                }
            }
        }
        return list;
    }

}
