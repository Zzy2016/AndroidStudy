package com.huidr.HuiDrDoctor.activity.fastReply;

import com.activeandroid.Model;
import com.activeandroid.annotation.Column;
import com.activeandroid.annotation.Table;
import com.activeandroid.query.Delete;
import com.activeandroid.query.Select;
import com.activeandroid.query.Update;

import java.util.List;

/**
 * 快速回复
 * Created by Laiyimin on 2016/10/20.
 */

@Table(name = "quick_reply_model", id = "_id")
public class ReplyModel extends Model {

    @Column(name = "Content")
    public String content;

    @Column(name = "SeqIndex")
    private int seqIndex;

    @Column(name = "isEdit")
    private boolean isEdit;

    public ReplyModel() {
        super();
    }

    public ReplyModel(boolean isEdit, String content) {
        super();
        this.content = content;
    }


    public static ReplyModel getEntry(int id) {
        return new Select().from(ReplyModel.class).where("_id = ?", id).executeSingle();
    }

    public static List<ReplyModel> getEntryAll() {
        return new Select().from(ReplyModel.class).execute();

    }

    public static void updateById(long id, String content) {

        Update update = new Update(ReplyModel.class);
        update.set("Content=" + content).where("_id=" + id).execute();
    }

    public static void deleteAll() {
        new Delete().from(ReplyModel.class).execute();
    }


    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public int getSeqIndex() {
        return seqIndex;
    }

    public void setSeqIndex(int seqIndex) {
        this.seqIndex = seqIndex;
    }

    public boolean isEdit() {
        return isEdit;
    }

    public void setEdit(boolean edit) {
        isEdit = edit;
    }
}





