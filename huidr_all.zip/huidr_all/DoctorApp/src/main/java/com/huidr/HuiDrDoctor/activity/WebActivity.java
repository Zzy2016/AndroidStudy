package com.huidr.HuiDrDoctor.activity;

import android.app.Dialog;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.FrameLayout;

import com.huidr.HuiDrDoctor.debug.R;
import com.huidr.HuiDrDoctor.util.LogUtil;
import com.huidr.lib.commom.base.BaseWebActivity;
import com.huidr.lib.commom.base.HuidrActivityManager;
import com.huidr.lib.commom.util.HbuildUtil;

import java.io.File;

import cn.jpush.im.android.api.JMessageClient;
import cn.jpush.im.android.api.event.LoginStateChangeEvent;
import cn.jpush.im.android.api.model.UserInfo;
import cn.jpush.im.api.BasicCallback;
import io.dcloud.EntryProxy;
import io.dcloud.common.DHInterface.ICore;
import io.dcloud.common.DHInterface.IWebview;
import io.dcloud.common.DHInterface.IWebviewStateListener;
import io.dcloud.feature.internal.sdk.SDK;
import jiguang.chat.utils.DialogCreator;
import jiguang.chat.utils.FileHelper;
import jiguang.chat.utils.ModulesConstants;
import jiguang.chat.utils.SharePreferenceManager;
import jiguang.chat.utils.ToastUtil;
import jiguang.chat.utils.event.BusEventMessage;


public class WebActivity extends BaseWebActivity {
    private IWebview webview;
    private FrameLayout rootView;
    private String url;
    private Bundle bundle;


    private static Dialog dialog;

    protected int mWidth;
    protected int mHeight;
    protected float mDensity;
    protected int mDensityDpi;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);


//        JMessageClient.registerEventReceiver(this);
//        获取屏幕参数 设置显示
        DisplayMetrics dm = new DisplayMetrics();
        getWindowManager().getDefaultDisplay().getMetrics(dm);
        mDensity = dm.density;
        mDensityDpi = dm.densityDpi;
        mWidth = dm.widthPixels;
        mHeight = dm.heightPixels;

    }

    /*
     * 接收极光事件
     *
     * */
    public void onEventMainThread(LoginStateChangeEvent event) {
        final LoginStateChangeEvent.Reason reason = event.getReason();

        UserInfo myInfo = event.getMyInfo();
        if (myInfo != null) {
            String path;
            File avatar = myInfo.getAvatarFile();
            if (avatar != null && avatar.exists()) {
                path = avatar.getAbsolutePath();
            } else {
                path = FileHelper.getUserAvatarPath(myInfo.getUserName());
            }
            SharePreferenceManager.setCachedUsername(myInfo.getUserName());
            SharePreferenceManager.setCachedAvatarPath(path);
            JMessageClient.logout();
        }
        switch (reason) {
            case user_logout:
                View.OnClickListener listener = new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {

                        if (v.getId() == R.id.jmui_cancel_btn) {

                            ToastUtil.shortToast(WebActivity.this, "顶号登录-取消登录");
                            dialog.cancel();
//                            BusEventMessage busEventMessage = new BusEventMessage(ModulesConstants.RE_LOGIN);
//                            EventBus.getDefault().post(busEventMessage);
                        }
                        if (v.getId() == R.id.jmui_commit_btn) {

                            JMessageClient.login(SharePreferenceManager.getCachedUsername(), SharePreferenceManager.getCachedPsw(), new BasicCallback() {
                                @Override
                                public void gotResult(int responseCode, String responseMessage) {
                                    if (responseCode == 0) {
                                        ToastUtil.shortToast(WebActivity.this, "顶号登录-确认登录");
                                        dialog.dismiss();
                                        dialog.cancel();
//                                        BusEventMessage busEventMessage = new BusEventMessage(ModulesConstants.JG_LOGIN_SUC);
//                                        EventBus.getDefault().post(busEventMessage);
                                    }
                                }
                            });
                        }
                    }
                };
                if (dialog == null) {

                    dialog = DialogCreator.createLogoutStatusDialog(WebActivity.this, "您的账号在其他设备上登陆", listener);
                    dialog.getWindow().setLayout((int) (0.8 * mWidth), WindowManager.LayoutParams.WRAP_CONTENT);
                    dialog.setCanceledOnTouchOutside(false);
                    dialog.show();
                }
                break;
            case user_password_change:
                // Intent intent = new Intent(BaseActivity.this, LoginActivity.class);
                // startActivity(intent);
                break;
        }
    }

    @Override
    protected void initView() {
        super.initView();
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        rootView = new FrameLayout(this);
        setContentView(rootView);

        bundle = this.getIntent().getExtras();
        url = bundle.getString("url");
        LogUtil.e("url----WebActivity-->", url);
        if (url.contains("?")) {
            String paramstring = url.split("\\?")[1];
            if (!paramstring.isEmpty()) {
                String[] params = paramstring.split("\\&");
                for (String param : params) {
                    String[] paramKeyValue = param.split("\\=");
                    urlKeys.put(paramKeyValue[0], paramKeyValue[1]);
                }
            }
        }
    }

    @Override
    public void onCoreInitEnd(ICore coreHandler) {
        super.onCoreInitEnd(coreHandler);
        String appid = getAppId(url);
        showDialog();
        webview = SDK.createWebview(this, HbuildUtil.getUrl(getApplicationContext(), "Doctor", url), appid, new IWebviewStateListener() {
            @Override
            public Object onCallBack(int pType, Object pArgs) {
                switch (pType) {
                    case IWebviewStateListener.ON_WEBVIEW_READY:
                        break;
                    case IWebviewStateListener.ON_PAGE_STARTED:
                        showDialog();
                        break;
                    case IWebviewStateListener.ON_PROGRESS_CHANGED:
                        break;
                    case IWebviewStateListener.ON_PAGE_FINISHED:
                        dismissDialog();
                        break;
                }
                return null;
            }
        });

        HuidrActivityManager.getInstance().addWebview(appid, webview);
        SDK.attach(rootView, webview);
        webview.onRootViewGlobalLayout(rootView);
    }

    @Override
    protected void onResume() {  //刷新
        super.onResume();
//        if(webview!=null) {
//            onCoreInitEnd(null);
//        }
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        finish();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        EntryProxy.getInstnace().onStop(this);
        SDK.closeWebView(webview);
//        JMessageClient.unRegisterEventReceiver(this);
        if (dialog != null) {
            dialog.dismiss();
        }
    }
}
