package com.huidr.HuiDrDoctor.activity.main.Consult.Model;

import java.util.List;

/*
* Conversion.toJsonString
*
* */
public class ConversionAbout {


    /**
     * a : msg604846869
     * b : bd6ad187437010acb0639f85
     * e : online604846869
     * f : 周玉梅
     * g : 0
     * extra :
     * id : f58d40c0-8204-467b-adc5-8045ab6f6981
     * lastMsgDate : 1570774352055
     * latestText : 测试
     * latestType : text
     * targetId : 100137
     * targetInfo : {"address":"","appkey":"bd6ad187437010acb0639f85","birthday":"","blacklist":0,"extras":{},"gender":"0","isFriend":1,"mGender":"unknown","mtime":1570773885,"nickname":"周玉梅","noDisturb":0,"memo_others":"","memo_name":"","region":"","signature":"","star":-1,"uid":358734067,"username":"100137"}
     * title : 周玉梅
     * type : single
     * unReadMsgCnt : 0
     */

    private String a;
    private String b;
    private String e;
    private String f;
    private int g;
    private String extra;
    private String id;
    private long lastMsgDate;
    private String latestText;
    private String latestType;
    private String targetId;
    private TargetInfoBean targetInfo;
    private String title;
    private String type;
    private int unReadMsgCnt;

    public String getA() {
        return a;
    }

    public void setA(String a) {
        this.a = a;
    }

    public String getB() {
        return b;
    }

    public void setB(String b) {
        this.b = b;
    }

    public String getE() {
        return e;
    }

    public void setE(String e) {
        this.e = e;
    }

    public String getF() {
        return f;
    }

    public void setF(String f) {
        this.f = f;
    }

    public int getG() {
        return g;
    }

    public void setG(int g) {
        this.g = g;
    }

    public String getExtra() {
        return extra;
    }

    public void setExtra(String extra) {
        this.extra = extra;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public long getLastMsgDate() {
        return lastMsgDate;
    }

    public void setLastMsgDate(long lastMsgDate) {
        this.lastMsgDate = lastMsgDate;
    }

    public String getLatestText() {
        return latestText;
    }

    public void setLatestText(String latestText) {
        this.latestText = latestText;
    }

    public String getLatestType() {
        return latestType;
    }

    public void setLatestType(String latestType) {
        this.latestType = latestType;
    }

    public String getTargetId() {
        return targetId;
    }

    public void setTargetId(String targetId) {
        this.targetId = targetId;
    }

    public TargetInfoBean getTargetInfo() {
        return targetInfo;
    }

    public void setTargetInfo(TargetInfoBean targetInfo) {
        this.targetInfo = targetInfo;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public int getUnReadMsgCnt() {
        return unReadMsgCnt;
    }

    public void setUnReadMsgCnt(int unReadMsgCnt) {
        this.unReadMsgCnt = unReadMsgCnt;
    }

    public static class TargetInfoBean {
        /**
         * address :
         * appkey : bd6ad187437010acb0639f85
         * birthday :
         * blacklist : 0
         * extras : {}
         * gender : 0
         * isFriend : 1
         * mGender : unknown
         * mtime : 1570773885
         * nickname : 周玉梅
         * noDisturb : 0
         * memo_others :
         * memo_name :
         * region :
         * signature :
         * star : -1
         * uid : 358734067
         * username : 100137
         */

        private String address;
        private String appkey;
        private String birthday;
        private int blacklist;
        private ExtrasBean extras;
        private String gender;
        private int isFriend;
        private String mGender;
        private int mtime;
        private String nickname;
        private int noDisturb;
        private String memo_others;
        private String memo_name;
        private String region;
        private String signature;
        private int star;
        private int uid;
        private String username;

        public String getAddress() {
            return address;
        }

        public void setAddress(String address) {
            this.address = address;
        }

        public String getAppkey() {
            return appkey;
        }

        public void setAppkey(String appkey) {
            this.appkey = appkey;
        }

        public String getBirthday() {
            return birthday;
        }

        public void setBirthday(String birthday) {
            this.birthday = birthday;
        }

        public int getBlacklist() {
            return blacklist;
        }

        public void setBlacklist(int blacklist) {
            this.blacklist = blacklist;
        }

        public ExtrasBean getExtras() {
            return extras;
        }

        public void setExtras(ExtrasBean extras) {
            this.extras = extras;
        }

        public String getGender() {
            return gender;
        }

        public void setGender(String gender) {
            this.gender = gender;
        }

        public int getIsFriend() {
            return isFriend;
        }

        public void setIsFriend(int isFriend) {
            this.isFriend = isFriend;
        }

        public String getMGender() {
            return mGender;
        }

        public void setMGender(String mGender) {
            this.mGender = mGender;
        }

        public int getMtime() {
            return mtime;
        }

        public void setMtime(int mtime) {
            this.mtime = mtime;
        }

        public String getNickname() {
            return nickname;
        }

        public void setNickname(String nickname) {
            this.nickname = nickname;
        }

        public int getNoDisturb() {
            return noDisturb;
        }

        public void setNoDisturb(int noDisturb) {
            this.noDisturb = noDisturb;
        }

        public String getMemo_others() {
            return memo_others;
        }

        public void setMemo_others(String memo_others) {
            this.memo_others = memo_others;
        }

        public String getMemo_name() {
            return memo_name;
        }

        public void setMemo_name(String memo_name) {
            this.memo_name = memo_name;
        }

        public String getRegion() {
            return region;
        }

        public void setRegion(String region) {
            this.region = region;
        }

        public String getSignature() {
            return signature;
        }

        public void setSignature(String signature) {
            this.signature = signature;
        }

        public int getStar() {
            return star;
        }

        public void setStar(int star) {
            this.star = star;
        }

        public int getUid() {
            return uid;
        }

        public void setUid(int uid) {
            this.uid = uid;
        }

        public String getUsername() {
            return username;
        }

        public void setUsername(String username) {
            this.username = username;
        }

        public static class ExtrasBean {
        }
    }
}
