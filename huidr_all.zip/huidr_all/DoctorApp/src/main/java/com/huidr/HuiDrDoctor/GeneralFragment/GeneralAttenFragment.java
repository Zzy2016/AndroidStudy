package com.huidr.HuiDrDoctor.GeneralFragment;

import android.app.Dialog;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import android.text.Html;
import android.util.Log;
import android.view.Display;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.ImageView;
import android.widget.TextView;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.chad.library.adapter.base.BaseQuickAdapter;
import com.chad.library.adapter.base.BaseViewHolder;
import com.google.gson.Gson;
import com.huidr.HuiDrDoctor.activity.WebActivity;
import com.huidr.HuiDrDoctor.activity.main.Consult.utils.PostAndGet;
import com.huidr.HuiDrDoctor.debug.BuildConfig;
import com.huidr.HuiDrDoctor.debug.R;
import com.huidr.HuiDrDoctor.module.home.AttenModel;
import com.huidr.HuiDrDoctor.module.home.PatientsModel;
import com.huidr.HuiDrDoctor.util.LogUtil;
import com.huidr.HuiDrDoctor.util.ThreadPoolManager;
import com.huidr.lib.commom.base.HuidrActivityManager;
import com.huidr.lib.commom.util.Toast;
import com.scwang.smartrefresh.layout.SmartRefreshLayout;
import com.scwang.smartrefresh.layout.api.RefreshLayout;
import com.scwang.smartrefresh.layout.listener.OnLoadMoreListener;
import com.scwang.smartrefresh.layout.listener.OnRefreshListener;
import com.zyao89.view.zloading.ZLoadingDialog;
import com.zyao89.view.zloading.Z_TYPE;

import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import jiguang.chat.utils.oss.SharedPreferenciesUtil;


public class GeneralAttenFragment extends Fragment {

    SmartRefreshLayout srlLayout;
    RecyclerView rvListAtten;
    ConstraintLayout clEmpty;
    TextView tvEmpty1;
    TextView tvEmpty2;

    int currentPage = 1;
    int totalPage = 0;
    long lastClick = 0;

    String tip;
    int tipType;
    Gson gson;
    AttenModel tempAttent;

    PatientsModel patientsModel;
    int [] patients;

    String urlGetPatient = BuildConfig.baseUrl + "patient/doctorPatientMedical/getPatients";
    String urlTags = BuildConfig.baseUrl + "patient/doctorPatientMedical/getPatientPoolByTags";

    ZLoadingDialog zLoadingDialog;

    public void getDataPatients() {
        ThreadPoolManager.getInstance().execute(new Runnable() {
            @Override
            public void run() {
                patientsModel = new PatientsModel();
                gson = new Gson();
                JSONObject jsonObject = new JSONObject();
                jsonObject.put("patientType", 3);
                String result = PostAndGet.doHttpPost(urlGetPatient, jsonObject);
                if (result == null | result.equals("网络异常")) {

                } else {

                    patientsModel = gson.fromJson(result, PatientsModel.class);
                    patients = new int[patientsModel.getRetValue().size()];
                    for (int i = 0; i < patientsModel.getRetValue().size(); i++) {
                        patients[i] = patientsModel.getRetValue().get(i);
                    }
                    handler.sendEmptyMessage(6);
                }
            }
        });
    }


    public void initView(View view) {
        srlLayout = view.findViewById(R.id.srl_layout);
        rvListAtten = view.findViewById(R.id.rv_list_atten);
        clEmpty = view.findViewById(R.id.cl_empty);
        tvEmpty1 = view.findViewById(R.id.tv_empty1);
        tvEmpty2 = view.findViewById(R.id.tv_empty2);


        srlLayout.setEnableLoadMore(true);
        srlLayout.setEnableRefresh(true);

        srlLayout.setOnRefreshListener(new OnRefreshListener() {
            @Override
            public void onRefresh(@NonNull RefreshLayout refreshLayout) {
                currentPage = 1;
                if (tip.equals("全部")) {
                    getNoTagDataByPage();
                } else {
                    getTagDataByPage();
                }
            }
        });

        srlLayout.setOnLoadMoreListener(new OnLoadMoreListener() {
            @Override
            public void onLoadMore(@NonNull RefreshLayout refreshLayout) {
                if (tempAttent.getRetValue().size() == 20 && currentPage < totalPage) {
                    currentPage += 1;
                    if (tip.equals("全部")) {
                        getNoTagDataByPage();
                    } else {
                        getTagDataByPage();
                    }
                } else {
                    com.huidr.lib.commom.util.Toast.getInstance(getActivity()).show("数据加载全部", 500);
                    srlLayout.finishLoadMore();
                }
            }
        });

        rvListAtten.setAdapter(attenAdapter);
        rvListAtten.setLayoutManager(new LinearLayoutManager(getContext()));
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_general_atten, container, false);
        initView(view);
        return view;
    }

    public static GeneralAttenFragment newInstance_Fragment(String tip, int tipType) {
        GeneralAttenFragment generalAttenFragment = new GeneralAttenFragment();
        Bundle bundle = new Bundle();
        bundle.putString("tip", tip);
        bundle.putInt("tipType", tipType);
        generalAttenFragment.setArguments(bundle);
        return generalAttenFragment;
    }

    @Override
    public void setUserVisibleHint(boolean isVisibleToUser) {
        super.setUserVisibleHint(isVisibleToUser);

        if (isVisibleToUser) {

            zLoadingDialog = new ZLoadingDialog(HuidrActivityManager.getInstance().getCurrentActivity());
            zLoadingDialog.setLoadingBuilder(Z_TYPE.STAR_LOADING)//设置类型
                    .setLoadingColor(Color.BLUE)//颜色
                    .setHintText("正在加载,请稍候...").setHintTextSize(16) // 设置字体大小 dp
                    .setHintTextColor(Color.GRAY)  // 设置字体颜色
                    .setDurationTime(0.5) // 设置动画时间百分比 - 0.5倍
                    .setCanceledOnTouchOutside(false).setCancelable(false).show();

            Bundle bundle = getArguments();
            tip = bundle.getString("tip");
            tipType = bundle.getInt("tipType");

            if (tip.equals("全部")) {
                getNoTagDataByPage();
            } else {
//                getTagDataByPage();

                getDataPatients();
            }
        }
    }


    /*
     * 获取所有患者列表
     *
     * */
    public void getNoTagDataByPage() {
        ThreadPoolManager.getInstance().execute(new Runnable() {
            @Override
            public void run() {
                LogUtil.e("分页数据", currentPage + " ");
//                String path = BuildConfig.baseUrl + "patient/doctorPatientMedical/getAttentionRelationshipPatients?pageIndex=" + currentPage + "&pageSize=20";
                String path = BuildConfig.baseUrl + "patient/doctorPatientMedical/getAttentionRelationshipPatients?pageIndex=" + currentPage + "&pageSize=20";
                String result = PostAndGet.doGetHttp(path);
                tempAttent = new AttenModel();
                Log.e("患者池 关注患者--->", result);
                if (result == null || result.equals("") || result.equals("网络异常")) {
                    handler.sendEmptyMessage(3);
                } else {
                    gson = new Gson();
                    tempAttent = gson.fromJson(result, AttenModel.class);
                    if (tempAttent.getStatus() == 0) {
                        totalPage = tempAttent.getTotalPage();
                        if (currentPage == 1) {
                            handler.sendEmptyMessage(1);
                        } else {
                            handler.sendEmptyMessage(2);
                        }
                    } else {
                        handler.sendEmptyMessage(3);
                    }
                }
            }
        });
    }

    /*
     * 根据标签获取患者列表
     * */
    public void getTagDataByPage() {
        ThreadPoolManager.getInstance().execute(new Runnable() {
            @Override
            public void run() {
                JSONObject jsonObject = new JSONObject();
                jsonObject.put("tagName", tip);
                jsonObject.put("tagType", tipType);
                jsonObject.put("patients", patients);
                jsonObject.put("pageIndex", currentPage);
                jsonObject.put("pageSize", 20);
                String result = PostAndGet.doHttpPost(urlTags, jsonObject);

                tempAttent = new AttenModel();
                Log.e("患者池 关注患者--->", result);
                if (result == null || result.equals("") || result.equals("网络异常")) {
                    handler.sendEmptyMessage(3);
                } else {
                    gson = new Gson();
                    tempAttent = gson.fromJson(result, AttenModel.class);
                    if (tempAttent.getStatus() == 0) {
                        totalPage = tempAttent.getTotalPage();
                        if (currentPage == 1) {
                            handler.sendEmptyMessage(1);
                        } else {
                            handler.sendEmptyMessage(2);
                        }
                    } else {
                        handler.sendEmptyMessage(3);
                    }
                }
                Log.e("根据标签获取最近查看", result);
            }
        });
    }

    /*
     * 适配
     * */
    BaseQuickAdapter<AttenModel.RetValueBean, BaseViewHolder> attenAdapter =
            new BaseQuickAdapter<AttenModel.RetValueBean, BaseViewHolder>(R.layout.item_patient_scroll_layout) {
                @Override
                protected void convert(final BaseViewHolder helper, final AttenModel.RetValueBean item) {
                    //            头像
                    ImageView imgItemHead = helper.getView(R.id.img_item_head);
                    imgItemHead.setBackgroundResource(R.drawable.head_patient);
//            提醒
                    ImageView imgNotice = helper.getView(R.id.img_notice);
                    imgNotice.setVisibility(View.GONE);
//            姓名
                    TextView tvItemName = helper.getView(R.id.tv_item_name);
                    tvItemName.setText(item.getUserName());
//            住院号
                    TextView tvPatientNum = helper.getView(R.id.tv_patient_num);
                    tvPatientNum.setText(item.getLatelyAdmitNo());
//            日期
                    TextView tvItemDate = helper.getView(R.id.tv_item_date);
                    tvItemDate.setText(item.getLatelyVisitingDate());
//            状态
                    TextView tvItemMsg = helper.getView(R.id.tv_item_msg);
                    tvItemMsg.setText(item.getLatelyAdmissionDiagnosis());
//            模板
                    TextView tvModel = helper.getView(R.id.tv_model);
                    tvModel.setText(item.getFollowupName());

                    TextView tvRight = helper.getView(R.id.tv_scroll_right);
                    String str = "<font>取消<br>关注</font>";
                    tvRight.setText(Html.fromHtml(str));
                    tvRight.setBackgroundResource(R.drawable.shape_atten_gray);

                    tvRight.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
//                    cancelAttent(helper.getAdapterPosition(), item.getId());
                            showCoopDialog(helper.getAdapterPosition(), item.getId());
                        }
                    });


                    ConstraintLayout clItem = helper.getView(R.id.cl_item);
//            患者信息

                    clItem.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            if (System.currentTimeMillis() - lastClick > 1000) {
                                JSONObject jsonObject = new JSONObject();
                                jsonObject.put("id", item.getId());
                                SharedPreferenciesUtil.putData("psearchID", jsonObject.toJSONString());
                                SharedPreferenciesUtil.putData("followDoctorId", item.getDoctorId());

                                Intent intent1 = new Intent(getActivity(), WebActivity.class);
                                Bundle bundle = new Bundle();
                                bundle.putString("url", "patientData.html");
                                intent1.putExtras(bundle);
                                startActivity(intent1);
                                lastClick = System.currentTimeMillis();
                            }
                        }
                    });

                }

            };


    //    取消添加协同对话框
    public void showCoopDialog(final int position, final int patientId) {

        final Dialog builder = new Dialog(getContext(), R.style.jmui_default_dialog_style);
        //final Dialog builder = new Dialog(this, R.style.jmui_default_dialog_style);
        View view = LayoutInflater.from(getContext()).inflate(R.layout.dialog_content, null);

        TextView tvTitle = view.findViewById(R.id.tv_title);
        TextView tvFooter1 = view.findViewById(R.id.tv_footer1);
        TextView tvFooter2 = view.findViewById(R.id.tv_footer2);

        tvTitle.setText("是否取消关注该患者！");


//        取消
        tvFooter1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                builder.cancel();
                attenAdapter.notifyItemChanged(position);

            }
        });
//确定
        tvFooter2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                builder.cancel();
//                modifyAttent(atten, position, patientId);
                cancelAttent(position, patientId);
//                attenAdapter.notifyDataSetChanged();
            }
        });

        builder.setContentView(view);
        //builder.setCanceledOnTouchOutside(true);
        builder.show();
        Window window = builder.getWindow();
        WindowManager.LayoutParams lp = window.getAttributes();
        WindowManager windowManager = getActivity().getWindowManager();
        Display display = windowManager.getDefaultDisplay();
        lp.width = (int) (display.getWidth() * 0.7);
//        lp.height = (int) (display.getHeight() * 0.1);
        window.setAttributes(lp);
    }

    //    取消关注 从页面消失
    public void cancelAttent(final int position, final int patientId) {
        ThreadPoolManager.getInstance().execute(new Runnable() {
            @Override
            public void run() {
                String id = (String) SharedPreferenciesUtil.getData("id", "0");
                String path = BuildConfig.baseUrl + "patient/doctorPatientMedical/addRemarksAndFollow?doctorId=" + id + "&patientId=" + patientId + "&isFollow=" + false;
                String result = PostAndGet.doGetHttp(path);
                Log.e("取消关注", result);
                try {
                    JSONObject jsonObject = JSON.parseObject(result);
                    if (jsonObject.getInteger("status") != null && jsonObject.getInteger("status") == 0) {
                        Message message = new Message();
                        message.what = 4;
                        message.arg1 = position;
                        handler.sendMessage(message);
                    } else {
                        handler.sendEmptyMessage(5);
                    }
                } catch (Exception e) {
                    handler.sendEmptyMessage(5);
                }
            }
        });
    }


    Handler handler = new Handler() {
        @Override
        public void handleMessage(Message msg) {
            super.handleMessage(msg);
            switch (msg.what) {
                case 1:
                    if(zLoadingDialog!=null){
                        new Handler().postDelayed(new Runnable() {
                            @Override
                            public void run() {
                                zLoadingDialog.dismiss();
                                zLoadingDialog=null;
                            }
                        },500);
                    }
                    attenAdapter.getData().clear();
                    if (tempAttent == null || tempAttent.getRetValue() == null || tempAttent.getRetValue().size() == 0) {
                        clEmpty.setVisibility(View.VISIBLE);
                        srlLayout.setVisibility(View.GONE);

                        String tip1 = "您还暂未关注患者";
                        String tip2 = "左滑患者列表即可关注";
                        tvEmpty1.setText(tip1);
                        tvEmpty2.setText(tip2);
                    } else {
                        clEmpty.setVisibility(View.GONE);
                        srlLayout.setVisibility(View.VISIBLE);
                        attenAdapter.getData().addAll(tempAttent.getRetValue());
                        attenAdapter.notifyDataSetChanged();
                    }
                    srlLayout.finishRefresh();
                    break;

                case 2:
                    if(zLoadingDialog!=null){
                        new Handler().postDelayed(new Runnable() {
                            @Override
                            public void run() {
                                zLoadingDialog.dismiss();
                                zLoadingDialog=null;
                            }
                        },500);
                    }
                    attenAdapter.getData().addAll(tempAttent.getRetValue());
                    attenAdapter.notifyDataSetChanged();
                    srlLayout.finishLoadMore();
                    break;
                case 3:
                    if(zLoadingDialog!=null){
                        new Handler().postDelayed(new Runnable() {
                            @Override
                            public void run() {
                                zLoadingDialog.dismiss();
                                zLoadingDialog=null;
                            }
                        },500);
                    }
                    srlLayout.finishRefresh();
                    srlLayout.finishLoadMore();

                    clEmpty.setVisibility(View.VISIBLE);
                    srlLayout.setVisibility(View.GONE);

                    String tip1 = "网络错误~";
                    String tip2 = "<font color='#248cfa'><u>立即刷新<u></font>";
                    tvEmpty1.setText(tip1);
                    tvEmpty2.setText(Html.fromHtml(tip2));

                    break;
                case 4:
//                    取消成功
                    Toast.getInstance(getContext()).show("取消成功", 500);
//                    attenAdapter.getData().remove(msg.arg1);
                    attenAdapter.remove(msg.arg1);
                    Log.e("关注患者数量", attenAdapter.getData().size() + "");
                    if (attenAdapter.getData().size() == 0) {
                        clEmpty.setVisibility(View.VISIBLE);
                        srlLayout.setVisibility(View.GONE);

                        String tip3 = "您还暂未关注患者";
                        String tip4 = "左滑患者列表即可关注";
                        tvEmpty1.setText(tip3);
                        tvEmpty2.setText(tip4);
                    }
                    break;
                case 5:
//取消失败
                    Toast.getInstance(getContext()).show("取消失败", 500);
                    attenAdapter.notifyDataSetChanged();
                    break;

                case 6:
                    getTagDataByPage();
                    break;
            }
        }
    };
}
