package com.huidr.HuiDrDoctor.module.home;

/**
 * @author: Administrator
 * @date: 2019-12-18
 */
public class FirstLoginModel {

    /**
     * status : 0
     * retValue : true
     */

    private int status;
    private boolean retValue;

    public int getStatus() {
        return status;
    }

    public void setStatus(int status) {
        this.status = status;
    }

    public boolean isRetValue() {
        return retValue;
    }

    public void setRetValue(boolean retValue) {
        this.retValue = retValue;
    }
}
