package com.huidr.HuiDrDoctor.SearchResult;

import android.content.Context;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.alibaba.fastjson.JSONObject;
import com.chad.library.adapter.base.BaseQuickAdapter;
import com.chad.library.adapter.base.BaseViewHolder;
import com.google.android.flexbox.FlexDirection;
import com.google.android.flexbox.FlexWrap;
import com.google.android.flexbox.FlexboxLayoutManager;
import com.google.gson.Gson;
import com.huidr.HuiDrDoctor.activity.main.Consult.utils.PostAndGet;
import com.huidr.HuiDrDoctor.debug.BuildConfig;
import com.huidr.HuiDrDoctor.debug.R;
import com.huidr.HuiDrDoctor.module.home.DeleteHisModel;
import com.huidr.HuiDrDoctor.module.home.HisSearchModel;
import com.huidr.HuiDrDoctor.util.LogUtil;
import com.huidr.HuiDrDoctor.util.ThreadPoolManager;
import com.huidr.lib.commom.base.BaseFragment;
import com.tendcloud.tenddata.TCAgent;

import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.recyclerview.widget.RecyclerView;
import jiguang.chat.utils.oss.SharedPreferenciesUtil;

public class SearchHisFragment extends BaseFragment {


    private String pathHis = BuildConfig.baseUrl + "hospital/search/searchHis";//历史搜索
    private Gson gson;
    private HisSearchModel hisSearchModel;


    private RecyclerView rvHis;
    private ImageView imageDelete;
//    private ImageView imageEmptyHis;//
//    private TextView tvEmptyHint;//
    private ConstraintLayout clEmptyHis;//cl_empty_his;


    @Override
    protected void findView(View parent) {
        rvHis = parent.findViewById(R.id.rv_his);
        imageDelete = parent.findViewById(R.id.img_delete);
//        imageEmptyHis = parent.findViewById(R.id.image_empty_his);
//        tvEmptyHint = parent.findViewById(R.id.tv_empty_hint);
        clEmptyHis = parent.findViewById(R.id.cl_empty_his);

        rvHis.setAdapter(hisAdapter);
        FlexboxLayoutManager manager = new FlexboxLayoutManager(getContext(), FlexDirection.ROW, FlexWrap.WRAP) {
            @Override
            public boolean canScrollVertically() {
                return false;
            }
        };
        rvHis.setLayoutManager(manager);

        imageDelete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                deleteHis();
            }
        });
    }

    @Override
    protected void initData() {
        gson = new Gson();
        hisSearchModel = new HisSearchModel();
        getSearchHis();
    }

    @Override
    protected View setContentView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_search_his, container, false);
    }


    /*获取历史搜索列表*/
    public void getSearchHis() {
        ThreadPoolManager.getInstance().execute(new Runnable() {
            @Override
            public void run() {
                JSONObject jsonObject = new JSONObject();
                jsonObject.put("searchType", 7);
                String result = PostAndGet.doHttpPost(pathHis, jsonObject);
                LogUtil.e("搜索历史", result);
                if (result.equals("网络异常")) {
                    handler.sendEmptyMessage(7);
                } else {
                    hisSearchModel = gson.fromJson(result, HisSearchModel.class);
                    if (hisSearchModel.getStatus() == 0) {
                        handler.sendEmptyMessage(6);
                    } else {
                        handler.sendEmptyMessage(7);
                    }
                }
            }
        });
    }

    /*删除历史记录*/
    public void deleteHis() {
        ThreadPoolManager.getInstance().execute(new Runnable() {
            @Override
            public void run() {
                String deleteUrl = BuildConfig.baseUrl + "hospital/search/delSearchHis";
                JSONObject jsonObject = new JSONObject();
                jsonObject.put("uid", (String) SharedPreferenciesUtil.getData("id", "0"));
                jsonObject.put("searchType", 7);
                String result = PostAndGet.doHttpPost(deleteUrl, jsonObject);
                Log.e("删除历史记录", result);
                if (result.equals("网络异常")) {//删除历史记录失败
                    handler.sendEmptyMessage(13);
                } else {//删除历史记录成功
                    DeleteHisModel simpleResultModel = gson.fromJson(result, DeleteHisModel.class);
                    if (simpleResultModel.getStatus() == 0) {
                        handler.sendEmptyMessage(12);
                    } else {
                        handler.sendEmptyMessage(13);
                    }
                }
            }
        });
    }


    private Handler handler = new Handler() {
        @Override
        public void handleMessage(Message msg) {
            super.handleMessage(msg);
            switch (msg.what) {
                case 6:
                    if (hisSearchModel.getRetValue().size() == 0) {
                        imageDelete.setVisibility(View.GONE);
                        showEmpty();
                    } else {
                        imageDelete.setVisibility(View.VISIBLE);
                        hisAdapter.addData(hisSearchModel.getRetValue());
                        hisAdapter.notifyDataSetChanged();
                        showList();
                    }
                    break;
                case 7:
                    imageDelete.setVisibility(View.GONE);
                    showEmpty();
                    break;
                case 12:
                    getSearchHis();
                    break;
                case 13:
                    Toast.makeText(getContext(), "删除失败，请稍后重试", Toast.LENGTH_SHORT).show();
                    break;
            }
        }
    };

    public void showEmpty() {
//        imageEmptyHis.setVisibility(View.VISIBLE);
//        tvEmptyHint.setVisibility(View.VISIBLE);
        clEmptyHis.setVisibility(View.VISIBLE);
        rvHis.setVisibility(View.GONE);
    }

    public void showList() {
//        imageEmptyHis.setVisibility(View.GONE);
//        tvEmptyHint.setVisibility(View.GONE);
        clEmptyHis.setVisibility(View.GONE);
        rvHis.setVisibility(View.VISIBLE);
    }


    /*
     * 历史搜索 适配
     * */
    private BaseQuickAdapter<HisSearchModel.RetValueBean, BaseViewHolder> hisAdapter =
            new BaseQuickAdapter<HisSearchModel.RetValueBean, BaseViewHolder>(R.layout.item_tip) {
        @Override
        protected void convert(BaseViewHolder helper, final HisSearchModel.RetValueBean item) {
            TextView tvTip = helper.getView(R.id.tv_tip);
            tvTip.setText(item.getSearchContent());

            tvTip.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
//                    .setText(item.getSearchContent());
////                    showSearch = true;
//                    doKeySearch();
                    TCAgent.onEvent(getContext(), "历史搜索的点击次数", "历史搜索的点击次数");
                    callBackValue.sendMessageValue(item.getSearchContent());
                }
            });
        }
    };

    public interface CallBackValue {
        public void sendMessageValue(String value);
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        callBackValue = (CallBackValue) getContext();
    }

    CallBackValue callBackValue;
}
