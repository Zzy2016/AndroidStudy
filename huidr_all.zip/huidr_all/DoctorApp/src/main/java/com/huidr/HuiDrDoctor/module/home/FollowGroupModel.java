package com.huidr.HuiDrDoctor.module.home;

import java.util.List;

/**
 * @author: Administrator
 * @date: 2019-12-25
 */
public class FollowGroupModel {

    /**
     * status : 0
     * page : 1
     * totalPage : 1
     * retValue : [{"groupId":10,"groupName":"随访组10","patientNum":0,"createTime":"2019-12-12 10:26:04"},{"groupId":25,"groupName":"哈哈","patientNum":5,"createTime":"2019-12-24 15:46:38"},{"groupId":26,"groupName":"哈哈","patientNum":5,"createTime":"2019-12-24 15:46:43"},{"groupId":27,"groupName":"哈哈","patientNum":5,"createTime":"2019-12-24 15:46:43"},{"groupId":28,"groupName":"哈哈","patientNum":5,"createTime":"2019-12-24 15:46:43"},{"groupId":29,"groupName":"哈哈","patientNum":5,"createTime":"2019-12-24 15:46:49"},{"groupId":30,"groupName":"肝外科随访组","patientNum":34,"createTime":"2019-12-24 16:22:19"},{"groupId":33,"groupName":"楼天空飘来飘去","patientNum":3,"createTime":"2019-12-24 17:02:24"},{"groupId":34,"groupName":"测的得得得","patientNum":6,"createTime":"2019-12-24 17:03:40"},{"groupId":35,"groupName":"来了来了来了","patientNum":4,"createTime":"2019-12-24 17:08:20"}]
     */

    private int status;
    private int page;
    private int totalPage;
    private List<RetValueBean> retValue;

    public int getStatus() {
        return status;
    }

    public void setStatus(int status) {
        this.status = status;
    }

    public int getPage() {
        return page;
    }

    public void setPage(int page) {
        this.page = page;
    }

    public int getTotalPage() {
        return totalPage;
    }

    public void setTotalPage(int totalPage) {
        this.totalPage = totalPage;
    }

    public List<RetValueBean> getRetValue() {
        return retValue;
    }

    public void setRetValue(List<RetValueBean> retValue) {
        this.retValue = retValue;
    }

    public static class RetValueBean {
        /**
         * groupId : 10
         * groupName : 随访组10
         * patientNum : 0
         * createTime : 2019-12-12 10:26:04
         */

        private int groupId;
        private String groupName;
        private int patientNum;
        private String createTime;
        private String groupImage;

        public String getGroupImage() {
            return groupImage;
        }

        public void setGroupImage(String groupImage) {
            this.groupImage = groupImage;
        }

        public int getGroupId() {
            return groupId;
        }

        public void setGroupId(int groupId) {
            this.groupId = groupId;
        }

        public String getGroupName() {
            return groupName;
        }

        public void setGroupName(String groupName) {
            this.groupName = groupName;
        }

        public int getPatientNum() {
            return patientNum;
        }

        public void setPatientNum(int patientNum) {
            this.patientNum = patientNum;
        }

        public String getCreateTime() {
            return createTime;
        }

        public void setCreateTime(String createTime) {
            this.createTime = createTime;
        }
    }
}
