package com.huidr.HuiDrDoctor.SearchResult;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import androidx.annotation.NonNull;

import android.text.Html;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.alibaba.fastjson.JSONObject;
import com.chad.library.adapter.base.BaseQuickAdapter;
import com.chad.library.adapter.base.BaseViewHolder;
import com.google.android.material.tabs.TabLayout;
import com.google.gson.Gson;
import com.guanaj.easyswipemenulibrary.EasySwipeMenuLayout;
import com.huidr.HuiDrDoctor.activity.WebActivity;
import com.huidr.HuiDrDoctor.activity.main.Consult.utils.PostAndGet;
import com.huidr.HuiDrDoctor.debug.BuildConfig;
import com.huidr.HuiDrDoctor.debug.R;
import com.huidr.HuiDrDoctor.module.home.PatientSearchModel;
import com.huidr.HuiDrDoctor.util.LogUtil;
import com.huidr.HuiDrDoctor.util.ThreadPoolManager;
import com.huidr.lib.commom.base.BaseFragment;
import com.scwang.smartrefresh.layout.SmartRefreshLayout;
import com.scwang.smartrefresh.layout.api.RefreshLayout;
import com.scwang.smartrefresh.layout.listener.OnLoadMoreListener;
import com.scwang.smartrefresh.layout.listener.OnRefreshListener;

import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import jiguang.chat.utils.oss.OssService;
import jiguang.chat.utils.oss.SharedPreferenciesUtil;

public class PatientSearchFragment extends BaseFragment {

    View footerView;


    PatientInterface patientInterface;
    OssService ossService;
    String key;
    //    MessageSearchModel messageSearchModel;
    Gson gson;
    long lastClick = 0;

    SmartRefreshLayout srlPatientSearch;//srl_patient_search
    RecyclerView rvPatientSearch;//rv_patient_search
    ConstraintLayout clPatientEmpty;//cl_patient_empty
    TextView tvEmpty1, tvEmpty2;
    Button btnLink;
    boolean isFollow = false;//是否开启随访报到
    int currentPage = 1;
    int totalPage = 1;
    TabLayout tabLayout;
    String path = BuildConfig.baseUrl + "patient/doctorPatientMedical/getFollowUpPoolList"; //患者搜索
    PatientSearchModel patientSearchModel;

    @Override
    protected void findView(final View parent) {
        srlPatientSearch = parent.findViewById(R.id.srl_patient_search);
        rvPatientSearch = parent.findViewById(R.id.rv_patient_search);
        clPatientEmpty = parent.findViewById(R.id.cl_patient_empty);
        tvEmpty1 = parent.findViewById(R.id.tv_empty1);
        tvEmpty2 = parent.findViewById(R.id.tv_empty2);
        btnLink = parent.findViewById(R.id.btn_link);

        rvPatientSearch.setAdapter(searchAdapter);
        rvPatientSearch.setLayoutManager(new LinearLayoutManager(getContext()));

        srlPatientSearch.setEnableRefresh(true);
        srlPatientSearch.setEnableLoadMore(true);

        srlPatientSearch.setOnRefreshListener(new OnRefreshListener() {
            @Override
            public void onRefresh(@NonNull RefreshLayout refreshLayout) {
                currentPage = 1;
                getPatientList();
            }
        });

        srlPatientSearch.setOnLoadMoreListener(new OnLoadMoreListener() {
            @Override
            public void onLoadMore(@NonNull RefreshLayout refreshLayout) {
                if (currentPage < totalPage && patientSearchModel.getRetValue().size() == 20) {
                    currentPage += 1;
                    getPatientList();
                } else {
                    Toast.makeText(getContext(), "数据加载全部", Toast.LENGTH_SHORT).show();
                    srlPatientSearch.finishLoadMore();
                }
            }
        });


        /*跳转患者池全部患者*/
        footerView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                patientInterface.doFinishPatient();
            }
        });

        /*跳转 开启 我的随访报到*/
        btnLink.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                patientInterface.doAddFollow();
            }
        });

        tabLayout = parent.findViewById(R.id.tab);
        tabLayout.addTab(tabLayout.newTab().setText("患者"));
        tabLayout.addTab(tabLayout.newTab().setText("医生"));
        tabLayout.getTabAt(0).select();

        tabLayout.setOnTabSelectedListener(new TabLayout.OnTabSelectedListener() {
            @Override
            public void onTabSelected(TabLayout.Tab tab) {
                if (tab.getText().toString().equals("医生")) {
                    patientInterface.switchDoctor();
                }
            }

            @Override
            public void onTabUnselected(TabLayout.Tab tab) {

            }

            @Override
            public void onTabReselected(TabLayout.Tab tab) {

            }
        });


//
    }

    public void getPatientList() {
        ThreadPoolManager.getInstance().execute(new Runnable() {
            @Override
            public void run() {
                String result = PostAndGet.doGetHttp(path + "?pageSize=20&pageIndex=" + currentPage + "&userName=" + key);
                LogUtil.e("搜索", result);
                if (result.equals("网络异常")) {
                    handler.sendEmptyMessage(3);
                } else {
                    patientSearchModel = gson.fromJson(result, PatientSearchModel.class);
                    if (patientSearchModel.getStatus() == 0) {
                        totalPage = patientSearchModel.getTotalPage();
                        if (currentPage == 1) {
                            handler.sendEmptyMessage(1);
                        } else {
                            handler.sendEmptyMessage(2);
                        }
                    } else {
                        handler.sendEmptyMessage(3);
                    }
                }
            }
        });

    }

    Handler handler = new Handler() {
        @Override
        public void handleMessage(Message msg) {
            super.handleMessage(msg);
            switch (msg.what) {
                case 1:
                    searchAdapter.getData().clear();
                    if (patientSearchModel.getRetValue().size() == 0) {
                        showEmpty();
                    } else {
                        searchAdapter.getData().addAll(patientSearchModel.getRetValue());
                        if (searchAdapter.getFooterLayoutCount() == 0) {
                            searchAdapter.addFooterView(footerView);
                        }
                        searchAdapter.notifyDataSetChanged();

                    }
                    srlPatientSearch.finishRefresh();
                    break;
                case 2:
                    searchAdapter.getData().addAll(patientSearchModel.getRetValue());
                    searchAdapter.notifyDataSetChanged();
                    srlPatientSearch.finishLoadMore();
                    break;
                case 3:

                    srlPatientSearch.finishRefresh();
                    srlPatientSearch.finishLoadMore();
                    tvEmpty1.setText(Html.fromHtml("<font color='#248cfa'>网络错误</font>"));
                    tvEmpty2.setVisibility(View.GONE);
                    btnLink.setVisibility(View.GONE);
                    break;
            }
        }
    };

    public void showEmpty() {
        srlPatientSearch.setVisibility(View.GONE);
        clPatientEmpty.setVisibility(View.VISIBLE);
        if (!isFollow) {  //随访报到关闭
            tvEmpty1.setText("暂未搜索到该患者,您可以去");
            tvEmpty2.setText(Html.fromHtml("开启患者<font color='#248cfa'>随访报到</font>"));
            tvEmpty2.setVisibility(View.VISIBLE);
            btnLink.setVisibility(View.VISIBLE);
        } else {   //随访报到开启
            tvEmpty1.setText("暂未搜索搜索到该患者~");
            tvEmpty2.setVisibility(View.GONE);
            btnLink.setVisibility(View.GONE);
        }
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        patientInterface = (PatientInterface) context;
        isFollow = getArguments().getBoolean("isFollow");
        key = getArguments().getString("key");
        Log.e("搜索关键字", isFollow + "   " + key);
    }

    @Override
    protected void initData() {
        ossService = new OssService(getContext());
//        messageSearchModel = new MessageSearchModel();
        patientSearchModel = new PatientSearchModel();
        gson = new Gson();

        getPatientList();
    }

    @Override
    protected View setContentView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        footerView = LayoutInflater.from(getContext()).inflate(R.layout.footer_patient, container, false);
        return inflater.inflate(R.layout.fragment_patient_search, container, false);
    }


    public interface PatientInterface {
        void doFinishPatient();

        void doAddFollow();

        void switchDoctor();
    }


    private BaseQuickAdapter<PatientSearchModel.RetValueBean, BaseViewHolder> searchAdapter = new BaseQuickAdapter<PatientSearchModel.RetValueBean, BaseViewHolder>(R.layout.item_scroll_layout) {
        @Override
        protected void convert(final BaseViewHolder helper, final PatientSearchModel.RetValueBean item) {


            EasySwipeMenuLayout esml = helper.getView(R.id.esml_item);
            esml.setCanLeftSwipe(false);
            esml.setCanRightSwipe(false);

            ImageView imgItemHead = helper.getView(R.id.img_item_head);
            setPatientImage(imgItemHead, item.getBindUserRelationship(), item.getUserSex());
            ImageView imgNotice = helper.getView(R.id.img_notice);
            imgNotice.setVisibility(View.GONE);
            ImageView imageItemGender = helper.getView(R.id.image_item_gender);
            imageItemGender.setVisibility(View.VISIBLE);
            if (item.getUserSex() == 1) {
                imageItemGender.setBackgroundResource(R.drawable.gender_man);
            } else if (item.getUserSex() == 2) {
                imageItemGender.setBackgroundResource(R.drawable.gender_w);
            } else {

            }

            TextView tvItemName = helper.getView(R.id.tv_item_name);
            tvItemName.setText(item.getUserName());
            TextView tvItemAge = helper.getView(R.id.tv_item_age);
            tvItemAge.setText(item.getLatelyAdmitNo());
            TextView tvItemState = helper.getView(R.id.tv_item_state);
            TextView tvItemDate = helper.getView(R.id.tv_item_date);
            tvItemDate.setText(item.getLatelyVisitingDate());
            TextView tvItemMsg = helper.getView(R.id.tv_item_msg);

            tvItemMsg.setText(item.getLatelyAdmissionDiagnosis());

            TextView tvItemMode = helper.getView(R.id.tv_item_model);
            tvItemMode.setText(item.getFollowupName());

            TextView tvScrollRight = helper.getView(R.id.tv_scroll_right);

            Button btnApply = helper.getView(R.id.btn_apply);
            btnApply.setVisibility(View.GONE);

            String tip = "";
            if (item.isIsFollow()) {
                tip = "<font>已<br>关注<font>";
                tvScrollRight.setBackgroundResource(R.drawable.shape_atten_gray);
            } else {
                tip = "<font>关注<br>患者<font>";
            }
//            tvScrollRight.setText(Html.fromHtml(tip));
//            tvScrollRight.setOnClickListener(new View.OnClickListener() {
//                @Override
//                public void onClick(View v) {
//                    if (item.isIsFollow()) { //已经关注 取消关注
////                        modifyAttent(false, helper.getAdapterPosition(), item.getId());
//                        searchAdapter.notifyDataSetChanged();
//                        Toast.makeText(getContext(), "该患者已关注", Toast.LENGTH_SHORT).show();
//                    } else {  //未关注 添加关注
////                        modifyAttent(true, helper.getAdapterPosition(), item.getId());
//                        showCoopDialog(true, helper.getAdapterPosition(), item.getId());
//                    }
//                }
//            });

            ConstraintLayout clItem = helper.getView(R.id.cl_item);
            clItem.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (System.currentTimeMillis() - lastClick > 1000) {
                        JSONObject jsonObject = new JSONObject();
                        jsonObject.put("id", item.getId());
                        SharedPreferenciesUtil.putData("psearchID", jsonObject.toJSONString());
                        SharedPreferenciesUtil.putData("followDoctorId", item.getDoctorId());

                        Intent intent1 = new Intent(getContext(), WebActivity.class);
                        Bundle bundle = new Bundle();
                        bundle.putString("url", "patientData.html");
                        intent1.putExtras(bundle);
                        startActivity(intent1);
                        lastClick = System.currentTimeMillis();
                    }
                }
            });

        }
    };

    public void setPatientImage(ImageView image, String ship, int sex) {
        if (ship == null) {
            image.setBackgroundResource(R.drawable.head_patient);
            return;
        }
        switch (ship) {
            case "本人":
                if (sex == 1) {
                    image.setBackgroundResource(R.drawable.my_him);
                } else {
                    image.setBackgroundResource(R.drawable.my_her);
                }
                break;
            case "丈夫":
                image.setBackgroundResource(R.drawable.husband);
                break;
            case "妻子":
                image.setBackgroundResource(R.drawable.wife);
                break;
            case "爸爸":
                image.setBackgroundResource(R.drawable.papa);
                break;
            case "妈妈":
                image.setBackgroundResource(R.drawable.mama);
                break;
            case "儿子":
                image.setBackgroundResource(R.drawable.son);
                break;
            case "女儿":
                image.setBackgroundResource(R.drawable.daughter);
                break;
//            case "其他":
//                image.setBackgroundResource(R.drawable.head_patient);
//                break;
            default:
                image.setBackgroundResource(R.drawable.head_patient);
                break;
        }
    }




}
