package com.huidr.HuiDrDoctor.activity.main.Consult.utils;

import android.util.Log;

import java.io.IOException;

import okhttp3.Interceptor;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class UtilState {
    public static String AppKey = "bd6ad187437010acb0639f85";
    public static String masterSecret = "54d75fb65d926356ff96af33";
    public static String base64_auth_string = Base64Utils.getBase64(AppKey + ":" + masterSecret);
    public static OkHttpClient.Builder httpClient;

    /*获取请求头*/
    public static void headers() {
        httpClient = new OkHttpClient.Builder();
        httpClient.addInterceptor(new Interceptor() {

            public okhttp3.Response intercept(Chain chain) throws IOException {
                Request request = chain.request().newBuilder().addHeader("Content-Type", "application/json; charset=utf-8").addHeader("Authorization", "Basic " + base64_auth_string).build();
                Log.d("onrequest", "request:" + request.toString());
                Log.d("onrequestHeader", "request headers:" + request.headers().toString());
                return chain.proceed(request);
            }
        });
    }

    /*判断好友在线状态*/
    public static void isFriendState(String userName, Callback<UserStateBean> callback) {
        String JPUSH_ROOT = "https://api.im.jpush.cn/";
        headers();
        Log.e("base64_auth_string", base64_auth_string);
        OkHttpClient client=httpClient.build();
        Retrofit retrofit = new Retrofit.Builder()
                .addConverterFactory(GsonConverterFactory.create())
                .baseUrl(JPUSH_ROOT)
                .client(client)
                .build();
        Api aPi = retrofit.create(Api.class);
        Call<UserStateBean> call = aPi.isFriendState(
                userName);
        call.enqueue(callback);
    }


}
