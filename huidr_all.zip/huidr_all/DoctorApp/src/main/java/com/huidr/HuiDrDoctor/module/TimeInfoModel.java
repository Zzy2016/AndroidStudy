package com.huidr.HuiDrDoctor.module;

import java.util.List;

/**
 * @author: Administrator
 * @date: 2019-12-31
 */
public class TimeInfoModel {

    /**
     * status : 0
     * page : 1
     * totalPage : 0
     * retValue : []
     */

    private int status;
    private int page;
    private int totalPage;
    private List<?> retValue;

    public int getStatus() {
        return status;
    }

    public void setStatus(int status) {
        this.status = status;
    }

    public int getPage() {
        return page;
    }

    public void setPage(int page) {
        this.page = page;
    }

    public int getTotalPage() {
        return totalPage;
    }

    public void setTotalPage(int totalPage) {
        this.totalPage = totalPage;
    }

    public List<?> getRetValue() {
        return retValue;
    }

    public void setRetValue(List<?> retValue) {
        this.retValue = retValue;
    }
}
