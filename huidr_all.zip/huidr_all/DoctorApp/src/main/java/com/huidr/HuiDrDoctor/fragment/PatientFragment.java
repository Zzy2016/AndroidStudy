package com.huidr.HuiDrDoctor.fragment;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.RadioGroup;

import com.google.gson.Gson;
import com.huidr.HuiDrDoctor.SearchResult.HomeSearchActivity;
import com.huidr.HuiDrDoctor.activity.WebActivity;
import com.huidr.HuiDrDoctor.activity.main.Consult.utils.PostAndGet;
import com.huidr.HuiDrDoctor.customview.ScrollPageView;
import com.huidr.HuiDrDoctor.debug.BuildConfig;
import com.huidr.HuiDrDoctor.debug.R;
import com.huidr.HuiDrDoctor.follow_fragment.AllPatientFragment;
import com.huidr.HuiDrDoctor.follow_fragment.AttentionFragment;
import com.huidr.HuiDrDoctor.follow_fragment.InhosFragment;
import com.huidr.HuiDrDoctor.follow_fragment.RecentFragment;
import com.huidr.HuiDrDoctor.follow_fragment.VisitFragment;
import com.huidr.HuiDrDoctor.module.H5UserInfo;
import com.huidr.HuiDrDoctor.module.home.SimpleResultModel;
import com.huidr.HuiDrDoctor.module.home.TipModel;
import com.huidr.HuiDrDoctor.util.ModifyDrawable;
import com.huidr.HuiDrDoctor.util.MulityClickUtils;
import com.huidr.HuiDrDoctor.util.ThreadPoolManager;
import com.huidr.lib.commom.base.BaseFragment;
import com.tendcloud.tenddata.TCAgent;

import java.util.ArrayList;
import java.util.List;

import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentPagerAdapter;
import jiguang.chat.utils.oss.SharedPreferenciesUtil;


/**
 * 患者池
 * 在院患者 patientData_inHos.html
 * 随访列表 followPatientList.html?id=52366
 * 关注患者 patientData.html
 * 全部患者 patientData.html
 */
public class PatientFragment extends BaseFragment implements View.OnClickListener {

    private ImageView imgSearch;
    private RadioButton radio1, radio2, radio3, radio4, radio5;
    private RadioGroup radioGroup;

    private H5UserInfo loginResult;

    private Gson gson;

    private ScrollPageView viewPagerFragments;//
    private PatientAdapter patientAdapter;

    private List<Fragment> fragmentList;//

    private List<TipModel.RetValueBean> tips;//标签


    int patientIndex = 0;

    String url = BuildConfig.baseUrl + "patient/doctorPatientMedical/getTags";//获取标签接口


    RecentFragment recentFragment;
    InhosFragment inhosFragment;
    VisitFragment visitFragment;
    AttentionFragment attentionFragment;
    AllPatientFragment allPatientFragment;

    Bundle bundle = new Bundle();
    String[] tipsArray;//标签数组
    int[] tipsTypeArray;//标签类型数组

    int lastIndex = 0;
    String tipName;

    @Override
    protected void initData() {
//        String user = (String) SharedPreferenciesUtil.getData("user_doctor_info", "");
        gson = new Gson();

//        if (!user.equals("")) {
//            loginResult = gson.fromJson(user, H5UserInfo.class);
//            followIsOpen = loginResult.getValue().isIsFollowup();
//        }

//        getDoctotTag();//获取标签

        recentFragment = new RecentFragment();
        inhosFragment = new InhosFragment();
        visitFragment = new VisitFragment();
        attentionFragment = new AttentionFragment();
        allPatientFragment = new AllPatientFragment();

        fragmentList = new ArrayList<>();

        fragmentList.add(allPatientFragment);
        fragmentList.add(visitFragment);
        fragmentList.add(inhosFragment);
        fragmentList.add(attentionFragment);
        fragmentList.add(recentFragment);



    }


    @Override
    protected View setContentView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_patient, container, false);
        return view;
    }


    /*
     * 寻找组件 设置监听
     * */
    @Override
    protected void findView(View parent) {
        initTitle(parent);
        imgSearch = parent.findViewById(R.id.image_search);
        imgSearch.setOnClickListener(this);
        viewPagerFragments = parent.findViewById(R.id.viewpager_fragment);
        patientAdapter = new PatientAdapter(getChildFragmentManager(), fragmentList);

        viewPagerFragments.setAdapter(patientAdapter);
//        viewPagerFragments.setOffscreenPageLimit(4);
        initPage();
    }


    class PatientAdapter extends FragmentPagerAdapter {

        List<Fragment> list;

        public PatientAdapter(FragmentManager fm, List<Fragment> list) {
            super(fm);
            this.list = list;
        }


        @Override
        public Fragment getItem(int i) {
            return list.get(i);
        }

        @Override
        public int getCount() {
            return list.size();
        }


    }


    //    开启关闭随访功能
    public void modifyFollowUp(final boolean isOpen) {
        ThreadPoolManager.getInstance().execute(new Runnable() {
            @Override
            public void run() {
                String path = BuildConfig.baseUrl + "hospital/doctorUser/operationFollowup?isFollowup=" + isOpen;
                String result = PostAndGet.doGetHttp(path);

                if (result.equals("网络异常")) {

                } else {
                    SimpleResultModel simpleResultModel = gson.fromJson(result, SimpleResultModel.class);
                    if (simpleResultModel.getStatus() == 0) {
                        if (isOpen) {
                            handler.sendEmptyMessage(1);
                        } else {
                            handler.sendEmptyMessage(2);
                        }

                    }
                }
            }
        });
    }

    /*
     * 点击事件
     * */
    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.image_search:

                if (MulityClickUtils.isFastClick()) {
//                    Intent intent = new Intent(getContext(), PatientSearchActivity.class);
                    Intent intent = new Intent(getContext(), HomeSearchActivity.class);
                    startActivity(intent);
                }
                break;

            case R.id.img_tip:

                if (MulityClickUtils.isFastClick()) {
                    Intent intent = new Intent(getContext(), WebActivity.class);
                    Bundle bundle = new Bundle();
                    bundle.putString("url", "patientData_setTagsNew.html");
                    intent.putExtras(bundle);
                    startActivity(intent);
                }

                break;
        }
    }


    private Handler handler = new Handler() {
        @Override
        public void handleMessage(Message msg) {
            super.handleMessage(msg);
            switch (msg.what) {
                case 1:
                    com.huidr.lib.commom.util.Toast.getInstance(getContext()).show("开启随访报到成功", 500);
                    break;
                case 2:
                    com.huidr.lib.commom.util.Toast.getInstance(getContext()).show("关闭随访报到成功", 500);
                    break;
//                    获取标签成功
                case 3:

                    tipsArray = new String[tips.size() + 1];
                    tipsTypeArray = new int[tips.size() + 1];
                    for (int j = 0; j < tipsArray.length; j++) {
                        if (j == 0) {
                            tipsArray[j] = "全部";
                            tipsTypeArray[j] = 500;
                        } else {
                            tipName = tips.get(j - 1).getTagName();
                            lastIndex = tipName.lastIndexOf(")");
                            tipsArray[j] = tipName.substring((lastIndex + 1));
                            tipsTypeArray[j] = tips.get(j - 1).getTagType();
                        }
                    }

                    bundle = new Bundle();
                    bundle.putStringArray("tip", tipsArray);
                    bundle.putIntArray("tipType", tipsTypeArray);

                    recentFragment.setArguments(bundle);
                    inhosFragment.setArguments(bundle);
                    visitFragment.setArguments(bundle);
                    attentionFragment.setArguments(bundle);
                    allPatientFragment.setArguments(bundle);

                    fragmentList.add(allPatientFragment);
                    fragmentList.add(visitFragment);
                    fragmentList.add(inhosFragment);
                    fragmentList.add(attentionFragment);
                    fragmentList.add(recentFragment);

                    viewPagerFragments.setAdapter(patientAdapter);
                    viewPagerFragments.setOffscreenPageLimit(4);

                    initPage();

                    break;
//                    获取标签失败
                case 4:

                    tipsArray = new String[]{"全部"};
                    bundle = new Bundle();
                    bundle.putStringArray("tip", tipsArray);

                    recentFragment.setArguments(bundle);
                    inhosFragment.setArguments(bundle);
                    visitFragment.setArguments(bundle);
                    attentionFragment.setArguments(bundle);
                    allPatientFragment.setArguments(bundle);

                    fragmentList.add(allPatientFragment);
                    fragmentList.add(visitFragment);
                    fragmentList.add(inhosFragment);
                    fragmentList.add(attentionFragment);
                    fragmentList.add(recentFragment);

                    viewPagerFragments.setAdapter(patientAdapter);
                    viewPagerFragments.setOffscreenPageLimit(2);
                    break;
            }
        }
    };


    /* //
          列表选择  titleView
     */
    public void initTitle(View parent) {

        radioGroup = parent.findViewById(R.id.radio_group);


        radio1 = parent.findViewById(R.id.radio1);
        radio2 = parent.findViewById(R.id.radio2);
        radio3 = parent.findViewById(R.id.radio3);
        radio4 = parent.findViewById(R.id.radio4);
        radio5 = parent.findViewById(R.id.radio5);

        ModifyDrawable.reSize(radio1, 90);
        ModifyDrawable.reSize(radio2, 90);
        ModifyDrawable.reSize(radio3, 90);
        ModifyDrawable.reSize(radio4, 90);
        ModifyDrawable.reSize(radio5, 90);


        radioGroup.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {
                switch (checkedId) {
                    case R.id.radio1:
                        viewPagerFragments.setCurrentItem(0, false);
                        patientIndex = 0;

                        break;
                    case R.id.radio2:
                        viewPagerFragments.setCurrentItem(1, false);
                        patientIndex = 1;

                        break;
                    case R.id.radio3:
                        viewPagerFragments.setCurrentItem(2, false);
                        patientIndex = 2;

                        break;
                    case R.id.radio4:
                        viewPagerFragments.setCurrentItem(3, false);
                        patientIndex = 3;

                        break;
                    case R.id.radio5:
                        viewPagerFragments.setCurrentItem(4, false);
                        patientIndex = 4;

                        break;
                }
            }
        });
    }


    //    初始化页面
    public void initPage() {
        patientIndex = (int) SharedPreferenciesUtil.getData("patientIndex", 4);
        Log.e("患者池", patientIndex + "");
        switch (patientIndex) {
            case 0:
                radio1.setChecked(true);
                TCAgent.onEvent(getContext(), "患者池最近查看的按钮点击次数", "患者池最近查看的按钮点击次数");
                viewPagerFragments.setCurrentItem(0, false);
                patientIndex = 0;

                break;
            case 1:
                radio2.setChecked(true);
                TCAgent.onEvent(getContext(), "患者池住院患者的按钮点击次数", "患者池住院患者的按钮点击次数");
                viewPagerFragments.setCurrentItem(1, false);
                patientIndex = 1;

                break;
            case 2:
                radio3.setChecked(true);
                TCAgent.onEvent(getContext(), "患者池随访患者的按钮点击次数", "患者池随访患者的按钮点击次数");
                viewPagerFragments.setCurrentItem(2, false);
                patientIndex = 2;

                break;
            case 3:
                radio4.setChecked(true);
                TCAgent.onEvent(getContext(), "患者池关注患者的按钮点击次数", "患者池关注患者的按钮点击次数");
                viewPagerFragments.setCurrentItem(3, false);
                patientIndex = 3;

                break;
            case 4:
                radio5.setChecked(true);
                TCAgent.onEvent(getContext(), "患者池全部患者的按钮点击次数", "患者池全部患者的按钮点击次数");
                patientIndex = 4;
                viewPagerFragments.setCurrentItem(4, false);
                break;
        }
    }





    @Override
    public void onStop() {
        super.onStop();
        SharedPreferenciesUtil.putData("patientIndex", patientIndex);
    }
}
