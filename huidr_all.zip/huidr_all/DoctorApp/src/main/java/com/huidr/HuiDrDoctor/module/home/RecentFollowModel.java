package com.huidr.HuiDrDoctor.module.home;

import java.util.List;

/**
 * @author: Administrator
 * @date: 2019-11-28
 */
public class RecentFollowModel {


    /**
     * status : 0
     * page : 1
     * totalPage : 1
     * retValue : [{"id":45846,"userName":"沈铭昌","userSex":1,"latelyAdmitNo":"692170","latelyBed":"13","bindUserRelationship":"本人","latelyAdmissionDiagnosis":"结直肠恶性肿瘤伴肝转移,肺转移性肿瘤,高血压,前列腺增生","latelyDischargeDiagnosis":"结直肠恶性肿瘤伴肝转移,肺转移性肿瘤(IV期),高血压,前列腺增生","latelyDischargeTime":"2019-04-24","latelyVisitingDate":"2019-04-23","doctorId":100137,"bindUid":141024,"followupName":"肝切除模板","isFollow":false},{"id":62444,"userName":"沈凤贞","userSex":2,"latelyAdmitNo":"1190998","latelyBed":"119","latelyAdmissionDiagnosis":"肝恶性肿瘤(综合治疗)","latelyDischargeTime":"2019-04-16","latelyVisitingDate":"2019-04-15","doctorId":100137,"followupName":"肝切除模板","isFollow":true},{"id":52366,"userName":"付丹","userSex":1,"latelyAdmitNo":"992499","latelyBed":"38","latelyAdmissionDiagnosis":"肝内胆管癌","latelyDischargeDiagnosis":"肝癌术后复发","latelyDischargeTime":"2019-04-20","latelyVisitingDate":"2019-04-14","doctorId":100137,"followupName":"肝切除模板","isFollow":false},{"id":47726,"userName":"陈文宝","userSex":1,"latelyAdmitNo":"1109621","latelyBed":"106","latelyAdmissionDiagnosis":"肝移植状态","latelyVisitingDate":"2019-04-19","doctorId":100137,"followupName":"肝切除模板","isFollow":false},{"id":51849,"userName":"叶永琴","userSex":2,"latelyAdmitNo":"990430","latelyBed":"41","latelyAdmissionDiagnosis":"肝恶性肿瘤(综合治疗)","latelyDischargeDiagnosis":"肝癌术后","latelyDischargeTime":"2017-01-11","latelyVisitingDate":"2019-03-04","doctorId":100137,"followupName":"肝切除模板","isFollow":true},{"id":51748,"userName":"杨正平","userSex":1,"latelyAdmitNo":"1007446","latelyBed":"32","latelyAdmissionDiagnosis":"肝占位性病变","latelyDischargeDiagnosis":"肝恶性肿瘤","latelyDischargeTime":"2016-12-13","latelyVisitingDate":"2019-04-04","doctorId":100137,"followupName":"肝切除模板","isFollow":false},{"id":51521,"userName":"许荣庆","userSex":1,"latelyAdmitNo":"606209","latelyBed":"32","latelyAdmissionDiagnosis":"肝胆管炎","latelyDischargeDiagnosis":"肝胆管炎","latelyDischargeTime":"2016-10-12","latelyVisitingDate":"2018-09-28","doctorId":100137,"followupName":"肝切除模板","isFollow":false},{"id":51509,"userName":"黄玲发","userSex":1,"latelyAdmitNo":"1126584","latelyBed":"30","latelyAdmissionDiagnosis":"肝细胞癌,乙肝后肝硬化","latelyDischargeDiagnosis":"肝细胞癌，乙肝后肝硬化","latelyDischargeTime":"2019-01-31","latelyVisitingDate":"2019-04-03","doctorId":100137,"followupName":"肝切除模板","isFollow":false},{"id":51505,"userName":"乔正荣","userSex":1,"latelyAdmitNo":"1001132","latelyBed":"35","latelyAdmissionDiagnosis":"肝占位性病变","latelyDischargeDiagnosis":"肝血管瘤","latelyDischargeTime":"2016-11-15","latelyVisitingDate":"2016-12-12","doctorId":100137,"followupName":"肝切除模板","isFollow":false},{"id":85980,"userName":"余大壮","userSex":1,"userIcon":"141272/patient/1574061067019482.png","bindUserRelationship":"本人(他)","doctorId":100137,"bindUid":141272,"isFollow":true},{"id":62074,"userName":"徐卉","userSex":2,"bindUserRelationship":"本人","doctorId":100137,"bindUid":100140,"isFollow":false},{"id":45887,"userName":"丁和荣","userSex":1,"latelyAdmitNo":"1161753","latelyBed":"9","bindUserRelationship":"其他","latelyAdmissionDiagnosis":"肝占位性病变","latelyDischargeDiagnosis":"肝右叶原发性肝癌","latelyDischargeTime":"2018-11-26","latelyVisitingDate":"2018-11-26","doctorId":100137,"bindUid":100137,"followupName":"肝切除模板","isFollow":false}]
     */

    private int status;
    private int page;
    private int totalPage;
    private List<RetValueBean> retValue;

    public int getStatus() {
        return status;
    }

    public void setStatus(int status) {
        this.status = status;
    }

    public int getPage() {
        return page;
    }

    public void setPage(int page) {
        this.page = page;
    }

    public int getTotalPage() {
        return totalPage;
    }

    public void setTotalPage(int totalPage) {
        this.totalPage = totalPage;
    }

    public List<RetValueBean> getRetValue() {
        return retValue;
    }

    public void setRetValue(List<RetValueBean> retValue) {
        this.retValue = retValue;
    }

    public static class RetValueBean {
        /**
         * id : 45846
         * userName : 沈铭昌
         * userSex : 1
         * latelyAdmitNo : 692170
         * latelyBed : 13
         * bindUserRelationship : 本人
         * latelyAdmissionDiagnosis : 结直肠恶性肿瘤伴肝转移,肺转移性肿瘤,高血压,前列腺增生
         * latelyDischargeDiagnosis : 结直肠恶性肿瘤伴肝转移,肺转移性肿瘤(IV期),高血压,前列腺增生
         * latelyDischargeTime : 2019-04-24
         * latelyVisitingDate : 2019-04-23
         * doctorId : 100137
         * bindUid : 141024
         * followupName : 肝切除模板
         * isFollow : false
         * userIcon : 141272/patient/1574061067019482.png
         */

        private int id;
        private String userName;
        private int userSex;
        private String latelyAdmitNo;
        private String latelyBed;
        private String bindUserRelationship;
        private String latelyAdmissionDiagnosis;
        private String latelyDischargeDiagnosis;
        private String latelyDischargeTime;
        private String latelyVisitingDate;
        private int doctorId;
        private int bindUid;
        private String followupName;
        private boolean isFollow;
        private String userIcon;

        public int getId() {
            return id;
        }

        public void setId(int id) {
            this.id = id;
        }

        public String getUserName() {
            return userName;
        }

        public void setUserName(String userName) {
            this.userName = userName;
        }

        public int getUserSex() {
            return userSex;
        }

        public void setUserSex(int userSex) {
            this.userSex = userSex;
        }

        public String getLatelyAdmitNo() {
            return latelyAdmitNo;
        }

        public void setLatelyAdmitNo(String latelyAdmitNo) {
            this.latelyAdmitNo = latelyAdmitNo;
        }

        public String getLatelyBed() {
            return latelyBed;
        }

        public void setLatelyBed(String latelyBed) {
            this.latelyBed = latelyBed;
        }

        public String getBindUserRelationship() {
            return bindUserRelationship;
        }

        public void setBindUserRelationship(String bindUserRelationship) {
            this.bindUserRelationship = bindUserRelationship;
        }

        public String getLatelyAdmissionDiagnosis() {
            return latelyAdmissionDiagnosis;
        }

        public void setLatelyAdmissionDiagnosis(String latelyAdmissionDiagnosis) {
            this.latelyAdmissionDiagnosis = latelyAdmissionDiagnosis;
        }

        public String getLatelyDischargeDiagnosis() {
            return latelyDischargeDiagnosis;
        }

        public void setLatelyDischargeDiagnosis(String latelyDischargeDiagnosis) {
            this.latelyDischargeDiagnosis = latelyDischargeDiagnosis;
        }

        public String getLatelyDischargeTime() {
            return latelyDischargeTime;
        }

        public void setLatelyDischargeTime(String latelyDischargeTime) {
            this.latelyDischargeTime = latelyDischargeTime;
        }

        public String getLatelyVisitingDate() {
            return latelyVisitingDate;
        }

        public void setLatelyVisitingDate(String latelyVisitingDate) {
            this.latelyVisitingDate = latelyVisitingDate;
        }

        public int getDoctorId() {
            return doctorId;
        }

        public void setDoctorId(int doctorId) {
            this.doctorId = doctorId;
        }

        public int getBindUid() {
            return bindUid;
        }

        public void setBindUid(int bindUid) {
            this.bindUid = bindUid;
        }

        public String getFollowupName() {
            return followupName;
        }

        public void setFollowupName(String followupName) {
            this.followupName = followupName;
        }

        public boolean isIsFollow() {
            return isFollow;
        }

        public void setIsFollow(boolean isFollow) {
            this.isFollow = isFollow;
        }

        public String getUserIcon() {
            return userIcon;
        }

        public void setUserIcon(String userIcon) {
            this.userIcon = userIcon;
        }
    }
}
