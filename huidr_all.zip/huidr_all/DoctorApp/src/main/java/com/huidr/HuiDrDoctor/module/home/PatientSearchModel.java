package com.huidr.HuiDrDoctor.module.home;

import java.util.List;

/**
 * @author: Administrator
 * @date: 2019-12-04
 */
public class PatientSearchModel {


    /**
     * status : 0
     * page : 1
     * totalPage : 3
     * retValue : [{"id":68541,"userName":"董莲","userSex":2,"doctorId":100166,"isFollow":true},{"id":49009,"userName":"董汉琦","userSex":1,"latelyAdmitNo":"947649","latelyBed":"20","latelyAdmissionDiagnosis":"肝恶性肿瘤个人史","latelyDischargeDiagnosis":"肝MT术后复发、腹腔转移","latelyDischargeTime":"2016-02-03","latelyVisitingDate":"2016-01-25","doctorId":100136,"followupName":"肝切除模板","isFollow":false},{"id":59014,"userName":"董浩","userSex":1,"latelyAdmitNo":"911048","latelyBed":"30","latelyAdmissionDiagnosis":"双侧慢性鼻窦炎","latelyDischargeDiagnosis":"双侧慢性鼻窦炎、鼻息肉","latelyDischargeTime":"2015-06-26","latelyVisitingDate":"2015-10-22","doctorId":100157,"isFollow":false},{"id":52572,"userName":"董高奎","userSex":1,"latelyAdmitNo":"856835","latelyBed":"37","latelyAdmissionDiagnosis":"肝继发恶性肿瘤,直肠恶性肿瘤综合治疗后,肺继发恶性肿瘤,高血压病","latelyDischargeDiagnosis":"肝继发恶性肿瘤,直肠恶性肿瘤综合治疗后,肺继发恶性肿瘤,高血压病","latelyDischargeTime":"2016-12-16","latelyVisitingDate":"2017-03-06","doctorId":100137,"followupName":"肝切除模板","isFollow":false},{"id":50272,"userName":"董国玉","userSex":1,"latelyAdmitNo":"933596","latelyBed":"7","latelyAdmissionDiagnosis":"肝占位性病变","latelyDischargeDiagnosis":"肝细胞癌","latelyDischargeTime":"2015-11-16","latelyVisitingDate":"2016-01-28","doctorId":100136,"followupName":"肝切除模板","isFollow":false},{"id":79302,"userName":"董柏然","userSex":1,"bindUserRelationship":"本人","doctorId":100166,"bindUid":141027,"isFollow":false},{"id":58785,"userName":"董金芬","userSex":2,"latelyAdmitNo":"1095620","latelyBed":"105","latelyAdmissionDiagnosis":"右侧鼻息肉,慢性鼻窦炎","latelyDischargeDiagnosis":"右侧鼻息肉","latelyDischargeTime":"2018-01-27","latelyVisitingDate":"2018-08-28","doctorId":100157,"isFollow":false},{"id":57920,"userName":"董平","userSex":1,"latelyAdmitNo":"1001539","latelyBed":"31","latelyAdmissionDiagnosis":"睡眠呼吸暂停低通气综合征","latelyDischargeDiagnosis":"睡眠呼吸暂停低通气综合征","latelyDischargeTime":"2019-01-22","latelyVisitingDate":"2019-03-06","doctorId":100157,"isFollow":false},{"id":49035,"userName":"董旭蕾","userSex":1,"latelyAdmitNo":"931696","latelyBed":"7","latelyAdmissionDiagnosis":"肝占位性病变","latelyDischargeDiagnosis":"肝细胞癌","latelyDischargeTime":"2015-11-05","latelyVisitingDate":"2019-04-23","doctorId":100136,"followupName":"肝切除模板","isFollow":false},{"id":61615,"userName":"董文康","userSex":1,"latelyAdmitNo":"1180796","latelyBed":"1","latelyAdmissionDiagnosis":"肝占位性病变","latelyDischargeDiagnosis":"原发性肝癌","latelyDischargeTime":"2019-03-04","latelyVisitingDate":"2019-04-18","doctorId":100136,"isFollow":false},{"id":58975,"userName":"董林弟","userSex":1,"latelyAdmitNo":"894184","latelyBed":"26","latelyAdmissionDiagnosis":"口腔恶性肿瘤","latelyDischargeDiagnosis":"口腔恶性肿瘤","latelyDischargeTime":"2015-05-30","latelyVisitingDate":"2015-05-29","doctorId":100157,"isFollow":false},{"id":50892,"userName":"董倩萍","userSex":2,"latelyAdmitNo":"964108","latelyBed":"9","latelyAdmissionDiagnosis":"肝占位性病变","latelyDischargeDiagnosis":"肝占位性病变","latelyDischargeTime":"2016-05-10","latelyVisitingDate":"2018-05-03","doctorId":100136,"followupName":"肝切除模板","isFollow":false},{"id":81176,"userName":"董老师","userSex":1,"bindUserRelationship":"本人","doctorId":100166,"bindUid":141043,"isFollow":false},{"id":62290,"userName":"董侯振","userSex":1,"bindUserRelationship":"本人","doctorId":100166,"bindUid":100147,"isFollow":false},{"id":58084,"userName":"董志兰","userSex":2,"latelyAdmitNo":"1057791","latelyBed":"35","latelyAdmissionDiagnosis":"咽部肿物","latelyDischargeDiagnosis":"口咽乳头状瘤","latelyDischargeTime":"2017-08-08","latelyVisitingDate":"2019-03-25","doctorId":100157,"isFollow":false},{"id":49355,"userName":"董广勤","userSex":1,"latelyAdmitNo":"1118639","latelyBed":"18","latelyAdmissionDiagnosis":"肝占位性病变","latelyDischargeDiagnosis":"肝占位性病变","latelyDischargeTime":"2018-05-24","latelyVisitingDate":"2018-06-21","doctorId":100136,"followupName":"肝切除模板","isFollow":false},{"id":83075,"userName":"董发","userSex":1,"bindUserRelationship":"本人","doctorId":100166,"bindUid":141087,"isFollow":false},{"id":51172,"userName":"董玉章","userSex":1,"latelyAdmitNo":"1148135","latelyBed":"122","latelyAdmissionDiagnosis":"肝占位性病变","latelyDischargeDiagnosis":"肝恶性肿瘤","latelyDischargeTime":"2018-09-25","latelyVisitingDate":"2018-09-25","doctorId":100136,"followupName":"肝切除模板","isFollow":false},{"id":58299,"userName":"董英雪","userSex":2,"latelyAdmitNo":"890604","latelyBed":"110","latelyAdmissionDiagnosis":"右侧声带息肉","latelyDischargeDiagnosis":"右侧声带息肉","latelyDischargeTime":"2017-02-08","latelyVisitingDate":"2018-03-08","doctorId":100157,"isFollow":false},{"id":49437,"userName":"董海涛","userSex":1,"latelyAdmitNo":"1149207","latelyBed":"29","latelyAdmissionDiagnosis":"肝占位性病变","latelyDischargeDiagnosis":"肝占位在综合治疗术后","latelyDischargeTime":"2018-09-28","latelyVisitingDate":"2019-04-11","doctorId":100136,"followupName":"肝切除模板","isFollow":false}]
     */

    private int status;
    private int page;
    private int totalPage;
    private List<RetValueBean> retValue;

    public int getStatus() {
        return status;
    }

    public void setStatus(int status) {
        this.status = status;
    }

    public int getPage() {
        return page;
    }

    public void setPage(int page) {
        this.page = page;
    }

    public int getTotalPage() {
        return totalPage;
    }

    public void setTotalPage(int totalPage) {
        this.totalPage = totalPage;
    }

    public List<RetValueBean> getRetValue() {
        return retValue;
    }

    public void setRetValue(List<RetValueBean> retValue) {
        this.retValue = retValue;
    }

    public static class RetValueBean {
        /**
         * id : 68541
         * userName : 董莲
         * userSex : 2
         * doctorId : 100166
         * isFollow : true
         * latelyAdmitNo : 947649
         * latelyBed : 20
         * latelyAdmissionDiagnosis : 肝恶性肿瘤个人史
         * latelyDischargeDiagnosis : 肝MT术后复发、腹腔转移
         * latelyDischargeTime : 2016-02-03
         * latelyVisitingDate : 2016-01-25
         * followupName : 肝切除模板
         * bindUserRelationship : 本人
         * bindUid : 141027
         */

        private int id;
        private String userName;
        private int userSex;
        private int doctorId;
        private boolean isFollow;
        private String latelyAdmitNo;
        private String latelyBed;
        private String latelyAdmissionDiagnosis;
        private String latelyDischargeDiagnosis;
        private String latelyDischargeTime;
        private String latelyVisitingDate;
        private String followupName;
        private String bindUserRelationship;
        private int bindUid;

        public int getId() {
            return id;
        }

        public void setId(int id) {
            this.id = id;
        }

        public String getUserName() {
            return userName;
        }

        public void setUserName(String userName) {
            this.userName = userName;
        }

        public int getUserSex() {
            return userSex;
        }

        public void setUserSex(int userSex) {
            this.userSex = userSex;
        }

        public int getDoctorId() {
            return doctorId;
        }

        public void setDoctorId(int doctorId) {
            this.doctorId = doctorId;
        }

        public boolean isIsFollow() {
            return isFollow;
        }

        public void setIsFollow(boolean isFollow) {
            this.isFollow = isFollow;
        }

        public String getLatelyAdmitNo() {
            return latelyAdmitNo;
        }

        public void setLatelyAdmitNo(String latelyAdmitNo) {
            this.latelyAdmitNo = latelyAdmitNo;
        }

        public String getLatelyBed() {
            return latelyBed;
        }

        public void setLatelyBed(String latelyBed) {
            this.latelyBed = latelyBed;
        }

        public String getLatelyAdmissionDiagnosis() {
            return latelyAdmissionDiagnosis;
        }

        public void setLatelyAdmissionDiagnosis(String latelyAdmissionDiagnosis) {
            this.latelyAdmissionDiagnosis = latelyAdmissionDiagnosis;
        }

        public String getLatelyDischargeDiagnosis() {
            return latelyDischargeDiagnosis;
        }

        public void setLatelyDischargeDiagnosis(String latelyDischargeDiagnosis) {
            this.latelyDischargeDiagnosis = latelyDischargeDiagnosis;
        }

        public String getLatelyDischargeTime() {
            return latelyDischargeTime;
        }

        public void setLatelyDischargeTime(String latelyDischargeTime) {
            this.latelyDischargeTime = latelyDischargeTime;
        }

        public String getLatelyVisitingDate() {
            return latelyVisitingDate;
        }

        public void setLatelyVisitingDate(String latelyVisitingDate) {
            this.latelyVisitingDate = latelyVisitingDate;
        }

        public String getFollowupName() {
            return followupName;
        }

        public void setFollowupName(String followupName) {
            this.followupName = followupName;
        }

        public String getBindUserRelationship() {
            return bindUserRelationship;
        }

        public void setBindUserRelationship(String bindUserRelationship) {
            this.bindUserRelationship = bindUserRelationship;
        }

        public int getBindUid() {
            return bindUid;
        }

        public void setBindUid(int bindUid) {
            this.bindUid = bindUid;
        }
    }
}
