package com.huidr.HuiDrDoctor.module.home;

/**
 * @author: Administrator
 * @date: 2019-11-22
 */
public class SimpleResultModel {

    /**
     * status : 0
     * retValue : 0
     */

    private int status;
    private int retValue;

    public int getStatus() {
        return status;
    }

    public void setStatus(int status) {
        this.status = status;
    }

    public int getRetValue() {
        return retValue;
    }

    public void setRetValue(int retValue) {
        this.retValue = retValue;
    }
}
