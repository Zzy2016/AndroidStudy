package com.huidr.HuiDrDoctor.contact_fragment;

import android.content.Context;
import android.os.Bundle;

import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.huidr.HuiDrDoctor.debug.R;
import com.huidr.lib.commom.base.BaseFragment;


import java.util.regex.Pattern;

import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;


/*item
 *申请/添加
 * 1.未添加联系人：

头像，医生姓名，住院号，时间，申请时间，通过(申请)，拒绝

2.已添加的联系人

头像、医生姓名、时间、科室、职称、消息的最近一条（默认显示18个端，第18个字段为省略号）


列表
医生的申请操作，和同意申请的列表记录
 *
 * 操作
 * 点击通过，默认添加到医生联系人

2.点击拒绝，通过按钮变为申请，可以向对方发送创建联系申请（列表的显示与搜索出来的结果一样），申请后24小时候如果对方未通过，可以再次申请，24小时内无法再次发送（弱提示：申请消息已发送，24小时后可再次申请）

搜索出医生a是未添加联系人的医生

当医生a向医生b，发送申请后

1.医生b未进行操作，医生b搜索该医生a，出现的就是申请的列表（有统一和拒绝按钮）

2.医生进行同意操作后，列表显示为联系人状态

3医生进行拒绝操作后，列表显示已拒绝的状态和申请按钮

4.已添加联系人的医生可以左划列表添加/取消协同医生

5.未添加联系人的医生不能左滑添加协同医生
 * */
public class ApplyFragment extends BaseFragment implements View.OnClickListener {


    private TextView tvCancel;
    private ImageView imgSearch;
    private EditText etInput;

    private int index = 0;  //  0  显示列表 1 显示搜索
    private FragmentManager fragmentManager;
    private FragmentTransaction fragmentTransaction;
    private Pattern pattern;
    private InputMethodManager imm;
    private ApplySearchFragment applySearchFragment;

    @Override
    protected void initData() {
        fragmentManager = getChildFragmentManager();
        pattern = Pattern.compile("^\\s*$");
        imm = (InputMethodManager) getContext().getSystemService(Context.INPUT_METHOD_SERVICE);
    }

    @Override
    protected View setContentView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_apply, container, false);
    }

    @Override
    protected void findView(View parent) {
        tvCancel = parent.findViewById(R.id.tv_cancel);
        imgSearch = parent.findViewById(R.id.img_search);
        etInput = parent.findViewById(R.id.et_input);


        tvCancel.setOnClickListener(this);
        imgSearch.setOnClickListener(this);


        etInput.setOnEditorActionListener(new TextView.OnEditorActionListener() {
            @Override
            public boolean onEditorAction(TextView v, int actionId, KeyEvent event) {
                if (actionId == 3) {//
                    if (etInput.getText().toString().length() > 0) {

                        if (pattern.matcher(etInput.getText().toString()).matches()) {
                            Toast.makeText(getContext(), "请重新输入", Toast.LENGTH_LONG).show();
                            etInput.setText("");
                        } else {
//                            doKeySearch();
                            index = 1;
                            tvCancel.setText("取消");
                            switchPage(index);
                        }

                    }

                    return true;
                } else {
                    return false;
                }
            }
        });

        switchPage(index);
    }

    /*切换页面*/
    public void switchPage(int index) {
        fragmentTransaction = fragmentManager.beginTransaction();
        if (index == 0) {
            fragmentTransaction.replace(R.id.fl_content, new ApplyListFragment());
        } else {
            applySearchFragment = new ApplySearchFragment();
            Bundle bundle = new Bundle();
            bundle.putString("search_key", etInput.getText().toString());
            applySearchFragment.setArguments(bundle);
            fragmentTransaction.replace(R.id.fl_content, applySearchFragment);
        }
        fragmentTransaction.commit();
    }


    public void beforeSearch() {
        if (pattern.matcher(etInput.getText().toString()).matches()) {
            Toast.makeText(getContext(), "请重新输入", Toast.LENGTH_SHORT).show();
        } else {
            index = 1;
            tvCancel.setText("取消");
            switchPage(index);
            hideImm(etInput);
        }
    }

    public void hideImm(EditText editText) {
        if (imm != null) {
            imm.hideSoftInputFromWindow(editText.getWindowToken(), 0);
        }
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.img_search:
                beforeSearch();
                break;
            case R.id.tv_cancel:
                if (tvCancel.getText().toString().equals("搜索")) {
                    beforeSearch();
                } else {
                    index = 0;
                    tvCancel.setText("搜索");
                    switchPage(index);
                    etInput.setText("");
                }

                break;
        }
    }

    /*------------------------*/
//    SmartRefreshLayout srlLayout;
//    RecyclerView rvListApply;
//
//    ConstraintLayout clEmptyApply;
//    TextView tvEmptyApply1, tvEmptyApply2;
//
//
//    List<ApplyListModel.RetValueBean> allApplyList;
//    ApplyListModel applyListModel;
//    Gson gson;
//    String doctorId;
//    int currentPage = 1;
//    int totalPage = 0;
//    OssService ossService;
//    String imgPath;
//    ZLoadingDialog dialog, dialog1;
//
//    Matrix matrix;
//
//    @Override
//    protected void initData() {
//        matrix = new Matrix();
//        matrix.setRotate(90);
//
//        dialog = new ZLoadingDialog(getContext());
//        dialog.setLoadingBuilder(Z_TYPE.STAR_LOADING)//设置类型
//                .setLoadingColor(Color.BLUE)//颜色
//                .setHintText("处理中,请稍候...").setHintTextSize(16) // 设置字体大小 dp
//                .setHintTextColor(Color.GRAY)  // 设置字体颜色
//                .setDurationTime(0.5) // 设置动画时间百分比 - 0.5倍
//                .setCanceledOnTouchOutside(false).setCancelable(false);
//
//        dialog1 = new ZLoadingDialog(getContext());
//        dialog1.setLoadingBuilder(Z_TYPE.STAR_LOADING)//设置类型
//                .setLoadingColor(Color.BLUE)//颜色
//                .setHintText("正在加载,请稍候...").setHintTextSize(16) // 设置字体大小 dp
//                .setHintTextColor(Color.GRAY)  // 设置字体颜色
//                .setDurationTime(0.5) // 设置动画时间百分比 - 0.5倍
//                .setCanceledOnTouchOutside(false).setCancelable(false).show();
//
//        ossService = new OssService(getContext());
//        imgPath = Environment.getExternalStorageDirectory() + "/" + getContext().getPackageName() + "/img/head/";
//
//        doctorId = (String) SharedPreferenciesUtil.getData("id", "");
//        applyListModel = new ApplyListModel();
//        allApplyList = new ArrayList<>();
//        gson = new Gson();
//        applyAdapter.setNewData(allApplyList);
//
//        getDataByPage();
//    }
//
//    @Override
//    protected View setContentView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
//        return inflater.inflate(R.layout.fragment_apply, container, false);
//    }
//
//    @Override
//    protected void findView(View parent) {
//        srlLayout = parent.findViewById(R.id.srl_layout);
//        rvListApply = parent.findViewById(R.id.rv_list_apply);
//        rvListApply.setAdapter(applyAdapter);
//        rvListApply.setLayoutManager(new LinearLayoutManager(getContext()));
//
//        /*
//         * 刷新最新数据
//         * 需要把数据清空 并且重新加载第一页数据
//         * */
//        srlLayout.setOnRefreshListener(new OnRefreshListener() {
//            @Override
//            public void onRefresh(@NonNull RefreshLayout refreshLayout) {
//                currentPage = 1;
//                getDataByPage();
//            }
//        });
//
//        /*
//         * 加载更多数据  判断当前列表size是否等于pageSize 只有size==pageSize 并且currentPage小于totalPage
//         * 说明未加载全部数据，可以加载下一页，否则未加载全部
//         * */
//        srlLayout.setOnLoadMoreListener(new OnLoadMoreListener() {
//            @Override
//            public void onLoadMore(@NonNull RefreshLayout refreshLayout) {
//
//                if (applyListModel.getRetValue().size() == 20 && currentPage < totalPage) {
//                    currentPage += 1;
//                    getDataByPage();
//                } else {
//                    Toast.getInstance(getContext()).show("数据加载全部", 500);
//                    srlLayout.finishLoadMore();
//                }
//            }
//        });
//
//        clEmptyApply = parent.findViewById(R.id.cl_empty_apply);
//        tvEmptyApply1 = parent.findViewById(R.id.tv_empty_apply1);
//        tvEmptyApply2 = parent.findViewById(R.id.tv_empty_apply2);
//
//        tvEmptyApply2.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                currentPage = 1;
//                getDataByPage();
//            }
//        });
//
//    }
//
//    /*申请列表适配器
//     *
//     * */
//    private BaseQuickAdapter<ApplyListModel.RetValueBean, BaseViewHolder> applyAdapter = new BaseQuickAdapter<ApplyListModel.RetValueBean, BaseViewHolder>(R.layout.item_apply_layout) {
//        @Override
//        protected void convert(final BaseViewHolder helper, final ApplyListModel.RetValueBean item) {
//            EasySwipeMenuLayout esmlItem = helper.getView(R.id.esml_item);
//            esmlItem.setCanRightSwipe(false);
//            esmlItem.setCanLeftSwipe(false);
//
//            ConstraintLayout clItem = helper.getView(R.id.cl_item);
//
//            clItem.setOnClickListener(new View.OnClickListener() {
//                @Override
//                public void onClick(View v) {
//                    if (JMessageClient.getMyInfo() == null) {
//                        return;
//                    }
//                    if (MulityClickUtils.isFastClick()) {
//
//                        Intent intent1 = new Intent(getContext(), WebActivity.class);
//                        Bundle bundle = new Bundle();
//                        bundle.putString("url", "personal.html?id=" + item.getId());
//                        intent1.putExtras(bundle);
//                        startActivity(intent1);
//                    }
//                }
//            });
//
//            CircleImageView imgItemHead = helper.getView(R.id.img_item_head);
//
//
//            Bitmap defaultBitmap = BitmapFactory.decodeResource(getResources(), R.drawable.nantou);
//            BitmapDrawable defaultDrawable = new BitmapDrawable(getResources(), defaultBitmap);
//            imgItemHead.setBackgroundDrawable(defaultDrawable);
//
//            if (item.getUserIcon() != null) {
//                imgItemHead.setTag(item.getUserIcon());
//                File file = new File(imgPath + item.getUserIcon());
//                if (file.exists()) {
//                    Bitmap bitmap1 = BitmapFactory.decodeFile(file.getAbsolutePath());
//                    if (bitmap1 != null) {
//                        bitmap1 = getCirleBitmap(bitmap1);
//                        BitmapDrawable bitmapDrawable1 = new BitmapDrawable(getContext().getResources(), bitmap1);
//                        if (item.getUserIcon().equals(imgItemHead.getTag())) {
//                            imgItemHead.setBackgroundDrawable(bitmapDrawable1);
//                        }
//                    }
//                } else {
//
//                    DowmImageUtils.BitmapWorkerTask bitmapWorkerTask = new DowmImageUtils.BitmapWorkerTask(imgItemHead, file, ossService);
//                    bitmapWorkerTask.execute(item.getUserIcon());
//
//                }
//
//            } else {
//                imgItemHead.setBackgroundDrawable(defaultDrawable);
//            }
//
//            ImageView imgNotice = helper.getView(R.id.img_notice);
//            imgNotice.setVisibility(View.GONE);
//            TextView tvItemName = helper.getView(R.id.tv_item_name);
//            TextView tvItemAge = helper.getView(R.id.tv_item_age);
//            TextView tvItemDate = helper.getView(R.id.tv_item_date);
//            TextView tvItemMsg = helper.getView(R.id.tv_item_msg);
//            final Button btnApply = helper.getView(R.id.btn_apply);
//            btnApply.setVisibility(View.VISIBLE);
//            final Button btnRefuse = helper.getView(R.id.btn_refuse);
//            btnRefuse.setVisibility(View.VISIBLE);
//            TextView tvScrollRight = helper.getView(R.id.tv_scroll_right);
//            TextView tvScrollDel = helper.getView(R.id.tv_scroll_del);
//
//            tvItemName.setText(item.getUserName());
//            tvItemAge.setText(item.getUserTitle() + "(" + item.getHospitalDepartment() + ")");
//            tvItemMsg.setText(item.getUpdateTime());
//
////            0  未处理 2 拒绝
//            if (item.getStatus() == 0) {
//                btnApply.setText("通过");
//                btnApply.setBackgroundResource(R.drawable.btn_grad_empty);
////                imgNotice.setVisibility(View.VISIBLE);
//                btnRefuse.setText("拒绝");
//                btnRefuse.setBackgroundResource(R.drawable.btn_red_empty);
//            } else if (item.getStatus() == 2) {
//                btnApply.setText("申请");
//                btnApply.setBackgroundResource(R.drawable.btn_grad_empty);
////                imgNotice.setVisibility(View.GONE);
//                btnRefuse.setText("已拒绝");
//                btnRefuse.setBackgroundResource(R.drawable.back_refurse_gray);
//            } else if (item.getStatus() == 3) {
//                btnApply.setText("已申请");
//                btnApply.setBackgroundResource(R.drawable.btn_gray1_apply);
////                imgNotice.setVisibility(View.GONE);
//                btnRefuse.setText("已拒绝");
//                btnRefuse.setBackgroundResource(R.drawable.back_refurse_gray);
//            } else {
//
//            }
//
//
////            1接受 2 拒绝
//            btnApply.setOnClickListener(new View.OnClickListener() {
//                @Override
//                public void onClick(View v) {
//
//                    if (MulityClickUtils.isFastClick()) {
//                        if (btnApply.getText().equals("通过")) {
//                            dialog.show();
////                        ContactManager.acceptInvitation(item.getId() + "", "", new BasicCallback() {
////                            @Override
////                            public void gotResult(int i, String s) {
////                                if (i == 0) {
////                                    modifyApply(item.getId() + "", 1, helper.getAdapterPosition());
////                                } else {
////                                    LogUtil.e("极光同意", s);
////                                    dialog.dismiss();
////                                }
////                            }
////                        });
//                            modifyApply(item.getId() + "", 1, helper.getAdapterPosition());
//                        } else if (btnApply.getText().equals("申请")) {
//                            dialog.show();
//                            ContactManager.sendInvitationRequest(item.getId() + "", "", "", new BasicCallback() {
//                                @Override
//                                public void gotResult(int responseCode, String responseMessage) {
//                                    if (0 == responseCode) {
//                                        LogUtil.e("极光发送邀请成功", "极光发送邀请成功");
//                                        addContact(item.getId() + "", helper.getAdapterPosition());
//                                    } else {
//                                        LogUtil.e("极光发送邀请失败", "极光发送邀请失败 " + responseMessage);
//                                        dialog.dismiss();
//                                        Toast.getInstance(getContext()).show("发送邀请失败", 500);
//                                    }
//                                }
//                            });
//                        } else {
//
//                        }
//                    }
//                }
//            });
//
//            btnRefuse.setOnClickListener(new View.OnClickListener() {
//                @Override
//                public void onClick(View v) {
////                    ContactManager.declineInvitation(item.getId() + "", "", "", new BasicCallback() {
////                        @Override
////                        public void gotResult(int i, String s) {
////                            modifyApply(item.getId() + "", 2);
////                        }
////                    });
//
//                    if (btnRefuse.getText().equals("拒绝")) {
//                        dialog.show();
//                        modifyApply(item.getId() + "", 2, helper.getAdapterPosition());
//                    }
//
//                }
//
//            });
//
//
//        }
//    };
//
//
//    //    添加联系人  访问接口
//    public void addContact(final String targetId, final int position) {
//        ThreadPoolManager.getInstance().execute(new Runnable() {
//            @Override
//            public void run() {
////                String path = "http://192.168.1.180:1189/doctorGroup/addContacts";
//                String path = BuildConfig.baseUrl + "hospital/doctorGroup/addContacts";
//                JSONObject jsonObject = new JSONObject();
//                String id = (String) SharedPreferenciesUtil.getData("id", "0");
////                申请人ID  applicantId
//                jsonObject.put("applicantId", id);
//                //                本申请人ID applicantId
//                jsonObject.put("respondentId", targetId);
//
//                String result = PostAndGet.doHttpPost(path, jsonObject);
//                LogUtil.e("添加联系人", result);
//                if (result.equals("网络异常")) {
//                    handler.sendEmptyMessage(10);
//                } else {
//                    SimpleResultModel simpleResultModel = gson.fromJson(result, SimpleResultModel.class);
//                    if (simpleResultModel.getStatus() == 0) {
////                        1发送成功 0 24小时内不能重复发送
//                        if (simpleResultModel.getRetValue() == 1) {
////                            handler.sendEmptyMessage(8);
//                            Message message = new Message();
//                            message.what = 8;
//                            message.arg1 = position;
//                            handler.sendMessage(message);
//                        } else if (simpleResultModel.getRetValue() == -1) {
//                            handler.sendEmptyMessage(9);
//                        } else {
//                            handler.sendEmptyMessage(10);
//                        }
//                    } else {
//                        handler.sendEmptyMessage(10);
//                    }
//                }
//            }
//        });
//    }
//
//    //    同意或拒绝 doctorGroup/updateContacts 1接受 2 拒绝
//    public void modifyApply(String targetId, final int status, final int position) {
////        final String path = "http://192.168.1.180:1189/doctorGroup/updateContacts";
//        final String path = BuildConfig.baseUrl + "hospital/doctorGroup/updateContacts";
//        final JSONObject jsonObject = new JSONObject();
//        jsonObject.put("doctorId", targetId);
//        jsonObject.put("status", status);
//        ThreadPoolManager.getInstance().execute(new Runnable() {
//            @Override
//            public void run() {
//                String result = PostAndGet.doHttpPost(path, jsonObject);
//                LogUtil.e("接受或者拒绝好友", result);
//                Message message = new Message();
//                message.arg1 = position;
//                message.arg2 = status;
//                if (result.equals("网络异常")) {
//                    message.what = 7;
//                    handler.sendMessage(message);
//                } else {
//                    SimpleResultModel simpleResultModel = new SimpleResultModel();
//                    simpleResultModel = gson.fromJson(result, SimpleResultModel.class);
//                    if (simpleResultModel.getStatus() == 0) {
//                        if (simpleResultModel.getRetValue() == 0) {
//                            message.what = 6;
//                            handler.sendMessage(message);
//                        } else {
//                            message.what = 7;
//                            handler.sendMessage(message);
//                        }
//                    } else {
//                        message.what = 7;
//                        handler.sendMessage(message);
//                    }
//                }
//            }
//        });
//    }
//
//    //    分页获取申请  doctorGroup/getDoctorUserUInfo
//    public void getDataByPage() {
////        final String path = "http://192.168.1.180:1189/doctorGroup/getApplyList";
//        final String path = BuildConfig.baseUrl + "hospital/doctorGroup/getApplyList";
//        final JSONObject jsonObject = new JSONObject();
//        jsonObject.put("pageIndex", currentPage);
//        jsonObject.put("pageSize", 20);
//        ThreadPoolManager.getInstance().execute(new Runnable() {
//            @Override
//            public void run() {
//                String result = PostAndGet.doHttpPost(path, jsonObject);
//                LogUtil.e("申请列表", result);
//                applyListModel = new ApplyListModel();
//                if (result.equals("网络异常")) {
//                    handler.sendEmptyMessage(3);
//                } else {
//                    applyListModel = gson.fromJson(result, ApplyListModel.class);
//                    if (applyListModel.getStatus() == 0) {
//                        totalPage = applyListModel.getTotalPage();
//                        if (currentPage == 1) {
//                            handler.sendEmptyMessage(1);
//                        } else {
//                            handler.sendEmptyMessage(2);
//                        }
//                    } else {
//                        handler.sendEmptyMessage(3);
//                    }
//                }
//            }
//        });
//    }
//
//    //1  刷新
////    2  加载更多
////    3  异常
//    private Handler handler = new Handler() {
//        @Override
//        public void handleMessage(Message msg) {
//            super.handleMessage(msg);
//            switch (msg.what) {
//                case 1:
//                    applyAdapter.getData().clear();
//                    if (applyListModel.getRetValue().size() == 0) {
//                        srlLayout.setVisibility(View.GONE);
//                        clEmptyApply.setVisibility(View.VISIBLE);
//                        tvEmptyApply1.setText("暂无申请~");
//                        tvEmptyApply2.setText("");
//                    } else {
//                        srlLayout.setVisibility(View.VISIBLE);
//                        clEmptyApply.setVisibility(View.GONE);
//                        applyAdapter.getData().addAll(applyListModel.getRetValue());
//                        applyAdapter.notifyDataSetChanged();
//                    }
//                    srlLayout.finishRefresh();
//                    if (dialog1 != null) {
//                        dialog1.dismiss();
//                    }
//                    break;
//                case 2:
//                    applyAdapter.getData().addAll(applyListModel.getRetValue());
//                    applyAdapter.notifyDataSetChanged();
//                    srlLayout.finishLoadMore();
//                    break;
//                case 3:
//                    srlLayout.finishLoadMore();
//                    srlLayout.finishRefresh();
//                    srlLayout.setVisibility(View.GONE);
//                    clEmptyApply.setVisibility(View.VISIBLE);
//                    tvEmptyApply1.setText("网络错误");
//                    String tip = "<font color='#248cfa'><u> 立即刷新 <u><font>";
//                    tvEmptyApply2.setText(Html.fromHtml(tip));
//                    if (dialog1 != null) {
//                        dialog1.dismiss();
//                    }
//                    break;
////                    接受拒绝好友申请成功  1接受 2 拒绝
//                case 6:
//                    if (dialog != null) {
//                        dialog.dismiss();
//                    }
//
//                    if (msg.arg2 == 1) {
//                        applyAdapter.getData().remove(msg.arg1);
//                        applyAdapter.notifyDataSetChanged();
//                        Toast.getInstance(getContext()).show("已通过好友申请", 500);
//                    } else {
//                        applyAdapter.getData().get(msg.arg1).setStatus(2);
//                        applyAdapter.notifyItemChanged(msg.arg1);
//                        Toast.getInstance(getContext()).show("已拒绝好友申请", 500);
//                    }
//                    break;
//                //                    接受拒绝好友申请失败
//                case 7:
//                    if (dialog != null) {
//                        dialog.dismiss();
//                    }
//                    if (msg.arg2 == 1) {
//                        Toast.getInstance(getContext()).show("通过好友申请失败", 500);
//                    } else {
//                        Toast.getInstance(getContext()).show("拒绝好友申请失败", 500);
//                    }
//                    break;
////发送成功  邀请好友
//                case 8:
//                    if (dialog != null) {
//                        dialog.dismiss();
//                    }
//                    applyAdapter.getData().get(msg.arg1).setStatus(3);
//                    applyAdapter.notifyItemChanged(msg.arg1);
//                    Toast.getInstance(getContext()).show("邀请发送成功", 500);
//                    break;
//                //发送成功  邀请好友  提示不要重复发送
//                case 9:
//                    if (dialog != null) {
//                        dialog.dismiss();
//                    }
//                    Toast.getInstance(getContext()).show("已发送邀请，请勿重复发送", 500);
//                    break;
//                //发送失败  邀请好友
//                case 10:
//                    if (dialog != null) {
//                        dialog.dismiss();
//                    }
//                    Toast.getInstance(getContext()).show("邀请发送失败", 500);
//                    break;
//            }
//        }
//    };
//
//
//    @Override
//    public void onStop() {
//        super.onStop();
//        applyAdapter.notifyDataSetChanged();
//        if (dialog != null) {
//            dialog.dismiss();
//        }
//    }

}
