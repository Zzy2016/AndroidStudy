package com.huidr.HuiDrDoctor.activity;

import android.content.Intent;
import android.graphics.Paint;
import android.os.Handler;
import android.os.Message;
import androidx.annotation.NonNull;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;

import android.text.Html;
import android.text.TextUtils;
import android.util.Log;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.PopupWindow;
import android.widget.TextView;

import com.chad.library.adapter.base.BaseQuickAdapter;
import com.chad.library.adapter.base.BaseViewHolder;
import com.contrarywind.listener.OnItemSelectedListener;
import com.contrarywind.view.WheelView;
import com.google.gson.Gson;
import com.huidr.HuiDrDoctor.activity.main.Consult.utils.PostAndGet;
import com.huidr.HuiDrDoctor.adapter.ArrayWheelAdapter;
import com.huidr.HuiDrDoctor.debug.BuildConfig;
import com.huidr.HuiDrDoctor.debug.R;
import com.huidr.HuiDrDoctor.module.home.DateListModel;
import com.huidr.HuiDrDoctor.module.home.ReplyListModel;
import com.huidr.HuiDrDoctor.module.model.LoginResultForH5;
import com.huidr.HuiDrDoctor.util.MulityClickUtils;
import com.huidr.HuiDrDoctor.util.ThreadPoolManager;
import com.huidr.lib.commom.util.Toast;
import com.scwang.smartrefresh.layout.SmartRefreshLayout;
import com.scwang.smartrefresh.layout.api.RefreshLayout;
import com.scwang.smartrefresh.layout.listener.OnLoadMoreListener;
import com.scwang.smartrefresh.layout.listener.OnRefreshListener;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import jiguang.chat.utils.oss.Constants;
import jiguang.chat.utils.oss.SharedPreferenciesUtil;

public class ReplyActivity extends AppCompatActivity {

    private TextView tvDate;
    private ImageView imgBack;
    private ImageView imgDate;
    private TextView tvReplyCount;
    private TextView tvReplyCount1;
    private TextView tvBack;//背景
    private TextView tvMonth;//月
    private TextView tvReplyCount2;//回答


    private PopupWindow popupWindow;
    private View view;

    private TextView tvCancelPop, tvEnsurePop;

    private SmartRefreshLayout srlQuestion;
    private RecyclerView rvListReply;

    private ImageView imgEmptyReply;
    private TextView tvEmpty;

    private List<String> replyList;
    private int currentPage = 1;
    private int totalPage = 1;


    private WheelView wheelViewYear;


    private List<String> dateList;//日期列表
    private int selectIndex;//选中日期 index
    private String selectDate;//选中的日期
    private int month;//月份
    private int year;//年分
    private int replyCount;//回答计数


    private int pageSize = 20;

    private DateListModel dateListModel;
    private Calendar calendar;


    //    回答列表

    //获取日期
    private String pathDate = BuildConfig.baseUrl + "recommend/askAnswerOptimizationDoctorController/getProblemHistoryTimeList";


    private final String TAG = "ReplyActivity";
    private Gson gson;

    private String replyTime;

    private ReplyListModel replyListModel;

    String doctorJobNum;
    int doctorDepId;
    int hospitalId;
    String doctorName;

    private SimpleDateFormat sDateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
    private Date date = new Date();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_reply);

        dateListModel = new DateListModel();
        gson = new Gson();
        calendar = Calendar.getInstance();
        replyListModel = new ReplyListModel();


        String userInfo = (String) SharedPreferenciesUtil.getData(Constants.SharedAccountConfig.USER_DOCTOR_INFO, "");
        Log.e("user", userInfo);

        LoginResultForH5 loginResult = gson.fromJson(userInfo, LoginResultForH5.class);

        doctorDepId = loginResult.getValue().getDepartmentId();
        doctorJobNum = loginResult.getValue().getUserJobNumber();
        hospitalId = loginResult.getValue().getHospitalId();
        doctorName = loginResult.getValue().getUserName();

        initView();
        initPopWindow();
        initData();


        getReplyDate();


    }

    /*获取 日期*/
    public void getReplyDate() {
        ThreadPoolManager.getInstance().execute(new Runnable() {
            @Override
            public void run() {
                String result = PostAndGet.doGetHttp(pathDate);
                Log.e(TAG, "日期" + result);

                if (TextUtils.isEmpty(result) || result.equals("网络异常")) {
                    handler.sendEmptyMessage(1);
                } else {
                    dateListModel = gson.fromJson(result, DateListModel.class);
                    if (dateListModel.getStatus() == 0) {
                        handler.sendEmptyMessage(0);
                    } else {
                        handler.sendEmptyMessage(1);
                    }
                }

            }
        });
    }


    /*分月获取 历史问答*/
    public void getReplyList() {
        ThreadPoolManager.getInstance().execute(new Runnable() {
            @Override
            public void run() {


                replyTime = year + "-" + month;


                String pathQueList = BuildConfig.baseUrl + "recommend/askAnswerOptimizationDoctorController/getProblemHistoryList?pageIndex=" + currentPage + "&pageSize=" + pageSize + "&replyTime=" + replyTime;
                String result = PostAndGet.doGetHttp(pathQueList);

                Log.e("回答列表  " + currentPage, result);

                if (TextUtils.isEmpty(result) || result.equals("网络异常")) {
                    handler.sendEmptyMessage(4);
                } else {
                    replyListModel = gson.fromJson(result, ReplyListModel.class);
                    if (replyListModel.getStatus() == 0) {
                        totalPage = replyListModel.getTotalPage();
                        if (currentPage == 1) {
                            handler.sendEmptyMessage(2);
                        } else {
                            handler.sendEmptyMessage(3);
                        }
                    } else {
                        handler.sendEmptyMessage(4);
                    }
                }
            }
        });
    }

    //    隐藏选择框
    public void hideSelect() {


        tvBack.setVisibility(View.GONE);
        tvDate.setVisibility(View.GONE);
        imgDate.setVisibility(View.GONE);
        tvReplyCount.setVisibility(View.GONE);
        tvReplyCount1.setVisibility(View.GONE);
        tvReplyCount2.setVisibility(View.GONE);
        tvMonth.setVisibility(View.GONE);
    }

    private Handler handler = new Handler() {
        @Override
        public void handleMessage(Message msg) {
            super.handleMessage(msg);
            switch (msg.what) {
//               获取日期成功
                case 0:

                    if (dateListModel.getRetValue() == null || dateListModel.getRetValue().size() == 0) {
                        hideSelect();
                        srlQuestion.setVisibility(View.GONE);
                        imgEmptyReply.setVisibility(View.VISIBLE);
                        tvEmpty.setVisibility(View.VISIBLE);
                    } else {
                        for (int i = 0; i < dateListModel.getRetValue().size(); i++) {

                            dateList.add(dateListModel.getRetValue().get(i).getKey() + "年" + dateListModel.getRetValue().get(i).getValue() + "月");
                            if (i == 0) {
                                selectDate = dateListModel.getRetValue().get(i).getKey() + "年" + dateListModel.getRetValue().get(i).getValue() + "月";
                                selectIndex = i;
                                year = Integer.valueOf(dateListModel.getRetValue().get(i).getKey());
                                month = Integer.valueOf(dateListModel.getRetValue().get(i).getValue());
                            }
                        }
                        wheelViewYear.setAdapter(new ArrayWheelAdapter(dateList));

                        wheelViewYear.setCyclic(false);
                        tvDate.setText(Html.fromHtml("<u>" + selectDate + "</u>"));
                        Log.e("riqi ", selectDate + "   " + selectIndex);

                        tvReplyCount.setText(String.valueOf(month));
//                    tvReplyCount.setText(month + "月：0回答");
                        getReplyList();
                    }

                    break;

//                    获取日期失败  显示当前 年月 0 回答  显示空态
                case 1:
                    hideSelect();
                    srlQuestion.setVisibility(View.GONE);
                    imgEmptyReply.setVisibility(View.VISIBLE);
                    tvEmpty.setVisibility(View.VISIBLE);
                    break;

                case 2:
//                    刷新数据
                    adapter.getData().clear();

                    if (replyListModel.getRetValue().size() == 0) {
                        srlQuestion.setVisibility(View.GONE);
                        imgEmptyReply.setVisibility(View.VISIBLE);
                        tvEmpty.setVisibility(View.VISIBLE);


                    } else {
//                        adapter.getData().addAll(replyListModel.getRetValue());

                        adapter.getData().addAll(replyListModel.getRetValue());
                        adapter.notifyDataSetChanged();
                    }

                    tvReplyCount.setText(String.valueOf(month));
                    tvReplyCount1.setText(String.valueOf(adapter.getData().size()));


                    srlQuestion.finishRefresh();

                    break;
                case 3:
//                    加载更多
                    adapter.getData().addAll(replyListModel.getRetValue());
                    adapter.notifyDataSetChanged();

                    tvReplyCount.setText(String.valueOf(month));
                    tvReplyCount1.setText(String.valueOf(adapter.getData().size()));

                    srlQuestion.finishLoadMore();
                    break;
                case 4:
//                    显示为空
                    tvReplyCount.setText(String.valueOf(month));
                    tvReplyCount1.setText("0");

                    srlQuestion.setVisibility(View.GONE);
                    imgEmptyReply.setVisibility(View.VISIBLE);
                    tvEmpty.setVisibility(View.VISIBLE);

                    srlQuestion.finishLoadMore();
                    srlQuestion.finishRefresh();
                    break;
            }
        }
    };


    /*初始化 日期选择器 数据*/
    public void initData() {

        dateList = new ArrayList<>();
    }


    public void initView() {
        tvBack = (TextView) findViewById(R.id.tv_back);
        tvDate = (TextView) findViewById(R.id.tv_date);
        imgBack = (ImageView) findViewById(R.id.img_back);
        imgDate = (ImageView) findViewById(R.id.img_date);
        tvReplyCount = (TextView) findViewById(R.id.tv_reply_count);
        tvReplyCount1 = (TextView) findViewById(R.id.tv_reply_count1);
        tvMonth = (TextView) findViewById(R.id.tv_month);
        tvReplyCount2 = (TextView) findViewById(R.id.tv_reply_count2);


        tvDate.setOnClickListener(clickListener);
        imgDate.setOnClickListener(clickListener);
        imgBack.setOnClickListener(clickListener);

        srlQuestion = (SmartRefreshLayout) findViewById(R.id.srl_reply);
        rvListReply = (RecyclerView) findViewById(R.id.rv_list_reply);


        rvListReply.setAdapter(adapter);
        rvListReply.setLayoutManager(new LinearLayoutManager(this));


        srlQuestion.setEnableRefresh(true);
        srlQuestion.setEnableLoadMore(true);

        srlQuestion.setOnRefreshListener(new OnRefreshListener() {
            @Override
            public void onRefresh(@NonNull RefreshLayout refreshLayout) {
                currentPage = 1;
                getReplyList();

//                srlQuestion.finishRefresh();
            }
        });

        srlQuestion.setOnLoadMoreListener(new OnLoadMoreListener() {
            @Override
            public void onLoadMore(@NonNull RefreshLayout refreshLayout) {
                srlQuestion.finishLoadMore();

                if (currentPage < totalPage && replyListModel.getRetValue().size() == 20) {
                    currentPage += 1;
                    getReplyList();
                } else {
                    srlQuestion.finishLoadMore();
                    Toast.getInstance(ReplyActivity.this).show("数据加载全部", 500);
                }

            }
        });


        imgEmptyReply = findViewById(R.id.img_empty);
        tvEmpty = findViewById(R.id.tv_empty);

    }

    BaseQuickAdapter<ReplyListModel.RetValueBean, BaseViewHolder> adapter = new BaseQuickAdapter<ReplyListModel.RetValueBean, BaseViewHolder>(R.layout.item_question) {
        @Override
        protected void convert(BaseViewHolder helper, final ReplyListModel.RetValueBean item) {
            ConstraintLayout clQue = helper.getView(R.id.cl_que);
            ImageView imgHead = helper.getView(R.id.img_head);
            TextView tvName = helper.getView(R.id.tv_name);
            TextView tvIndi = helper.getView(R.id.tv_indi);
            TextView tvDate = helper.getView(R.id.tv_date);
            TextView tvSource = helper.getView(R.id.tv_source);
            TextView tvDep = helper.getView(R.id.tv_dep);
            TextView tvDepart = helper.getView(R.id.tv_depart);
            TextView tvQuestion = helper.getView(R.id.tv_question);
            Button btnDetail = helper.getView(R.id.btn_detail);
            Button btnReply = helper.getView(R.id.btn_reply);
            TextView tvHide = helper.getView(R.id.tv_hide);
            tvHide.getPaint().setFlags(Paint.UNDERLINE_TEXT_FLAG);


            tvName.setText(item.getUserName());


            if (item.getUserPrimaryPhysicianCode() != null && doctorJobNum.equals(item.getUserPrimaryPhysicianCode())) {
                tvIndi.setVisibility(View.VISIBLE);
            } else {
                tvIndi.setVisibility(View.GONE);
            }

//            if(item.getUserPrimaryPhysicianCode()==null){
//                if(item.getUserPrimaryPhysicianName().equals(doctorName)){
//                    tvIndi.setVisibility(View.VISIBLE);
//                }else{
//                    tvIndi.setVisibility(View.GONE);
//                }
//            }else{
//               if(doctorJobNum.equals(item.getUserPrimaryPhysicianCode())){
//                   tvIndi.setVisibility(View.VISIBLE);
//               }else{
//                   tvIndi.setVisibility(View.GONE);
//               }
//            }

            tvSource.setText(item.getUserHospitalName());
            tvDep.setText(item.getUserDepartmentName());
            tvDepart.setText(item.getUserDepartmentName());


            if (item.getReplyTime() != null) {
//                date.setTime() );
//                String str = sDateFormat.format(date);
//                tvDate.setText( str );

                long time = new Double((Double) item.getReplyTime()).longValue();
                date.setTime(time);
                String str = sDateFormat.format(date);
                tvDate.setText(str);
                Log.e("时间", item.getReplyTime() + "");

            }
            tvQuestion.setText("问题：" + item.getProblemContent());

            btnDetail.setVisibility(View.GONE);
            btnReply.setVisibility(View.GONE);
            tvHide.setVisibility(View.GONE);


            clQue.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (MulityClickUtils.isFastClick()) {
                        Intent intent = new Intent(ReplyActivity.this, QuestionDetailActivity.class);
                        intent.putExtra("showType", 1);
                        intent.putExtra("showImm", 0);
                        intent.putExtra("queId", item.getId());//
                        intent.putExtra("showReturn", 0);
                        startActivity(intent);
                    }
                }
            });
        }
    };

    /*初始化日期选择框*/
    public void initPopWindow() {


        view = LayoutInflater.from(ReplyActivity.this).inflate(R.layout.pop_date_layout, null);
        popupWindow = new PopupWindow(view, ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT);
        popupWindow.setOutsideTouchable(true);


        tvCancelPop = view.findViewById(R.id.tv_cancel);
        tvEnsurePop = view.findViewById(R.id.tv_ensure);


        tvCancelPop.setOnClickListener(clickListener);
        tvEnsurePop.setOnClickListener(clickListener);

        wheelViewYear = (WheelView) view.findViewById(R.id.wheel_year);


        wheelViewYear.setTextSize(16);


        wheelViewYear.setOnItemSelectedListener(new OnItemSelectedListener() {
            @Override
            public void onItemSelected(int index) {

                Log.e("选择日期", dateList.get(index));
                selectDate = dateList.get(index);
                selectIndex = index;
                month = Integer.valueOf(dateListModel.getRetValue().get(index).getValue());
                year = Integer.valueOf(dateListModel.getRetValue().get(index).getKey());
            }
        });
    }


    /*显示 PopupWindow*/
    public void showPopWindow() {
        Log.e("日期选择2", selectDate + "  " + selectIndex);
        wheelViewYear.setCurrentItem(selectIndex);
        WindowManager.LayoutParams lp = getWindow().getAttributes();
        lp.alpha = 0.5f; //0.0-1.0  透明 不透明
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND);
        getWindow().setAttributes(lp);
        popupWindow.showAtLocation(getWindow().getDecorView(), Gravity.BOTTOM, 0, 0);
    }

    /*隐藏 PopupWindow*/
    public void hidePopWindow() {
        WindowManager.LayoutParams lp = getWindow().getAttributes();
        lp.alpha = 1f; //0.0-1.0
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND);
        getWindow().setAttributes(lp);
        popupWindow.dismiss();
    }


    private View.OnClickListener clickListener = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            switch (v.getId()) {
                case R.id.tv_date:
                    showPopWindow();
                    break;
                case R.id.img_back:
                    finish();
                    break;

                case R.id.tv_cancel:
                    hidePopWindow();
                    break;
                case R.id.tv_ensure:
                    hidePopWindow();
                    Log.e("日期选择", selectDate + "  " + selectIndex);
                    tvDate.setText(Html.fromHtml("<u>" + selectDate + "</u>"));
                    tvReplyCount.setText(String.valueOf(month));
                    currentPage = 1;
                    getReplyList();
                    break;

            }
        }
    };
}

