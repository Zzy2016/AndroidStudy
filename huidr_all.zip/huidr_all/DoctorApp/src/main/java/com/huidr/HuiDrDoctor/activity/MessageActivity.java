package com.huidr.HuiDrDoctor.activity;

import android.app.Activity;
import android.content.ContentValues;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;

import android.text.Html;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.ajguan.library.EasyRefreshLayout;
import com.chad.library.adapter.base.BaseQuickAdapter;
import com.chad.library.adapter.base.BaseViewHolder;
import com.google.android.material.tabs.TabLayout;
import com.huidr.HuiDrDoctor.debug.R;
import com.huidr.HuiDrDoctor.module.model.SysMessage;
import com.huidr.HuiDrDoctor.util.LocalConstants;
import com.huidr.HuiDrDoctor.util.LogUtil;
import com.huidr.lib.commom.util.Toast;
import com.huidr.lib.commom.view.RecycleViewDivider;

import org.greenrobot.eventbus.EventBus;
import org.greenrobot.eventbus.Subscribe;
import org.greenrobot.eventbus.ThreadMode;
import org.litepal.LitePal;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.List;

import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import jiguang.chat.utils.event.BusEventMessage;

import static org.litepal.LitePalApplication.getContext;

/*
 * 系统消息 系统消息保存在本地数据库，
 * 首次打开从数据库加载全部数据，按照page每次读取20条
 *
 * */
public class MessageActivity extends Activity implements View.OnClickListener {

    private ImageView imageViewBack;
    private TabLayout tabType;
    private EasyRefreshLayout mEasyRefreshLayout;
    private RecyclerView mRecyclerView;
    private List<SysMessage> sysMessages;
    private boolean loadAll;
    private int page = 1;
    private TextView textView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_message);
        EventBus.getDefault().register(this);
        initView();
    }


    public void initView() {
        this.imageViewBack = findViewById(R.id.img_activity_left);

        this.mEasyRefreshLayout = findViewById(R.id.sys_msg_easy_refresh);
        this.mRecyclerView = findViewById(R.id.sys_msg_recyclerview);
        this.tabType = findViewById(R.id.tab_type);
        tabType.addTab(tabType.newTab().setText("消息动态"));
        tabType.addTab(tabType.newTab().setText("图文咨询"));

        mRecyclerView.setLayoutManager(new LinearLayoutManager(this));
        sysMessages = new ArrayList<>();
        initSysMessages();

        infoAdapter.addData(getSysPagesByPage(1));
        mRecyclerView.setAdapter(infoAdapter);

        mRecyclerView.addItemDecoration(new RecycleViewDivider(this, LinearLayoutManager.VERTICAL));
        initListener();
    }


    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.img_activity_left:
                finish();
                break;
        }
    }

    @Subscribe(threadMode = ThreadMode.MAIN)
    public void onMessageEvent(BusEventMessage event) {
        if (event.getEventType().equalsIgnoreCase(LocalConstants.REFRESH_SYS_MSG)) {
            initSysMessages();
            page = 1;
            loadAll = false;
            infoAdapter.setNewData(getSysPagesByPage(1));
        }
    }


    @Subscribe(threadMode = ThreadMode.MAIN)
    public void MessageEvent(BusEventMessage event) {
        if (event.getEventType().equalsIgnoreCase(LocalConstants.NOTICE_REDIRECT)) {

            Intent intent1 = new Intent(this, ConsultRecordActivity.class);
            startActivity(intent1);
        }
    }

    private BaseQuickAdapter<SysMessage, BaseViewHolder> infoAdapter = new BaseQuickAdapter<SysMessage, BaseViewHolder>(R.layout.item_layout) {

        @Override
        protected void convert(BaseViewHolder helper, final SysMessage item) {
            helper.setText(R.id.tv_sys_msg_content, item.getSysMsgContent());
            helper.setText(R.id.tv_sys_msg_time, Html.fromHtml("<u>" + item.getTime() + "<u>"));
            String shows = "";

            String time = item.getTime();
            time = time.replace("月", " ");
            time = time.replace("日", " ");
            time = time.replace("   ", " ");
            String[] times = time.split(" ");


            if (times.length >= 3) {
                String[] times1 = times[2].split(":");
                Calendar calendar = Calendar.getInstance();
                int month = calendar.get(Calendar.MONTH) + 1;
                int day = calendar.get(Calendar.DAY_OF_MONTH);
                int hour = calendar.get(Calendar.HOUR);

                if (month == Integer.valueOf(times[0]) && day == Integer.valueOf(times[1])) {
                    if (Integer.valueOf(times1[0]) >= 12) {
                        shows = "下午" + " " + times[2];
                    } else {
                        shows = "上午" + " " + times[2];
                    }
                } else {
                    shows = item.getTime();
                }
                LogUtil.e("通知时间---》", shows);
            }


//            时间
            if (item.getTime() != null) {
//                helper.setText(R.id.text_time, item.getTime());
                helper.setText(R.id.text_time, shows);
            } else {
//                helper.setText(R.id.text_time, "下午 1 : 20");
            }


            if (item.getUrl() != null) {
                helper.itemView.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
//                        SysMessage{sysMsgContent='有患者向您咨询', url='consultingRecord.html', time='11月1日  15:08', readFlag=1}

                        LogUtil.e("点击 url", "==" + item.getUrl() + "----" + item.equals(" ") + "++++" + item.getUrl().length());
                        if (item.getUrl().equals("")) {

                        } else {
                            BusEventMessage busEventMessage = new BusEventMessage(LocalConstants.NOTICE_REDIRECT);
                            busEventMessage.setObject(item.getUrl());
                            EventBus.getDefault().post(busEventMessage);
                        }

//                        if(item.getUrl().length()==0){
//
//                        }else if(item.getUrl().equals("consultingRecord.html")){
//                            Intent intent1 = new Intent(MessageActivity.this, ConsultRecordActivity.class);
//                            startActivity(intent1);
//                        }
                    }
                });
            }

        }

    };


    private void initListener() {
        imageViewBack.setOnClickListener(this);
        /*    */
        mEasyRefreshLayout.addEasyEvent(new EasyRefreshLayout.EasyEvent() {
            /*
             * 加载更多 1+页
             * */
            @Override
            public void onLoadMore() {

                new Handler().postDelayed(new Runnable() {
                    @Override
                    public void run() {


                        if (!loadAll) {
                            page++;
                            int postion = infoAdapter.getData().size();
                            infoAdapter.getData().addAll(getSysPagesByPage(page));
                            infoAdapter.notifyDataSetChanged();
                            mRecyclerView.scrollToPosition(postion);
                        } else {
                            Toast.getInstance(getContext()).show("已加载全部", 0);
                        }
                        mEasyRefreshLayout.closeLoadView();
                    }
                }, 500);

            }

            /*
             * 加载最新页 第一页
             * */
            @Override
            public void onRefreshing() {
                new Handler().postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        initSysMessages();  //从数据库重新加载全部数据，
                        page = 1;
                        loadAll = false;
                        infoAdapter.setNewData(getSysPagesByPage(1));

                        Toast.getInstance(getContext()).show("刷新成功", 0);


                        mEasyRefreshLayout.refreshComplete();

                    }
                }, 1000);

            }
        });
    }

    //page从1开始每次取 20条 从(page -1) *20 to page * 20 取子集
    int pageItems = 20;

    private List<SysMessage> getSysPagesByPage(int page) {

        if (sysMessages.size() > 0) {
            if (sysMessages.size() >= page * pageItems) {

                List<SysMessage> list = new ArrayList<>();
                list.addAll(sysMessages.subList((page - 1) * pageItems, page * pageItems));
                return list;
            } else {
                loadAll = true;

                List<SysMessage> list = new ArrayList<>();
                list.addAll(sysMessages.subList((page - 1) * pageItems, sysMessages.size()));
                //Collections.reverse(list);
                return list;

            }
        }
        return new ArrayList<SysMessage>();
    }


    /*
     * 打开页面时 读取数据库所有消息
     *
     * */
    private void initSysMessages() {
        sysMessages.clear();
        sysMessages.addAll(LitePal.findAll(SysMessage.class));
        Collections.reverse(sysMessages);

        ContentValues contentValues = new ContentValues();
        contentValues.put("readFlag", 1);
        LitePal.updateAll(SysMessage.class, contentValues);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        EventBus.getDefault().unregister(this);
    }

}
