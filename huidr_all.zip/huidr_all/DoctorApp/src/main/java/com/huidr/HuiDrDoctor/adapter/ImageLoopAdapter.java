package com.huidr.HuiDrDoctor.adapter;

import android.content.Context;
import androidx.annotation.NonNull;
import androidx.viewpager.widget.PagerAdapter;
import androidx.viewpager.widget.ViewPager;

import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

import com.huidr.HuiDrDoctor.util.LogUtil;
import com.tendcloud.tenddata.TCAgent;

import java.util.List;

/**
 * @author: Administrator
 * @date: 2019-11-13
 */
public class ImageLoopAdapter extends PagerAdapter {

    private ViewPager viewPager;
    private List<ImageView> imageViews;
    private Context context;

    public ImageLoopAdapter(ViewPager viewPager, List<ImageView> imageViews, Context context) {
        this.viewPager = viewPager;
        this.imageViews = imageViews;
        this.context = context;
    }

    public ImageLoopAdapter(ViewPager viewPager, List<ImageView> imageViews) {
        this.viewPager = viewPager;
        this.imageViews = imageViews;
    }

    @Override
    public int getCount() {
        return Integer.MAX_VALUE;
    }

    @Override
    public boolean isViewFromObject(@NonNull View view, @NonNull Object o) {
        return view == o;
    }

    @NonNull
    @Override
    public Object instantiateItem(@NonNull ViewGroup container, final int position) {
//        return super.instantiateItem(container, position);
        ImageView iv = imageViews.get(position % imageViews.size());

        iv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                LogUtil.e("消息页Banner", position + "  ");
                TCAgent.onEvent(context, "医生点击banner跳转页面的次数", "医生点击banner跳转页面的次数");
            }
        });

        if (iv.getParent() != null) {
            ((ViewPager) imageViews.get(position % imageViews.size()).getParent()).removeView(imageViews.get(position % imageViews.size()));
        }
        viewPager.addView(iv);

        return iv;
    }

    @Override
    public void destroyItem(@NonNull ViewGroup container, int position, @NonNull Object object) {
//        super.destroyItem(container, position, object);
        viewPager.removeView(imageViews.get(position % imageViews.size()));
    }


}
