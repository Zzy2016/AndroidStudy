package com.huidr.HuiDrDoctor.follow_fragment;

import android.app.Dialog;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import android.text.Html;
import android.util.Log;
import android.view.Display;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.ImageView;
import android.widget.TextView;

import com.alibaba.fastjson.JSONObject;
import com.chad.library.adapter.base.BaseQuickAdapter;
import com.chad.library.adapter.base.BaseViewHolder;
import com.google.gson.Gson;
import com.huidr.HuiDrDoctor.activity.WebActivity;
import com.huidr.HuiDrDoctor.activity.main.Consult.utils.PostAndGet;
import com.huidr.HuiDrDoctor.debug.BuildConfig;
import com.huidr.HuiDrDoctor.debug.R;
import com.huidr.HuiDrDoctor.module.home.RecentFollowModel;
import com.huidr.HuiDrDoctor.module.home.SimpleResultModel;
import com.huidr.HuiDrDoctor.util.LogUtil;
import com.huidr.HuiDrDoctor.util.ThreadPoolManager;
import com.huidr.lib.commom.base.BaseFragment;
import com.huidr.lib.commom.base.HuidrActivityManager;
import com.scwang.smartrefresh.layout.SmartRefreshLayout;
import com.scwang.smartrefresh.layout.api.RefreshLayout;
import com.scwang.smartrefresh.layout.listener.OnLoadMoreListener;
import com.scwang.smartrefresh.layout.listener.OnRefreshListener;
import com.zyao89.view.zloading.ZLoadingDialog;
import com.zyao89.view.zloading.Z_TYPE;

import java.util.ArrayList;
import java.util.List;

import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import jiguang.chat.utils.oss.SharedPreferenciesUtil;

/**
 * 最近查看
 * 头像，患者姓名，住院号，时间，状态，所匹配模板（默认显示18个端，第18个字段为省略号）
 * <p>
 * 分页获取每页20条 倒序
 * <p>
 * 跳转
 * 1.从随访患者获取到的跳转患者随访列表 *
 * 2.从住院患者，关注患者，全部患者获取到的跳转患者资料
 */
public class RecentFragment extends BaseFragment {


    SmartRefreshLayout smartRefreshLayout;
    RecyclerView rvListRecent;

    ConstraintLayout clEmpty;
    TextView tvEmpty1, tvEmpty2;

    List<RecentFollowModel.RetValueBean> allRecentList;
    List<RecentFollowModel.RetValueBean> tempRecentList;//缓存列表

    RecentFollowModel recentFollowModel;
    Gson gson;
    private int currentPage = 1;
    private int totalPage = 1;

    long lastClick = 0;
    ZLoadingDialog zLoadingDialog;

    @Override
    protected void initData() {
        recentFollowModel = new RecentFollowModel();
        gson = new Gson();
        allRecentList = new ArrayList<>();
        tempRecentList = new ArrayList<>();
        recentAdapter.setNewData(allRecentList);
    }


    /*
     * 使用ViewPager和FragmentPagerFragment  切换Fragment时会调用setUserVisibleHint 判断isVisibleToUser
     * boolean值 可以刷新数据
     * */
    @Override
    public void setUserVisibleHint(boolean isVisibleToUser) {
        super.setUserVisibleHint(isVisibleToUser);

        if (isVisibleToUser) {
            zLoadingDialog = new ZLoadingDialog(HuidrActivityManager.getInstance().getCurrentActivity());
            zLoadingDialog.setLoadingBuilder(Z_TYPE.STAR_LOADING)//设置类型
                    .setLoadingColor(Color.BLUE)//颜色
                    .setHintText("正在加载,请稍候...").setHintTextSize(16) // 设置字体大小 dp
                    .setHintTextColor(Color.GRAY)  // 设置字体颜色
                    .setDurationTime(0.5) // 设置动画时间百分比 - 0.5倍
                    .setCanceledOnTouchOutside(false).setCancelable(false).show();
            Log.e("Dialog-RecentPatient","show");
            getDataByPage();
        } else {

            if(zLoadingDialog!=null){
                zLoadingDialog.dismiss();
            }


            recentAdapter.notifyDataSetChanged();
        }
    }


    @Override
    protected View setContentView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_recent, container, false);
    }

    @Override
    protected void findView(View parent) {
        smartRefreshLayout = parent.findViewById(R.id.srl_layout);

        smartRefreshLayout.setEnableRefresh(true);
        smartRefreshLayout.setEnableLoadMore(true);

        smartRefreshLayout.setOnRefreshListener(new OnRefreshListener() {
            @Override
            public void onRefresh(@NonNull RefreshLayout refreshLayout) {
                currentPage = 1;
                getDataByPage();
            }
        });

        smartRefreshLayout.setOnLoadMoreListener(new OnLoadMoreListener() {
            @Override
            public void onLoadMore(@NonNull RefreshLayout refreshLayout) {
                if (tempRecentList.size() == 20 && currentPage < totalPage) {
                    currentPage += 1;
                    getDataByPage();
                } else {
                    com.huidr.lib.commom.util.Toast.getInstance(getActivity()).show("数据加载全部", 500);
                    smartRefreshLayout.finishLoadMore();
                }


            }
        });

        rvListRecent = parent.findViewById(R.id.rv_list_recent);
        rvListRecent.setAdapter(recentAdapter);
        rvListRecent.setLayoutManager(new LinearLayoutManager(getActivity()));


        clEmpty = parent.findViewById(R.id.cl_empty);
        tvEmpty1 = parent.findViewById(R.id.tv_empty1);
        tvEmpty2 = parent.findViewById(R.id.tv_empty2);

        tvEmpty2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (tvEmpty2.getText().toString().equals("立即刷新")) {
                    currentPage = 1;
                    getDataByPage();
                }
            }
        });


    }

    /*
     * 加载数据完成 刷新页面
     * 1  刷新页面  加载第一页
     * 2  加载更多页
     * 3  空态页     *
     * */
    private Handler handler = new Handler() {
        @Override
        public void handleMessage(Message msg) {
            super.handleMessage(msg);
            switch (msg.what) {

                case 1:
                    if (zLoadingDialog != null) {
                        new Handler().postDelayed(new Runnable() {
                            @Override
                            public void run() {
                                zLoadingDialog.dismiss();
                                zLoadingDialog = null;
                            }
                        }, 500);
                    }
                    recentAdapter.getData().clear();
//                    tempRecentList==0  显示空态页
                    if (tempRecentList.size() == 0) {
                        clEmpty.setVisibility(View.VISIBLE);
                        smartRefreshLayout.setVisibility(View.GONE);
                        String tip1 = "您还未关注患者";
                        String tip2 = "左滑患者列表即可关注";
                        tvEmpty1.setText(tip1);
                        tvEmpty2.setText(tip2);
                    } else {
                        clEmpty.setVisibility(View.GONE);
                        smartRefreshLayout.setVisibility(View.VISIBLE);

                        recentAdapter.getData().addAll(tempRecentList);
                        recentAdapter.notifyDataSetChanged();
                    }
                    smartRefreshLayout.finishRefresh();
                    break;
                case 2:
                    recentAdapter.getData().addAll(tempRecentList);
                    recentAdapter.notifyDataSetChanged();
                    smartRefreshLayout.finishLoadMore();
                    break;
                case 3:
                    if (zLoadingDialog != null) {
                        zLoadingDialog.dismiss();
                    }
                    clEmpty.setVisibility(View.VISIBLE);
                    smartRefreshLayout.setVisibility(View.GONE);
                    String tip1 = "网络错误~";
                    String tip2 = "<font color='#248cfa'><u>立即刷新<u></font>";
                    tvEmpty1.setText(tip1);
                    tvEmpty2.setText(Html.fromHtml(tip2));
                    smartRefreshLayout.finishLoadMore();
                    smartRefreshLayout.finishRefresh();
                    break;

                case 4:
                    String tip = "";
                    Boolean atten = (Boolean) msg.obj;
                    if (atten) {
                        tip = "关注患者成功";
                        recentAdapter.getData().get(msg.arg1).setIsFollow(true);
                    } else {
                        tip = "取消成功";
                        recentAdapter.getData().get(msg.arg1).setIsFollow(false);
                    }
                    com.huidr.lib.commom.util.Toast.getInstance(getActivity()).show(tip, 500);
                    recentAdapter.notifyDataSetChanged();

                    break;
                case 5:
                    String str = "";
                    Boolean atten1 = (Boolean) msg.obj;
                    if (atten1) {
                        str = "关注患者失败";
                    } else {
                        str = "取消失败";
                    }
                    com.huidr.lib.commom.util.Toast.getInstance(getActivity()).show(str, 500);
                    recentAdapter.notifyDataSetChanged();
                    break;
            }
        }
    };


    //  根据关系类型  设置默认图片
    public void setPatientImage(ImageView image, String ship, int sex) {
        if (ship == null) {
            image.setBackgroundResource(R.drawable.head_patient);
            return;
        }
        switch (ship) {
            case "本人":
                if (sex == 1) {
                    image.setBackgroundResource(R.drawable.my_him);
                } else {
                    image.setBackgroundResource(R.drawable.my_her);
                }
                break;
            case "丈夫":
                image.setBackgroundResource(R.drawable.husband);
                break;
            case "妻子":
                image.setBackgroundResource(R.drawable.wife);
                break;
            case "爸爸":
                image.setBackgroundResource(R.drawable.papa);
                break;
            case "妈妈":
                image.setBackgroundResource(R.drawable.mama);
                break;
            case "儿子":
                image.setBackgroundResource(R.drawable.son);
                break;
            case "女儿":
                image.setBackgroundResource(R.drawable.daughter);
                break;
            case "其他":
                image.setBackgroundResource(R.drawable.head_patient);
                break;
            default:
                image.setBackgroundResource(R.drawable.head_patient);
                break;
        }
    }


    //    最近查看适配
    private BaseQuickAdapter<RecentFollowModel.RetValueBean, BaseViewHolder> recentAdapter = new BaseQuickAdapter<RecentFollowModel.RetValueBean, BaseViewHolder>(R.layout.item_patient_scroll_layout) {
        @Override
        protected void convert(final BaseViewHolder helper, final RecentFollowModel.RetValueBean item) {


            //            头像
            ImageView imgItemHead = helper.getView(R.id.img_item_head);

            setPatientImage(imgItemHead, item.getBindUserRelationship(), item.getUserSex());


//            提醒
            ImageView imgNotice = helper.getView(R.id.img_notice);
            imgNotice.setVisibility(View.GONE);
//            姓名
            TextView tvItemName = helper.getView(R.id.tv_item_name);
            tvItemName.setText(item.getUserName());
//            住院号
            TextView tvPatientNum = helper.getView(R.id.tv_patient_num);

            if (item.getLatelyAdmitNo() != null) {
                tvPatientNum.setText(item.getLatelyAdmitNo() + "");
            } else {
                tvPatientNum.setText("");
            }

//            日期
            TextView tvItemDate = helper.getView(R.id.tv_item_date);


            if (item.getLatelyVisitingDate() != null) {
                tvItemDate.setText(item.getLatelyVisitingDate());
            } else {
                tvItemDate.setText(item.getLatelyDischargeTime());
            }

//            if(item.getLatelyDischargeTime()==null){
//
//            }else{
//
//            }
//            状态
            TextView tvItemMsg = helper.getView(R.id.tv_item_msg);

            if (item.getLatelyAdmissionDiagnosis() != null) {
                tvItemMsg.setText(item.getLatelyAdmissionDiagnosis());
            } else {
                tvItemMsg.setText(item.getLatelyDischargeDiagnosis());
            }


//            模板
            TextView tvModel = helper.getView(R.id.tv_model);
            tvModel.setText(item.getFollowupName());


            TextView tvRight = helper.getView(R.id.tv_scroll_right);

            if (item.isIsFollow()) {
                String str = "<font>已<br>关注</font>";
                tvRight.setText(Html.fromHtml(str));
                tvRight.setBackgroundResource(R.drawable.shape_atten_gray);
            } else {
                String str = "<font>关注<br>患者</font>";
                tvRight.setText(Html.fromHtml(str));
                tvRight.setBackgroundResource(R.drawable.shape_attent_blue);
            }

            tvRight.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
//                    已经关注  取下关注
                    if (item.isIsFollow()) {
//                        modifyAttent(false, helper.getAdapterPosition(), item.getId());
//                        recentAdapter.notifyDataSetChanged();
                        recentAdapter.notifyItemChanged(helper.getAdapterPosition());
                        com.huidr.lib.commom.util.Toast.getInstance(getContext()).show("该患者已关注", 500);
                    } else {//为关注  关注患者
//                        modifyAttent(true, helper.getAdapterPosition(), item.getId());
                        showCoopDialog(true, helper.getAdapterPosition(), item.getId());

                    }

                }
            });

            ConstraintLayout clItem = helper.getView(R.id.cl_item);

//1.从随访患者获取到的跳转患者随访列表
//
//2.从住院患者，关注患者，全部患者获取到的跳转患者资料
//
            clItem.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (System.currentTimeMillis() - lastClick > 1000) {
                        JSONObject jsonObject = new JSONObject();
                        jsonObject.put("id", item.getId());
                        SharedPreferenciesUtil.putData("psearchID", jsonObject.toJSONString());
                        SharedPreferenciesUtil.putData("followDoctorId", item.getDoctorId());

                        Intent intent1 = new Intent(getActivity(), WebActivity.class);
                        Bundle bundle = new Bundle();
                        bundle.putString("url", "patientData.html");
                        intent1.putExtras(bundle);
                        startActivity(intent1);
                        lastClick = System.currentTimeMillis();
                    }
                }
            });


        }
    };


    //    取消添加协同对话框
    public void showCoopDialog(final boolean atten, final int position, final int patientId) {

        final Dialog builder = new Dialog(getContext(), R.style.jmui_default_dialog_style);
        //final Dialog builder = new Dialog(this, R.style.jmui_default_dialog_style);
        View view = LayoutInflater.from(getContext()).inflate(R.layout.dialog_content, null);

        TextView tvTitle = view.findViewById(R.id.tv_title);
        TextView tvFooter1 = view.findViewById(R.id.tv_footer1);
        TextView tvFooter2 = view.findViewById(R.id.tv_footer2);

        tvTitle.setText("是否关注该患者！");


//        取消
        tvFooter1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                builder.cancel();
                recentAdapter.notifyItemChanged(position);

            }
        });
//确定
        tvFooter2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                builder.cancel();
                modifyAttent(atten, position, patientId);
                recentAdapter.notifyItemChanged(position);
            }
        });

        builder.setContentView(view);
        //builder.setCanceledOnTouchOutside(true);
        builder.show();
        Window window = builder.getWindow();
        WindowManager.LayoutParams lp = window.getAttributes();
        WindowManager windowManager = getActivity().getWindowManager();
        Display display = windowManager.getDefaultDisplay();
        lp.width = (int) (display.getWidth() * 0.7);
//        lp.height = (int) (display.getHeight() * 0.1);
        window.setAttributes(lp);
    }


    //    关注患者 取消关注
    /*
     * atten 关注 取消
     * position  列表index
     * patientId  患者ID
     * */
    public void modifyAttent(final boolean atten, final int position, final int patientId) {
        ThreadPoolManager.getInstance().execute(new Runnable() {
            @Override
            public void run() {
                String id = (String) SharedPreferenciesUtil.getData("id", "0");
//                String path = BuildConfig.baseUrl + "patient/doctorPatientMedical/addRemarksAndFollow?doctorId=" + id + "&patientId=" + patientId + "&isFollow=" + atten;
//                String path = "http://192.168.1.180:196/doctorPatientMedical/addRemarksAndFollow?doctorId=" + id + "&patientId=" + patientId + "&isFollow=" + atten;
                String path = BuildConfig.baseUrl + "patient/doctorPatientMedical/addRemarksAndFollow?doctorId=" + id + "&patientId=" + patientId + "&isFollow=" + atten;
                String result = PostAndGet.doGetHttp(path);

                LogUtil.e("关注", result);
                if (result.equals("网络异常")) {

                } else {
                    SimpleResultModel simpleResultModel = gson.fromJson(result, SimpleResultModel.class);
                    Message message = new Message();
                    message.obj = atten;
                    if (simpleResultModel.getStatus() == 0) {
                        message.what = 4;
                        message.arg1 = position;
                        handler.sendMessage(message);
                    } else {
                        message.what = 5;
                        handler.sendMessage(message);
                    }
                }

            }
        });
    }


    //    页面不可见的时候 刷新页面  关闭打开的item
//    @Override
//    public void onStop() {
//        super.onStop();
//        recentAdapter.notifyDataSetChanged();
//    }

    //    分页获取数据
    public void getDataByPage() {
        ThreadPoolManager.getInstance().execute(new Runnable() {
            @Override
            public void run() {
                String id = (String) SharedPreferenciesUtil.getData("id", "0");
//                String path = "http://192.168.1.180:196/doctorPatientMedical/getPatientByRecently";
                String path = BuildConfig.baseUrl + "patient/doctorPatientMedical/getPatientByRecently";


                JSONObject jsonObject = new JSONObject();
                jsonObject.put("doctorId", id);
                jsonObject.put("pageIndex", currentPage);
                jsonObject.put("pageSize", 20);

                String result = PostAndGet.doHttpPost(path, jsonObject);
                recentFollowModel = new RecentFollowModel();

                LogUtil.e("最近查看--》", result);
                if (result == null && result.equals("网络异常")) {
                    handler.sendEmptyMessage(3);
                } else {
                    recentFollowModel = gson.fromJson(result, RecentFollowModel.class);
                    if (recentFollowModel.getStatus() == 0) {
                        totalPage = recentFollowModel.getTotalPage();
                        if (currentPage == 1) {
                            tempRecentList = recentFollowModel.getRetValue();
                            handler.sendEmptyMessage(1);
                        } else {
                            handler.sendEmptyMessage(2);
                        }
                    } else {
                        handler.sendEmptyMessage(3);
                    }
                }
            }
        });
    }


//    String[] tips;//标签数组
//    int[] tipTypes;//标签类型数组
//
//
//    TabLayout tlTipRecent;
//    ImageView imageTip;
//    ScrollPageView vpRecent;
//
//    List<Fragment> listFragment;
//
//    RecentFragmentAdapter recentFragmentAdapter;
//
//    PatientsModel patientsModel;
//
//
//
//
//    @Override
//    protected void initData() {
//        patientsModel = new PatientsModel();
//    }
//
//
//
//
//
//
//    /*
//     * 使用ViewPager和FragmentPagerFragment  切换Fragment时会调用setUserVisibleHint 判断isVisibleToUser
//     * boolean值 可以刷新数据
//     * */
//    @Override
//    public void setUserVisibleHint(boolean isVisibleToUser) {
//        super.setUserVisibleHint(isVisibleToUser);
//        tips = getArguments().getStringArray("tip");
//        tipTypes = getArguments().getIntArray("tipType");
//        if (isVisibleToUser) {
////            tips = getArguments().getStringArray("tip");
////            tipTypes = getArguments().getIntArray("tipType");
//        }
//    }
//
//    class RecentFragmentAdapter extends FragmentPagerAdapter {
//
//        public RecentFragmentAdapter(FragmentManager fm) {
//            super(fm);
//        }
//
//
//        @Override
//        public Fragment getItem(int i) {
//            return listFragment.get(i);
//        }
//
//        @Override
//        public int getCount() {
//            return listFragment.size();
//        }
//
//        @Nullable
//        @Override
//        public CharSequence getPageTitle(int position) {
//            if (tips[position].length() <= 4) {
//                return tips[position];
//            } else {
//                String tip = tips[position];
//                tip = tip.substring(0, 4);
//                tip = tip.concat("...");
//                return tip;
//            }
//
//        }
//    }
//
//
//    @Override
//    protected View setContentView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
//        return inflater.inflate(R.layout.fragment_recent, container, false);
//    }
//
//    @Override
//    protected void findView(View parent) {
//        Log.e("RecentFragment1", "findView");
//
//        tlTipRecent = parent.findViewById(R.id.tl_tip_recent);
//        imageTip = parent.findViewById(R.id.img_tip);
//        vpRecent = parent.findViewById(R.id.vp_recent);
//
//
//        imageTip.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                if (MulityClickUtils.isFastClick()) {
//                    Intent intent = new Intent(getActivity(), WebActivity.class);
//                    Bundle bundle = new Bundle();
//                    bundle.putString("url", "patientData_setTagsNew.html");
//                    intent.putExtras(bundle);
//                    startActivity(intent);
//                }
//            }
//        });
//
//        listFragment = new ArrayList<>();
//
//
//        for (int i = 0; i < tips.length; i++) {
//            Log.e("最近查看收到的标签", tips[i]);
//            GeneralFragment generalFragment = GeneralFragment.newInstance_Fragment(tips[i], tipTypes[i]);
//            listFragment.add(generalFragment);
//        }
//
//        recentFragmentAdapter = new RecentFragmentAdapter(getChildFragmentManager());
//        vpRecent.setAdapter(recentFragmentAdapter);
//        tlTipRecent.setupWithViewPager(vpRecent);
//
//        tlTipRecent.setOnTabSelectedListener(new TabLayout.OnTabSelectedListener() {
//            @Override
//            public void onTabSelected(TabLayout.Tab tab) {
//                int position = tab.getPosition();
//
//                tab.setText(tips[position]);
//                vpRecent.setCurrentItem(position,false);
//            }
//
//            @Override
//            public void onTabUnselected(TabLayout.Tab tab) {
//                int position = tab.getPosition();
//                if (tips[position].length() <= 4) {
//                    tab.setText(tips[position]);
//                } else {
//                    String tip = tips[position];
//                    tip = tip.substring(0, 4);
//                    tip = tip.concat("...");
//                    tab.setText(tip);
//                }
//
//            }
//
//            @Override
//            public void onTabReselected(TabLayout.Tab tab) {
//
//            }
//        });
//    }
}
