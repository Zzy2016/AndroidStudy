package com.huidr.HuiDrDoctor.module.model;

/**
 * @author: Administrator
 * @date: 2019-11-12
 */
public class ConsultSet {

    /**
     * status : 0
     * retValue : {"enable":false,"price":10000,"enableLimitOneDay":false,"limitOneDay":100,"enableLimitTime":true,"limitEndTime":82800,"limitStartTime":0,"hasPayPassword":true}
     */

    private int status;
    private RetValueBean retValue;

    public int getStatus() {
        return status;
    }

    public void setStatus(int status) {
        this.status = status;
    }

    public RetValueBean getRetValue() {
        return retValue;
    }

    public void setRetValue(RetValueBean retValue) {
        this.retValue = retValue;
    }

    public static class RetValueBean {
        /**
         * enable : false
         * price : 10000
         * enableLimitOneDay : false
         * limitOneDay : 100
         * enableLimitTime : true
         * limitEndTime : 82800
         * limitStartTime : 0
         * hasPayPassword : true
         */

        private boolean enable;
        private int price;
        private boolean enableLimitOneDay;
        private int limitOneDay;
        private boolean enableLimitTime;
        private int limitEndTime;
        private int limitStartTime;
        private boolean hasPayPassword;

        public boolean isEnable() {
            return enable;
        }

        public void setEnable(boolean enable) {
            this.enable = enable;
        }

        public int getPrice() {
            return price;
        }

        public void setPrice(int price) {
            this.price = price;
        }

        public boolean isEnableLimitOneDay() {
            return enableLimitOneDay;
        }

        public void setEnableLimitOneDay(boolean enableLimitOneDay) {
            this.enableLimitOneDay = enableLimitOneDay;
        }

        public int getLimitOneDay() {
            return limitOneDay;
        }

        public void setLimitOneDay(int limitOneDay) {
            this.limitOneDay = limitOneDay;
        }

        public boolean isEnableLimitTime() {
            return enableLimitTime;
        }

        public void setEnableLimitTime(boolean enableLimitTime) {
            this.enableLimitTime = enableLimitTime;
        }

        public int getLimitEndTime() {
            return limitEndTime;
        }

        public void setLimitEndTime(int limitEndTime) {
            this.limitEndTime = limitEndTime;
        }

        public int getLimitStartTime() {
            return limitStartTime;
        }

        public void setLimitStartTime(int limitStartTime) {
            this.limitStartTime = limitStartTime;
        }

        public boolean isHasPayPassword() {
            return hasPayPassword;
        }

        public void setHasPayPassword(boolean hasPayPassword) {
            this.hasPayPassword = hasPayPassword;
        }
    }
}
