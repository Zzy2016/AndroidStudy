package com.huidr.HuiDrDoctor.module.home;

import java.util.List;

/**
 * @author: Administrator
 * @date: 2019-12-09
 */
public class MessageSearchModel {


    /**
     * status : 0
     * retValue : {"patient":[{"id":45846,"userName":"沈铭昌","userSex":1,"userBirth":"1930-05-10","latelyAdmitNo":"692170","latelyBed":"13","bindUserRelationship":"本人","latelyAdmissionDiagnosis":"结直肠恶性肿瘤伴肝转移,肺转移性肿瘤,高血压,前列腺增生","latelyDischargeDiagnosis":"结直肠恶性肿瘤伴肝转移,肺转移性肿瘤(IV期),高血压,前列腺增生","latelyDischargeTime":"2019-04-24","latelyVisitingDate":"2019-04-23","doctorId":100137,"bindUid":141024,"followupState":2,"isFollow":false}],"doctor":[{"id":140352,"userName":"沈振斌","userIcon":"140352/doctor/1575947817726.png","userSex":1,"userTitle":"副主任医师","hospitalName":"复旦大学附属中山医院","hospitalDepartment":"普外科","fabulousCount":0,"patientCount":1276,"consultation":2,"consultPrice":100,"isFollowup":true}],"article":[],"problem":[]}
     */

    private int status;
    private RetValueBean retValue;

    public int getStatus() {
        return status;
    }

    public void setStatus(int status) {
        this.status = status;
    }

    public RetValueBean getRetValue() {
        return retValue;
    }

    public void setRetValue(RetValueBean retValue) {
        this.retValue = retValue;
    }

    public static class RetValueBean {
        private List<PatientBean> patient;
        private List<DoctorBean> doctor;
        private List<?> article;
        private List<?> problem;

        public List<PatientBean> getPatient() {
            return patient;
        }

        public void setPatient(List<PatientBean> patient) {
            this.patient = patient;
        }

        public List<DoctorBean> getDoctor() {
            return doctor;
        }

        public void setDoctor(List<DoctorBean> doctor) {
            this.doctor = doctor;
        }

        public List<?> getArticle() {
            return article;
        }

        public void setArticle(List<?> article) {
            this.article = article;
        }

        public List<?> getProblem() {
            return problem;
        }

        public void setProblem(List<?> problem) {
            this.problem = problem;
        }

        public static class PatientBean {
            /**
             * id : 45846
             * userName : 沈铭昌
             * userSex : 1
             * userBirth : 1930-05-10
             * latelyAdmitNo : 692170
             * latelyBed : 13
             * bindUserRelationship : 本人
             * latelyAdmissionDiagnosis : 结直肠恶性肿瘤伴肝转移,肺转移性肿瘤,高血压,前列腺增生
             * latelyDischargeDiagnosis : 结直肠恶性肿瘤伴肝转移,肺转移性肿瘤(IV期),高血压,前列腺增生
             * latelyDischargeTime : 2019-04-24
             * latelyVisitingDate : 2019-04-23
             * doctorId : 100137
             * bindUid : 141024
             * followupState : 2
             * isFollow : false
             */

            private int id;
            private String userName;
            private int userSex;
            private String userBirth;
            private String latelyAdmitNo;
            private String latelyBed;
            private String bindUserRelationship;
            private String latelyAdmissionDiagnosis;
            private String latelyDischargeDiagnosis;
            private String latelyDischargeTime;
            private String latelyVisitingDate;
            private int doctorId;
            private int bindUid;
            private int followupState;
            private boolean isFollow;

            public int getId() {
                return id;
            }

            public void setId(int id) {
                this.id = id;
            }

            public String getUserName() {
                return userName;
            }

            public void setUserName(String userName) {
                this.userName = userName;
            }

            public int getUserSex() {
                return userSex;
            }

            public void setUserSex(int userSex) {
                this.userSex = userSex;
            }

            public String getUserBirth() {
                return userBirth;
            }

            public void setUserBirth(String userBirth) {
                this.userBirth = userBirth;
            }

            public String getLatelyAdmitNo() {
                return latelyAdmitNo;
            }

            public void setLatelyAdmitNo(String latelyAdmitNo) {
                this.latelyAdmitNo = latelyAdmitNo;
            }

            public String getLatelyBed() {
                return latelyBed;
            }

            public void setLatelyBed(String latelyBed) {
                this.latelyBed = latelyBed;
            }

            public String getBindUserRelationship() {
                return bindUserRelationship;
            }

            public void setBindUserRelationship(String bindUserRelationship) {
                this.bindUserRelationship = bindUserRelationship;
            }

            public String getLatelyAdmissionDiagnosis() {
                return latelyAdmissionDiagnosis;
            }

            public void setLatelyAdmissionDiagnosis(String latelyAdmissionDiagnosis) {
                this.latelyAdmissionDiagnosis = latelyAdmissionDiagnosis;
            }

            public String getLatelyDischargeDiagnosis() {
                return latelyDischargeDiagnosis;
            }

            public void setLatelyDischargeDiagnosis(String latelyDischargeDiagnosis) {
                this.latelyDischargeDiagnosis = latelyDischargeDiagnosis;
            }

            public String getLatelyDischargeTime() {
                return latelyDischargeTime;
            }

            public void setLatelyDischargeTime(String latelyDischargeTime) {
                this.latelyDischargeTime = latelyDischargeTime;
            }

            public String getLatelyVisitingDate() {
                return latelyVisitingDate;
            }

            public void setLatelyVisitingDate(String latelyVisitingDate) {
                this.latelyVisitingDate = latelyVisitingDate;
            }

            public int getDoctorId() {
                return doctorId;
            }

            public void setDoctorId(int doctorId) {
                this.doctorId = doctorId;
            }

            public int getBindUid() {
                return bindUid;
            }

            public void setBindUid(int bindUid) {
                this.bindUid = bindUid;
            }

            public int getFollowupState() {
                return followupState;
            }

            public void setFollowupState(int followupState) {
                this.followupState = followupState;
            }

            public boolean isIsFollow() {
                return isFollow;
            }

            public void setIsFollow(boolean isFollow) {
                this.isFollow = isFollow;
            }
        }

        public static class DoctorBean {
            /**
             * id : 140352
             * userName : 沈振斌
             * userIcon : 140352/doctor/1575947817726.png
             * userSex : 1
             * userTitle : 副主任医师
             * hospitalName : 复旦大学附属中山医院
             * hospitalDepartment : 普外科
             * fabulousCount : 0
             * patientCount : 1276
             * consultation : 2
             * consultPrice : 100
             * isFollowup : true
             */

            private int id;
            private String userName;
            private String userIcon;
            private int userSex;
            private String userTitle;
            private String hospitalName;
            private String hospitalDepartment;
            private int fabulousCount;
            private int patientCount;
            private int consultation;
            private int consultPrice;
            private boolean isFollowup;

            public int getId() {
                return id;
            }

            public void setId(int id) {
                this.id = id;
            }

            public String getUserName() {
                return userName;
            }

            public void setUserName(String userName) {
                this.userName = userName;
            }

            public String getUserIcon() {
                return userIcon;
            }

            public void setUserIcon(String userIcon) {
                this.userIcon = userIcon;
            }

            public int getUserSex() {
                return userSex;
            }

            public void setUserSex(int userSex) {
                this.userSex = userSex;
            }

            public String getUserTitle() {
                return userTitle;
            }

            public void setUserTitle(String userTitle) {
                this.userTitle = userTitle;
            }

            public String getHospitalName() {
                return hospitalName;
            }

            public void setHospitalName(String hospitalName) {
                this.hospitalName = hospitalName;
            }

            public String getHospitalDepartment() {
                return hospitalDepartment;
            }

            public void setHospitalDepartment(String hospitalDepartment) {
                this.hospitalDepartment = hospitalDepartment;
            }

            public int getFabulousCount() {
                return fabulousCount;
            }

            public void setFabulousCount(int fabulousCount) {
                this.fabulousCount = fabulousCount;
            }

            public int getPatientCount() {
                return patientCount;
            }

            public void setPatientCount(int patientCount) {
                this.patientCount = patientCount;
            }

            public int getConsultation() {
                return consultation;
            }

            public void setConsultation(int consultation) {
                this.consultation = consultation;
            }

            public int getConsultPrice() {
                return consultPrice;
            }

            public void setConsultPrice(int consultPrice) {
                this.consultPrice = consultPrice;
            }

            public boolean isIsFollowup() {
                return isFollowup;
            }

            public void setIsFollowup(boolean isFollowup) {
                this.isFollowup = isFollowup;
            }
        }
    }
}
