package com.huidr.HuiDrDoctor.module.base;

import android.os.Bundle;

import com.huidr.HuiDrDoctor.MainApplication;
import com.huidr.lib.commom.base.BaseSwipeBackActivity;

/**
 * Activity父类，初始化了ApplicationDelegate
 * Created by Laiyimin on 2016/12/9.
 */

public abstract class BaseDrBackActivity extends BaseSwipeBackActivity {

    protected MainApplication mApplication;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        mApplication = (MainApplication) MainApplication.getInstance();
        super.onCreate(savedInstanceState);
    }
}
