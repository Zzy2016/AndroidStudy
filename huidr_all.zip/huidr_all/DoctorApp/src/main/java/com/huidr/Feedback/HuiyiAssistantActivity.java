package com.huidr.Feedback;

import android.os.Bundle;


import com.alibaba.sdk.android.feedback.impl.FeedbackAPI;
import com.huidr.HuiDrDoctor.debug.R;

import java.util.concurrent.Callable;

import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentActivity;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

/**
 *
 */
public class HuiyiAssistantActivity extends FragmentActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_fragment);

        FeedbackAPI.activity = this; // 设置activity

        FragmentManager fm = getSupportFragmentManager();
        final FragmentTransaction transaction = fm.beginTransaction();
        final Fragment feedback = FeedbackAPI.getFeedbackFragment();
        // must be called
        FeedbackAPI.setFeedbackFragment(new Callable() {
            @Override
            public Object call() throws Exception {
                transaction.replace(R.id.content, feedback);
                transaction.commit();
                return null;
            }
        }, null);

        FeedbackAPI.setTranslucent(false);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        FeedbackAPI.cleanFeedbackFragment();
        FeedbackAPI.cleanActivity();
    }
}
