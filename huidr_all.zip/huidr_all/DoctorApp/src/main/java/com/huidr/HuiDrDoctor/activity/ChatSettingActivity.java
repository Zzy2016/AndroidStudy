package com.huidr.HuiDrDoctor.activity;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import com.activeandroid.query.Select;
import com.huidr.HuiDrDoctor.debug.R;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import cn.jpush.im.android.api.JMessageClient;
import cn.jpush.im.android.api.model.Conversation;
import cn.jpush.im.android.api.model.UserInfo;
import cn.jpush.im.api.BasicCallback;
import jiguang.chat.database.FriendEntry;
import jiguang.chat.utils.SharePreferenceManager;
import jiguang.chat.utils.SortConvList;
import jiguang.chat.utils.SortTopConvList;

import static jiguang.chat.activity.ChatActivity.TARGET_ID;

public class ChatSettingActivity extends Activity implements View.OnClickListener {

    private ImageView imgReturnBack;
    private ImageView imageViewUserHeadIcon;
    private TextView textViewUserName;
    private TextView textViewUserTitle;
    private TextView textViewUserDepartment;
    private TextView textViewClearMessage;
    private Switch switchMessageIgnore;
    private Switch switchToTop;
    private List<FriendEntry> friendEntries;
    private String targetId;
    private UserInfo userInfo;
    private Conversation conversation;
    private boolean imgIgnore;
    private boolean toTop;
    private SharedPreferences sharedPreferences;
    private SharedPreferences.Editor editor;
    private List<Conversation> mDatas = new ArrayList<>();
    List<Conversation> topConv = new ArrayList<>();
    List<Conversation> forCurrent = new ArrayList<>();
    List<Conversation> delFeedBack = new ArrayList<>();
    private RelativeLayout doctor_message;

    long lastClickDoctor;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_chat_setting);
        Intent intent = getIntent();
        targetId = intent.getStringExtra(TARGET_ID);

        mDatas = JMessageClient.getConversationList(); //所有会话
        conversation = JMessageClient.getSingleConversation(targetId);//当前会话

        sharedPreferences = this.getSharedPreferences("messageStatusAndToTop", MODE_PRIVATE);
        editor = sharedPreferences.edit();
        imgIgnore = sharedPreferences.getBoolean("imgIgnore", false);//忽略标示

        initView();
    }

    private void initView() {
        imgReturnBack = (ImageView) findViewById(R.id.return_btn);
        imageViewUserHeadIcon = (ImageView) findViewById(R.id.user_hear_icon);
        textViewUserName = (TextView) findViewById(R.id.tv_user_name);
        textViewUserTitle = (TextView) findViewById(R.id.tv_user_title);
        textViewUserDepartment = (TextView) findViewById(R.id.tv_user_department);
        textViewClearMessage = (TextView) findViewById(R.id.tv_cleaer_message);
        switchMessageIgnore = (Switch) findViewById(R.id.switch_message_ignore);
        switchToTop = (Switch) findViewById(R.id.switch_message_top);
        doctor_message = (RelativeLayout) findViewById(R.id.doctor_message);

        if (imgIgnore) {
            switchMessageIgnore.setChecked(true);
        } else {
            switchMessageIgnore.setChecked(false);
        }

        if (!TextUtils.isEmpty(conversation.getExtra())) {
            switchToTop.setChecked(true);
        } else {
            switchToTop.setChecked(false);
        }

        conversation = JMessageClient.getSingleConversation(targetId);
        userInfo = (UserInfo) conversation.getTargetInfo();

        friendEntries = new Select().from(FriendEntry.class).where("Username=?", targetId).execute();//当前好友

        if (friendEntries.size() > 0) {//如果不是好友  FriendEntries为空
            textViewUserName.setText(friendEntries.get(0).nickName);
            textViewUserTitle.setText(friendEntries.get(0).userTitle);
            textViewUserDepartment.setText(friendEntries.get(0).hospitalDepartment);
        } else {

            textViewUserName.setText("当前用户不是您的好友");
        }


        imgReturnBack.setOnClickListener(this);
        textViewClearMessage.setOnClickListener(this);
        switchToTop.setOnClickListener(this);
        switchMessageIgnore.setOnClickListener(this);
        doctor_message.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {

            //返回按钮
            case R.id.return_btn:
//                Intent intent1 = new Intent(this, ChatActivity.class);
//                intent1.putExtra(JGApplication.CONV_TITLE, userInfo.getExtra(ModulesConstants.USER_NAME_D));
//                intent1.putExtra(JGApplication.TARGET_ID, userInfo.getUserName());
//                intent1.putExtra(JGApplication.TARGET_APP_KEY, userInfo.getAppKey());
//                startActivity(intent1);
                finish();
                break;

            //清空返回记录
            case R.id.tv_cleaer_message:
                //清空消息记录
                //Conversation conversation = JMessageClient.getSingleConversation(targetId);
                if (conversation != null) {
                    conversation.deleteAllMessage();
                }
                Toast.makeText(this, "聊天记录清除成功", Toast.LENGTH_SHORT).show();
                break;

            //消息免打扰
            case R.id.switch_message_ignore:
                if (imgIgnore) {  //当前设置为免打扰  可以取消免打扰
                    editor.putBoolean("imgIgnore", false);
                    userInfo.setNoDisturb(0, new BasicCallback() {
                        @Override
                        public void gotResult(int i, String s) {

                        }
                    });
                } else {           //未设置为免打扰   可以设置免打扰
                    editor.putBoolean("imgIgnore", true);
                    userInfo.setNoDisturb(1, new BasicCallback() {
                        @Override
                        public void gotResult(int i, String s) {

                        }
                    });
                }
                editor.commit();
                break;

            //  置顶聊天
            case R.id.switch_message_top:
                if (!TextUtils.isEmpty(conversation.getExtra())) {  //当前为置顶聊天  可取消
                    setCancelConvTop(conversation);
                } else {    //当前不是置顶聊天  可以设置置顶聊天
                    setConvTop(conversation);
                }
                break;
//
            //personal.html?id=targetId
            //跳转到医生详情
            case R.id.doctor_message:

                long currentTime = System.currentTimeMillis();
                if (currentTime - lastClickDoctor > 1000) {
                    String url = "personal.html?id=" + targetId;
                    Intent intent = new Intent(this, WebActivity.class);
                    //用Bundle携带数据
                    Bundle bundle = new Bundle();
                    bundle.putString("url", url);
                    intent.putExtras(bundle);
                    startActivity(intent);
                    lastClickDoctor = currentTime;
                }
                break;
        }
    }


    /*
     * 设置置顶聊天
     *
     * */
    public void setConvTop(Conversation conversation) {
        int count = 0;
        //遍历原有的会话,得到有几个会话是置顶的
        for (Conversation conv : mDatas) {
            if (!TextUtils.isEmpty(conv.getExtra())) {
//                if (conv.getId()==conversation.getId()){
//                   return;
//                }else{
//                    count++;
//                }
                count++;
            }
        }
        conversation.updateConversationExtra(count + "");
        mDatas.remove(conversation);
        mDatas.add(count, conversation);
    }


    /*
     * 取消置顶聊天
     *
     * */
    public void setCancelConvTop(Conversation conversation) {
        forCurrent.clear();
        topConv.clear();
        int i = 0;
        for (Conversation oldConv : mDatas) {
            //在原来的会话中找到取消置顶的这个,添加到待删除中
            if (oldConv.getId().equals(conversation.getId())) {
                oldConv.updateConversationExtra("");
                break;
            }
        }
        //全部会话排序
        SortConvList sortConvList = new SortConvList();
        Collections.sort(mDatas, sortConvList);

        //遍历会话找到原来设置置顶的
        for (Conversation con : mDatas) {
            if (!TextUtils.isEmpty(con.getExtra())) {
                forCurrent.add(con);
            }
        }
        topConv.addAll(forCurrent);
        SharePreferenceManager.setCancelTopSize(topConv.size());
        mDatas.removeAll(forCurrent);
        if (topConv != null && topConv.size() > 0) {
            SortTopConvList top = new SortTopConvList();
            Collections.sort(topConv, top);
            for (Conversation conv : topConv) {
                mDatas.add(i, conv);
                i++;
            }
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
    }
}
