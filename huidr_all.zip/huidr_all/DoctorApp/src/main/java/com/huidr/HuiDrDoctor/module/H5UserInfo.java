package com.huidr.HuiDrDoctor.module;

import androidx.annotation.NonNull;

/**
 * @author: Administrator
 * @date: 2019-12-05
 */
public class H5UserInfo {

    /**
     * key : loginKey
     * value : {"id":100161,"mobile":"13916633695","userName":"沈纳","userIcon":"system/doctor/8177-81-12527.jpg","userSex":1,"userTitle":"副主任医师","userJobNumber":"12527","hospitalId":8177,"hospitalName":"复旦大学附属中山医院","departmentId":81,"hospitalDepartment":"耳鼻喉科","expertise":"","honor":"","fabulousCount":0,"isFabulous":false,"academicActivities":"","outpatientTimeList":"[{\"1\":{\"sel\":false},\"2\":{\"sel\":false},\"3\":{\"sel\":true},\"4\":{\"sel\":false},\"5\":{\"sel\":false},\"6\":{\"sel\":false},\"7\":{\"sel\":false}},{\"1\":{\"sel\":false},\"2\":{\"sel\":true},\"3\":{\"sel\":false},\"4\":{\"sel\":false},\"5\":{\"sel\":false},\"6\":{\"sel\":false},\"7\":{\"sel\":false}}]","imPassword":"7No5Y9Ml5z","isSetLoginPassword":false,"jwt":"eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiIxMDAxNjEiLCJleHAiOjE1NzYxNDM3NDIsImlhdCI6MTU3NTUzODk0MiwiQWNjb3VudEluZm8iOnsiaWQiOjEwMDE2MSwibW9iaWxlIjoiMTM5MTY2MzM2OTUiLCJsb2dpbk5hbWUiOiI4MTc3XzEyNTI3IiwidXNlckljb24iOiJzeXN0ZW0vZG9jdG9yLzgxNzctODEtMTI1MjcuanBnIiwidXNlclNleCI6MSwidXNlclR5cGUiOjIsInVzZXJOYW1lIjoi5rKI57qzIiwiaW1QYXNzd29yZCI6IjdObzVZOU1sNXoiLCJpc1NldExvZ2luUGFzc3dvcmQiOmZhbHNlLCJvc05hbWUiOiJBbmRyb2lkIiwibGFzdExvZ2luVGltZSI6IjIwMTktMTItMDUgMTc6NDI6MjIiLCJ2ZXJzaW9uIjoiMi4wLjciLCJ1c2VyUm9sZSI6WyJST0xFX0RPQ1RPUiIsIlJPTEVfUEFUSUVOVCJdLCJpc0VuYWJsZSI6ZmFsc2UsImFkZFRpbWUiOiIyMDE5LTAxLTE1IDE4OjI2OjU4In19.VdtBS0_w2jl5o5YmccdzB0vqmPp5YNflY9dMtkvYG3Y","doctorSearchDate":"2019-04-25 00:00:36","osName":"Android","enable":false,"isFollowup":false,"followupState":0}
     */

    private String key;
    private ValueBean value;

    public String getKey() {
        return key;
    }

    public void setKey(String key) {
        this.key = key;
    }

    public ValueBean getValue() {
        return value;
    }

    public void setValue(ValueBean value) {
        this.value = value;
    }

    public static class ValueBean {
        /**
         * id : 100161
         * mobile : 13916633695
         * userName : 沈纳
         * userIcon : system/doctor/8177-81-12527.jpg
         * userSex : 1
         * userTitle : 副主任医师
         * userJobNumber : 12527
         * hospitalId : 8177
         * hospitalName : 复旦大学附属中山医院
         * departmentId : 81
         * hospitalDepartment : 耳鼻喉科
         * expertise :
         * honor :
         * fabulousCount : 0
         * isFabulous : false
         * academicActivities :
         * outpatientTimeList : [{"1":{"sel":false},"2":{"sel":false},"3":{"sel":true},"4":{"sel":false},"5":{"sel":false},"6":{"sel":false},"7":{"sel":false}},{"1":{"sel":false},"2":{"sel":true},"3":{"sel":false},"4":{"sel":false},"5":{"sel":false},"6":{"sel":false},"7":{"sel":false}}]
         * imPassword : 7No5Y9Ml5z
         * isSetLoginPassword : false
         * jwt : eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiIxMDAxNjEiLCJleHAiOjE1NzYxNDM3NDIsImlhdCI6MTU3NTUzODk0MiwiQWNjb3VudEluZm8iOnsiaWQiOjEwMDE2MSwibW9iaWxlIjoiMTM5MTY2MzM2OTUiLCJsb2dpbk5hbWUiOiI4MTc3XzEyNTI3IiwidXNlckljb24iOiJzeXN0ZW0vZG9jdG9yLzgxNzctODEtMTI1MjcuanBnIiwidXNlclNleCI6MSwidXNlclR5cGUiOjIsInVzZXJOYW1lIjoi5rKI57qzIiwiaW1QYXNzd29yZCI6IjdObzVZOU1sNXoiLCJpc1NldExvZ2luUGFzc3dvcmQiOmZhbHNlLCJvc05hbWUiOiJBbmRyb2lkIiwibGFzdExvZ2luVGltZSI6IjIwMTktMTItMDUgMTc6NDI6MjIiLCJ2ZXJzaW9uIjoiMi4wLjciLCJ1c2VyUm9sZSI6WyJST0xFX0RPQ1RPUiIsIlJPTEVfUEFUSUVOVCJdLCJpc0VuYWJsZSI6ZmFsc2UsImFkZFRpbWUiOiIyMDE5LTAxLTE1IDE4OjI2OjU4In19.VdtBS0_w2jl5o5YmccdzB0vqmPp5YNflY9dMtkvYG3Y
         * doctorSearchDate : 2019-04-25 00:00:36
         * osName : Android
         * enable : false
         * isFollowup : false
         * followupState : 0
         */

        private int id;
        private String mobile;
        private String userName;
        private String userIcon;
        private int userSex;
        private String userTitle;
        private String userJobNumber;
        private int hospitalId;
        private String hospitalName;
        private int departmentId;
        private String hospitalDepartment;
        private String expertise;
        private String honor;
        private int fabulousCount;
        private boolean isFabulous;
        private String academicActivities;
        private String outpatientTimeList;
        private String imPassword;
        private boolean isSetLoginPassword;
        private String jwt;
        private String doctorSearchDate;
        private String osName;
        private boolean enable;
        private boolean isFollowup;
        private int followupState;

        public int getId() {
            return id;
        }

        public void setId(int id) {
            this.id = id;
        }

        public String getMobile() {
            return mobile;
        }

        public void setMobile(String mobile) {
            this.mobile = mobile;
        }

        public String getUserName() {
            return userName;
        }

        public void setUserName(String userName) {
            this.userName = userName;
        }

        public String getUserIcon() {
            return userIcon;
        }

        public void setUserIcon(String userIcon) {
            this.userIcon = userIcon;
        }

        public int getUserSex() {
            return userSex;
        }

        public void setUserSex(int userSex) {
            this.userSex = userSex;
        }

        public String getUserTitle() {
            return userTitle;
        }

        public void setUserTitle(String userTitle) {
            this.userTitle = userTitle;
        }

        public String getUserJobNumber() {
            return userJobNumber;
        }

        public void setUserJobNumber(String userJobNumber) {
            this.userJobNumber = userJobNumber;
        }

        public int getHospitalId() {
            return hospitalId;
        }

        public void setHospitalId(int hospitalId) {
            this.hospitalId = hospitalId;
        }

        public String getHospitalName() {
            return hospitalName;
        }

        public void setHospitalName(String hospitalName) {
            this.hospitalName = hospitalName;
        }

        public int getDepartmentId() {
            return departmentId;
        }

        public void setDepartmentId(int departmentId) {
            this.departmentId = departmentId;
        }

        public String getHospitalDepartment() {
            return hospitalDepartment;
        }

        public void setHospitalDepartment(String hospitalDepartment) {
            this.hospitalDepartment = hospitalDepartment;
        }

        public String getExpertise() {
            return expertise;
        }

        public void setExpertise(String expertise) {
            this.expertise = expertise;
        }

        public String getHonor() {
            return honor;
        }

        public void setHonor(String honor) {
            this.honor = honor;
        }

        public int getFabulousCount() {
            return fabulousCount;
        }

        public void setFabulousCount(int fabulousCount) {
            this.fabulousCount = fabulousCount;
        }

        public boolean isIsFabulous() {
            return isFabulous;
        }

        public void setIsFabulous(boolean isFabulous) {
            this.isFabulous = isFabulous;
        }

        public String getAcademicActivities() {
            return academicActivities;
        }

        public void setAcademicActivities(String academicActivities) {
            this.academicActivities = academicActivities;
        }

        public String getOutpatientTimeList() {
            return outpatientTimeList;
        }

        public void setOutpatientTimeList(String outpatientTimeList) {
            this.outpatientTimeList = outpatientTimeList;
        }

        public String getImPassword() {
            return imPassword;
        }

        public void setImPassword(String imPassword) {
            this.imPassword = imPassword;
        }

        public boolean isIsSetLoginPassword() {
            return isSetLoginPassword;
        }

        public void setIsSetLoginPassword(boolean isSetLoginPassword) {
            this.isSetLoginPassword = isSetLoginPassword;
        }

        public String getJwt() {
            return jwt;
        }

        public void setJwt(String jwt) {
            this.jwt = jwt;
        }

        public String getDoctorSearchDate() {
            return doctorSearchDate;
        }

        public void setDoctorSearchDate(String doctorSearchDate) {
            this.doctorSearchDate = doctorSearchDate;
        }

        public String getOsName() {
            return osName;
        }

        public void setOsName(String osName) {
            this.osName = osName;
        }

        public boolean isEnable() {
            return enable;
        }

        public void setEnable(boolean enable) {
            this.enable = enable;
        }

        public boolean isIsFollowup() {
            return isFollowup;
        }

        public void setIsFollowup(boolean isFollowup) {
            this.isFollowup = isFollowup;
        }

        public int getFollowupState() {
            return followupState;
        }

        public void setFollowupState(int followupState) {
            this.followupState = followupState;
        }

    }
}
