package com.huidr.HuiDrDoctor.GeneralFragment;

import android.app.Dialog;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.drawable.BitmapDrawable;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import android.text.Html;
import android.util.Log;
import android.view.Display;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.ImageView;
import android.widget.TextView;

import com.alibaba.fastjson.JSONObject;
import com.chad.library.adapter.base.BaseQuickAdapter;
import com.chad.library.adapter.base.BaseViewHolder;
import com.google.gson.Gson;
import com.huidr.HuiDrDoctor.activity.WebActivity;
import com.huidr.HuiDrDoctor.activity.main.Consult.utils.PostAndGet;
import com.huidr.HuiDrDoctor.debug.BuildConfig;
import com.huidr.HuiDrDoctor.debug.R;
import com.huidr.HuiDrDoctor.module.home.FollowGroupModel;
import com.huidr.HuiDrDoctor.module.home.PatientsModel;
import com.huidr.HuiDrDoctor.module.home.SimpleResultModel;
import com.huidr.HuiDrDoctor.module.home.VisitModel;
import com.huidr.HuiDrDoctor.util.CircleImageView;
import com.huidr.HuiDrDoctor.util.DownLoadImg;
import com.huidr.HuiDrDoctor.util.LogUtil;
import com.huidr.HuiDrDoctor.util.MulityClickUtils;
import com.huidr.HuiDrDoctor.util.ThreadPoolManager;
import com.huidr.lib.commom.base.HuidrActivityManager;
import com.scwang.smartrefresh.layout.SmartRefreshLayout;
import com.scwang.smartrefresh.layout.api.RefreshLayout;
import com.scwang.smartrefresh.layout.listener.OnLoadMoreListener;
import com.scwang.smartrefresh.layout.listener.OnRefreshListener;
import com.zyao89.view.zloading.ZLoadingDialog;
import com.zyao89.view.zloading.Z_TYPE;
import java.io.File;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import jiguang.chat.utils.oss.OssService;
import jiguang.chat.utils.oss.SharedPreferenciesUtil;
import static com.huidr.HuiDrDoctor.util.DownLoadImg.getCirleBitmap;


public class GeneralVisitFragment extends Fragment {

    SmartRefreshLayout srlLayout;
    RecyclerView rvListVisit;
    ConstraintLayout clEmpty;
    ImageView imgEmpty;
    TextView tvEmpty1;
    TextView tvEmpty2;
    int currentPage = 1;
    int totalPage = 1;
    String tip;
    int tipType;
    long lastClick = 0;
    Gson gson;
    OssService ossService;
    String headPath;
    private VisitModel tempVisitModel;  //随访列表Model
    private FollowGroupModel followGroupModel;//随访组列表Model
    String urlGetPatient = BuildConfig.baseUrl + "patient/doctorPatientMedical/getPatients";
    String urlTags = BuildConfig.baseUrl + "patient/doctorPatientMedical/getPatientPoolByTags";
    int[] patients;
    PatientsModel patientsModel;
    List<VisitModel.RetValueBean> visitList, tempList;//随访患者列表
    List<FollowGroupModel.RetValueBean> groupList;//随访组列表
    ZLoadingDialog zLoadingDialog;
    int refreshCount = 0;

    public void getPatientData() {
        ThreadPoolManager.getInstance().execute(new Runnable() {
            @Override
            public void run() {
                patientsModel = new PatientsModel();
                gson = new Gson();
                JSONObject jsonObject = new JSONObject();
                jsonObject.put("patientType", 4);
                String result = PostAndGet.doHttpPost(urlGetPatient, jsonObject);
                if (result == null | result.equals("网络异常")) {

                } else {

                    patientsModel = gson.fromJson(result, PatientsModel.class);
                    patients = new int[patientsModel.getRetValue().size()];
                    for (int i = 0; i < patientsModel.getRetValue().size(); i++) {
                        patients[i] = patientsModel.getRetValue().get(i);
                    }
                    handler.sendEmptyMessage(10);
                }
            }
        });
    }


    public void initView(View parent) {
        srlLayout = parent.findViewById(R.id.srl_layout);
        rvListVisit = parent.findViewById(R.id.rv_list_visit);
        clEmpty = parent.findViewById(R.id.cl_empty);
        imgEmpty = parent.findViewById(R.id.img_empty);
        tvEmpty1 = parent.findViewById(R.id.tv_empty1);
        tvEmpty2 = parent.findViewById(R.id.tv_empty2);

        srlLayout.setEnableLoadMore(true);
        srlLayout.setEnableRefresh(true);

        srlLayout.setOnRefreshListener(new OnRefreshListener() {
            @Override
            public void onRefresh(@NonNull RefreshLayout refreshLayout) {
                currentPage = 1;
                if (tip.equals("全部")) {
                    getFollowGroup();
                } else {
                    getPatientData();
                }


            }
        });

        srlLayout.setOnLoadMoreListener(new OnLoadMoreListener() {
            @Override
            public void onLoadMore(@NonNull RefreshLayout refreshLayout) {
                if (tempVisitModel.getRetValue().size() == 20 && currentPage < totalPage) {
                    currentPage += 1;
//                    getDataByPage();
                    if (tip.equals("全部")) {
                        getFollowGroup();
                    } else {
                        getPatientData();
                    }
                } else {
                    com.huidr.lib.commom.util.Toast.getInstance(getActivity()).show("数据加载全部", 500);
                    srlLayout.finishLoadMore();
                }
            }
        });

        rvListVisit.setAdapter(visitAdapter);
        visitAdapter.setNewData(visitList);
        rvListVisit.setLayoutManager(new LinearLayoutManager(getContext()));

        tvEmpty2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (tvEmpty2.getText().toString().equals("点击刷新")) {
                    refreshCount += 1;
                }

                if (tip.equals("全部")) {
                    getFollowGroup();
                } else {
                    getPatientData();
                }

                zLoadingDialog = new ZLoadingDialog(HuidrActivityManager.getInstance().getCurrentActivity());
                zLoadingDialog.setLoadingBuilder(Z_TYPE.STAR_LOADING)//设置类型
                        .setLoadingColor(Color.BLUE)//颜色
                        .setHintText("正在加载,请稍候...").setHintTextSize(16) // 设置字体大小 dp
                        .setHintTextColor(Color.GRAY)  // 设置字体颜色
                        .setDurationTime(0.5) // 设置动画时间百分比 - 0.5倍
                        .setCanceledOnTouchOutside(false).setCancelable(false).show();


            }
        });
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_general_visit, container, false);
        initData();
        initView(view);
        return view;
    }

    public void initData() {
        headPath = getContext().getExternalFilesDir("").getAbsolutePath() + "/img/head/";
        ossService = new OssService(getContext());

        visitList = new ArrayList<>();
        groupList = new ArrayList<>();
        tempList = new ArrayList<>();
    }


    public static GeneralVisitFragment newInstance_Fragment(String tip, int tipType) {
        GeneralVisitFragment generalVisitFragment = new GeneralVisitFragment();
        Bundle bundle = new Bundle();
        bundle.putString("tip", tip);
        bundle.putInt("tipType", tipType);
        generalVisitFragment.setArguments(bundle);
        return generalVisitFragment;
    }


    @Override
    public void setUserVisibleHint(boolean isVisibleToUser) {
        super.setUserVisibleHint(isVisibleToUser);
        if (isVisibleToUser) {
            currentPage = 1;
            zLoadingDialog = new ZLoadingDialog(HuidrActivityManager.getInstance().getCurrentActivity());
            zLoadingDialog.setLoadingBuilder(Z_TYPE.STAR_LOADING)//设置类型
                    .setLoadingColor(Color.BLUE)//颜色
                    .setHintText("正在加载,请稍候...").setHintTextSize(16) // 设置字体大小 dp
                    .setHintTextColor(Color.GRAY)  // 设置字体颜色
                    .setDurationTime(0.5) // 设置动画时间百分比 - 0.5倍
                    .setCanceledOnTouchOutside(false).setCancelable(false).show();

            Bundle bundle = getArguments();
            tip = bundle.getString("tip");
            tipType = bundle.getInt("tipType");

            if (tip.equals("全部")) {
                Log.e("随访患者====》", "setUser 全部 ");
                getFollowGroup();
            } else {
                Log.e("随访患者====》", "setUser " + tip);
                getPatientData();
            }
        } else {
            visitAdapter.notifyDataSetChanged();
        }
    }


    //    获取随访组
    public void getFollowGroup() {
        ThreadPoolManager.getInstance().execute(new Runnable() {
            @Override
            public void run() {
                String id = (String) SharedPreferenciesUtil.getData("id", "0");
                String path = BuildConfig.baseUrl + "hospital/followupGroupController/getFollowupGroups?loginUserId=" + id;
                LogUtil.e("获取随访组", PostAndGet.doGetHttp(path));
                String result = PostAndGet.doGetHttp(path);
                if (result == null || result.equals("网络异常")) {

                } else {
                    gson = new Gson();
                    followGroupModel = new FollowGroupModel();
                    followGroupModel = gson.fromJson(result, FollowGroupModel.class);

                    groupList = followGroupModel.getRetValue();
                    if (groupList.size() > 0) {
                        if (visitList.size() == 0) {
                            for (int i = 0; i < groupList.size(); i++) {
                                VisitModel.RetValueBean item = new VisitModel.RetValueBean();
                                item.setGroupId(groupList.get(i).getGroupId());
                                item.setGroupImage(groupList.get(i).getGroupImage());
                                item.setGroupName(groupList.get(i).getGroupName());
                                item.setPatientNum(groupList.get(i).getPatientNum() + "");
                                item.setCreateTime(groupList.get(i).getCreateTime());
                                tempList.add(item);
                            }
                        }
                    }

//                    tempList = visitList;

                    if (tip.equals("全部")) {
                        handler.sendEmptyMessage(7);
                    } else {
                        handler.sendEmptyMessage(11);
                    }
                }
            }
        });
    }

    //    随访患者列表
    //    患者头像、住院号、当前进行的随访（期数/次数：如果已逾期，则显示其逾期的那一次）（默认显示18个端，第18个字段为省略号）、
    //    随访逾期的天数
    private BaseQuickAdapter<VisitModel.RetValueBean, BaseViewHolder> visitAdapter = new BaseQuickAdapter<VisitModel.RetValueBean, BaseViewHolder>(R.layout.item_patient_scroll_layout) {
        @Override
        protected void convert(final BaseViewHolder helper, final VisitModel.RetValueBean item) {

            if (item.getGroupName() == null) {  //随访患者
                //            头像
                ImageView imgItemHead = helper.getView(R.id.img_item_head);

                imgItemHead.setBackgroundResource(R.drawable.head_patient);

//                Bitmap bitmap = BitmapFactory.decodeResource(getResources(), R.drawable.head_patient);
//                BitmapDrawable bitmapDrawable = new BitmapDrawable(getResources(), bitmap);
//                imgItemHead.setBackgroundDrawable(bitmapDrawable);

//            提醒
                ImageView imgNotice = helper.getView(R.id.img_notice);
                imgNotice.setVisibility(View.GONE);
//            姓名
                TextView tvItemName = helper.getView(R.id.tv_item_name);
                tvItemName.setText(item.getPatientName());
//            住院号
                TextView tvPatientNum = helper.getView(R.id.tv_patient_num);
                tvPatientNum.setText(item.getAdmitNo());
//            日期
                TextView tvItemDate = helper.getView(R.id.tv_item_date);
                if (item.getRecentSuccessVisitingDate() != null) {
                    tvItemDate.setText(item.getRecentSuccessVisitingDate().split(" ")[0]);
                }

//            状态
                TextView tvItemMsg = helper.getView(R.id.tv_item_msg);
                tvItemMsg.setText(item.getSolutionName() + "第" + item.getStage() + "期(第" + (item.getCurrentTimes() + 1) + "次)");
//            模板
                TextView tvModel = helper.getView(R.id.tv_model);

                if (item.getLastVisitingDate() != null) {
                    try {
                        int count = getDaysCount(item.getLastVisitingDate().split(" ")[0]);
                        String text = "逾期<font color='#EB5463'>" + count + "</font>天";
                        tvModel.setText(Html.fromHtml(text));
                    } catch (Exception e) {

                    }
                }

                final TextView tvRight = helper.getView(R.id.tv_scroll_right);
                if (item.isIsFollow()) {
                    String str = "<font>已<br>关注</font>";
                    tvRight.setText(Html.fromHtml(str));
                    tvRight.setBackgroundResource(R.drawable.shape_atten_gray);
                } else {
                    String str = "<font>关注<br>患者</font>";
                    tvRight.setText(Html.fromHtml(str));
                    tvRight.setBackgroundResource(R.drawable.shape_attent_blue);
                }

                tvRight.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        if (item.isIsFollow()) {
//                        已经关注  取消关注
//                        modifyAttent(false, helper.getAdapterPosition(), item.getPatientId());
                            visitAdapter.notifyItemChanged(helper.getAdapterPosition());
                            com.huidr.lib.commom.util.Toast.getInstance(getContext()).show("该患者已关注", 500);
                        } else {
//                        为关注 添加关注
//                        modifyAttent(true, helper.getAdapterPosition(), item.getPatientId());
                            showCoopDialog(true, helper.getAdapterPosition(), item.getPatientId());
                        }
                    }
                });


                ConstraintLayout clItem = helper.getView(R.id.cl_item);
//            2.点击随访报到/建立随访组
//
//进入随访报到管理/创建随访组页面
                clItem.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        if (System.currentTimeMillis() - lastClick > 1000) {
                            Intent intent1 = new Intent(getActivity(), WebActivity.class);
                            Bundle bundle = new Bundle();
                            bundle.putString("url", "followPatientList.html?id=" + item.getPatientId());
                            intent1.putExtras(bundle);
                            startActivity(intent1);
                            lastClick = System.currentTimeMillis();
                        }
                    }
                });
            } else {  //随访组
                helper.setText(R.id.tv_item_name, item.getGroupName());
                helper.setVisible(R.id.img_notice, false);
                helper.setVisible(R.id.tv_model, false);
                helper.setVisible(R.id.tv_patient_num, false);
                TextView tvRight = helper.getView(R.id.tv_scroll_right);
                tvRight.setBackgroundResource(R.drawable.back_dissolve);
                tvRight.setText(Html.fromHtml("<font>解散<br>编组</font>"));
                if (item.getCreateTime() != null) {
                    helper.setText(R.id.tv_item_date, item.getCreateTime().split(" ")[0]);
                }
                helper.setText(R.id.tv_item_msg, "[" + item.getPatientNum() + "位患者正在进行随访]");


                tvRight.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        if (MulityClickUtils.isFastClick()) {
                            showDissloveDialog(helper.getAdapterPosition(), item.getGroupId());
                        }
                    }
                });

                CircleImageView imageView = helper.getView(R.id.img_item_head);

                Bitmap bitmap = BitmapFactory.decodeResource(getResources(), R.drawable.followgroup);
                BitmapDrawable bitmapDrawable = new BitmapDrawable(getResources(), bitmap);
                imageView.setBackgroundDrawable(bitmapDrawable);

                if (item.getGroupImage() == null) {
                    imageView.setBackgroundDrawable(bitmapDrawable);
                } else {
                    imageView.setTag(item.getGroupImage());
                    File file = new File(headPath + item.getGroupImage());
                    if (file.exists()) {

                        Bitmap bitmap1 = BitmapFactory.decodeFile(file.getAbsolutePath());
                        if (bitmap1 != null) {
                            bitmap1 = getCirleBitmap(bitmap1);
                            BitmapDrawable bitmapDrawable1 = new BitmapDrawable(bitmap1);
                            if (imageView.getTag().equals(item.getGroupImage())) {
                                imageView.setBackgroundDrawable(bitmapDrawable1);
                            }
                        }
                    } else {
                        DownLoadImg.BitmapWorkerTask bitmapWorkerTask = new DownLoadImg.BitmapWorkerTask(imageView, file, ossService);
                        bitmapWorkerTask.execute(item.getGroupImage());
                    }
                }

                ConstraintLayout clItem = helper.getView(R.id.cl_item);
                clItem.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        if (MulityClickUtils.isFastClick()) {
                            Intent intent1 = new Intent(getContext(), WebActivity.class);
                            Bundle bundle = new Bundle();
                            bundle.putString("url", "followUp_groupDetail.html?id=" + item.getGroupId());
                            intent1.putExtras(bundle);
                            startActivity(intent1);
                        }
                    }
                });
            }


        }
    };

    //   获取逾期天数
    public int getDaysCount(String startTime) throws ParseException {
        int result = 0;
        Calendar calendar = Calendar.getInstance();
        long current = calendar.getTimeInMillis();
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd");
        calendar.setTime(simpleDateFormat.parse(startTime));
        long start = calendar.getTimeInMillis();
        result = (int) ((current - start) / (1000 * 60 * 60 * 24));
        return result;
    }

    //    取消添加协同对话框
    public void showDissloveDialog(final int position, final int id) {

        final Dialog builder = new Dialog(getContext(), R.style.jmui_default_dialog_style);
        //final Dialog builder = new Dialog(this, R.style.jmui_default_dialog_style);
        View view = LayoutInflater.from(getContext()).inflate(R.layout.disslove_dialog, null);

        TextView tvTitle = view.findViewById(R.id.tv_title);
        TextView tvFooter1 = view.findViewById(R.id.tv_cancel);
        TextView tvFooter2 = view.findViewById(R.id.tv_ensure);

        tvTitle.setText("您确定解散肝外科随访组？解散后随访计划也将跟随取消,之前已完成的随访 可以在患者资料里进行查看");


//        取消
        tvFooter1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                builder.cancel();
//                visitAdapter.notifyItemChanged(position);

            }
        });
//确定
        tvFooter2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                builder.cancel();
                deleteFollowGroup(position, id);
//                visitAdapter.notifyItemChanged(position);
            }
        });

        builder.setContentView(view);
        //builder.setCanceledOnTouchOutside(true);
        builder.show();
        Window window = builder.getWindow();
        WindowManager.LayoutParams lp = window.getAttributes();
        WindowManager windowManager = getActivity().getWindowManager();
        Display display = windowManager.getDefaultDisplay();
        lp.width = (int) (display.getWidth() * 0.7);
//        lp.height = (int) (display.getHeight() * 0.1);
        window.setAttributes(lp);
    }

    //    删除随访组
    public void deleteFollowGroup(final int position, final int id) {
        ThreadPoolManager.getInstance().execute(new Runnable() {
            @Override
            public void run() {
                String path = BuildConfig.baseUrl + "hospital/followupGroupController/delFollowupGroupByGroupId";
                JSONObject jsonObject = new JSONObject();
                jsonObject.put("groupId", id);
                String result = PostAndGet.doHttpPost(path, jsonObject);

                if (result == null || result.equals("网络异常")) {
                    handler.sendEmptyMessage(9);
                } else {
                    SimpleResultModel simpleResultModel = gson.fromJson(result, SimpleResultModel.class);
                    if (simpleResultModel.getStatus() == 0) {
//                        handler.sendEmptyMessage(8);
                        Message message = new Message();
                        message.what = 8;
                        message.arg1 = position;
                        handler.sendMessage(message);
                    } else {
                        handler.sendEmptyMessage(9);
                    }
                }


                LogUtil.e("删除结果", result);
            }
        });
    }

    //    取消添加协同对话框
    public void showCoopDialog(final boolean atten, final int position, final int patientId) {

        final Dialog builder = new Dialog(getContext(), R.style.jmui_default_dialog_style);
        //final Dialog builder = new Dialog(this, R.style.jmui_default_dialog_style);
        View view = LayoutInflater.from(getContext()).inflate(R.layout.dialog_content, null);

        TextView tvTitle = view.findViewById(R.id.tv_title);
        TextView tvFooter1 = view.findViewById(R.id.tv_footer1);
        TextView tvFooter2 = view.findViewById(R.id.tv_footer2);

        tvTitle.setText("是否关注该患者！");


//        取消
        tvFooter1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                builder.cancel();
                visitAdapter.notifyItemChanged(position);

            }
        });
//确定
        tvFooter2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                builder.cancel();
                modifyAttent(atten, position, patientId);
                visitAdapter.notifyItemChanged(position);
            }
        });

        builder.setContentView(view);
        //builder.setCanceledOnTouchOutside(true);
        builder.show();
        Window window = builder.getWindow();
        WindowManager.LayoutParams lp = window.getAttributes();
        WindowManager windowManager = getActivity().getWindowManager();
        Display display = windowManager.getDefaultDisplay();
        lp.width = (int) (display.getWidth() * 0.7);
//        lp.height = (int) (display.getHeight() * 0.1);
        window.setAttributes(lp);
    }

    //    关注患者  取消关注
    public void modifyAttent(final boolean atten, final int position, final int patientId) {
        ThreadPoolManager.getInstance().execute(new Runnable() {
            @Override
            public void run() {
                String id = (String) SharedPreferenciesUtil.getData("id", "0");
//                String path = BuildConfig.baseUrl + "patient/doctorPatientMedical/addRemarksAndFollow?doctorId=" + id + "&patientId=" + patientId + "&isFollow=" + atten;
//                String path = "http://192.168.1.180:196/doctorPatientMedical/addRemarksAndFollow?doctorId=" + id + "&patientId=" + patientId + "&isFollow=" + atten;
                String path = BuildConfig.baseUrl + "patient/doctorPatientMedical/addRemarksAndFollow?doctorId=" + id + "&patientId=" + patientId + "&isFollow=" + atten;
                String result = PostAndGet.doGetHttp(path);

                LogUtil.e("关注", result);
                if (result.equals("网络异常")) {

                } else {
                    SimpleResultModel simpleResultModel = gson.fromJson(result, SimpleResultModel.class);
                    Message message = new Message();
                    message.obj = atten;
                    if (simpleResultModel.getStatus() == 0) {
                        message.what = 5;
                        message.arg1 = position;
                        handler.sendMessage(message);
                    } else {
                        message.what = 6;
                        handler.sendMessage(message);
                    }
                }

            }
        });
    }


    private Handler handler = new Handler() {
        @Override
        public void handleMessage(Message msg) {
            super.handleMessage(msg);
            switch (msg.what) {
//                刷新
                case 1:
                    if (zLoadingDialog != null) {
                        new Handler().postDelayed(new Runnable() {
                            @Override
                            public void run() {
                                zLoadingDialog.dismiss();
                                zLoadingDialog = null;
                            }
                        }, 500);
                    }
                    visitAdapter.getData().clear();
                    if (tempVisitModel == null || tempVisitModel.getRetValue() == null || tempVisitModel.getRetValue().size() == 0) {
                        clEmpty.setVisibility(View.VISIBLE);
                        srlLayout.setVisibility(View.GONE);
                        String tip1 = "暂无患者";
                        String tip2 = "<font color='#248cfa'><u>点击刷新<u></font>";
                        tvEmpty1.setText(tip1);
                        tvEmpty2.setText(Html.fromHtml(tip2));
                        if (refreshCount == 3) {
                            tvEmpty2.setVisibility(View.GONE);
                            refreshCount = 0;
                        } else {
                            if (tvEmpty2.getVisibility() == View.GONE) {
                                tvEmpty2.setVisibility(View.VISIBLE);
                            }
                        }
                    } else {
                        srlLayout.setVisibility(View.VISIBLE);
                        visitAdapter.addData(tempList);
                        visitAdapter.addData(tempVisitModel.getRetValue());
                        visitAdapter.notifyDataSetChanged();
                    }
                    srlLayout.finishRefresh();
                    break;
//                    加载
                case 2:
                    if (zLoadingDialog != null) {
                        new Handler().postDelayed(new Runnable() {
                            @Override
                            public void run() {
                                zLoadingDialog.dismiss();
                                zLoadingDialog = null;
                            }
                        }, 500);
                    }
                    visitAdapter.getData().addAll(tempVisitModel.getRetValue());
                    visitAdapter.notifyDataSetChanged();
                    srlLayout.finishLoadMore();
                    break;
//                    报错
                case 3:
                    if (zLoadingDialog != null) {
                        new Handler().postDelayed(new Runnable() {
                            @Override
                            public void run() {
                                zLoadingDialog.dismiss();
                                zLoadingDialog = null;
                            }
                        }, 500);
                    }
                    clEmpty.setVisibility(View.VISIBLE);
                    srlLayout.setVisibility(View.GONE);
                    srlLayout.finishRefresh();
                    srlLayout.finishLoadMore();
                    String tip1 = "网络错误~";
                    String tip2 = "<font color='#248cfa'><u>立即刷新</u></font>";
                    tvEmpty1.setText(tip1);
                    tvEmpty2.setText(Html.fromHtml(tip2));
                    break;
//                    显示随访报到人数
                case 4://
//                    tvFollowupCount.setText(msg.arg1 + "");
                    break;
                case 5:
//                    取消关注 添加关注成功
                    String tip = "";
                    Boolean atten = (Boolean) msg.obj;
                    if (atten) {
                        tip = "关注患者成功";
                        visitAdapter.getData().get(msg.arg1).setIsFollow(true);
                    } else {
                        tip = "取消成功";
                        visitAdapter.getData().get(msg.arg1).setIsFollow(false);
                    }
                    com.huidr.lib.commom.util.Toast.getInstance(getActivity()).show(tip, 500);
                    visitAdapter.notifyDataSetChanged();
                    break;
                case 6:
//                    取消关注 添加关注失败
                    String str = "";
                    Boolean atten1 = (Boolean) msg.obj;
                    if (atten1) {
                        str = "关注患者失败";
                    } else {
                        str = "取消失败";
                    }
                    com.huidr.lib.commom.util.Toast.getInstance(getActivity()).show(str, 500);
                    visitAdapter.notifyDataSetChanged();
                    break;
                case 7:
//                    groupAdapter.setNewData(followGroupModel.getRetValue());

                    getDataByPage();
                    break;

//                    删除成功
                case 8:
                    visitAdapter.remove(msg.arg1);
                    break;
                case 9:
                    visitAdapter.notifyDataSetChanged();
                    break;

                case 10:
                    getFollowGroup();
                    break;
                case 11:
//                    visitAdapter.setNewData(followGroupModel.getRetValue());
                    getTagDataByPage();
                    break;
            }
        }
    };

    //    分页获取随访列表
    public void getDataByPage() {
        ThreadPoolManager.getInstance().execute(new Runnable() {
            @Override
            public void run() {
                String path = BuildConfig.baseUrl + "followup/followUpService/getVisitingHandles?pageIndex=" + currentPage + "&pageSize=20&ignore=" + false;
                String result = PostAndGet.doGetHttp(path);
                LogUtil.e("患者池 随访患者", result);
                if (result.equals("网络异常")) {
                    handler.sendEmptyMessage(3);
                } else {
                    tempVisitModel = new VisitModel();
                    tempVisitModel = gson.fromJson(result, VisitModel.class);
                    if (tempVisitModel == null) {
                        handler.sendEmptyMessage(3);
                    } else if (tempVisitModel.getStatus() == 0) {
                        totalPage = tempVisitModel.getTotalPage();
                        if (currentPage == 1) {
                            handler.sendEmptyMessage(1);
                        } else {
                            handler.sendEmptyMessage(2);
                        }
                    } else {
                        handler.sendEmptyMessage(3);
                    }
                }
            }
        });
    }

    /*
     * 分页获取有标签的数据
     * */
    public void getTagDataByPage() {
        ThreadPoolManager.getInstance().execute(new Runnable() {
            @Override
            public void run() {
                JSONObject jsonObject = new JSONObject();
                jsonObject.put("tagName", tip);
                jsonObject.put("tagType", tipType);
                jsonObject.put("patients", patients);
                jsonObject.put("pageIndex", currentPage);
                jsonObject.put("pageSize", 20);
                String result = PostAndGet.doHttpPost(urlTags, jsonObject);
                Log.e("获取随访标签数据", result);
                if (result.equals("网络异常")) {
                    handler.sendEmptyMessage(3);
                } else {
                    tempVisitModel = new VisitModel();
                    tempVisitModel = gson.fromJson(result, VisitModel.class);
                    if (tempVisitModel == null) {
                        handler.sendEmptyMessage(3);
                    } else if (tempVisitModel.getStatus() == 0) {
                        totalPage = tempVisitModel.getTotalPage();
                        if (currentPage == 1) {
                            handler.sendEmptyMessage(1);
                        } else {
                            handler.sendEmptyMessage(2);
                        }
                    } else {
                        handler.sendEmptyMessage(3);
                    }
                }

            }
        });
    }
}
