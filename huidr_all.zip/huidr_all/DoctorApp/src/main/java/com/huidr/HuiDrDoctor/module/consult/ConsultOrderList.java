package com.huidr.HuiDrDoctor.module.consult;

import java.util.List;

public class ConsultOrderList {

    /**
     * status : 0
     * page : 1
     * totalPage : 1
     * retValue : [{"orderId":"2019090916222730925174","orderStatusAction":3,"orderStatus":2,"orderTopic":"图文咨询","orderDetails":"{\"doctorHeadImg\":\"system/doctor/8177-72-12160.jpg\",\"doctorHospital\":\"复旦大学附属中山医院\",\"doctorId\":100140,\"doctorName\":\"测试骨科1\",\"hospitalDepartment\":\"骨科\",\"needHelp\":\"测试485391第一个问题第一个问题\",\"patientId\":85458,\"patientName\":\"患者段\",\"pics\":[],\"position\":\"副主任医师\"}","orderKind":2,"payOrderId":"2019090916222730925174","payPlatformKind":3,"createTime":"2019-09-09 16:22:28","buyerId":141162,"sellerId":100140,"buyerRelationId":85458,"addressInfo":{},"orderPrice":200,"couponPrice":0,"integralPrice":0,"goodsDetails":[{"id":24,"goodsName":"测试骨科1的图文咨询服务","goodsNumber":1,"goodsBalance":200,"merchantId":100140,"goodsGroup":2,"isOnShelf":true,"enableInfiniteStock":true,"stock":50,"mainPicture":"/article/uploadImg/1.jpg","enableDayLimitSale":false,"dayLimitMaxSale":50,"enableDayLimitTime":true,"dayLimitTimeStart":0,"dayLimitTimeEnd":82800,"isMathCoupon":true}],"payTime":"2019-09-09 16:22:38","freight":0}]
     */

    private int status;
    private int page;
    private int totalPage;
    private List<RetValueBean> retValue;

    public int getStatus() {
        return status;
    }

    public void setStatus(int status) {
        this.status = status;
    }

    public int getPage() {
        return page;
    }

    public void setPage(int page) {
        this.page = page;
    }

    public int getTotalPage() {
        return totalPage;
    }

    public void setTotalPage(int totalPage) {
        this.totalPage = totalPage;
    }

    public List<RetValueBean> getRetValue() {
        return retValue;
    }

    public void setRetValue(List<RetValueBean> retValue) {
        this.retValue = retValue;
    }

    public static class RetValueBean {
        /**
         * orderId : 2019090916222730925174
         * orderStatusAction : 3
         * orderStatus : 2
         * orderTopic : 图文咨询
         * orderDetails : {"doctorHeadImg":"system/doctor/8177-72-12160.jpg","doctorHospital":"复旦大学附属中山医院","doctorId":100140,"doctorName":"测试骨科1","hospitalDepartment":"骨科","needHelp":"测试485391第一个问题第一个问题","patientId":85458,"patientName":"患者段","pics":[],"position":"副主任医师"}
         * orderKind : 2
         * payOrderId : 2019090916222730925174
         * payPlatformKind : 3
         * createTime : 2019-09-09 16:22:28
         * buyerId : 141162
         * sellerId : 100140
         * buyerRelationId : 85458
         * addressInfo : {}
         * orderPrice : 200
         * couponPrice : 0
         * integralPrice : 0
         * goodsDetails : [{"id":24,"goodsName":"测试骨科1的图文咨询服务","goodsNumber":1,"goodsBalance":200,"merchantId":100140,"goodsGroup":2,"isOnShelf":true,"enableInfiniteStock":true,"stock":50,"mainPicture":"/article/uploadImg/1.jpg","enableDayLimitSale":false,"dayLimitMaxSale":50,"enableDayLimitTime":true,"dayLimitTimeStart":0,"dayLimitTimeEnd":82800,"isMathCoupon":true}]
         * payTime : 2019-09-09 16:22:38
         * freight : 0
         */

        private String orderId;
        private int orderStatusAction;
        private int orderStatus;
        private String orderTopic;
        private String orderDetails;
        private int orderKind;
        private String payOrderId;
        private int payPlatformKind;
        private String createTime;
        private int buyerId;
        private int sellerId;
        private int buyerRelationId;
        private AddressInfoBean addressInfo;
        private int orderPrice;
        private int couponPrice;
        private int integralPrice;
        private String payTime;
        private int freight;
        private List<GoodsDetailsBean> goodsDetails;

        public String getOrderId() {
            return orderId;
        }

        public void setOrderId(String orderId) {
            this.orderId = orderId;
        }

        public int getOrderStatusAction() {
            return orderStatusAction;
        }

        public void setOrderStatusAction(int orderStatusAction) {
            this.orderStatusAction = orderStatusAction;
        }

        public int getOrderStatus() {
            return orderStatus;
        }

        public void setOrderStatus(int orderStatus) {
            this.orderStatus = orderStatus;
        }

        public String getOrderTopic() {
            return orderTopic;
        }

        public void setOrderTopic(String orderTopic) {
            this.orderTopic = orderTopic;
        }

        public String getOrderDetails() {
            return orderDetails;
        }

        public void setOrderDetails(String orderDetails) {
            this.orderDetails = orderDetails;
        }

        public int getOrderKind() {
            return orderKind;
        }

        public void setOrderKind(int orderKind) {
            this.orderKind = orderKind;
        }

        public String getPayOrderId() {
            return payOrderId;
        }

        public void setPayOrderId(String payOrderId) {
            this.payOrderId = payOrderId;
        }

        public int getPayPlatformKind() {
            return payPlatformKind;
        }

        public void setPayPlatformKind(int payPlatformKind) {
            this.payPlatformKind = payPlatformKind;
        }

        public String getCreateTime() {
            return createTime;
        }

        public void setCreateTime(String createTime) {
            this.createTime = createTime;
        }

        public int getBuyerId() {
            return buyerId;
        }

        public void setBuyerId(int buyerId) {
            this.buyerId = buyerId;
        }

        public int getSellerId() {
            return sellerId;
        }

        public void setSellerId(int sellerId) {
            this.sellerId = sellerId;
        }

        public int getBuyerRelationId() {
            return buyerRelationId;
        }

        public void setBuyerRelationId(int buyerRelationId) {
            this.buyerRelationId = buyerRelationId;
        }

        public AddressInfoBean getAddressInfo() {
            return addressInfo;
        }

        public void setAddressInfo(AddressInfoBean addressInfo) {
            this.addressInfo = addressInfo;
        }

        public int getOrderPrice() {
            return orderPrice;
        }

        public void setOrderPrice(int orderPrice) {
            this.orderPrice = orderPrice;
        }

        public int getCouponPrice() {
            return couponPrice;
        }

        public void setCouponPrice(int couponPrice) {
            this.couponPrice = couponPrice;
        }

        public int getIntegralPrice() {
            return integralPrice;
        }

        public void setIntegralPrice(int integralPrice) {
            this.integralPrice = integralPrice;
        }

        public String getPayTime() {
            return payTime;
        }

        public void setPayTime(String payTime) {
            this.payTime = payTime;
        }

        public int getFreight() {
            return freight;
        }

        public void setFreight(int freight) {
            this.freight = freight;
        }

        public List<GoodsDetailsBean> getGoodsDetails() {
            return goodsDetails;
        }

        public void setGoodsDetails(List<GoodsDetailsBean> goodsDetails) {
            this.goodsDetails = goodsDetails;
        }

        public static class AddressInfoBean {
        }

        public static class GoodsDetailsBean {
            /**
             * id : 24
             * goodsName : 测试骨科1的图文咨询服务
             * goodsNumber : 1
             * goodsBalance : 200
             * merchantId : 100140
             * goodsGroup : 2
             * isOnShelf : true
             * enableInfiniteStock : true
             * stock : 50
             * mainPicture : /article/uploadImg/1.jpg
             * enableDayLimitSale : false
             * dayLimitMaxSale : 50
             * enableDayLimitTime : true
             * dayLimitTimeStart : 0
             * dayLimitTimeEnd : 82800
             * isMathCoupon : true
             */

            private int id;
            private String goodsName;
            private int goodsNumber;
            private int goodsBalance;
            private int merchantId;
            private int goodsGroup;
            private boolean isOnShelf;
            private boolean enableInfiniteStock;
            private int stock;
            private String mainPicture;
            private boolean enableDayLimitSale;
            private int dayLimitMaxSale;
            private boolean enableDayLimitTime;
            private int dayLimitTimeStart;
            private int dayLimitTimeEnd;
            private boolean isMathCoupon;

            public int getId() {
                return id;
            }

            public void setId(int id) {
                this.id = id;
            }

            public String getGoodsName() {
                return goodsName;
            }

            public void setGoodsName(String goodsName) {
                this.goodsName = goodsName;
            }

            public int getGoodsNumber() {
                return goodsNumber;
            }

            public void setGoodsNumber(int goodsNumber) {
                this.goodsNumber = goodsNumber;
            }

            public int getGoodsBalance() {
                return goodsBalance;
            }

            public void setGoodsBalance(int goodsBalance) {
                this.goodsBalance = goodsBalance;
            }

            public int getMerchantId() {
                return merchantId;
            }

            public void setMerchantId(int merchantId) {
                this.merchantId = merchantId;
            }

            public int getGoodsGroup() {
                return goodsGroup;
            }

            public void setGoodsGroup(int goodsGroup) {
                this.goodsGroup = goodsGroup;
            }

            public boolean isIsOnShelf() {
                return isOnShelf;
            }

            public void setIsOnShelf(boolean isOnShelf) {
                this.isOnShelf = isOnShelf;
            }

            public boolean isEnableInfiniteStock() {
                return enableInfiniteStock;
            }

            public void setEnableInfiniteStock(boolean enableInfiniteStock) {
                this.enableInfiniteStock = enableInfiniteStock;
            }

            public int getStock() {
                return stock;
            }

            public void setStock(int stock) {
                this.stock = stock;
            }

            public String getMainPicture() {
                return mainPicture;
            }

            public void setMainPicture(String mainPicture) {
                this.mainPicture = mainPicture;
            }

            public boolean isEnableDayLimitSale() {
                return enableDayLimitSale;
            }

            public void setEnableDayLimitSale(boolean enableDayLimitSale) {
                this.enableDayLimitSale = enableDayLimitSale;
            }

            public int getDayLimitMaxSale() {
                return dayLimitMaxSale;
            }

            public void setDayLimitMaxSale(int dayLimitMaxSale) {
                this.dayLimitMaxSale = dayLimitMaxSale;
            }

            public boolean isEnableDayLimitTime() {
                return enableDayLimitTime;
            }

            public void setEnableDayLimitTime(boolean enableDayLimitTime) {
                this.enableDayLimitTime = enableDayLimitTime;
            }

            public int getDayLimitTimeStart() {
                return dayLimitTimeStart;
            }

            public void setDayLimitTimeStart(int dayLimitTimeStart) {
                this.dayLimitTimeStart = dayLimitTimeStart;
            }

            public int getDayLimitTimeEnd() {
                return dayLimitTimeEnd;
            }

            public void setDayLimitTimeEnd(int dayLimitTimeEnd) {
                this.dayLimitTimeEnd = dayLimitTimeEnd;
            }

            public boolean isIsMathCoupon() {
                return isMathCoupon;
            }

            public void setIsMathCoupon(boolean isMathCoupon) {
                this.isMathCoupon = isMathCoupon;
            }
        }
    }
}
