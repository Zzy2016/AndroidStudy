package com.huidr.HuiDrDoctor.follow_fragment;

import android.app.Dialog;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import android.text.Html;
import android.util.Log;
import android.view.Display;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.alibaba.fastjson.JSONObject;
import com.chad.library.adapter.base.BaseQuickAdapter;
import com.chad.library.adapter.base.BaseViewHolder;
import com.google.gson.Gson;
import com.huidr.HuiDrDoctor.activity.WebActivity;
import com.huidr.HuiDrDoctor.activity.main.Consult.utils.PostAndGet;
import com.huidr.HuiDrDoctor.debug.BuildConfig;
import com.huidr.HuiDrDoctor.debug.R;
import com.huidr.HuiDrDoctor.module.home.InhosModel;
import com.huidr.HuiDrDoctor.module.home.SimpleResultModel;
import com.huidr.HuiDrDoctor.util.LogUtil;
import com.huidr.HuiDrDoctor.util.ThreadPoolManager;
import com.huidr.lib.commom.base.BaseFragment;
import com.huidr.lib.commom.base.HuidrActivityManager;
import com.scwang.smartrefresh.layout.SmartRefreshLayout;
import com.scwang.smartrefresh.layout.api.RefreshLayout;
import com.scwang.smartrefresh.layout.listener.OnLoadMoreListener;
import com.scwang.smartrefresh.layout.listener.OnRefreshListener;
import com.zyao89.view.zloading.ZLoadingDialog;
import com.zyao89.view.zloading.Z_TYPE;

import java.util.ArrayList;
import java.util.List;

import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import jiguang.chat.utils.oss.SharedPreferenciesUtil;

/**
 * 头像，患者姓名，住院号，时间，状态，所匹配模板（默认显示18个端，第18个字段为省略号）
 * <p>
 * 分页获取数据 每页20条
 * <p>
 * item点击跳转点击跳转患者详情
 */
public class InhosFragment extends BaseFragment {


    private SmartRefreshLayout smartRefreshLayout;
    private RecyclerView rvListInhos;
    private List<InhosModel.RetValueBean> allInhos; //所有列表
    private InhosModel tempInhos;//缓存列表
    private int currentPage = 1;
    private int totalPage = 0;
    private Gson gson;

    private ConstraintLayout clEmptyInhos;
    private TextView tvEmptyInhos1, tvEmptyInhos2;

    long lastClick = 0;
    ZLoadingDialog zLoadingDialog;

    @Override
    protected View setContentView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_inhos, container, false);
    }


    @Override
    public void setUserVisibleHint(boolean isVisibleToUser) {
        super.setUserVisibleHint(isVisibleToUser);


        if (isVisibleToUser) {
            LogUtil.e("加载数据", "在院患者");
            zLoadingDialog = new ZLoadingDialog(HuidrActivityManager.getInstance().getCurrentActivity());
            zLoadingDialog.setLoadingBuilder(Z_TYPE.STAR_LOADING)//设置类型
                    .setLoadingColor(Color.BLUE)//颜色
                    .setHintText("正在加载,请稍候...").setHintTextSize(16) // 设置字体大小 dp
                    .setHintTextColor(Color.GRAY)  // 设置字体颜色
                    .setDurationTime(0.5) // 设置动画时间百分比 - 0.5倍
                    .setCanceledOnTouchOutside(false).setCancelable(false).show();
            Log.e("Dialog-InhosPatient","show");
            getDataByPage();
        } else {
            if(zLoadingDialog!=null){
                zLoadingDialog.dismiss();
            }
            inHosAdapter.notifyDataSetChanged();
        }
    }


    @Override
    protected void initData() {
        gson = new Gson();
        allInhos = new ArrayList<>();
        tempInhos = new InhosModel();
        inHosAdapter.setNewData(allInhos);
    }


    @Override
    protected void findView(View parent) {
        smartRefreshLayout = parent.findViewById(R.id.srl_layout);
        smartRefreshLayout.setEnableLoadMore(true);
        smartRefreshLayout.setEnableRefresh(true);

        smartRefreshLayout.setOnLoadMoreListener(new OnLoadMoreListener() {
            @Override
            public void onLoadMore(@NonNull RefreshLayout refreshLayout) {
                if (tempInhos.getRetValue().size() == 20 && currentPage < totalPage) {
                    currentPage += 1;
                    getDataByPage();
                } else {
                    smartRefreshLayout.finishLoadMore();
                    Toast.makeText(getActivity(), "数据已加载全部", Toast.LENGTH_SHORT).show();
                }

            }
        });

        smartRefreshLayout.setOnRefreshListener(new OnRefreshListener() {
            @Override
            public void onRefresh(@NonNull RefreshLayout refreshLayout) {
                currentPage = 1;
                getDataByPage();
            }
        });

        rvListInhos = parent.findViewById(R.id.rv_list_inhos);
        rvListInhos.setAdapter(inHosAdapter);
        rvListInhos.setLayoutManager(new LinearLayoutManager(getActivity()));


        clEmptyInhos = parent.findViewById(R.id.cl_empty_inhos);
        tvEmptyInhos1 = parent.findViewById(R.id.tv_empty_inhos1);
        tvEmptyInhos2 = parent.findViewById(R.id.tv_empty_inhos2);

        tvEmptyInhos2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (tvEmptyInhos2.getText().toString().equals("立即刷新")) {
                    currentPage = 1;
                    inHosAdapter.getData().clear();
                    getDataByPage();
                }
            }
        });

        LogUtil.e("获取最近查看", "123");

    }

    private BaseQuickAdapter<InhosModel.RetValueBean, BaseViewHolder> inHosAdapter = new BaseQuickAdapter<InhosModel.RetValueBean, BaseViewHolder>(R.layout.item_patient_scroll_layout) {

        @Override
        protected void convert(final BaseViewHolder helper, final InhosModel.RetValueBean item) {

//            头像
            ImageView imgItemHead = helper.getView(R.id.img_item_head);
            setPatientImage(imgItemHead, item.getBindUserRelationship(), item.getUserSex());
//            提醒
            ImageView imgNotice = helper.getView(R.id.img_notice);
            imgNotice.setVisibility(View.GONE);
//            姓名
            TextView tvItemName = helper.getView(R.id.tv_item_name);
            tvItemName.setText(item.getUserName());
//            住院号
            TextView tvPatientNum = helper.getView(R.id.tv_patient_num);
            tvPatientNum.setText(item.getLatelyAdmitNo());
//            日期
            TextView tvItemDate = helper.getView(R.id.tv_item_date);
            tvItemDate.setText(item.getLatelyVisitingDate());
//            状态
            TextView tvItemMsg = helper.getView(R.id.tv_item_msg);
            tvItemMsg.setText(item.getLatelyAdmissionDiagnosis());
//            模板
            TextView tvModel = helper.getView(R.id.tv_model);
            tvModel.setText(item.getFollowupName());


            final TextView tvRight = helper.getView(R.id.tv_scroll_right);

            if (item.isIsFollow()) {
                String str = "<font>已<br>关注</font>";
                tvRight.setText(Html.fromHtml(str));
                tvRight.setBackgroundResource(R.drawable.shape_atten_gray);
            } else {
                String str = "<font>关注<br>患者</font>";
                tvRight.setText(Html.fromHtml(str));
                tvRight.setBackgroundResource(R.drawable.shape_attent_blue);
            }

            tvRight.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (item.isIsFollow()) {
//                        取消关注
//                        modifyAttent(false, helper.getAdapterPosition(), item.getId());
                        inHosAdapter.notifyItemChanged(helper.getAdapterPosition());
                        com.huidr.lib.commom.util.Toast.getInstance(getContext()).show("该患者已关注", 500);
                    } else {
//                        关注患者
//                        modifyAttent(true, helper.getAdapterPosition(), item.getId());
                        showCoopDialog(true, helper.getAdapterPosition(), item.getId());

                    }
                }
            });

            ConstraintLayout clItem = helper.getView(R.id.cl_item);
//            点击跳转 患者详情  patientData_inHos.html?id=52366
            clItem.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {

                    if (System.currentTimeMillis() - lastClick > 1000) {
                        JSONObject jsonObject = new JSONObject();
                        jsonObject.put("id", item.getId());
                        SharedPreferenciesUtil.putData("psearchID", jsonObject.toJSONString());
                        SharedPreferenciesUtil.putData("followDoctorId", item.getDoctorId());

                        Intent intent1 = new Intent(getActivity(), WebActivity.class);
                        Bundle bundle = new Bundle();
                        bundle.putString("url", "patientData_inHos.html");
                        intent1.putExtras(bundle);
                        startActivity(intent1);
                        lastClick = System.currentTimeMillis();
                    }
                }
            });
        }
    };

    //    取消添加协同对话框
    public void showCoopDialog(final boolean atten, final int position, final int patientId) {

        final Dialog builder = new Dialog(getContext(), R.style.jmui_default_dialog_style);
        //final Dialog builder = new Dialog(this, R.style.jmui_default_dialog_style);
        View view = LayoutInflater.from(getContext()).inflate(R.layout.dialog_content, null);

        TextView tvTitle = view.findViewById(R.id.tv_title);
        TextView tvFooter1 = view.findViewById(R.id.tv_footer1);
        TextView tvFooter2 = view.findViewById(R.id.tv_footer2);

        tvTitle.setText("是否关注该患者！");


//        取消
        tvFooter1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                builder.cancel();
                inHosAdapter.notifyItemChanged(position);

            }
        });
//确定
        tvFooter2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                builder.cancel();
                modifyAttent(atten, position, patientId);
                inHosAdapter.notifyItemChanged(position);
            }
        });

        builder.setContentView(view);
        //builder.setCanceledOnTouchOutside(true);
        builder.show();
        Window window = builder.getWindow();
        WindowManager.LayoutParams lp = window.getAttributes();
        WindowManager windowManager = getActivity().getWindowManager();
        Display display = windowManager.getDefaultDisplay();
        lp.width = (int) (display.getWidth() * 0.7);
//        lp.height = (int) (display.getHeight() * 0.1);
        window.setAttributes(lp);
    }

    //  根据关系类型  设置默认图片
    public void setPatientImage(ImageView image, String ship, int sex) {
        if (ship == null) {
            image.setBackgroundResource(R.drawable.head_patient);
            return;
        }
        switch (ship) {
            case "本人":
                if (sex == 1) {
                    image.setBackgroundResource(R.drawable.my_him);
                } else {
                    image.setBackgroundResource(R.drawable.my_her);
                }
                break;
            case "丈夫":
                image.setBackgroundResource(R.drawable.husband);
                break;
            case "妻子":
                image.setBackgroundResource(R.drawable.wife);
                break;
            case "爸爸":
                image.setBackgroundResource(R.drawable.papa);
                break;
            case "妈妈":
                image.setBackgroundResource(R.drawable.mama);
                break;
            case "儿子":
                image.setBackgroundResource(R.drawable.son);
                break;
            case "女儿":
                image.setBackgroundResource(R.drawable.daughter);
                break;
            case "其他":
                image.setBackgroundResource(R.drawable.head_patient);
                break;
            default:
                image.setBackgroundResource(R.drawable.head_patient);
                break;
        }
    }


    //    关注患者  取消关注
    public void modifyAttent(final boolean atten, final int position, final int patientId) {
        ThreadPoolManager.getInstance().execute(new Runnable() {
            @Override
            public void run() {
                String id = (String) SharedPreferenciesUtil.getData("id", "0");
//                String path = BuildConfig.baseUrl + "patient/doctorPatientMedical/addRemarksAndFollow?doctorId=" + id + "&patientId=" + patientId + "&isFollow=" + atten;
//                String path = "http://192.168.1.180:196/doctorPatientMedical/addRemarksAndFollow?doctorId=" + id + "&patientId=" + patientId + "&isFollow=" + atten;
                String path = BuildConfig.baseUrl + "patient/doctorPatientMedical/addRemarksAndFollow?doctorId=" + id + "&patientId=" + patientId + "&isFollow=" + atten;
                String result = PostAndGet.doGetHttp(path);

                LogUtil.e("关注", result);
                if (result.equals("网络异常")) {

                } else {
                    SimpleResultModel simpleResultModel = gson.fromJson(result, SimpleResultModel.class);
                    Message message = new Message();
                    message.obj = atten;
                    if (simpleResultModel.getStatus() == 0) {
                        message.what = 4;
                        message.arg1 = position;
                        handler.sendMessage(message);
                    } else {
                        message.what = 5;
                        handler.sendMessage(message);
                    }
                }
            }
        });
    }


    //    分页获取数据
    public void getDataByPage() {
        ThreadPoolManager.getInstance().execute(new Runnable() {
            @Override
            public void run() {
//                String path = BuildConfig.baseUrl + "patient/doctorPatientMedical/getFollowUpPoolList?pageIndex=" + currentPage + "&hospitalActionStatus=1&pageSize=20";
                String path = BuildConfig.baseUrl + "patient/doctorPatientMedical/getFollowUpPoolList?pageIndex=" + currentPage + "&hospitalActionStatus=1&pageSize=20";
                String result = PostAndGet.doGetHttp(path);
                tempInhos = new InhosModel();

                LogUtil.e("患者池 住院患者", result);
                if (result == null || result.equals("网络异常")) {
                    handler.sendEmptyMessage(3);
                } else {
                    tempInhos = gson.fromJson(result, InhosModel.class);
                    if (tempInhos == null) {
                        handler.sendEmptyMessage(3);
                    } else if (tempInhos.getStatus() == 0) {
                        totalPage = tempInhos.getTotalPage();
                        if (currentPage == 1) {
                            handler.sendEmptyMessage(currentPage);
                        } else {
                            handler.sendEmptyMessage(2);
                        }
                    } else {
                        handler.sendEmptyMessage(3);
                    }
                }
            }
        });
    }

    private Handler handler = new Handler() {
        @Override
        public void handleMessage(Message msg) {
            super.handleMessage(msg);
            switch (msg.what) {
                case 1:
                    if (zLoadingDialog != null) {
                        new Handler().postDelayed(new Runnable() {
                            @Override
                            public void run() {
                                zLoadingDialog.dismiss();
                                zLoadingDialog = null;
                            }
                        }, 500);
                    }
                    inHosAdapter.getData().clear();
                    if (tempInhos == null || tempInhos.getRetValue() == null || tempInhos.getRetValue().size() == 0) {
                        clEmptyInhos.setVisibility(View.VISIBLE);
                        smartRefreshLayout.setVisibility(View.GONE);
                        String tip1 = "您还暂未关注患者";
                        String tip2 = "左滑患者列表即可关注";
                        tvEmptyInhos1.setText(tip1);
                        tvEmptyInhos2.setText(tip2);
                    } else {
                        clEmptyInhos.setVisibility(View.GONE);
                        smartRefreshLayout.setVisibility(View.VISIBLE);
                        inHosAdapter.getData().addAll(tempInhos.getRetValue());
                        inHosAdapter.notifyDataSetChanged();
                    }
                    smartRefreshLayout.finishRefresh();
                    break;
                case 2:
                    inHosAdapter.getData().addAll(tempInhos.getRetValue());
                    inHosAdapter.notifyDataSetChanged();
                    smartRefreshLayout.finishLoadMore();
                    break;
                case 3:
                    if(zLoadingDialog!=null){
                        zLoadingDialog.dismiss();
                    }
                    clEmptyInhos.setVisibility(View.VISIBLE);
                    smartRefreshLayout.setVisibility(View.GONE);
                    String tip1 = "网络错误~";
                    String tip2 = "<font color='#248cfa'><u>立即刷新<u></font>";
                    tvEmptyInhos1.setText(tip1);
                    tvEmptyInhos2.setText(Html.fromHtml(tip2));
                    smartRefreshLayout.finishRefresh();
                    smartRefreshLayout.finishLoadMore();
                    break;
                case 4://取消关注 关注患者 成功
                    String tip = "";
                    Boolean atten = (Boolean) msg.obj;
                    if (atten) {
                        tip = "关注患者成功";
                        inHosAdapter.getData().get(msg.arg1).setIsFollow(true);
                    } else {
                        tip = "取消成功";
                        inHosAdapter.getData().get(msg.arg1).setIsFollow(false);
                    }
                    com.huidr.lib.commom.util.Toast.getInstance(getActivity()).show(tip, 500);
                    inHosAdapter.notifyDataSetChanged();
                    break;
                case 5://取消关注 关注患者 失败
                    String str = "";
                    Boolean atten1 = (Boolean) msg.obj;
                    if (atten1) {
                        str = "关注患者失败";
                    } else {
                        str = "取消失败";
                    }
                    com.huidr.lib.commom.util.Toast.getInstance(getActivity()).show(str, 500);
                    inHosAdapter.notifyDataSetChanged();
                    break;
            }

        }
    };


//    String[] tips;//获取的标签数组
//    int[] tipTypes;//获取标签类型的数组
//
//    TabLayout tlTipInhos;//tl_tip_inhos
//    ImageView imageTip;
//    ScrollPageView viewPager;
//
//    List<Fragment> listFragment;
//    InHosFragmentAdapter inHosFragmentAdapter;
//
//
//    @Override
//    protected View setContentView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
//        return inflater.inflate(R.layout.fragment_inhos, container, false);
//    }
//
//
//    @Override
//    public void setUserVisibleHint(boolean isVisibleToUser) {
//        super.setUserVisibleHint(isVisibleToUser);
//        if (isVisibleToUser) {
//            tips = getArguments().getStringArray("tip");
//            tipTypes = getArguments().getIntArray("tipType");
//            listFragment.clear();
//            for (int i = 0; i < tips.length; i++) {
//                GeneralInhosFragment generalInhosFragment = GeneralInhosFragment.newInstance_Fragment(tips[i]);
//                listFragment.add(generalInhosFragment);
//            }
//            inHosFragmentAdapter.notifyDataSetChanged();
//        }
//    }
//
//
//    @Override
//    protected void initData() {
//
//    }
//
//
//    @Override
//    protected void findView(View parent) {
//
//        tlTipInhos = parent.findViewById(R.id.tl_tip_inhos);
//        imageTip = parent.findViewById(R.id.img_tip);
//        viewPager = parent.findViewById(R.id.vp_inhos);
//
//        listFragment = new ArrayList<>();
//
//
//        inHosFragmentAdapter = new InHosFragmentAdapter(getChildFragmentManager());
//        viewPager.setAdapter(inHosFragmentAdapter);
//        tlTipInhos.setupWithViewPager(viewPager);
//
//        imageTip.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                if (MulityClickUtils.isFastClick()) {
//                    Intent intent = new Intent(getActivity(), WebActivity.class);
//                    Bundle bundle = new Bundle();
//                    bundle.putString("url", "patientData_setTagsNew.html");
//                    intent.putExtras(bundle);
//                    startActivity(intent);
//                }
//            }
//        });
//
//        tlTipInhos.setOnTabSelectedListener(new TabLayout.OnTabSelectedListener() {
//            @Override
//            public void onTabSelected(TabLayout.Tab tab) {
//                int position = tab.getPosition();
//
//                tab.setText(tips[position]);
//            }
//
//            @Override
//            public void onTabUnselected(TabLayout.Tab tab) {
//                int position = tab.getPosition();
//                if (tips[position].length() <= 4) {
//                    tab.setText(tips[position]);
//                } else {
//                    String tip = tips[position];
//                    tip = tip.substring(0, 4);
//                    tip = tip.concat("...");
//                    tab.setText(tip);
//                }
//
//            }
//
//            @Override
//            public void onTabReselected(TabLayout.Tab tab) {
//
//            }
//        });
//    }
//
//    class InHosFragmentAdapter extends FragmentPagerAdapter {
//
//        public InHosFragmentAdapter(FragmentManager fm) {
//            super(fm);
//        }
//
//        @Override
//        public Fragment getItem(int i) {
//            return listFragment.get(i);
//        }
//
//        @Override
//        public int getCount() {
//            return listFragment.size();
//        }
//
//        @Nullable
//        @Override
//        public CharSequence getPageTitle(int position) {
//            if (tips[position].length() <= 4) {
//                return tips[position];
//            } else {
//                String tip = tips[position];
//                tip = tip.substring(0, 4);
//                tip = tip.concat("...");
//                return tip;
//            }
//        }
//    }
}
