package com.huidr.HuiDrDoctor.module.home;

import java.util.List;

/**
 * @author: Administrator
 * @date: 2019-12-05
 */
public class SearchContractModel {


    /**
     * status : 0
     * page : 1
     * totalPage : 1
     * retValue : [{"id":100161,"mobile":"13916633695","userName":"沈纳","userIcon":"system/doctor/8177-81-12527.jpg",
     * "userSex":1,"userTitle":"副主任医师","userJobNumber":"12527","hospitalId":8177,"hospitalName":"复旦大学附属中山医院",
     * "departmentId":81,"hospitalDepartment":"耳鼻喉科","fabulousCount":0,"outpatientTimeList":"[{\"1\":{\"sel\":false},\"2\":
     * {\"sel\":false},\"3\":{\"sel\":true},\"4\":{\"sel\":false},\"5\":{\"sel\":false},\"6\":{\"sel\":false},\"7\":{\"sel\":false}},
     * {\"1\":{\"sel\":false},\"2\":{\"sel\":true},\"3\":{\"sel\":false},\"4\":{\"sel\":false},\"5\":{\"sel\":false},\"6\":{\"sel\":false},\"7\":{\"sel\":false}}]","imPassword":"","isSetLoginPassword":false,"doctorSearchDate":"2019-04-25 00:00:36","osName":"Android","isFollowup":false,"isContacts":false,"isAssist":false,"isApply":false},{"id":140352,"mobile":"13666666665","userName":"沈振斌","userIcon":"140352/doctor/1575947817726.png","userSex":1,"userTitle":"副主任医师","userJobNumber":"12054","hospitalId":8177,"hospitalName":"复旦大学附属中山医院","departmentId":74,"hospitalDepartment":"普外科","fabulousCount":0,"imPassword":"","isSetLoginPassword":false,"doctorSearchDate":"2019-04-25 00:01:01","osName":"iOS","isFollowup":true,"isContacts":false,"isAssist":false,"isApply":false}]
     */

    private int status;
    private int page;
    private int totalPage;
    private List<RetValueBean> retValue;

    public int getStatus() {
        return status;
    }

    public void setStatus(int status) {
        this.status = status;
    }

    public int getPage() {
        return page;
    }

    public void setPage(int page) {
        this.page = page;
    }

    public int getTotalPage() {
        return totalPage;
    }

    public void setTotalPage(int totalPage) {
        this.totalPage = totalPage;
    }

    public List<RetValueBean> getRetValue() {
        return retValue;
    }

    public void setRetValue(List<RetValueBean> retValue) {
        this.retValue = retValue;
    }

    public static class RetValueBean {
        /**
         * id : 100161
         * mobile : 13916633695
         * userName : 沈纳
         * userIcon : system/doctor/8177-81-12527.jpg
         * userSex : 1
         * userTitle : 副主任医师
         * userJobNumber : 12527
         * hospitalId : 8177
         * hospitalName : 复旦大学附属中山医院
         * departmentId : 81
         * hospitalDepartment : 耳鼻喉科
         * fabulousCount : 0
         * outpatientTimeList : [{"1":{"sel":false},"2":{"sel":false},"3":{"sel":true},"4":{"sel":false},"5":{"sel":false},"6":{"sel":false},"7":{"sel":false}},{"1":{"sel":false},"2":{"sel":true},"3":{"sel":false},"4":{"sel":false},"5":{"sel":false},"6":{"sel":false},"7":{"sel":false}}]
         * imPassword :
         * isSetLoginPassword : false
         * doctorSearchDate : 2019-04-25 00:00:36
         * osName : Android
         * isFollowup : false
         * isContacts : false
         * isAssist : false
         * isApply : false
         */

        private int id;
        private String mobile;
        private String userName;
        private String userIcon;
        private int userSex;
        private String userTitle;
        private String userJobNumber;
        private int hospitalId;
        private String hospitalName;
        private int departmentId;
        private String hospitalDepartment;
        private int fabulousCount;
        private String outpatientTimeList;
        private String imPassword;
        private boolean isSetLoginPassword;
        private String doctorSearchDate;
        private String osName;
        private boolean isFollowup;
        private boolean isContacts;
        private boolean isAssist;
        private boolean isApply;

        public int getId() {
            return id;
        }

        public void setId(int id) {
            this.id = id;
        }

        public String getMobile() {
            return mobile;
        }

        public void setMobile(String mobile) {
            this.mobile = mobile;
        }

        public String getUserName() {
            return userName;
        }

        public void setUserName(String userName) {
            this.userName = userName;
        }

        public String getUserIcon() {
            return userIcon;
        }

        public void setUserIcon(String userIcon) {
            this.userIcon = userIcon;
        }

        public int getUserSex() {
            return userSex;
        }

        public void setUserSex(int userSex) {
            this.userSex = userSex;
        }

        public String getUserTitle() {
            return userTitle;
        }

        public void setUserTitle(String userTitle) {
            this.userTitle = userTitle;
        }

        public String getUserJobNumber() {
            return userJobNumber;
        }

        public void setUserJobNumber(String userJobNumber) {
            this.userJobNumber = userJobNumber;
        }

        public int getHospitalId() {
            return hospitalId;
        }

        public void setHospitalId(int hospitalId) {
            this.hospitalId = hospitalId;
        }

        public String getHospitalName() {
            return hospitalName;
        }

        public void setHospitalName(String hospitalName) {
            this.hospitalName = hospitalName;
        }

        public int getDepartmentId() {
            return departmentId;
        }

        public void setDepartmentId(int departmentId) {
            this.departmentId = departmentId;
        }

        public String getHospitalDepartment() {
            return hospitalDepartment;
        }

        public void setHospitalDepartment(String hospitalDepartment) {
            this.hospitalDepartment = hospitalDepartment;
        }

        public int getFabulousCount() {
            return fabulousCount;
        }

        public void setFabulousCount(int fabulousCount) {
            this.fabulousCount = fabulousCount;
        }

        public String getOutpatientTimeList() {
            return outpatientTimeList;
        }

        public void setOutpatientTimeList(String outpatientTimeList) {
            this.outpatientTimeList = outpatientTimeList;
        }

        public String getImPassword() {
            return imPassword;
        }

        public void setImPassword(String imPassword) {
            this.imPassword = imPassword;
        }

        public boolean isIsSetLoginPassword() {
            return isSetLoginPassword;
        }

        public void setIsSetLoginPassword(boolean isSetLoginPassword) {
            this.isSetLoginPassword = isSetLoginPassword;
        }

        public String getDoctorSearchDate() {
            return doctorSearchDate;
        }

        public void setDoctorSearchDate(String doctorSearchDate) {
            this.doctorSearchDate = doctorSearchDate;
        }

        public String getOsName() {
            return osName;
        }

        public void setOsName(String osName) {
            this.osName = osName;
        }

        public boolean isIsFollowup() {
            return isFollowup;
        }

        public void setIsFollowup(boolean isFollowup) {
            this.isFollowup = isFollowup;
        }

        public boolean isIsContacts() {
            return isContacts;
        }

        public void setIsContacts(boolean isContacts) {
            this.isContacts = isContacts;
        }

        public boolean isIsAssist() {
            return isAssist;
        }

        public void setIsAssist(boolean isAssist) {
            this.isAssist = isAssist;
        }

        public boolean isIsApply() {
            return isApply;
        }

        public void setIsApply(boolean isApply) {
            this.isApply = isApply;
        }
    }
}
