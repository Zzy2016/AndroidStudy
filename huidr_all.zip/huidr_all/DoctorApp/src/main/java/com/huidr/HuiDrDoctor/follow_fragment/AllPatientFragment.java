package com.huidr.HuiDrDoctor.follow_fragment;

import android.app.Dialog;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import androidx.annotation.NonNull;

import android.text.Html;
import android.util.Log;
import android.view.Display;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.ImageView;
import android.widget.TextView;


import com.alibaba.fastjson.JSONObject;
import com.chad.library.adapter.base.BaseQuickAdapter;
import com.chad.library.adapter.base.BaseViewHolder;
import com.google.gson.Gson;
import com.huidr.HuiDrDoctor.activity.WebActivity;
import com.huidr.HuiDrDoctor.activity.main.Consult.utils.PostAndGet;

import com.huidr.HuiDrDoctor.debug.BuildConfig;
import com.huidr.HuiDrDoctor.debug.R;
import com.huidr.HuiDrDoctor.module.home.AllPatientModel;
import com.huidr.HuiDrDoctor.module.home.SimpleResultModel;
import com.huidr.HuiDrDoctor.util.LogUtil;
import com.huidr.HuiDrDoctor.util.MulityClickUtils;
import com.huidr.HuiDrDoctor.util.ThreadPoolManager;
import com.huidr.lib.commom.base.BaseFragment;
import com.huidr.lib.commom.base.HuidrActivityManager;
import com.huidr.lib.commom.util.Toast;
import com.scwang.smartrefresh.layout.SmartRefreshLayout;
import com.scwang.smartrefresh.layout.api.RefreshLayout;
import com.scwang.smartrefresh.layout.listener.OnLoadMoreListener;
import com.scwang.smartrefresh.layout.listener.OnRefreshListener;
import com.zyao89.view.zloading.ZLoadingDialog;
import com.zyao89.view.zloading.Z_TYPE;


import java.util.ArrayList;
import java.util.List;

import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import jiguang.chat.utils.oss.SharedPreferenciesUtil;

/**
 * item
 * 头像，患者姓名，住院号，时间，状态，所匹配模板（默认显示18个端，第18个字段为省略号）
 * <p>
 * 1.通过医院匹配的患者
 * <p>
 * 2.患者报到的患者
 * <p>
 * 3.精卫问卷的自动匹配患者
 * <p>
 * 4.协同医生的共享
 * <p>
 * <p>
 * 点击跳转随访列表
 * <p>
 * patient/doctorPatientMedical/getFollowUpPoolList
 * pageIndex
 * pageSize 20
 * <p>
 * 全部患者 根据标签
 */
public class AllPatientFragment extends BaseFragment {


    private SmartRefreshLayout srlLayout;
    private RecyclerView rvListAll;

    private ConstraintLayout clEmptyAll;
    private TextView tvEmptyAll1, tvEmptyAll2;

    List<AllPatientModel.RetValueBean> allPatient;
    AllPatientModel tempAllPatient;
    private int currentPage = 1;
    private int totalPage = 1;
    Gson gson;

    long lastClick = 0;
    ZLoadingDialog zLoadingDialog;


    @Override
    protected void initData() {///////////

        allPatient = new ArrayList<>();
        tempAllPatient = new AllPatientModel();
        allAdapter.setNewData(allPatient);
        gson = new Gson();
    }


    @Override
    public void setUserVisibleHint(boolean isVisibleToUser) {
        super.setUserVisibleHint(isVisibleToUser);
        LogUtil.e("加载数据", "全部患者");
        if (isVisibleToUser) {

            zLoadingDialog = new ZLoadingDialog(HuidrActivityManager.getInstance().getCurrentActivity());
            zLoadingDialog.setLoadingBuilder(Z_TYPE.STAR_LOADING)//设置类型
                    .setLoadingColor(Color.BLUE)//颜色
                    .setHintText("正在加载,请稍候...").setHintTextSize(16) // 设置字体大小 dp
                    .setHintTextColor(Color.GRAY)  // 设置字体颜色
                    .setDurationTime(0.5) // 设置动画时间百分比 - 0.5倍
                    .setCanceledOnTouchOutside(false).setCancelable(false).show();
            Log.e("Dialog-AllPatient", "show");

            getDataByPage();
        } else {
            if (zLoadingDialog != null) {
                zLoadingDialog.dismiss();
            }
            allAdapter.notifyDataSetChanged();
        }
    }

    public void getDataByPage() {
        ThreadPoolManager.getInstance().execute(new Runnable() {
            @Override
            public void run() {

                String path = BuildConfig.baseUrl + "patient/doctorPatientMedical/getFollowUpPoolList?pageIndex=" + currentPage + "&pageSize=20";

                String result = PostAndGet.doGetHttp(path);

                tempAllPatient = new AllPatientModel();
//                LogUtil.e("患者池 全部患者", result);
                Log.e("患者池 全部患者" + currentPage, result);

                if (result == null || result.equals("网络异常")) {
                    handler.sendEmptyMessage(3);
                } else {
                    tempAllPatient = gson.fromJson(result, AllPatientModel.class);
                    if (tempAllPatient.getStatus() == 0) {
                        totalPage = tempAllPatient.getTotalPage();
                        if (currentPage == 1) {
                            handler.sendEmptyMessage(1);
                        } else {
                            handler.sendEmptyMessage(2);
                        }
                    } else {
                        handler.sendEmptyMessage(3);
                    }
                }

            }
        });
    }


    private Handler handler = new Handler() {
        @Override
        public void handleMessage(Message msg) {
            super.handleMessage(msg);
            switch (msg.what) {
                case 1:
                    if (zLoadingDialog != null) {
                        new Handler().postDelayed(new Runnable() {
                            @Override
                            public void run() {
                                zLoadingDialog.dismiss();
                                zLoadingDialog = null;
                            }
                        }, 500);
                    }
                    allAdapter.getData().clear();
                    if (tempAllPatient == null || tempAllPatient.getRetValue() == null || tempAllPatient.getRetValue().size() == 0) {
                        clEmptyAll.setVisibility(View.VISIBLE);
                        srlLayout.setVisibility(View.GONE);
                        String tip1 = "您还暂未关注患者";
                        String tip2 = "左滑患者列表即可关注";
                        tvEmptyAll1.setText(tip1);
                        tvEmptyAll2.setText(tip2);
                    } else {

                        clEmptyAll.setVisibility(View.GONE);
                        srlLayout.setVisibility(View.VISIBLE);

                        allAdapter.getData().addAll(tempAllPatient.getRetValue());
                        allAdapter.notifyDataSetChanged();
                    }
                    srlLayout.finishRefresh();
                    break;
                case 2:
                    allAdapter.getData().addAll(tempAllPatient.getRetValue());
                    allAdapter.notifyDataSetChanged();
                    srlLayout.finishLoadMore();
                    break;
                case 3:
                    if (zLoadingDialog != null) {
                        zLoadingDialog.dismiss();
                    }
                    srlLayout.finishRefresh();
                    srlLayout.finishLoadMore();
                    String tip1 = "网络错误~";
                    String tip2 = "<font color='#248cfa'><u>立即刷新<u></font>";

                    srlLayout.setVisibility(View.GONE);
                    clEmptyAll.setVisibility(View.VISIBLE);
                    tvEmptyAll1.setText(tip1);
                    tvEmptyAll2.setText(Html.fromHtml(tip2));
                    break;
                case 4:
                    String tip = "";
                    Boolean atten = (Boolean) msg.obj;
                    if (atten) {
                        tip = "关注患者成功";
                        allAdapter.getData().get(msg.arg1).setIsFollow(true);
                    } else {
                        tip = "取消成功";
                        allAdapter.getData().get(msg.arg1).setIsFollow(false);
                    }
                    allAdapter.notifyDataSetChanged();

                    com.huidr.lib.commom.util.Toast.getInstance(getActivity()).show(tip, 500);

                    break;
                case 5:
                    String str = "";
                    Boolean atten1 = (Boolean) msg.obj;
                    if (atten1) {
                        str = "关注患者失败";
                    } else {
                        str = "取消失败";
                    }
                    allAdapter.notifyDataSetChanged();

                    com.huidr.lib.commom.util.Toast.getInstance(getActivity()).show(str, 500);
                    break;
            }
        }
    };


    @Override
    protected View setContentView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_all_patient, container, false);
    }


    @Override
    protected void findView(View parent) {
        srlLayout = parent.findViewById(R.id.srl_layout);
        srlLayout.setEnableRefresh(true);
        srlLayout.setEnableLoadMore(true);
        srlLayout.setOnRefreshListener(new OnRefreshListener() {
            @Override
            public void onRefresh(@NonNull RefreshLayout refreshLayout) {
                currentPage = 1;
                getDataByPage();
            }
        });
        srlLayout.setOnLoadMoreListener(new OnLoadMoreListener() {
            @Override
            public void onLoadMore(@NonNull RefreshLayout refreshLayout) {
//                if (tempAllPatient.getRetValue().size() < 20) {
//                    Toast.getInstance(getContext()).show("数据加载全部", 500);
//                } else {
//                    currentPage += 1;
//                    getDataByPage();
//                }

                if (tempAllPatient.getRetValue().size() == 20 && currentPage < totalPage) {
                    currentPage += 1;
                    getDataByPage();
                } else {
                    srlLayout.finishLoadMore();
                    Toast.getInstance(getContext()).show("数据加载全部", 500);
                }
            }
        });

        rvListAll = parent.findViewById(R.id.rv_list_all);
        rvListAll.setAdapter(allAdapter);
        rvListAll.setLayoutManager(new LinearLayoutManager(getActivity()));

        clEmptyAll = parent.findViewById(R.id.cl_empty_all);
        tvEmptyAll1 = parent.findViewById(R.id.tv_empty_all1);
        tvEmptyAll2 = parent.findViewById(R.id.tv_empty_all2);

        tvEmptyAll2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (tvEmptyAll2.getText().toString().equals("立即刷新")) {
                    currentPage = 1;
                    getDataByPage();
                }
            }
        });

    }

    private BaseQuickAdapter<AllPatientModel.RetValueBean, BaseViewHolder> allAdapter = new BaseQuickAdapter<AllPatientModel.RetValueBean, BaseViewHolder>(R.layout.item_patient_scroll_layout) {
        @Override
        protected void convert(final BaseViewHolder helper, final AllPatientModel.RetValueBean item) {


//            头像
            ImageView imgItemHead = helper.getView(R.id.img_item_head);
            setPatientImage(imgItemHead, item.getBindUserRelationship(), item.getUserSex());
//            提醒
            ImageView imgNotice = helper.getView(R.id.img_notice);
            imgNotice.setVisibility(View.GONE);
//            姓名
            TextView tvItemName = helper.getView(R.id.tv_item_name);
            tvItemName.setText(item.getUserName());
//            住院号
            TextView tvPatientNum = helper.getView(R.id.tv_patient_num);
            tvPatientNum.setText(item.getLatelyAdmitNo());
//            日期
            TextView tvItemDate = helper.getView(R.id.tv_item_date);
            tvItemDate.setText(item.getLatelyVisitingDate());
//            状态
            TextView tvItemMsg = helper.getView(R.id.tv_item_msg);
            tvItemMsg.setText(item.getLatelyAdmissionDiagnosis());
//            模板
            TextView tvModel = helper.getView(R.id.tv_model);
            tvModel.setText(item.getFollowupName());


            final TextView tvRight = helper.getView(R.id.tv_scroll_right);

            if (item.isIsFollow()) {
                String str = "<font>已<br>关注</font>";
                tvRight.setText(Html.fromHtml(str));
                tvRight.setBackgroundResource(R.drawable.shape_atten_gray);
            } else {
                String str = "<font>关注<br>患者</font>";
                tvRight.setText(Html.fromHtml(str));
                tvRight.setBackgroundResource(R.drawable.shape_attent_blue);
            }

            tvRight.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (MulityClickUtils.isFastClick()) {
                        if (item.isIsFollow()) {
//                       已经关注 取消关注

                            allAdapter.notifyItemChanged(helper.getAdapterPosition());
                            Toast.getInstance(getContext()).show("该患者已关注", 500);

                        } else {
//                        未关注 添加关注
//                        modifyAttent(true, helper.getAdapterPosition(), item.getId());
                            showCoopDialog(true, helper.getAdapterPosition(), item.getId());
                        }
                    }
                }
            });


            ConstraintLayout clItem = helper.getView(R.id.cl_item);
//            随访列表
            clItem.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {

                    if (System.currentTimeMillis() - lastClick > 1000) {
                        JSONObject jsonObject = new JSONObject();
                        jsonObject.put("id", item.getId());
                        SharedPreferenciesUtil.putData("psearchID", jsonObject.toJSONString());//患者ID
                        SharedPreferenciesUtil.putData("followDoctorId", item.getDoctorId());  //医生ID

                        Intent intent1 = new Intent(getActivity(), WebActivity.class);
                        Bundle bundle = new Bundle();
                        bundle.putString("url", "patientData.html");
                        intent1.putExtras(bundle);
                        startActivity(intent1);
                        lastClick = System.currentTimeMillis();
                    }
                }
            });
        }
    };


    //  根据关系类型  设置默认图片
    public void setPatientImage(ImageView image, String ship, int sex) {
        if (ship == null) {
            image.setBackgroundResource(R.drawable.head_patient);
            return;
        }
        switch (ship) {
            case "本人":
                if (sex == 1) {
                    image.setBackgroundResource(R.drawable.my_him);
                } else {
                    image.setBackgroundResource(R.drawable.my_her);
                }
                break;
            case "丈夫":
                image.setBackgroundResource(R.drawable.husband);
                break;
            case "妻子":
                image.setBackgroundResource(R.drawable.wife);
                break;
            case "爸爸":
                image.setBackgroundResource(R.drawable.papa);
                break;
            case "妈妈":
                image.setBackgroundResource(R.drawable.mama);
                break;
            case "儿子":
                image.setBackgroundResource(R.drawable.son);
                break;
            case "女儿":
                image.setBackgroundResource(R.drawable.daughter);
                break;
            case "其他":
                image.setBackgroundResource(R.drawable.head_patient);
                break;
            default:
                image.setBackgroundResource(R.drawable.head_patient);
                break;
        }
    }


    //    取消添加协同对话框
    public void showCoopDialog(final boolean atten, final int position, final int patientId) {

        final Dialog builder = new Dialog(getContext(), R.style.jmui_default_dialog_style);
        //final Dialog builder = new Dialog(this, R.style.jmui_default_dialog_style);
        View view = LayoutInflater.from(getContext()).inflate(R.layout.dialog_content, null);

        TextView tvTitle = view.findViewById(R.id.tv_title);
        TextView tvFooter1 = view.findViewById(R.id.tv_footer1);
        TextView tvFooter2 = view.findViewById(R.id.tv_footer2);

        tvTitle.setText("是否关注该患者！");


//        取消
        tvFooter1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                builder.cancel();
                allAdapter.notifyItemChanged(position);
            }
        });
//确定
        tvFooter2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                builder.cancel();
                modifyAttent(atten, position, patientId);
                allAdapter.notifyItemChanged(position);
            }
        });

        builder.setContentView(view);
        //builder.setCanceledOnTouchOutside(true);
        builder.show();
        Window window = builder.getWindow();
        WindowManager.LayoutParams lp = window.getAttributes();
        WindowManager windowManager = getActivity().getWindowManager();
        Display display = windowManager.getDefaultDisplay();
        lp.width = (int) (display.getWidth() * 0.7);
//        lp.height = (int) (display.getHeight() * 0.1);
        window.setAttributes(lp);
    }

    //    关注患者  取消关注
    public void modifyAttent(final boolean atten, final int position, final int patientId) {
        ThreadPoolManager.getInstance().execute(new Runnable() {
            @Override
            public void run() {
                String id = (String) SharedPreferenciesUtil.getData("id", "0");
//                String path = BuildConfig.baseUrl + "patient/doctorPatientMedical/addRemarksAndFollow?doctorId=" + id + "&patientId=" + patientId + "&isFollow=" + atten;
//                String path = "http://192.168.1.180:196/doctorPatientMedical/addRemarksAndFollow?doctorId=" + id + "&patientId=" + patientId + "&isFollow=" + atten;
                String path = BuildConfig.baseUrl + "patient/doctorPatientMedical/addRemarksAndFollow?doctorId=" + id + "&patientId=" + patientId + "&isFollow=" + atten;
                String result = PostAndGet.doGetHttp(path);

                LogUtil.e("关注", result);
                if (result.equals("网络异常")) {

                } else {
                    SimpleResultModel simpleResultModel = gson.fromJson(result, SimpleResultModel.class);
                    Message message = new Message();
                    message.obj = atten;
                    if (simpleResultModel.getStatus() == 0) {
                        message.what = 4;
                        message.arg1 = position;
                        handler.sendMessage(message);
                    } else {
                        message.what = 5;
                        handler.sendMessage(message);
                    }
                }

            }
        });
    }

}
