package com.huidr.HuiDrDoctor.activity;

import android.Manifest;
import android.annotation.TargetApi;
import android.app.Activity;
import android.app.Dialog;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.provider.MediaStore;
import androidx.core.content.ContextCompat;
import android.text.Editable;
import android.text.Html;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.util.DisplayMetrics;
import android.view.Display;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.view.inputmethod.InputMethodManager;
import android.widget.AbsListView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.alibaba.fastjson.JSONObject;
import com.google.gson.Gson;
import com.huidr.HuiDrDoctor.activity.main.Consult.Model.SingleAcvice;
import com.huidr.HuiDrDoctor.activity.main.Consult.Model.SingleOrder;
import com.huidr.HuiDrDoctor.activity.main.Consult.Model.TimeModel;
import com.huidr.HuiDrDoctor.activity.main.Consult.utils.PostAndGet;
import com.huidr.HuiDrDoctor.activity.main.Consult.utils.UserStateBean;
import com.huidr.HuiDrDoctor.activity.main.Consult.utils.UtilState;
import com.huidr.HuiDrDoctor.debug.BuildConfig;
import com.huidr.HuiDrDoctor.debug.R;
import com.huidr.HuiDrDoctor.util.LogUtil;
import com.huidr.HuiDrDoctor.util.ThreadPoolManager;
import com.huidr.lib.commom.base.HuidrActivityManager;
import com.tendcloud.tenddata.TCAgent;

import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.lang.ref.WeakReference;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

import cn.jpush.im.android.api.JMessageClient;
import cn.jpush.im.android.api.content.EventNotificationContent;
import cn.jpush.im.android.api.content.FileContent;
import cn.jpush.im.android.api.content.ImageContent;
import cn.jpush.im.android.api.content.LocationContent;
import cn.jpush.im.android.api.content.TextContent;
import cn.jpush.im.android.api.enums.ContentType;
import cn.jpush.im.android.api.enums.ConversationType;
import cn.jpush.im.android.api.enums.MessageDirect;
import cn.jpush.im.android.api.event.MessageEvent;
import cn.jpush.im.android.api.model.Conversation;
import cn.jpush.im.android.api.model.GroupInfo;
import cn.jpush.im.android.api.model.Message;
import cn.jpush.im.android.api.model.UserInfo;
import cn.jpush.im.android.api.options.MessageSendingOptions;
import cn.jpush.im.android.eventbus.EventBus;
import jiguang.chat.activity.BaseActivity;
import jiguang.chat.activity.ChatActivity;
import jiguang.chat.activity.ChooseAtMemberActivity;
import jiguang.chat.activity.ForwardMsgActivity;
import jiguang.chat.activity.FriendListActivity;
import jiguang.chat.adapter.ChattingListAdapter;
import jiguang.chat.application.JGApplication;
import jiguang.chat.entity.Event;
import jiguang.chat.entity.EventType;
import jiguang.chat.model.Constants;
import jiguang.chat.pickerimage.PickImageActivity;
import jiguang.chat.pickerimage.utils.Extras;
import jiguang.chat.pickerimage.utils.RequestCode;
import jiguang.chat.pickerimage.utils.SendImageHelper;
import jiguang.chat.pickerimage.utils.StorageType;
import jiguang.chat.pickerimage.utils.StorageUtil;
import jiguang.chat.pickerimage.utils.StringUtil;
import jiguang.chat.utils.IdHelper;
import jiguang.chat.utils.SimpleCommonUtils;
import jiguang.chat.utils.ToastUtil;
import jiguang.chat.utils.event.ImageEvent;
import jiguang.chat.utils.keyboard.XhsEmoticonsKeyBoard;
import jiguang.chat.utils.keyboard.data.EmoticonEntity;
import jiguang.chat.utils.keyboard.interfaces.EmoticonClickListener;
import jiguang.chat.utils.keyboard.utils.EmoticonsKeyboardUtils;
import jiguang.chat.utils.keyboard.widget.EmoticonsEditText;
import jiguang.chat.utils.keyboard.widget.FuncLayout;
import jiguang.chat.utils.oss.SharedPreferenciesUtil;
import jiguang.chat.utils.photovideo.takevideo.utils.FileUtils;
import jiguang.chat.view.ChatView;
import jiguang.chat.view.FuncGridView;
import jiguang.chat.view.TipItem;
import jiguang.chat.view.TipView;
import jiguang.chat.view.listview.DropDownListView;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

import static jiguang.chat.application.JGApplication.GROUP_NAME;
import static jiguang.chat.application.JGApplication.MEMBERS_COUNT;
import static jiguang.chat.application.JGApplication.MsgIDs;

/*
 * 咨询聊天页
 *
 * 获取订单ID
 * 查询订单信息
 * 查询是否有建议
 *
 * 发起建议
 *
 * 结束咨询
 *
 * 获取订单的时间 替换点第一条消息的时间
 *
 * */
public class ConsultReplyActivity extends BaseActivity implements View.OnClickListener, FuncLayout.OnFuncKeyBoardListener, View.OnTouchListener {

    private String username;

    public static final String JPG = ".jpg";
    private ImageView imgBack;
    private TextView tvName;
    private TextView tvinLine;
    private TextView tvStateBack;
    private TextView tvRight;
    private TextView tvTip, tvTip1;
    private Conversation mConv;
    private XhsEmoticonsKeyBoard ekBar;
    private DropDownListView lvChat;
    private ChatView chatView;
    private UserInfo mMyInfo;
    private Activity mContext;
    private File mTmpFile;
    private List<UserInfo> mAtList;
    private boolean mAtAll = false;
    private ChattingListAdapter mChatAdapter;
    private List<UserInfo> forDel = new ArrayList<>();
    private String mTargetId;  //会话目标Id
    private boolean mIsSingle = true;  //单聊
    private String mTargetAppKey;//会话目标  appkey
    private boolean mLongClick = false;
    private boolean mShowSoftInput = false;
    InputMethodManager mImm;
    private static final int REFRESH_LAST_PAGE = 0x1023;
    private static final int REFRESH_CHAT_TITLE = 0x1024;
    private static final int REFRESH_GROUP_NAME = 0x1025;
    private static final int REFRESH_GROUP_NUM = 0x1026;
    private static final String DRAFT = "draft";
    private final ConsultReplyActivity.UIHandler mUIHandler = new ConsultReplyActivity.UIHandler(this);

    private long mGroupId;


    private long lastClick1;//图片
    private long lastClick2;//名片
    private long lastClick3;//拍摄

    private long lastLeft;
    private long lastRight;


    Button floatingActionButton;
    int screenWidth;
    int screenHeight;
    int lastX;
    int lastY;

    private long startTime = 0;
    private long endTime = 0;

    private boolean isclick;

    private String orderId;// 订单Id
    private String lastAdvice = "";//最新建议

    private String patientName;

    Gson gson;
    SingleOrder singleOrder;
    LinearLayout llBack;

    String orderAcceptTime;//咨询开始时间
    int patientId;//患者ID
    String patientUid;//患者Uid
    long orderAcceptTime1;//

    int state = 0;  //1 咨询中 显示键盘 0已结束 不显示键盘


    String doctorId;
    /*
     *长按事件
     *
     * */
    private ChattingListAdapter.ContentLongClickListener longClickListener = new ChattingListAdapter.ContentLongClickListener() {

        @Override
        public void onContentLongClick(final int position, View view) {
            final Message msg = mChatAdapter.getMessage(position);

            if (msg == null) {
                return;
            }
            //如果是文本消息
            if ((msg.getContentType() == ContentType.text) && msg.getContent().getStringExtra("businessCard") == null) {
                //接收方
                if (msg.getDirect() == MessageDirect.receive) {
                    int[] location = new int[2];
                    view.getLocationOnScreen(location);
                    float OldListY = (float) location[1];
                    float OldListX = (float) location[0];
                    new TipView.Builder(ConsultReplyActivity.this, chatView, (int) OldListX + view.getWidth() / 2, (int) OldListY + view.getHeight()).addItem(new TipItem("复制")).addItem(new TipItem("转发")).addItem(new TipItem("删除")).setOnItemClickListener(new TipView.OnItemClickListener() {
                        @Override
                        public void onItemClick(String str, final int position) {
                            if (position == 0) {
                                if (msg.getContentType() == ContentType.text) {
                                    final String content = ((TextContent) msg.getContent()).getText();
                                    if (Build.VERSION.SDK_INT > 11) {
                                        ClipboardManager clipboard = (ClipboardManager) mContext.getSystemService(Context.CLIPBOARD_SERVICE);
                                        ClipData clip = ClipData.newPlainText("Simple text", content);
                                        clipboard.setPrimaryClip(clip);
                                    } else {
                                        android.text.ClipboardManager clip = (android.text.ClipboardManager) mContext.getSystemService(Context.CLIPBOARD_SERVICE);
                                        if (clip.hasText()) {
                                            clip.getText();
                                        }
                                    }
                                    Toast.makeText(ConsultReplyActivity.this, "已复制", Toast.LENGTH_SHORT).show();
                                } else {
                                    Toast.makeText(ConsultReplyActivity.this, "只支持复制文字", Toast.LENGTH_SHORT).show();
                                }
                            } else if (position == 1) {
                                Intent intent = new Intent(ConsultReplyActivity.this, ForwardMsgActivity.class);
                                JGApplication.forwardMsg.clear();
                                JGApplication.forwardMsg.add(msg);
                                startActivity(intent);
                            } else {
                                //删除
                                mConv.deleteMessage(msg.getId());
                                mChatAdapter.removeMessage(msg);
                            }
                        }

                        @Override
                        public void dismiss() {

                        }
                    }).create();
                    //发送方
                } else {
                    int[] location = new int[2];
                    view.getLocationOnScreen(location);
                    float OldListY = (float) location[1];
                    float OldListX = (float) location[0];
//                    new TipView.Builder(ConsultReplyActivity.this, chatView, (int) OldListX + view.getWidth() / 2, (int) OldListY + view.getHeight()).addItem(new TipItem("复制")).addItem(new TipItem("转发")).addItem(new TipItem("撤回")).addItem(new TipItem("删除")).setOnItemClickListener(new TipView.OnItemClickListener() {
                    new TipView.Builder(ConsultReplyActivity.this, chatView, (int) OldListX + view.getWidth() / 2, (int) OldListY + view.getHeight()).addItem(new TipItem("复制")).addItem(new TipItem("转发")).addItem(new TipItem("删除")).setOnItemClickListener(new TipView.OnItemClickListener() {
                        @Override
                        public void onItemClick(String str, final int position) {
                            if (position == 0) {
                                if (msg.getContentType() == ContentType.text) {
                                    final String content = ((TextContent) msg.getContent()).getText();
                                    if (Build.VERSION.SDK_INT > 11) {
                                        ClipboardManager clipboard = (ClipboardManager) mContext.getSystemService(Context.CLIPBOARD_SERVICE);
                                        ClipData clip = ClipData.newPlainText("Simple text", content);
                                        clipboard.setPrimaryClip(clip);
                                    } else {
                                        android.text.ClipboardManager clip = (android.text.ClipboardManager) mContext.getSystemService(Context.CLIPBOARD_SERVICE);
                                        if (clip.hasText()) {
                                            clip.getText();
                                        }
                                    }
                                    Toast.makeText(ConsultReplyActivity.this, "已复制", Toast.LENGTH_SHORT).show();
                                } else {
                                    Toast.makeText(ConsultReplyActivity.this, "只支持复制文字", Toast.LENGTH_SHORT).show();
                                }
                            } else if (position == 1) {
                                //转发
                                if (msg.getContentType() == ContentType.text || msg.getContentType() == ContentType.image || (msg.getContentType() == ContentType.file && (msg.getContent()).getStringExtra("video") != null)) {
                                    Intent intent = new Intent(ConsultReplyActivity.this, ForwardMsgActivity.class);
                                    JGApplication.forwardMsg.clear();
                                    JGApplication.forwardMsg.add(msg);
                                    startActivity(intent);
                                } else {
                                    Toast.makeText(ConsultReplyActivity.this, "只支持转发文本,图片,小视频", Toast.LENGTH_SHORT).show();
                                }
                            } else if (position == 2) {
                                //删除
                                mConv.deleteMessage(msg.getId());
                                mChatAdapter.removeMessage(msg);
//                                //撤回
//                                mConv.retractMessage(msg, new BasicCallback() {
//                                    @Override
//                                    public void gotResult(int i, String s) {
//                                        if (i == 855001) {
//                                            Toast.makeText(ConsultReplyActivity.this, "发送时间过长，不能撤回", Toast.LENGTH_SHORT).show();
//                                        } else if (i == 0) {
//                                            mChatAdapter.delMsgRetract(msg);
//                                        }
//                                    }
//                                });
                            } else {

                            }
                        }

                        @Override
                        public void dismiss() {

                        }
                    }).create();
                }
                //除了文本消息类型之外的消息类型
            } else {
                //接收方
                if (msg.getDirect() == MessageDirect.receive) {
                    int[] location = new int[2];
                    view.getLocationOnScreen(location);
                    float OldListY = (float) location[1];
                    float OldListX = (float) location[0];
                    new TipView.Builder(ConsultReplyActivity.this, chatView, (int) OldListX + view.getWidth() / 2, (int) OldListY + view.getHeight()).addItem(new TipItem("转发")).addItem(new TipItem("删除")).setOnItemClickListener(new TipView.OnItemClickListener() {
                        @Override
                        public void onItemClick(String str, final int position) {
                            if (position == 1) {
                                //删除
                                mConv.deleteMessage(msg.getId());
                                mChatAdapter.removeMessage(msg);
                            } else {
                                Intent intent = new Intent(ConsultReplyActivity.this, ForwardMsgActivity.class);
                                JGApplication.forwardMsg.clear();
                                JGApplication.forwardMsg.add(msg);
                                startActivity(intent);
                            }
                        }

                        @Override
                        public void dismiss() {

                        }
                    }).create();
                    //发送方
                } else {
                    int[] location = new int[2];
                    view.getLocationOnScreen(location);
                    float OldListY = (float) location[1];
                    float OldListX = (float) location[0];
//                    new TipView.Builder(ConsultReplyActivity.this, chatView, (int) OldListX + view.getWidth() / 2, (int) OldListY + view.getHeight()).addItem(new TipItem("转发")).addItem(new TipItem("撤回")).addItem(new TipItem("删除")).setOnItemClickListener(new TipView.OnItemClickListener() {
                    new TipView.Builder(ConsultReplyActivity.this, chatView, (int) OldListX + view.getWidth() / 2, (int) OldListY + view.getHeight()).addItem(new TipItem("转发")).addItem(new TipItem("删除")).setOnItemClickListener(new TipView.OnItemClickListener() {
                        @Override
                        public void onItemClick(String str, final int position) {
                            if (position == 1) {
                                //删除
                                mConv.deleteMessage(msg.getId());
                                mChatAdapter.removeMessage(msg);
//                                //撤回
//                                mConv.retractMessage(msg, new BasicCallback() {
//                                    @Override
//                                    public void gotResult(int i, String s) {
//                                        if (i == 855001) {
//                                            Toast.makeText(ConsultReplyActivity.this, "发送时间过长，不能撤回", Toast.LENGTH_SHORT).show();
//                                        } else if (i == 0) {
//                                            mChatAdapter.delMsgRetract(msg);
//                                        }
//                                    }
//                                });
                            } else if (position == 0) {
                                Intent intent = new Intent(ConsultReplyActivity.this, ForwardMsgActivity.class);
                                JGApplication.forwardMsg.clear();
                                JGApplication.forwardMsg.add(msg);
                                startActivity(intent);
                            } else {
//                                //删除
//                                mConv.deleteMessage(msg.getId());
//                                mChatAdapter.removeMessage(msg);
                            }
                        }

                        @Override
                        public void dismiss() {

                        }
                    }).create();
                }
            }
        }
    };

    /*
     * 键盘监听
     * 表情  选择
     * 删除
     * */ EmoticonClickListener emoticonClickListener = new EmoticonClickListener() {
        @Override
        public void onEmoticonClick(Object o, int actionType, boolean isDelBtn) {

            if (isDelBtn) {
                SimpleCommonUtils.delClick(ekBar.getEtChat());
            } else {
                if (o == null) {
                    return;
                }
                if (actionType == Constants.EMOTICON_CLICK_BIGIMAGE) {
                    if (o instanceof EmoticonEntity) {
                        OnSendImage(((EmoticonEntity) o).getIconUri());
                    }
                } else {

                    String content = null;
//                    if (o instanceof EmojiBean) {
//                        content = ((EmojiBean) o).emoji;
//                    } else
                    if (o instanceof EmoticonEntity) {
                        content = ((EmoticonEntity) o).getContent();
                    }

                    if (TextUtils.isEmpty(content)) {
                        return;
                    }
                    int index = ekBar.getEtChat().getSelectionStart();
                    Editable editable = ekBar.getEtChat().getText();
                    editable.insert(index, content);
                }
            }
        }
    };

    //发送极光熊
    private void OnSendImage(String iconUri) {
        String substring = iconUri.substring(7);
        File file = new File(substring);
        ImageContent.createImageContentAsync(file, new ImageContent.CreateImageContentCallback() {
            @Override
            public void gotResult(int responseCode, String responseMessage, ImageContent imageContent) {
                if (responseCode == 0) {
                    imageContent.setStringExtra("jiguang", "xiong");
                    Message msg = mConv.createSendMessage(imageContent);
                    //handleSendMsg(msg.getId());
                } else {
                    ToastUtil.shortToast(mContext, responseMessage);
                }
            }
        });
    }

    public void initView() {

        DisplayMetrics dm = getResources().getDisplayMetrics();
        screenWidth = dm.widthPixels;
        screenHeight = dm.heightPixels - 50;

        ekBar = (XhsEmoticonsKeyBoard) findViewById(R.id.ek_bar);


        tvStateBack = (TextView) findViewById(R.id.tv_state_back);

        lvChat = (DropDownListView) findViewById(R.id.lv_chat);
        chatView = (ChatView) findViewById(R.id.chat_view);
        chatView.initModule();

        SimpleCommonUtils.initEmoticonsEditText(ekBar.getEtChat());
        imgBack = (ImageView) findViewById(R.id.img_back);
        llBack = (LinearLayout) findViewById(R.id.ll_back);
        tvName = (TextView) findViewById(R.id.tv_name);
        tvinLine = (TextView) findViewById(R.id.tv_inline);
        tvRight = (TextView) findViewById(R.id.tv_right);
        tvTip = (TextView) findViewById(R.id.tv_tip);
        tvTip1 = (TextView) findViewById(R.id.tv_tip1);
        ekBar.setmEtChatHide();//隐藏 表情按钮


        floatingActionButton = (Button) findViewById(R.id.fab);
        floatingActionButton.setOnClickListener(this);
//        floatingActionButton.setOnTouchListener(this);


//        imgBack.setOnClickListener(this);
        llBack.setOnClickListener(this);
        tvRight.setOnClickListener(this);
        initEmoticonsKeyBoardBar();

        mImm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);


        ekBar.getEtChat().addTextChangedListener(new TextWatcher() {
            private CharSequence temp = "";

            @Override
            public void afterTextChanged(Editable arg0) {
                if (temp.length() > 0) {
                    mLongClick = false;
                }

                if (mAtList != null && mAtList.size() > 0) {
                    for (UserInfo info : mAtList) {
                        String name = info.getDisplayName();

                        if (!arg0.toString().contains("@" + name + " ")) {
                            forDel.add(info);
                        }
                    }
                    mAtList.removeAll(forDel);
                }

                if (!arg0.toString().contains("@所有成员 ")) {
                    mAtAll = false;
                }

            }

            @Override
            public void beforeTextChanged(CharSequence arg0, int arg1, int arg2, int arg3) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int count, int after) {
                temp = s;
                if (s.length() > 0 && after >= 1 && s.subSequence(start, start + 1).charAt(0) == '@' && !mLongClick) {
                    if (null != mConv && mConv.getType() == ConversationType.group) {
                        ChooseAtMemberActivity.show((ChatActivity) mContext, ekBar.getEtChat(), mConv.getTargetId());
                    }
                }
            }
        });


        if (state == 1) {  //咨询中显示
            ekBar.getRlEk().setVisibility(View.VISIBLE);
            tvTip.setVisibility(View.VISIBLE);
            tvTip1.setVisibility(View.VISIBLE);
            floatingActionButton.setVisibility(View.VISIBLE);
        } else {
            //        隐藏键盘
            ekBar.getRlEk().setVisibility(View.GONE);
            tvTip.setVisibility(View.GONE);
            tvTip1.setVisibility(View.GONE);
            floatingActionButton.setVisibility(View.GONE);
        }


    }

    @Override
    protected void onNewIntent(Intent intent) {
//        super.onNewIntent(intent);
        setIntent(intent);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_consult_reply);
        HuidrActivityManager.getInstance().addActivity(this);
        setSwipeBackEnable(false);
//        医生ID 患者ID

        gson = new Gson();
        mContext = ConsultReplyActivity.this;
        username = getIntent().getStringExtra("username");
        mTargetId = getIntent().getStringExtra("username");
        patientName = getIntent().getStringExtra("nickname");
        orderId = getIntent().getStringExtra("orderid");
        patientUid = getIntent().getStringExtra("patientUid");
        state = getIntent().getIntExtra("state", 1);


        Bundle bundle = getIntent().getExtras();


        mTargetAppKey = BuildConfig.patientAppkey;

        //获取订单ID
        ThreadPoolManager.getInstance().execute(new Runnable() {
            @Override
            public void run() {
                String sellid = (String) SharedPreferenciesUtil.getData(jiguang.chat.utils.oss.Constants.SharedAccountConfig.ID, "0");
                JSONObject jsonObject1 = new JSONObject();
                jsonObject1.put("orderId", orderId);
                String adviceResult = PostAndGet.doHttpPost(BuildConfig.baseUrl + "consult/consult/getDoctorConsultSuggestDetail", jsonObject1);
                SingleAcvice singleAcvice = gson.fromJson(adviceResult, SingleAcvice.class);
                if (singleAcvice != null) {
                    if (singleAcvice.getRetValue().size() != 0) {
                        if (singleAcvice.getRetValue().get(0).isIsSuggest()) {
                            lastAdvice = singleAcvice.getRetValue().get(0).getSuggest();
                        }
                    }
                }
                String time = PostAndGet.doHttpPost(BuildConfig.baseUrl + "consult/consult/getFirstConsultSuggestDetail", jsonObject1);
                LogUtil.e("获取时间", time);

                if (time.contains("commitTime")) {
                    TimeModel timeModel = gson.fromJson(time, TimeModel.class);
                    if (timeModel != null) {
                        orderAcceptTime1 = timeModel.getRetValue().getCommitTime();
                    }
                    handler.sendEmptyMessage(103);
                }

            }
        });


        initView();
        initData();
        initListView();
    }

    public void initData() {
        doctorId=(String) SharedPreferenciesUtil.getData("id","0");

        getPatientState();
        tvName.setText(patientName);
        mMyInfo = JMessageClient.getMyInfo();
        if (!TextUtils.isEmpty(mTargetId)) {
            //单聊
            mIsSingle = true;

            mConv = JMessageClient.getSingleConversation(mTargetId, mTargetAppKey);
            if (mConv == null) {
                mConv = Conversation.createSingleConversation(mTargetId, mTargetAppKey);
            }
            mChatAdapter = new ChattingListAdapter(mContext, mConv, longClickListener);
            Message message = mConv.getLatestMessage();
            if (message != null) {
                LogUtil.e("消息", message.toJson());
            }

        }


        chatView.setChatListAdapter(mChatAdapter);
        chatView.getListView().setOnDropDownListener(new DropDownListView.OnDropDownListener() {
            @Override
            public void onDropDown() {
                mUIHandler.sendEmptyMessageDelayed(REFRESH_LAST_PAGE, 1000);
            }
        });
        chatView.setToBottom();
        chatView.setConversation(mConv);

    }

    @Override
    public boolean dispatchKeyEvent(KeyEvent event) {
        if (EmoticonsKeyboardUtils.isFullScreen(this)) {
            boolean isConsum = ekBar.dispatchKeyEventInFullScreen(event);
            return isConsum ? isConsum : super.dispatchKeyEvent(event);
        }
        return super.dispatchKeyEvent(event);
    }

    //    聊天列表
    private void initListView() {
        lvChat.setAdapter(mChatAdapter);
        lvChat.setOnScrollListener(new AbsListView.OnScrollListener() {
            @Override
            public void onScrollStateChanged(AbsListView view, int scrollState) {
                switch (scrollState) {
                    case SCROLL_STATE_FLING:
                        break;
                    case SCROLL_STATE_IDLE:
                        break;
                    case SCROLL_STATE_TOUCH_SCROLL:
                        ekBar.reset();
                        break;
                }
            }

            @Override
            public void onScroll(AbsListView view, int firstVisibleItem, int visibleItemCount, int totalItemCount) {
            }
        });
    }

    /*
     * 获取患者状态 在线 离线
     * */
    public void getPatientState() {
        UtilState.isFriendState(username, new Callback<UserStateBean>() {
            @TargetApi(Build.VERSION_CODES.JELLY_BEAN)
            @Override
            public void onResponse(Call<UserStateBean> call, Response<UserStateBean> response) {
                if (response.code() == 200) {
                    LogUtil.e("获取状态成功", "0");
                    LogUtil.e("获取状态成功", response.body().online + "");
                    if (response.body().online) {
                        tvinLine.setText("在线");
                        tvinLine.setTextColor(getResources().getColor(R.color.top_blue));
                        tvStateBack.setBackground(getResources().getDrawable(R.drawable.back_online));
                    } else {
                        tvinLine.setText("离线");
                        tvinLine.setTextColor(getResources().getColor(R.color.gray));
                        tvStateBack.setBackground(getResources().getDrawable(R.drawable.back_un_online));
                    }
                } else {
                    LogUtil.e("获取状态成功", "1");
                }
            }

            @Override
            public void onFailure(Call<UserStateBean> call, Throwable t) {

            }
        });
    }


    /*
     * 点击事件
     * */
    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.ll_back:
                long currentTime = System.currentTimeMillis();
                LogUtil.e("返回", "返回" + (currentTime - lastLeft));
                if (currentTime - lastLeft > 1000) {
                    returnBtn();
                    lastLeft = currentTime;
                }
                break;
            case R.id.tv_right:
                long currentTime1 = System.currentTimeMillis();
                if (currentTime1 - lastRight > 1000) {
                    TCAgent.onEvent(this, "沟通界面点击患者资料次数", "沟通界面点击患者资料次数");
                    Intent intent1 = new Intent(ConsultReplyActivity.this, WebActivity.class);
                    JSONObject jsonObject = new JSONObject();
                    jsonObject.put("id", patientUid);
                    SharedPreferenciesUtil.putData("psearchID", jsonObject.toJSONString());
                    SharedPreferenciesUtil.putData("followDoctorId",doctorId);
                    Bundle bundle = new Bundle();
                    bundle.putString("url", "patientData.html");
                    intent1.putExtras(bundle);
                    startActivity(intent1);

                    lastRight = currentTime1;
                }
                break;
            case R.id.fab:
                TCAgent.onEvent(this, "点击关闭咨询次数", "点击关闭咨询次数");
                ShowAdviceDialog();
                break;
        }
    }


    @Override
    public void onBackPressed() {
        super.onBackPressed();
        returnBtn();
    }

    private void returnBtn() {
        mConv.resetUnreadCount();
        dismissSoftInput();
        JMessageClient.exitConversation();
        //发送保存为草稿事件到会话列表
        EventBus.getDefault().post(new Event.Builder().setType(EventType.draft).setConversation(mConv).setDraft(ekBar.getEtChat().getText().toString()).build());
        HuidrActivityManager.getInstance().removeActivity(this);
        finish();
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
    }

    private void dismissSoftInput() {
        if (mShowSoftInput) {
            if (mImm != null) {
                mImm.hideSoftInputFromWindow(ekBar.getEtChat().getWindowToken(), 0);
                mShowSoftInput = false;
            }
            try {
                Thread.sleep(200);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }

    /*
     * 初始化键盘
     *
     *
     * */
    private void initEmoticonsKeyBoardBar() {
        ekBar.setAdapter(SimpleCommonUtils.getCommonAdapter(this, emoticonClickListener));
        ekBar.addOnFuncKeyBoardListener(this);
//        SimpleAppsGridView gridView = new SimpleAppsGridView(this);
//        ekBar.addFuncView(gridView);

        FuncGridView funGridView = new FuncGridView(this);

        ekBar.addFuncView(funGridView);

        //EmoticonsKeyboardUtils.setDefKeyboardHeight(this,240);
        ekBar.getEtChat().setOnSizeChangedListener(new EmoticonsEditText.OnSizeChangedListener() {
            @Override
            public void onSizeChanged(int w, int h, int oldw, int oldh) {
                scrollToBottom();
            }
        });
        //发送按钮
        ekBar.getBtnSend().setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String mcgContent = ekBar.getEtChat().getText().toString();
                scrollToBottom();
                if (mcgContent.equals("")) {
                    return;
                }
                Message msg;
                TextContent content = new TextContent(mcgContent);
                if (mAtAll) {
                    msg = mConv.createSendMessageAtAllMember(content, null);
                    mAtAll = false;
                } else if (null != mAtList) {
                    msg = mConv.createSendMessage(content, mAtList, null);
                } else {
                    msg = mConv.createSendMessage(content);
                }
                EventBus.getDefault().post(new Event.Builder().setType(EventType.createConversation).setConversation(mConv).build());
                //设置需要已读回执
                MessageSendingOptions options = new MessageSendingOptions();
                options.setNeedReadReceipt(true);
                JMessageClient.sendMessage(msg, options);
                mChatAdapter.addMsgFromReceiptToList(msg);
                ekBar.getEtChat().setText("");
                if (mAtList != null) {
                    mAtList.clear();
                }
                if (forDel != null) {
                    forDel.clear();
                }
            }
        });
        //切换语音输入
        ekBar.getVoiceOrText().setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int i = v.getId();
                if (i == com.example.jichat.R.id.btn_voice_or_text) {
                    ekBar.setVideoText();
                    ekBar.getBtnVoice().initConv(mConv, mChatAdapter, chatView);
                }
            }
        });
    }

    private void scrollToBottom() {
        lvChat.requestLayout();
        lvChat.post(new Runnable() {
            @Override
            public void run() {
                lvChat.setSelection(lvChat.getBottom());
            }
        });
    }


    @Override
    public void OnFuncPop(int height) {

    }

    @Override
    public void OnFuncClose() {

    }


    /*
     *
     * 点击加号以后
     *
     * 图片 个人名片 拍摄
     * */
    public void onEventMainThread(ImageEvent event) {
        Intent intent;


        switch (event.getFlag()) {
            /* 选择图片 */
            case JGApplication.IMAGE_MESSAGE:

                long currentTime = System.currentTimeMillis();
                if (currentTime - lastClick1 > 1000) {
                    int from = PickImageActivity.FROM_LOCAL;
                    int requestCode = RequestCode.PICK_IMAGE;
                    if (ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
                        //if (PermissionChecker.checkSelfPermission(ConsultReplyActivity.this, Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
                        Toast.makeText(this, "请在应用管理中打开“读写存储”访问权限！", Toast.LENGTH_LONG).show();
                    } else {
                        PickImageActivity.start(this, requestCode, from, tempFile(), true, 9, true, false, 0, 0);
                    }

                    lastClick1 = currentTime;
                } else {

                }
                break;
            /* 拍照  */
            case JGApplication.TAKE_PHOTO_MESSAGE:


                long currentTime1 = System.currentTimeMillis();
                if (currentTime1 - lastClick2 > 1000) {
                    if ((ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) ||
                            //if ((PermissionChecker.checkSelfPermission(ConsultReplyActivity.this, Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) ||
                            (ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) || (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED)) {
                        Toast.makeText(this, "请在应用管理中打开“相机,读写存储,录音”访问权限！", Toast.LENGTH_LONG).show();
                    } else {
                  /*  intent = new Intent(ConsultReplyActivity.this, CameraActivity.class);
                    startActivityForResult(intent, RequestCode.TAKE_PHOTO);*/
                        Intent intents = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
                        if (intents.resolveActivity(this.getPackageManager()) != null) {
                            try {
                                mTmpFile = FileUtils.createTmpFile(this);
                            } catch (IOException e) {
                                e.printStackTrace();
                            }
                            if (mTmpFile != null && mTmpFile.exists()) {
                                /*获取当前系统的android版本号*/
                                int currentapiVersion = android.os.Build.VERSION.SDK_INT;
                                if (currentapiVersion < 24) {
                                    intents.putExtra(MediaStore.EXTRA_OUTPUT, Uri.fromFile(mTmpFile));
                                    startActivityForResult(intents, RequestCode.TAKE_PHOTO);
                                } else {
                                    ContentValues contentValues = new ContentValues(1);
                                    contentValues.put(MediaStore.Images.Media.DATA, mTmpFile.getAbsolutePath());
                                    Uri uri = getContentResolver().insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, contentValues);
                                    intents.putExtra(MediaStore.EXTRA_OUTPUT, uri);
                                    startActivityForResult(intents, RequestCode.TAKE_PHOTO);
                                }
                            } else {
                                Toast.makeText(this, com.example.jichat.R.string.msg_image_no_exits, Toast.LENGTH_SHORT).show();
                            }
                        } else {
                            Toast.makeText(this, com.example.jichat.R.string.msg_no_camera, Toast.LENGTH_SHORT).show();
                        }
                    }
                    lastClick2 = currentTime1;
                }
                break;

            /*   名片    */
            case JGApplication.BUSINESS_CARD:  //选择联系人
                long currentTime2 = System.currentTimeMillis();
                if (currentTime2 - lastClick3 > 1000) {
                    intent = new Intent(mContext, FriendListActivity.class);
                    intent.putExtra("isSingle", mIsSingle);
                    intent.putExtra("userId", username);
                    intent.putExtra("groupId", mGroupId);
                    intent.putExtra("appkey", "bd6ad187437010acb0639f85");
                    startActivity(intent);
                    lastClick3 = currentTime2;
                }
                break;
            default:
                break;
        }

    }

    private String tempFile() {
        String filename = StringUtil.get32UUID() + JPG;
        return StorageUtil.getWritePath(filename, StorageType.TYPE_TEMP);
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        switch (requestCode) {
            case RequestCode.PICK_IMAGE://4
                onPickImageActivityResult(requestCode, data);
                break;
            case RequestCode.TAKE_PHOTO:
                if (mTmpFile.length() > 25) {
                    Bitmap bitmap = BitmapFactory.decodeFile(mTmpFile.getAbsolutePath());
                    ByteArrayOutputStream baos = new ByteArrayOutputStream();
                    bitmap.compress(Bitmap.CompressFormat.JPEG, 100, baos);
                    byte[] datas = baos.toByteArray();
                    Bitmap preBitmap = FileUtils.compressBitmap(datas, 720, 1280);
                    byte[] newDatas = FileUtils.compressBitmapToBytes(preBitmap, 300 * 1024);
                    Bitmap bitmaps = BitmapFactory.decodeByteArray(newDatas, 0, newDatas.length);
                    ImageContent.createImageContentAsync(bitmaps, new ImageContent.CreateImageContentCallback() {
                        @Override
                        public void gotResult(int responseCode, String responseMessage, ImageContent imageContent) {
                            if (responseCode == 0) {
                                Message msg = mConv.createSendMessage(imageContent);
                                handleSendMsg(msg.getId());
                            }
                        }
                    });
                }
                mTmpFile = new File("");
                break;
        }

        switch (resultCode) {
            case JGApplication.RESULT_CODE_AT_MEMBER:
                if (!mIsSingle) {
                    GroupInfo groupInfo = (GroupInfo) mConv.getTargetInfo();
                    String username = data.getStringExtra(JGApplication.TARGET_ID);
                    String appKey = data.getStringExtra(JGApplication.TARGET_APP_KEY);
                    UserInfo userInfo = groupInfo.getGroupMemberInfo(username, appKey);
                    if (null == mAtList) {
                        mAtList = new ArrayList<UserInfo>();
                    }
                    mAtList.add(userInfo);
                    mLongClick = true;
                    ekBar.getEtChat().appendMention(data.getStringExtra(JGApplication.NAME));
                    ekBar.getEtChat().setSelection(ekBar.getEtChat().getText().length());
                }
                break;
            case JGApplication.RESULT_CODE_AT_ALL:
                mAtAll = data.getBooleanExtra(JGApplication.ATALL, false);
                mLongClick = true;
                if (mAtAll) {
                    ekBar.getEtChat().setText(ekBar.getEtChat().getText().toString() + "所有成员 ");
                    ekBar.getEtChat().setSelection(ekBar.getEtChat().getText().length());
                }
                break;

            case RequestCode.TAKE_VIDEO:
                if (data != null) {
                    String path = data.getStringExtra("video");
                    try {
                        FileContent fileContent = new FileContent(new File(path));
                        fileContent.setStringExtra("video", "mp4");
                        Message msg = mConv.createSendMessage(fileContent);
                        handleSendMsg(msg.getId());
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
                break;
            case JGApplication.RESULT_CODE_SEND_LOCATION:
                //之前是在地图选择那边做的发送逻辑,这里是通过msgID拿到的message放到ui上.但是发现问题,message的status始终是send_going状态
                //因为那边发送的是自己创建的对象,这里通过id取出来的不是同一个对象.尽管内容都是一样的.所以为了保证发送的对象个ui上拿出来的
                //对象是同一个,就地图那边传过来数据,在这边进行创建message
                double latitude = data.getDoubleExtra("latitude", 0);
                double longitude = data.getDoubleExtra("longitude", 0);
                int mapview = data.getIntExtra("mapview", 0);
                String street = data.getStringExtra("street");
                String path = data.getStringExtra("path");
                LocationContent locationContent = new LocationContent(latitude, longitude, mapview, street);
                locationContent.setStringExtra("path", path);
                Message message = mConv.createSendMessage(locationContent);
                MessageSendingOptions options = new MessageSendingOptions();
                options.setNeedReadReceipt(true);
                JMessageClient.sendMessage(message, options);
                mChatAdapter.addMsgFromReceiptToList(message);

                int customMsgId = data.getIntExtra("customMsg", -1);
                if (-1 != customMsgId) {
                    Message customMsg = mConv.getMessage(customMsgId);
                    mChatAdapter.addMsgToList(customMsg);
                }
                chatView.setToBottom();
                break;
            case JGApplication.RESULT_CODE_SEND_FILE:
                int[] intArrayExtra = data.getIntArrayExtra(MsgIDs);
                for (int msgId : intArrayExtra) {
                    handleSendMsg(msgId);
                }
                break;
            case JGApplication.RESULT_CODE_CHAT_DETAIL:
                String title = data.getStringExtra(JGApplication.CONV_TITLE);
                if (!mIsSingle) {
                    GroupInfo groupInfo = (GroupInfo) mConv.getTargetInfo();
                    UserInfo userInfo = groupInfo.getGroupMemberInfo(mMyInfo.getUserName(), mMyInfo.getAppKey());
                    //如果自己在群聊中，同时显示群人数
                    if (userInfo != null) {
                        if (TextUtils.isEmpty(title)) {
                            chatView.setChatTitle(IdHelper.getString(mContext, "group"), data.getIntExtra(MEMBERS_COUNT, 0));
                        } else {
                            chatView.setChatTitle(title, data.getIntExtra(MEMBERS_COUNT, 0));
                        }
                    } else {
                        if (TextUtils.isEmpty(title)) {
                            chatView.setChatTitle(IdHelper.getString(mContext, "group"));
                        } else {
                            chatView.setChatTitle(title);
                        }
                        chatView.dismissGroupNum();
                    }

                } else chatView.setChatTitle(title);
                if (data.getBooleanExtra("deleteMsg", false)) {
                    mChatAdapter.clearMsgList();
                }
                break;
        }

    }


    /**
     * 图片选取回调
     */
    private void onPickImageActivityResult(int requestCode, Intent data) {
        if (data == null) {
            return;
        }
        boolean local = data.getBooleanExtra(Extras.EXTRA_FROM_LOCAL, false);
        if (local) {
            // 本地相册
            sendImageAfterSelfImagePicker(data);
        }
    }

    /**
     * 发送图片
     */
    private void sendImageAfterSelfImagePicker(final Intent data) {
        SendImageHelper.sendImageAfterSelfImagePicker(this, data, new SendImageHelper.Callback() {
            @Override
            public void sendImage(final File file, boolean isOrig) {

                //所有图片都在这里拿到
                ImageContent.createImageContentAsync(file, new ImageContent.CreateImageContentCallback() {
                    @Override
                    public void gotResult(int responseCode, String responseMessage, ImageContent imageContent) {
                        if (responseCode == 0) {
                            Message msg = mConv.createSendMessage(imageContent);
                            handleSendMsg(msg.getId());
                        }
                    }
                });

            }
        });
    }

    /**
     * 处理发送图片，刷新界面
     *
     * @param data intent
     */
    private void handleSendMsg(int data) {
        mChatAdapter.setSendMsgs(data);
        chatView.setToBottom();
    }

    @Override
    public boolean onTouch(View v, MotionEvent event) {
        int action = event.getAction();
        switch (action) {
            case MotionEvent.ACTION_DOWN:
                lastX = (int) event.getRawX();
                lastY = (int) event.getRawY();

                isclick = false;//当按下的时候设置isclick为false，具体原因看后边的讲解

                startTime = System.currentTimeMillis();
                System.out.println("执行顺序down");
                break;
            /**
             * layout(l,t,r,b) l Left position, relative to parent t Top position,
             * relative to parent r Right position, relative to parent b Bottom
             * position, relative to parent
             * */
            case MotionEvent.ACTION_MOVE:
                System.out.println("执行顺序move");

                isclick = true;//当按钮被移动的时候设置isclick为true
                int dx = (int) event.getRawX() - lastX;
                int dy = (int) event.getRawY() - lastY;

                int left = v.getLeft() + dx;
                int top = v.getTop() + dy;
                int right = v.getRight() + dx;
                int bottom = v.getBottom() + dy;
                if (left < 0) {
                    left = 0;
                    right = left + v.getWidth();
                }
                if (right > screenWidth) {
                    right = screenWidth;
                    left = right - v.getWidth();
                }
                if (top < 0) {
                    top = 0;
                    bottom = top + v.getHeight();
                }
                if (bottom > screenHeight) {
                    bottom = screenHeight;
                    top = bottom - v.getHeight();
                }
                v.layout(left, top, right, bottom);
                lastX = (int) event.getRawX();
                lastY = (int) event.getRawY();
                break;
            case MotionEvent.ACTION_UP:
                endTime = System.currentTimeMillis();
                //当从点击到弹起小于半秒的时候,则判断为点击,如果超过则不响应点击事件
                if ((endTime - startTime) > 0.1 * 1000L) {
                    isclick = true;
                } else {
                    isclick = false;
                }
                System.out.println("执行顺序up");

                break;
        }
        return isclick;
    }

    public Handler handler = new Handler() {
        @Override
        public void handleMessage(android.os.Message msg) {
            super.handleMessage(msg);
            switch (msg.what) {
                case 0:
                    tvTip1.setText("患者正在处理...请稍侯");
                    break;
                case 2:
                    tvName.setText(patientName);
                    break;
                case 103:
//                    当前时间
//                    Calendar calendar = Calendar.getInstance();
//                    int currentDay = calendar.get(Calendar.DAY_OF_MONTH);
//                    int currentHour = calendar.get(Calendar.HOUR_OF_DAY);
//                    int currentMinute = calendar.get(Calendar.MINUTE);
////                     咨询开始时间
//                    LogUtil.e("订单开始时间",orderAcceptTime1+" ");
//                    calendar.setTimeInMillis(orderAcceptTime1);
//                    int createDay = calendar.get(Calendar.DATE);
//                    int createHour = calendar.get(Calendar.HOUR_OF_DAY);
//                    int createMinute = calendar.get(Calendar.MINUTE);
//
//                    LogUtil.e("测试",calendar.getTimeInMillis()+" ");
//                    String strHour = "";
//                    String strMinute = "";
//                    if (createHour < 10) {
//                        strHour = "0" + createHour;
//                    } else {
//                        strHour = createHour + "";
//                    }
//
//                    if (createMinute < 10) {
//                        strMinute = "0" + createMinute;
//                    } else {
//                        strMinute = "" + createMinute;
//                    }
//
//                    if ((currentDay - createDay) == 0) {
//                        tvTip.setText("该咨询将在后天" + strHour + ":" + strMinute + "自动结束，如需追问，请及时提问");
//                    } else if ((currentDay - createDay) == 1) {
//                        tvTip.setText("该咨询将在明天" + strHour + ":" + strMinute + "自动结束，如需追问，请及时提问");
//                    } else if ((currentDay - createDay) == 2) {
//                        if (currentHour < createHour) {
//                            if (currentMinute < createMinute) {
//                                tvTip.setText("该咨询将在今天" + strHour + ":" + strMinute + "自动结束，如需追问，请及时提问");
//                            }
//                        }
//                    }
                    tvTip.setText(getTimeString(orderAcceptTime1));
                    break;
            }
        }
    };


    public String getTimeString(long createTime) {
        String result = "";
        //当前时间
        Calendar calendar = Calendar.getInstance();
        int currentDay = calendar.get(Calendar.DAY_OF_MONTH);
        int currentHour = calendar.get(Calendar.HOUR_OF_DAY);
        int currentMinute = calendar.get(Calendar.MINUTE);
        //咨询开始时间
        int spandHours = (int) ((calendar.getTimeInMillis() - createTime) / (1000 * 60 * 60));//已经过去的小时数
        calendar.setTimeInMillis(createTime);
        int createDay = calendar.get(Calendar.DATE);
        int createHour = calendar.get(Calendar.HOUR_OF_DAY);
        int createMinute = calendar.get(Calendar.MINUTE);
        String showHours = createHour + "";
        if (createHour < 10) {
            showHours = "0" + createHour;
        }
        String showMinute = createMinute + "";
        if (createMinute < 10) {
            showMinute = "0" + createMinute;
        }
        int shortHours = 24 - createHour;  //距离第二天小时数
        if (spandHours < shortHours) {
            result = "该咨询将在后天" + showHours + ":" + showMinute + "自动结束,如需追问，请及时提问";
        } else if (spandHours < (shortHours + 24)) {
            result = "该咨询将在明天" + showHours + ":" + showMinute + "自动结束,如需追问，请及时提问";
        } else {
            result = "该咨询将在今天" + showHours + ":" + showMinute + "自动结束,如需追问，请及时提问";
        }

        return result;
    }

    private static class UIHandler extends Handler {
        private final WeakReference<ConsultReplyActivity> mActivity;


        public UIHandler(ConsultReplyActivity activity) {
            mActivity = new WeakReference<ConsultReplyActivity>(activity);
        }

        @Override
        public void handleMessage(android.os.Message msg) {
            super.handleMessage(msg);
            ConsultReplyActivity activity = mActivity.get();
            if (activity != null) {
                switch (msg.what) {
                    case REFRESH_LAST_PAGE:
                        activity.mChatAdapter.dropDownToRefresh();
                        activity.chatView.getListView().onDropDownComplete();
                        if (activity.mChatAdapter.isHasLastPage()) {
                            if (Build.VERSION.SDK_INT >= 21) {
                                activity.chatView.getListView().setSelectionFromTop(activity.mChatAdapter.getOffset(), activity.chatView.getListView().getHeaderHeight());
                            } else {
                                activity.chatView.getListView().setSelection(activity.mChatAdapter.getOffset());
                            }
                            activity.mChatAdapter.refreshStartPosition();
                        } else {
                            activity.chatView.getListView().setSelection(0);
                        }
                        //显示上一页的消息数18条
                        activity.chatView.getListView().setOffset(activity.mChatAdapter.getOffset());
                        break;
                }
            }
        }
    }


    /*
     * 刷新页面
     * */
    @Override
    protected void onRestart() {
        super.onRestart();
        initView();
        initData();
        initListView();
    }


    public void onEvent(MessageEvent event) {
        final Message message = event.getMessage();

        //若为群聊相关事件，如添加、删除群成员
        if (message.getContentType() == ContentType.eventNotification) {
            GroupInfo groupInfo = (GroupInfo) message.getTargetInfo();
            long groupId = groupInfo.getGroupID();
            EventNotificationContent.EventNotificationType type = ((EventNotificationContent) message.getContent()).getEventNotificationType();
            if (groupId == mGroupId) {
                switch (type) {
                    case group_member_added:
                        //添加群成员事件
                        List<String> userNames = ((EventNotificationContent) message.getContent()).getUserNames();
                        //群主把当前用户添加到群聊，则显示聊天详情按钮
                        refreshGroupNum();
                        if (userNames.contains(mMyInfo.getNickname()) || userNames.contains(mMyInfo.getUserName())) {
                            runOnUiThread(new Runnable() {
                                @Override
                                public void run() {
                                    chatView.showRightBtn();
                                }
                            });
                        }

                        break;
                    case group_member_removed:
                        //删除群成员事件
                        userNames = ((EventNotificationContent) message.getContent()).getUserNames();
                        //群主删除了当前用户，则隐藏聊天详情按钮
                        if (userNames.contains(mMyInfo.getNickname()) || userNames.contains(mMyInfo.getUserName())) {
                            runOnUiThread(new Runnable() {
                                @Override
                                public void run() {
                                    chatView.dismissRightBtn();
                                    GroupInfo groupInfo = (GroupInfo) mConv.getTargetInfo();
                                    if (TextUtils.isEmpty(groupInfo.getGroupName())) {
                                        chatView.setChatTitle(com.example.jichat.R.string.group);
                                    } else {
                                        chatView.setChatTitle(groupInfo.getGroupName());
                                    }
                                    chatView.dismissGroupNum();
                                }
                            });
                        } else {
                            refreshGroupNum();
                        }

                        break;
                    case group_member_exit:
                        EventNotificationContent content = (EventNotificationContent) message.getContent();
                        if (content.getUserNames().contains(JMessageClient.getMyInfo().getUserName())) {
                            mChatAdapter.notifyDataSetChanged();
                        } else {
                            refreshGroupNum();
                        }
                        break;
                }
            }
        }
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                if (message.getTargetType() == ConversationType.single) {
                    UserInfo userInfo = (UserInfo) message.getTargetInfo();
                    String targetId = userInfo.getUserName();
                    String appKey = userInfo.getAppKey();
                    if (mIsSingle && targetId.equals(mTargetId) && appKey.equals(mTargetAppKey)) {
                        Message lastMsg = mChatAdapter.getLastMsg();
                        if (lastMsg == null || message.getId() != lastMsg.getId()) {
                            mChatAdapter.addMsgToList(message);
                        } else {
                            mChatAdapter.notifyDataSetChanged();
                        }
                    }
                } else {
                    long groupId = ((GroupInfo) message.getTargetInfo()).getGroupID();
                    if (groupId == mGroupId) {
                        Message lastMsg = mChatAdapter.getLastMsg();
                        if (lastMsg == null || message.getId() != lastMsg.getId()) {
                            mChatAdapter.addMsgToList(message);
                        } else {
                            mChatAdapter.notifyDataSetChanged();
                        }
                    }
                }
            }
        });
    }

    private void refreshGroupNum() {
        Conversation conv = JMessageClient.getGroupConversation(mGroupId);
        GroupInfo groupInfo = (GroupInfo) conv.getTargetInfo();
        if (!TextUtils.isEmpty(groupInfo.getGroupName())) {
            android.os.Message handleMessage = mUIHandler.obtainMessage();
            handleMessage.what = REFRESH_GROUP_NAME;
            Bundle bundle = new Bundle();
            bundle.putString(GROUP_NAME, groupInfo.getGroupName());
            bundle.putInt(MEMBERS_COUNT, groupInfo.getGroupMembers().size());
            handleMessage.setData(bundle);
            handleMessage.sendToTarget();
        } else {
            android.os.Message handleMessage = mUIHandler.obtainMessage();
            handleMessage.what = REFRESH_GROUP_NUM;
            Bundle bundle = new Bundle();
            bundle.putInt(MEMBERS_COUNT, groupInfo.getGroupMembers().size());
            handleMessage.setData(bundle);
            handleMessage.sendToTarget();
        }
    }

    /*
     * 发送建议
     * "patientId":"123",  患者
       "orderId":"123",    订单
       "suggest":"111"     建议
     *
     * */
    public void sendAdvice(String orderId, String suggest) {
        String result = null;
        StringBuffer buffer = new StringBuffer();
        String str = BuildConfig.baseUrl + "consult/consult/saveConsultSuggest";
        HttpURLConnection connection = null;
        String jwt = (String) SharedPreferenciesUtil.getData("jwt", "");
        try {
            JSONObject jsonObject = new JSONObject();
            jsonObject.put("patientId", mConv.getTargetId());
            jsonObject.put("orderId", orderId);
            jsonObject.put("suggest", suggest);
            URL url = new URL(str);
            connection = (HttpURLConnection) url.openConnection();
            connection.setRequestMethod("POST");
            connection.setRequestProperty("Charset", "UTF-8");
            connection.setRequestProperty("jwt", jwt);
            connection.setRequestProperty("accept", "application/json");
            connection.setRequestProperty("Connection", "Keep-Alive");
            connection.setRequestProperty("Content-Type", "application/json");
            connection.setDoOutput(true);
            connection.setDoInput(true);
            connection.connect();
            OutputStream outputStream = connection.getOutputStream();
            outputStream.write(jsonObject.toString().getBytes());
            outputStream.flush();
            outputStream.close();

            BufferedReader reader = new BufferedReader(new InputStreamReader(connection.getInputStream()));
            String str1 = null;
            while ((str1 = reader.readLine()) != null) {
                buffer.append(str1);
            }
            result = buffer.toString();
            LogUtil.e("发送建议", result);

        } catch (Exception e) {
            LogUtil.e("发送建议异常", e.toString());
        }

    }


    /*
     * 建议对话框
     * */
    public void ShowAdviceDialog() {
        final Dialog builder = new Dialog(this, com.huidr.lib.commom.R.style.customDialog);

        View view = LayoutInflater.from(this).inflate(R.layout.dialog_layout, null);

        final TextView tvTitleDialog = (TextView) view.findViewById(R.id.tv_title_dialog);


        tvTitleDialog.setText("对患者" + patientName + "的最终建议:");

        final TextView tvCount = (TextView) view.findViewById(R.id.tv_count);
        final EditText etInput = (EditText) view.findViewById(R.id.et_input);
        TextView tvCancel = (TextView) view.findViewById(R.id.tv_cancel);
        TextView tvEnsure = (TextView) view.findViewById(R.id.tv_ensure);


        etInput.setHint("请输入您对患者" + patientName + "宝贵的建议和意见");
//        if(!(lastAdvice.equals(""))){
//            etInput.setText(lastAdvice);
//        }
        LogUtil.e("显示建议", lastAdvice);
        etInput.setText(lastAdvice);
        String count = "<font color='#EB5463'>" + etInput.getText().toString().length() + "</font>/200";
        tvCount.setText(Html.fromHtml(count));


        etInput.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {
                LogUtil.e("123", etInput.getText().toString().length() + " ");
                String count = "<font color='#EB5463'>" + etInput.getText().toString().length() + "</font>/200";
                tvCount.setText(Html.fromHtml(count));
            }
        });

        tvCancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                builder.cancel();
            }
        });

        tvEnsure.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (etInput.getText().toString().length() > 0) {
                    if (etInput.getText().toString().equals(lastAdvice)) {
                        Toast.makeText(ConsultReplyActivity.this, "请输入建议", Toast.LENGTH_SHORT).show();
                    } else {
                        lastAdvice = etInput.getText().toString();
                        builder.cancel();
                        new Thread(new Runnable() {
                            @Override
                            public void run() {
//                            String sellid = (String) SharedPreferenciesUtil.getData(jiguang.chat.utils.oss.Constants.SharedAccountConfig.ID, "0");
                                LogUtil.e("sellid", orderId);
                                sendAdvice(orderId, etInput.getText().toString());

                            }
                        }).start();
                        sendTextInChat(lastAdvice);
                        if (tvTip1.getText().toString().equals("如患者病情紧急请及时规劝患者前往医院检查")) {
                            tvTip1.setText("患者正在处理...请稍侯");
                        }
                        Toast.makeText(ConsultReplyActivity.this, "建议发送成功", Toast.LENGTH_SHORT).show();
                    }
                } else {
                    Toast.makeText(ConsultReplyActivity.this, "请输入建议", Toast.LENGTH_SHORT).show();
                }
            }
        });
        builder.setCanceledOnTouchOutside(true);
        builder.setContentView(view);
        builder.show();
        Window window = builder.getWindow();
        WindowManager.LayoutParams lp = window.getAttributes();
        WindowManager windowManager = getWindowManager();
        Display display = windowManager.getDefaultDisplay();
        lp.width = (int) (display.getWidth() * 0.6);
        window.setAttributes(lp);
    }

    /*
     *将建议发送到聊天页面  医生建议：
     * */
    public void sendTextInChat(String str) {
        Message msg;
        scrollToBottom();
        TextContent content = new TextContent("医生建议：" + str);
        msg = mConv.createSendMessage(content);
        EventBus.getDefault().post(new Event.Builder().setType(EventType.createConversation).setConversation(mConv).build());
        //设置需要已读回执
        MessageSendingOptions options = new MessageSendingOptions();
        options.setNeedReadReceipt(true);
        JMessageClient.sendMessage(msg, options);
        mChatAdapter.addMsgFromReceiptToList(msg);  //不加  新建议不会显示
    }

}
