package com.huidr.HuiDrDoctor.contact_fragment;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.drawable.BitmapDrawable;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import android.text.Html;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import com.alibaba.fastjson.JSONObject;
import com.chad.library.adapter.base.BaseQuickAdapter;
import com.chad.library.adapter.base.BaseViewHolder;
import com.google.gson.Gson;
import com.guanaj.easyswipemenulibrary.EasySwipeMenuLayout;
import com.huidr.HuiDrDoctor.activity.WebActivity;
import com.huidr.HuiDrDoctor.activity.main.Consult.utils.PostAndGet;
import com.huidr.HuiDrDoctor.debug.BuildConfig;
import com.huidr.HuiDrDoctor.debug.R;
import com.huidr.HuiDrDoctor.module.home.ApplyListModel;
import com.huidr.HuiDrDoctor.module.home.SimpleResultModel;
import com.huidr.HuiDrDoctor.util.CircleImageView;
import com.huidr.HuiDrDoctor.util.DownLoadImg;
import com.huidr.HuiDrDoctor.util.LogUtil;
import com.huidr.HuiDrDoctor.util.MulityClickUtils;
import com.huidr.HuiDrDoctor.util.ThreadPoolManager;
import com.huidr.lib.commom.base.BaseFragment;
import com.huidr.lib.commom.util.Toast;
import com.scwang.smartrefresh.layout.SmartRefreshLayout;
import com.scwang.smartrefresh.layout.api.RefreshLayout;
import com.scwang.smartrefresh.layout.listener.OnLoadMoreListener;
import com.scwang.smartrefresh.layout.listener.OnRefreshListener;
import com.zyao89.view.zloading.ZLoadingDialog;
import com.zyao89.view.zloading.Z_TYPE;

import java.io.File;

import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import cn.jpush.im.android.api.ContactManager;
import cn.jpush.im.android.api.JMessageClient;
import cn.jpush.im.api.BasicCallback;
import jiguang.chat.utils.oss.OssService;
import jiguang.chat.utils.oss.SharedPreferenciesUtil;


public class ApplyListFragment extends BaseFragment {


    private ZLoadingDialog dialog, dialog1;//  处理窗口 加载窗口
    private String imgPath;
    private OssService ossService;
    private Gson gson;

    private SmartRefreshLayout srlApplyList;
    private RecyclerView rvApplyList;
    private ConstraintLayout clEmptyApply; //cl_empty_apply;
    private int currentPage = 1;
    private int totalPage = 0;
    private ApplyListModel applyListModel;
    private TextView tvEmptyApply1, tvEmptyApply2;

    @Override
    protected void findView(View parent) {
        srlApplyList = parent.findViewById(R.id.srl_apply_list);
        rvApplyList = parent.findViewById(R.id.rv_apply_list);
        clEmptyApply = parent.findViewById(R.id.cl_empty_apply);

        srlApplyList.setEnableLoadMore(true);
        srlApplyList.setEnableRefresh(true);

        rvApplyList.setAdapter(applyAdapter);
        rvApplyList.setLayoutManager(new LinearLayoutManager(getContext()));


        tvEmptyApply1 = parent.findViewById(R.id.tv_empty_apply1);
        tvEmptyApply2 = parent.findViewById(R.id.tv_empty_apply2);


        srlApplyList.setOnRefreshListener(new OnRefreshListener() {
            @Override
            public void onRefresh(@NonNull RefreshLayout refreshLayout) {
                currentPage = 1;
                getDataByPage();
            }
        });

        srlApplyList.setOnLoadMoreListener(new OnLoadMoreListener() {
            @Override
            public void onLoadMore(@NonNull RefreshLayout refreshLayout) {
                if (applyListModel.getRetValue().size() == 20 && currentPage < totalPage) {
                    currentPage += 1;
                    getDataByPage();
                } else {
                    Toast.getInstance(getContext()).show("数据加载全部", 500);
                    srlApplyList.finishLoadMore();
                }
            }
        });


    }

    @Override
    protected void initData() {

        dialog = new ZLoadingDialog(getContext());
        dialog.setLoadingBuilder(Z_TYPE.STAR_LOADING)//设置类型
                .setLoadingColor(Color.BLUE)//颜色
                .setHintText("处理中,请稍候...").setHintTextSize(16) // 设置字体大小 dp
                .setHintTextColor(Color.GRAY)  // 设置字体颜色
                .setDurationTime(0.5) // 设置动画时间百分比 - 0.5倍
                .setCanceledOnTouchOutside(false).setCancelable(false);

        dialog1 = new ZLoadingDialog(getContext());
        dialog1.setLoadingBuilder(Z_TYPE.STAR_LOADING)//设置类型
                .setLoadingColor(Color.BLUE)//颜色
                .setHintText("正在加载,请稍候...").setHintTextSize(16) // 设置字体大小 dp
                .setHintTextColor(Color.GRAY)  // 设置字体颜色
                .setDurationTime(0.5) // 设置动画时间百分比 - 0.5倍
                .setCanceledOnTouchOutside(false).setCancelable(false).show();

        ossService = new OssService(getContext());
        imgPath = getContext().getExternalFilesDir("").getAbsolutePath() + "/img/head/";
        gson = new Gson();

        getDataByPage();
    }

    @Override
    protected View setContentView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_apply_list, container, false);
        return view;
    }


    private BaseQuickAdapter<ApplyListModel.RetValueBean, BaseViewHolder> applyAdapter = new BaseQuickAdapter<ApplyListModel.RetValueBean, BaseViewHolder>(R.layout.item_apply_layout) {
        @Override
        protected void convert(final BaseViewHolder helper, final ApplyListModel.RetValueBean item) {
            EasySwipeMenuLayout esmlItem = helper.getView(R.id.esml_item);
            esmlItem.setCanRightSwipe(false);
            esmlItem.setCanLeftSwipe(false);

            ConstraintLayout clItem = helper.getView(R.id.cl_item);

            clItem.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (JMessageClient.getMyInfo() == null) {
                        return;
                    }
                    if (MulityClickUtils.isFastClick()) {

                        Intent intent1 = new Intent(getContext(), WebActivity.class);
                        Bundle bundle = new Bundle();
                        bundle.putString("url", "personal.html?id=" + item.getId());
                        intent1.putExtras(bundle);
                        startActivity(intent1);
                    }
                }
            });

            CircleImageView imgItemHead = helper.getView(R.id.img_item_head);


            Bitmap defaultBitmap = BitmapFactory.decodeResource(getResources(), R.drawable.nantou);
            BitmapDrawable defaultDrawable = new BitmapDrawable(getResources(), defaultBitmap);
            imgItemHead.setBackgroundDrawable(defaultDrawable);

            if (item.getUserIcon() != null) {
                imgItemHead.setTag(item.getUserIcon());
                File file = new File(imgPath + item.getUserIcon());
                if (file.exists()) {
                    Bitmap bitmap1 = BitmapFactory.decodeFile(file.getAbsolutePath());
                    if (bitmap1 != null) {
                        bitmap1 = DownLoadImg.getCirleBitmap(bitmap1);
                        BitmapDrawable bitmapDrawable1 = new BitmapDrawable(getContext().getResources(), bitmap1);
                        if (item.getUserIcon().equals(imgItemHead.getTag())) {
                            imgItemHead.setBackgroundDrawable(bitmapDrawable1);
                        }
                    }
                } else {
                    DownLoadImg.BitmapWorkerTask bitmapWorkerTask = new DownLoadImg.BitmapWorkerTask(imgItemHead, file, ossService);
                    bitmapWorkerTask.execute(item.getUserIcon());
                }

            } else {
                imgItemHead.setBackgroundDrawable(defaultDrawable);
            }

            ImageView imgNotice = helper.getView(R.id.img_notice);
            imgNotice.setVisibility(View.GONE);
            TextView tvItemName = helper.getView(R.id.tv_item_name);
            TextView tvItemAge = helper.getView(R.id.tv_item_age);
            TextView tvItemDate = helper.getView(R.id.tv_item_date);
            TextView tvItemMsg = helper.getView(R.id.tv_item_msg);
            final Button btnApply = helper.getView(R.id.btn_apply);
            btnApply.setVisibility(View.VISIBLE);
            final Button btnRefuse = helper.getView(R.id.btn_refuse);
            btnRefuse.setVisibility(View.VISIBLE);
            TextView tvScrollRight = helper.getView(R.id.tv_scroll_right);
            TextView tvScrollDel = helper.getView(R.id.tv_scroll_del);

            tvItemName.setText(item.getUserName());
            tvItemAge.setText(item.getUserTitle() + "(" + item.getHospitalDepartment() + ")");
            tvItemMsg.setText(item.getUpdateTime());

//            0  未处理 2 拒绝
            if (item.getStatus() == 0) {
                btnApply.setText("通过");
                btnApply.setBackgroundResource(R.drawable.btn_grad_empty);
//                imgNotice.setVisibility(View.VISIBLE);
                btnRefuse.setText("拒绝");
                btnRefuse.setBackgroundResource(R.drawable.btn_red_empty);
            } else if (item.getStatus() == 2) {
                btnApply.setText("申请");
                btnApply.setBackgroundResource(R.drawable.btn_grad_empty);
//                imgNotice.setVisibility(View.GONE);
                btnRefuse.setText("已拒绝");
                btnRefuse.setBackgroundResource(R.drawable.back_refurse_gray);
            } else if (item.getStatus() == 3) {
                btnApply.setText("已申请");
                btnApply.setBackgroundResource(R.drawable.btn_gray1_apply);
//                imgNotice.setVisibility(View.GONE);
                btnRefuse.setText("已拒绝");
                btnRefuse.setBackgroundResource(R.drawable.back_refurse_gray);
            } else {

            }


//            1接受 2 拒绝
            btnApply.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {

                    if (MulityClickUtils.isFastClick()) {
                        if (btnApply.getText().equals("通过")) {
                            dialog.show();
//                        ContactManager.acceptInvitation(item.getId() + "", "", new BasicCallback() {
//                            @Override
//                            public void gotResult(int i, String s) {
//                                if (i == 0) {
//                                    modifyApply(item.getId() + "", 1, helper.getAdapterPosition());
//                                } else {
//                                    LogUtil.e("极光同意", s);
//                                    dialog.dismiss();
//                                }
//                            }
//                        });
                            modifyApply(item.getId() + "", 1, helper.getAdapterPosition());
                        } else if (btnApply.getText().equals("申请")) {
                            dialog.show();
                            ContactManager.sendInvitationRequest(item.getId() + "", "", "", new BasicCallback() {
                                @Override
                                public void gotResult(int responseCode, String responseMessage) {
                                    if (0 == responseCode) {
                                        LogUtil.e("极光发送邀请成功", "极光发送邀请成功");
                                        addContact(item.getId() + "", helper.getAdapterPosition());
                                    } else {
                                        LogUtil.e("极光发送邀请失败", "极光发送邀请失败 " + responseMessage);
                                        dialog.dismiss();
                                        Toast.getInstance(getContext()).show("发送邀请失败", 500);
                                    }
                                }
                            });
                        } else {

                        }
                    }
                }
            });

            btnRefuse.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
//                    ContactManager.declineInvitation(item.getId() + "", "", "", new BasicCallback() {
//                        @Override
//                        public void gotResult(int i, String s) {
//                            modifyApply(item.getId() + "", 2);
//                        }
//                    });

                    if (btnRefuse.getText().equals("拒绝")) {
                        dialog.show();
                        modifyApply(item.getId() + "", 2, helper.getAdapterPosition());
                    }

                }

            });
        }
    };


    //    同意或拒绝 doctorGroup/updateContacts 1接受 2 拒绝
    public void modifyApply(String targetId, final int status, final int position) {
//        final String path = "http://192.168.1.180:1189/doctorGroup/updateContacts";
        final String path = BuildConfig.baseUrl + "hospital/doctorGroup/updateContacts";
        final JSONObject jsonObject = new JSONObject();
        jsonObject.put("doctorId", targetId);
        jsonObject.put("status", status);
        ThreadPoolManager.getInstance().execute(new Runnable() {
            @Override
            public void run() {
                String result = PostAndGet.doHttpPost(path, jsonObject);
                LogUtil.e("接受或者拒绝好友", result);
                Message message = new Message();
                message.arg1 = position;
                message.arg2 = status;
                if (result.equals("网络异常")) {
                    message.what = 7;
                    handler.sendMessage(message);
                } else {
                    SimpleResultModel simpleResultModel = new SimpleResultModel();
                    simpleResultModel = gson.fromJson(result, SimpleResultModel.class);
                    if (simpleResultModel.getStatus() == 0) {
                        if (simpleResultModel.getRetValue() == 0) {
                            message.what = 6;
                            handler.sendMessage(message);
                        } else {
                            message.what = 7;
                            handler.sendMessage(message);
                        }
                    } else {
                        message.what = 7;
                        handler.sendMessage(message);
                    }
                }
            }
        });
    }

    //    添加联系人  访问接口
    public void addContact(final String targetId, final int position) {
        ThreadPoolManager.getInstance().execute(new Runnable() {
            @Override
            public void run() {
//                String path = "http://192.168.1.180:1189/doctorGroup/addContacts";
                String path = BuildConfig.baseUrl + "hospital/doctorGroup/addContacts";
                JSONObject jsonObject = new JSONObject();
                String id = (String) SharedPreferenciesUtil.getData("id", "0");
//                申请人ID  applicantId
                jsonObject.put("applicantId", id);
                //                本申请人ID applicantId
                jsonObject.put("respondentId", targetId);

                String result = PostAndGet.doHttpPost(path, jsonObject);
                LogUtil.e("添加联系人", result);
                if (result.equals("网络异常")) {
                    handler.sendEmptyMessage(10);
                } else {
                    SimpleResultModel simpleResultModel = gson.fromJson(result, SimpleResultModel.class);
                    if (simpleResultModel.getStatus() == 0) {
//                        1发送成功 0 24小时内不能重复发送
                        if (simpleResultModel.getRetValue() == 1) {
//                            handler.sendEmptyMessage(8);
                            Message message = new Message();
                            message.what = 8;
                            message.arg1 = position;
                            handler.sendMessage(message);
                        } else if (simpleResultModel.getRetValue() == -1) {
                            handler.sendEmptyMessage(9);
                        } else {
                            handler.sendEmptyMessage(10);
                        }
                    } else {
                        handler.sendEmptyMessage(10);
                    }
                }
            }
        });
    }

    private Handler handler = new Handler() {
        @Override
        public void handleMessage(Message msg) {
            super.handleMessage(msg);
            switch (msg.what) {
                case 1:

                    applyAdapter.getData().clear();
                    if (applyListModel.getRetValue().size() == 0) {
                        srlApplyList.setVisibility(View.GONE);
                        clEmptyApply.setVisibility(View.VISIBLE);
                        tvEmptyApply1.setText("暂无医生申请联系人");
                        tvEmptyApply2.setText("输入医生姓名发起申请~");
                    } else {
                        srlApplyList.setVisibility(View.VISIBLE);
                        clEmptyApply.setVisibility(View.GONE);
                        applyAdapter.getData().addAll(applyListModel.getRetValue());
                        applyAdapter.notifyDataSetChanged();
                    }
                    srlApplyList.finishRefresh();
                    if (dialog1 != null) {
                        new Handler().postDelayed(new Runnable() {
                            @Override
                            public void run() {
                                dialog1.dismiss();
                            }
                        }, 500);
                    }
                    break;
                case 2:
                    applyAdapter.getData().addAll(applyListModel.getRetValue());
                    applyAdapter.notifyDataSetChanged();
                    srlApplyList.finishLoadMore();
                    break;
                case 3:
                    srlApplyList.finishLoadMore();
                    srlApplyList.finishRefresh();
                    srlApplyList.setVisibility(View.GONE);
                    clEmptyApply.setVisibility(View.VISIBLE);
                    tvEmptyApply1.setText("网络错误");
                    String tip = "<font color='#248cfa'><u> 立即刷新 <u><font>";
                    tvEmptyApply2.setText(Html.fromHtml(tip));
                    if (dialog1 != null) {
                        new Handler().postDelayed(new Runnable() {
                            @Override
                            public void run() {
                                dialog1.dismiss();
                            }
                        }, 500);
                    }
                    break;
//                    接受拒绝好友申请成功  1接受 2 拒绝
                case 6:
                    if (dialog != null) {
                        dialog.dismiss();
                    }

                    if (msg.arg2 == 1) {
                        applyAdapter.getData().remove(msg.arg1);
                        applyAdapter.notifyDataSetChanged();
                        Toast.getInstance(getContext()).show("已通过好友申请", 500);
                    } else {
                        applyAdapter.getData().get(msg.arg1).setStatus(2);
                        applyAdapter.notifyItemChanged(msg.arg1);
                        Toast.getInstance(getContext()).show("已拒绝好友申请", 500);
                    }
                    break;
                //                    接受拒绝好友申请失败
                case 7:
                    if (dialog != null) {
                        dialog.dismiss();
                    }
                    if (msg.arg2 == 1) {
                        Toast.getInstance(getContext()).show("通过好友申请失败", 500);
                    } else {
                        Toast.getInstance(getContext()).show("拒绝好友申请失败", 500);
                    }
                    break;
                //发送成功  邀请好友
                case 8:
                    if (dialog != null) {
                        dialog.dismiss();
                    }
                    applyAdapter.getData().get(msg.arg1).setStatus(3);
                    applyAdapter.notifyItemChanged(msg.arg1);
                    Toast.getInstance(getContext()).show("邀请发送成功", 500);
                    break;
                //发送成功  邀请好友  提示不要重复发送
                case 9:
                    if (dialog != null) {
                        dialog.dismiss();
                    }
                    Toast.getInstance(getContext()).show("已发送邀请，请勿重复发送", 500);
                    break;
                //发送失败  邀请好友
                case 10:
                    if (dialog != null) {
                        dialog.dismiss();
                    }
                    Toast.getInstance(getContext()).show("邀请发送失败", 500);
                    break;
            }
        }
    };

    public void getDataByPage() {

        final String path = BuildConfig.baseUrl + "hospital/doctorGroup/getApplyList";
        final JSONObject jsonObject = new JSONObject();
        jsonObject.put("pageIndex", currentPage);
        jsonObject.put("pageSize", 20);
        ThreadPoolManager.getInstance().execute(new Runnable() {
            @Override
            public void run() {
                String result = PostAndGet.doHttpPost(path, jsonObject);
                LogUtil.e("申请列表", result);
                applyListModel = new ApplyListModel();
                if (result.equals("网络异常")) {
                    handler.sendEmptyMessage(3);
                } else {
                    applyListModel = gson.fromJson(result, ApplyListModel.class);
                    if (applyListModel.getStatus() == 0) {
                        totalPage = applyListModel.getTotalPage();
                        if (currentPage == 1) {
                            handler.sendEmptyMessage(1);
                        } else {
                            handler.sendEmptyMessage(2);
                        }
                    } else {
                        handler.sendEmptyMessage(3);
                    }
                }
            }
        });
    }
}
