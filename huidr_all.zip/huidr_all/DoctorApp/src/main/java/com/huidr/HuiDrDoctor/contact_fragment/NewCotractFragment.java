package com.huidr.HuiDrDoctor.contact_fragment;

import android.app.Dialog;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.Matrix;
import android.graphics.drawable.BitmapDrawable;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import androidx.annotation.NonNull;

import android.text.Html;
import android.util.Log;
import android.view.Display;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import com.alibaba.fastjson.JSONObject;
import com.chad.library.adapter.base.BaseQuickAdapter;
import com.chad.library.adapter.base.BaseViewHolder;
import com.google.gson.Gson;
import com.huidr.HuiDrDoctor.activity.WebActivity;
import com.huidr.HuiDrDoctor.activity.main.Consult.utils.PostAndGet;
import com.huidr.HuiDrDoctor.debug.BuildConfig;
import com.huidr.HuiDrDoctor.debug.R;
import com.huidr.HuiDrDoctor.module.home.AllContractModel;
import com.huidr.HuiDrDoctor.module.home.SimpleResultModel;
import com.huidr.HuiDrDoctor.util.CircleImageView;
import com.huidr.HuiDrDoctor.util.DownLoadImg;
import com.huidr.HuiDrDoctor.util.LogUtil;
import com.huidr.HuiDrDoctor.util.MulityClickUtils;
import com.huidr.HuiDrDoctor.util.ThreadPoolManager;
import com.huidr.lib.commom.base.BaseFragment;
import com.scwang.smartrefresh.layout.SmartRefreshLayout;
import com.scwang.smartrefresh.layout.api.RefreshLayout;
import com.scwang.smartrefresh.layout.listener.OnLoadMoreListener;
import com.scwang.smartrefresh.layout.listener.OnRefreshListener;
import com.zyao89.view.zloading.ZLoadingDialog;
import com.zyao89.view.zloading.Z_TYPE;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import cn.jpush.im.android.api.JMessageClient;
import cn.jpush.im.android.api.callback.GetUserInfoCallback;
import cn.jpush.im.android.api.content.TextContent;
import cn.jpush.im.android.api.model.Conversation;
import cn.jpush.im.android.api.model.UserInfo;
import cn.jpush.im.api.BasicCallback;
import jiguang.chat.activity.ChatActivity;
import jiguang.chat.application.JGApplication;
import jiguang.chat.utils.oss.OssService;
import jiguang.chat.utils.oss.SharedPreferenciesUtil;

import static com.huidr.HuiDrDoctor.util.DownLoadImg.getCirleBitmap;


/*
 * 联系人fragment
 *
 * 头像，医生姓名，住院号，时间，申请时间，通过(申请)，拒绝
 *
 *      医生可以获取的全部联系人名单
        1.系统自动进行匹配的联系人
        2.自己添加的联系人
        列表显示：
        1.按照医生姓名首字母进行排序
        2.默认全部显示，一次20条消息（包括首次）上拉加载
        医生可以获取的全部联系人名单
        1.系统自动进行匹配的联系人
        2.自己添加的联系人
        列表显示：
        1.按照医生姓名首字母进行排序
        2.默认全部显示，一次20条消息（包括首次）上拉加载
        操作
        1.点击头像跳转医生详情
        2.点击列表进入医生聊天页面
        3.左划列表添加/取消协同医生
 *
 * */
public class NewCotractFragment extends BaseFragment {

    SmartRefreshLayout srlLayout;
    RecyclerView rvListContract;

    ConstraintLayout clEmptyContract;
    TextView tvEmptyContract1, tvEmptyContract2;


    List<AllContractModel.RetValueBean> allContractList;
    AllContractModel allContractModel;
    Gson gson;
    int currentPage = 1;
    int totalPage = 1;
    String doctorId;

    ZLoadingDialog dialog;


    ZLoadingDialog dialog1;
    String pathAdd = BuildConfig.baseUrl + "hospital/doctorGroup/addAssistDoctor";//添加协同
    String pathDelete = BuildConfig.baseUrl + "hospital/doctorGroup/removeAssistDoctor";//删除协同

    String imgPath;
    OssService ossService;
    Matrix matrix;

    Date date = new Date();
    String str = "yyyy-MM-dd";
    SimpleDateFormat simpleDateFormat = new SimpleDateFormat(str);

    @Override
    protected void initData() {
        matrix = new Matrix();
        matrix.setRotate(90);
        dialog = new ZLoadingDialog(getContext());

        dialog.setLoadingBuilder(Z_TYPE.STAR_LOADING)//设置类型
                .setLoadingColor(Color.BLUE)//颜色
                .setHintText("处理中,请稍候...").setHintTextSize(16) // 设置字体大小 dp
                .setHintTextColor(Color.GRAY)  // 设置字体颜色
                .setDurationTime(0.5) // 设置动画时间百分比 - 0.5倍
                .setCanceledOnTouchOutside(false).setCancelable(false);
        dialog1 = new ZLoadingDialog(getContext());
        dialog1.setLoadingBuilder(Z_TYPE.STAR_LOADING)//设置类型
                .setLoadingColor(Color.BLUE)//颜色
                .setHintText("正在加载,请稍候...").setHintTextSize(16) // 设置字体大小 dp
                .setHintTextColor(Color.GRAY)  // 设置字体颜色
                .setDurationTime(0.5) // 设置动画时间百分比 - 0.5倍
                .setCanceledOnTouchOutside(false).setCancelable(false).show();

        allContractList = new ArrayList<>();
        allContractModel = new AllContractModel();
        gson = new Gson();
        doctorId = (String) SharedPreferenciesUtil.getData("id", "0");

        contractAdapter.setNewData(allContractList);

        getDataByPage();

    }


    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        imgPath = getContext().getExternalFilesDir("").getAbsolutePath() + "/img/head/";
        ossService = new OssService(getContext());
    }

    @Override
    protected View setContentView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_new_cotract, container, false);
    }

    @Override
    protected void findView(View parent) {
        srlLayout = parent.findViewById(R.id.srl_layout);

        srlLayout.setOnLoadMoreListener(new OnLoadMoreListener() {
            @Override
            public void onLoadMore(@NonNull RefreshLayout refreshLayout) {
                if (allContractModel.getRetValue().size() == 20 && currentPage < totalPage) {
                    currentPage += 1;
                    getDataByPage();
                } else {
                    com.huidr.lib.commom.util.Toast.getInstance(getContext()).show("数据加载全部", 500);
                    srlLayout.finishLoadMore();
                }
            }
        });

        srlLayout.setOnRefreshListener(new OnRefreshListener() {
            @Override
            public void onRefresh(@NonNull RefreshLayout refreshLayout) {
                currentPage = 1;
                getDataByPage();
            }
        });

        rvListContract = parent.findViewById(R.id.rv_list_contract);

        rvListContract.setAdapter(contractAdapter);
        rvListContract.setLayoutManager(new LinearLayoutManager(getContext()));


        clEmptyContract = parent.findViewById(R.id.cl_empty_contract);
        tvEmptyContract1 = parent.findViewById(R.id.tv_empty_contract1);
        tvEmptyContract2 = parent.findViewById(R.id.tv_empty_contract2);


        tvEmptyContract2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                currentPage = 1;
                getDataByPage();
            }
        });


    }

    //    分页获取联系人
    public void getDataByPage() {
        ThreadPoolManager.getInstance().execute(new Runnable() {
            @Override
            public void run() {
                String path = BuildConfig.baseUrl + "hospital/doctorGroup/getContactsList";
                JSONObject jsonObject = new JSONObject();
                jsonObject.put("pageIndex", currentPage);
                jsonObject.put("pageSize", 20);

                String result = PostAndGet.doHttpPost(path, jsonObject);

                LogUtil.e("全部联系人", result);
                allContractModel = new AllContractModel();
                if (result.equals("网络异常")) {
                    handler.sendEmptyMessage(3);
                } else {
                    allContractModel = gson.fromJson(result, AllContractModel.class);
                    if (allContractModel.getStatus() == 0) {
                        totalPage = allContractModel.getTotalPage();
                        if (currentPage == 1) {
                            handler.sendEmptyMessage(1);
                        } else {
                            handler.sendEmptyMessage(2);
                        }
                    } else {
                        handler.sendEmptyMessage(3);
                    }
                }
            }
        });
    }

    private Handler handler = new Handler() {
        @Override
        public void handleMessage(Message msg) {
            super.handleMessage(msg);
            switch (msg.what) {
                case 1:
                    contractAdapter.getData().clear();
                    if (allContractModel.getRetValue().size() == 0) {
                        clEmptyContract.setVisibility(View.VISIBLE);
                        srlLayout.setVisibility(View.GONE);
                        tvEmptyContract1.setText("暂无联系人~");
                        tvEmptyContract2.setText("");
                    } else {

                        contractAdapter.getData().addAll(allContractModel.getRetValue());
                        contractAdapter.notifyDataSetChanged();
                    }
                    srlLayout.finishRefresh();

                    if (dialog1 != null) {
                        new Handler().postDelayed(new Runnable() {
                            @Override
                            public void run() {
                                dialog1.dismiss();
                            }
                        }, 500);
                    }
                    break;
                case 2:
                    contractAdapter.getData().addAll(allContractModel.getRetValue());
                    contractAdapter.notifyDataSetChanged();
                    srlLayout.finishLoadMore();
                    break;
                case 3:
                    srlLayout.finishRefresh();
                    srlLayout.finishLoadMore();
                    clEmptyContract.setVisibility(View.VISIBLE);
                    srlLayout.setVisibility(View.GONE);
                    tvEmptyContract1.setText("网络错误~");
                    String tip = "<font color='#248cfa'><u>立即刷新<u><font>";
                    tvEmptyContract2.setText(Html.fromHtml(tip));
                    if (dialog1 != null) {
                        new Handler().postDelayed(new Runnable() {
                            @Override
                            public void run() {
                                dialog1.dismiss();
                            }
                        }, 500);
                    }
                    break;

//                    删除好友成功
                case 4:
                    LogUtil.e("删除id", msg.arg1 + " ");

                    if (dialog != null) {
                        dialog.dismiss();
                    }
                    com.huidr.lib.commom.util.Toast.getInstance(getContext()).show("删除好友成功", 500);
                    contractAdapter.remove(msg.arg1);
                    break;
                //                    删除好友失败
                case 5:
                    if (dialog != null) {
                        dialog.dismiss();
                    }
                    com.huidr.lib.commom.util.Toast.getInstance(getContext()).show("删除好友失败", 500);
                    contractAdapter.notifyItemChanged(msg.arg1);
                    break;


//                    添加协同成功
                case 11:
                    if (dialog != null) {
                        dialog.dismiss();
                    }
                    contractAdapter.getData().get(msg.arg1).setIsAssist(true);
                    com.huidr.lib.commom.util.Toast.getInstance(getContext()).show("添加协同医生成功", 500);
                    contractAdapter.notifyItemChanged(msg.arg1);
                    break;
                //                    添加协同失败
                case 12:
                    if (dialog != null) {
                        dialog.dismiss();
                    }
                    com.huidr.lib.commom.util.Toast.getInstance(getContext()).show("添加协同医生失败", 500);
                    contractAdapter.notifyItemChanged(msg.arg1);
//                    contractAdapter.notifyDataSetChanged();
                    break;
                //                    删除协同成功
                case 13:
                    if (dialog != null) {
                        dialog.dismiss();
                    }
                    contractAdapter.getData().get(msg.arg1).setIsAssist(false);
                    com.huidr.lib.commom.util.Toast.getInstance(getContext()).show("删除协同医生成功", 500);
                    contractAdapter.notifyItemChanged(msg.arg1);
                    break;
                //                    删除协同失败
                case 14:
                    if (dialog != null) {
                        dialog.dismiss();
                    }
                    com.huidr.lib.commom.util.Toast.getInstance(getContext()).show("删除协同医生失败", 500);
                    contractAdapter.notifyItemChanged(msg.arg1);
                    break;
            }
        }
    };

    private BaseQuickAdapter<AllContractModel.RetValueBean, BaseViewHolder> contractAdapter;

    {
        contractAdapter = new BaseQuickAdapter<AllContractModel.RetValueBean, BaseViewHolder>(R.layout.item_apply_layout) {
            @Override
            protected void convert(final BaseViewHolder helper, final AllContractModel.RetValueBean item) {

                ConstraintLayout cl_item = helper.getView(R.id.cl_item);
                cl_item.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        if (JMessageClient.getMyInfo() == null) {
                            return;
                        }

                        if (MulityClickUtils.isFastClick()) {
                            addDoctorToRecent(item.getContactsId() + "");
                            Intent intent = new Intent(getActivity(), ChatActivity.class);
                            Bundle bundle = new Bundle();
                            bundle.putString("targetId", item.getContactsId() + "");
                            bundle.putString(JGApplication.CONV_TITLE, item.getContactsName());
                            bundle.putString(JGApplication.TARGET_APP_KEY, BuildConfig.appkey);
                            intent.putExtras(bundle);
                            startActivity(intent);
                        }
                    }
                });

                CircleImageView imgItemHead = helper.getView(R.id.img_item_head);
                imgItemHead.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        if (MulityClickUtils.isFastClick()) {
                            Intent intent1 = new Intent(getActivity(), WebActivity.class);
                            Bundle bundle = new Bundle();
                            bundle.putString("url", "personal.html?id=" + item.getContactsId());
                            intent1.putExtras(bundle);
                            startActivity(intent1);
                        }
                    }
                });
                ImageView imgNotice = helper.getView(R.id.img_notice);
                imgNotice.setVisibility(View.GONE);
                TextView tvItemName = helper.getView(R.id.tv_item_name);
                tvItemName.setText(item.getContactsName());
                TextView tvItemAge = helper.getView(R.id.tv_item_age);
                tvItemAge.setText(item.getContactsTitle() + "(" + item.getContactsDepartment() + ")");
                TextView tvItemDate = helper.getView(R.id.tv_item_date);
                TextView tvItemMsg = helper.getView(R.id.tv_item_msg);
                Button btnApply = helper.getView(R.id.btn_apply);
                Button btnRefuse = helper.getView(R.id.btn_refuse);
                TextView tvScrollRight = helper.getView(R.id.tv_scroll_right);
                TextView tvScrollDel = helper.getView(R.id.tv_scroll_del);

                Conversation conversation = JMessageClient.getSingleConversation(item.getContactsId() + "");
                if (conversation == null) {
                    tvItemMsg.setText("暂无聊天消息");
                    tvItemDate.setVisibility(View.GONE);
//                imgNotice.setVisibility(View.GONE);
                } else {
                    cn.jpush.im.android.api.model.Message message = conversation.getLatestMessage();
                    if (message != null) {

                        switch (message.getContentType()) {
                            case text:
                                tvItemMsg.setText(((TextContent) message.getContent()).getText());
                                break;
                            case voice:
                                tvItemMsg.setText("[语音消息]");
                                break;
                            case image:
                                tvItemMsg.setText("[图片]");
                                break;
                            case file:
                                tvItemMsg.setText("[文件]");
                                break;
                            case location:
                                tvItemMsg.setText("[位置]");
                                break;
                            default:
                                break;
                        }

                        date.setTime(message.getCreateTime());
                        tvItemDate.setText(simpleDateFormat.format(date));
                        tvItemDate.setVisibility(View.VISIBLE);
                    } else {
                        tvItemMsg.setText("暂无聊天消息");
                        tvItemDate.setVisibility(View.GONE);
                    }

                }

                String str = "";
                if (item.isIsAssist()) {
                    str = "<font>取消<br>协同</font>";
                    tvScrollRight.setBackgroundResource(R.drawable.shape_atten_gray);
                } else {
                    str = "<font>添加<br>协同</font>";
                    tvScrollRight.setBackgroundResource(R.drawable.add_coop_back);
                }
                tvScrollRight.setText(Html.fromHtml(str));

                tvScrollRight.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        if (MulityClickUtils.isFastClick()) {
                            showCoopDialog(item.getContactsId() + "", helper.getAdapterPosition(), item.isIsAssist());
                        }
                    }
                });


                Bitmap defaultBitmap = BitmapFactory.decodeResource(getResources(), R.drawable.nantou);
                BitmapDrawable defaultDrawable = new BitmapDrawable(getResources(), defaultBitmap);
                imgItemHead.setBackgroundDrawable(defaultDrawable);

                if (item.getContactsIcon() != null) {

                    imgItemHead.setTag(item.getContactsIcon());
                    final File file = new File(imgPath + item.getContactsIcon());
                    if (file.exists()) {
                        Bitmap bitmap1 = BitmapFactory.decodeFile(file.getAbsolutePath());

                        if (bitmap1 != null) {
                            bitmap1 = getCirleBitmap(bitmap1);
                            BitmapDrawable bitmapDrawable1 = new BitmapDrawable(getContext().getResources(), bitmap1);
                            if (item.getContactsIcon().equals(imgItemHead.getTag())) {
                                imgItemHead.setBackgroundDrawable(bitmapDrawable1);
                            }
                        }
                    } else {
                        DownLoadImg.BitmapWorkerTask bitmapWorkerTask = new DownLoadImg.BitmapWorkerTask(imgItemHead, file, ossService);
                        bitmapWorkerTask.execute(item.getContactsIcon());

                    }

                } else {
                    Log.e("默认图片", (defaultDrawable == null) + "");
                    imgItemHead.setBackgroundDrawable(defaultDrawable);
                }


                String del = "<font>删除<br>好友<font>";
                tvScrollDel.setText(Html.fromHtml(del));
                tvScrollDel.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        if (MulityClickUtils.isFastClick()) {
                            showDialog1(item.getContactsId() + "", item.getId() + "", helper.getAdapterPosition(), item.isIsAssist());
                        }
                    }
                });
            }
        };
    }


    //    添加最近查看医生
    public void addDoctorToRecent(final String id) {
        ThreadPoolManager.getInstance().execute(new Runnable() {
            @Override
            public void run() {
//                String path = "http://192.168.1.180:1189/doctorGroup/addRecentlyCheckDoctor";
                String path = BuildConfig.baseUrl + "hospital/doctorGroup/addRecentlyCheckDoctor";
                JSONObject jsonObject = new JSONObject();
                jsonObject.put("doctorId", id);
                String result = PostAndGet.doHttpPost(path, jsonObject);
                LogUtil.e("添加最近查看", result);
                if (result.equals("网络异常")) {

                } else {

                }
            }
        });
    }


    @Override
    public void onStop() {
        super.onStop();
        if (dialog != null) {
            dialog.dismiss();
        }
        if (dialog1 != null) {
            dialog1.dismiss();
        }

        contractAdapter.notifyDataSetChanged();

    }

    //   IM 删除联系人
    public void imDeleteContract(final String targetId, final String id, final int position, final boolean isAssist) {
        JMessageClient.getUserInfo(targetId, new GetUserInfoCallback() {
            @Override
            public void gotResult(int i, String s, UserInfo userInfo) {
                if (i == 0) {
                    userInfo.removeFromFriendList(new BasicCallback() {
                        @Override
                        public void gotResult(int i, String s) {
                            if (i == 0) {
                                deleteContract(id, position, isAssist);
                            } else {
                                LogUtil.e("IM删除联系人", s);
                                if (s.equals("user not friend")) {
                                    deleteContract(id, position, isAssist);
                                }
//                                contractAdapter.notifyItemChanged(position);
//                                com.huidr.lib.commom.util.Toast.getInstance(getContext()).show("极光登录失败", 500);
                            }
                        }
                    });
                } else {
                    LogUtil.e("123", "123");
                    contractAdapter.notifyItemChanged(position);
                    com.huidr.lib.commom.util.Toast.getInstance(getContext()).show("极光登录失败", 500);
                }
            }
        });
    }

    //    访问删除接口  删除好友
//    doctorGroup/deleteContacts
    public void deleteContract(final String targetId, final int position, final boolean isAssist) {
        ThreadPoolManager.getInstance().execute(new Runnable() {
            @Override
            public void run() {

                String path = BuildConfig.baseUrl + "hospital/doctorGroup/deleteContacts";
                JSONObject jsonObject = new JSONObject();
                jsonObject.put("id", targetId);
                jsonObject.put("isAssist", isAssist);
                String result = PostAndGet.doHttpPost(path, jsonObject);
                Message message = new Message();
                message.arg1 = position;
                LogUtil.e("删除联系人", result);
                if (result.equals("网络异常")) {
                    message.what = 5;
                    handler.sendMessage(message);
                } else {
                    SimpleResultModel simpleResultModel = gson.fromJson(result, SimpleResultModel.class);
                    if (simpleResultModel.getStatus() == 0) {
                        if (simpleResultModel.getRetValue() == 0) {

                            message.what = 4;
                            handler.sendMessage(message);
                        } else {
                            message.what = 5;
                            handler.sendMessage(message);
                        }
                    } else {
                        message.what = 5;
                        handler.sendMessage(message);
                    }
                }
            }
        });
    }


    //    添加协同  String path = "http://192.168.1.180:1189/doctorGroup/addAssistDoctor";
    public void addAssistDoctor(final String id, final int position) {
        ThreadPoolManager.getInstance().execute(new Runnable() {
            @Override
            public void run() {
                JSONObject jsonObject = new JSONObject();
                int uid = Integer.valueOf(id);
                int[] a = new int[]{uid};
                jsonObject.put("assistUids", a);

                String result = PostAndGet.doHttpPost(pathAdd, jsonObject);
                LogUtil.e("添加协同医生", result);
                Message msg = new Message();
                msg.arg1 = position;
                if (result.equals("网络异常")) {
                    msg.what = 12;
                    handler.sendMessage(msg);
                } else {
                    SimpleResultModel simpleResultModel = gson.fromJson(result, SimpleResultModel.class);
                    if (simpleResultModel.getStatus() == 0) {
                        if (simpleResultModel.getRetValue() == 0) {
                            msg.what = 11;
                            handler.sendMessage(msg);
                        } else {
                            msg.what = 12;
                            handler.sendMessage(msg);
                        }
                    } else {
                        msg.what = 12;
                        handler.sendMessage(msg);
                    }
                }
            }
        });
    }


    //    删除协同医生
    public void deleteCooperDoctor(final String deleteId, final int position) {
        ThreadPoolManager.getInstance().execute(new Runnable() {
            @Override
            public void run() {
                JSONObject jsonObject = new JSONObject();
                jsonObject.put("assistUid", deleteId);
                String result = PostAndGet.doHttpPost(pathDelete, jsonObject);

                Message message = new Message();
                message.arg1 = position;

                if (result.equals("网络异常")) {
                    message.what = 14;
                    handler.sendMessage(message);
                } else {
                    SimpleResultModel simpleResultModel = gson.fromJson(result, SimpleResultModel.class);
                    if (simpleResultModel.getStatus() == 0) {
                        if (simpleResultModel.getRetValue() == 0) {
                            message.what = 13;
                            handler.sendMessage(message);
                        } else {
                            message.what = 14;
                            handler.sendMessage(message);
                        }
                    } else {
                        message.what = 14;
                        handler.sendMessage(message);
                    }
                }
            }
        });
    }


    //    删除好友 对话框
    public void showDialog1(final String id, final String id1, final int position, final boolean isAssist) {

        final Dialog builder = new Dialog(getContext(), R.style.jmui_default_dialog_style);
        //final Dialog builder = new Dialog(this, R.style.jmui_default_dialog_style);
        View view = LayoutInflater.from(getContext()).inflate(R.layout.dialog_content, null);

        TextView tvTitle = view.findViewById(R.id.tv_title);
        TextView tvFooter1 = view.findViewById(R.id.tv_footer1);
        TextView tvFooter2 = view.findViewById(R.id.tv_footer2);

        tvTitle.setText("是否删除此联系人");

//        取消
        tvFooter1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                builder.cancel();
                contractAdapter.notifyItemChanged(position);
            }
        });
//确定
        tvFooter2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                imDeleteContract(id, id1, position, isAssist);
                builder.cancel();
            }
        });

        builder.setContentView(view);
        //builder.setCanceledOnTouchOutside(true);
        builder.show();
        Window window = builder.getWindow();
        WindowManager.LayoutParams lp = window.getAttributes();
        WindowManager windowManager = getActivity().getWindowManager();
        Display display = windowManager.getDefaultDisplay();
        lp.width = (int) (display.getWidth() * 0.7);
//        lp.height = (int) (display.getHeight() * 0.1);
        window.setAttributes(lp);
    }

    //    取消添加协同对话框
    public void showCoopDialog(final String id, final int position, final boolean isCoop) {

        final Dialog builder = new Dialog(getContext(), R.style.jmui_default_dialog_style);
        //final Dialog builder = new Dialog(this, R.style.jmui_default_dialog_style);
        View view = LayoutInflater.from(getContext()).inflate(R.layout.dialog_content, null);

        TextView tvTitle = view.findViewById(R.id.tv_title);
        TextView tvFooter1 = view.findViewById(R.id.tv_footer1);
        TextView tvFooter2 = view.findViewById(R.id.tv_footer2);

        if (isCoop) {
            tvTitle.setText("是否删除协同医生!");
        } else {
            tvTitle.setText("是否添加协同医生!");
        }


//        取消
        tvFooter1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                builder.cancel();

                contractAdapter.notifyItemChanged(position);
            }
        });
//确定
        tvFooter2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                builder.cancel();
                if (isCoop) {
                    deleteCooperDoctor(id, position);
                } else {
                    addAssistDoctor(id, position);
                }
            }
        });

        builder.setContentView(view);
        //builder.setCanceledOnTouchOutside(true);
        builder.show();
        Window window = builder.getWindow();
        WindowManager.LayoutParams lp = window.getAttributes();
        WindowManager windowManager = getActivity().getWindowManager();
        Display display = windowManager.getDefaultDisplay();
        lp.width = (int) (display.getWidth() * 0.7);
//        lp.height = (int) (display.getHeight() * 0.1);
        window.setAttributes(lp);
    }
}
