package com.huidr.HuiDrDoctor.services;

import android.app.Service;
import android.content.Intent;
import android.os.IBinder;
import android.util.Log;

import com.huidr.HuiDrDoctor.debug.BuildConfig;

import cn.jpush.im.android.api.JMessageClient;
import cn.jpush.im.android.api.callback.GetUserInfoCallback;
import cn.jpush.im.android.api.model.Conversation;
import cn.jpush.im.android.api.model.UserInfo;
import cn.jpush.im.api.BasicCallback;

public class MyServiceDelete extends Service {

    String patientId;

    public MyServiceDelete() {
    }

    @Override
    public IBinder onBind(Intent intent) {
        // TODO: Return the communication channel to the service.
        throw new UnsupportedOperationException("Not yet implemented");
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        patientId = intent.getStringExtra("patientId");
        Conversation conversation = JMessageClient.getSingleConversation(patientId, BuildConfig.patientAppkey);


        conversation.deleteAllMessage();
//        JMessageClient.deleteSingleConversation(patientId, BuildConfig.patientAppkey);
        JMessageClient.getUserInfo(patientId, BuildConfig.patientAppkey, new GetUserInfoCallback() {
            @Override
            public void gotResult(int i, String s, UserInfo userInfo) {
                if (i == 0) {
                    userInfo.removeFromFriendList(new BasicCallback() {
                        @Override
                        public void gotResult(int i, String s) {
                            Log.e("结束咨询  48", i + "医生删除患者" + s);
                            if (i == 0) {
                                Log.e("结束咨询  48", "删除好友成功");
//                                        finish();
//                                new Handler().postDelayed(new Runnable() {
//                                    @Override
//                                    public void run() {
//                                        finish();
//                                    }
//                                }, 2000);

                                stopSelf();
                            }
                        }
                    });

                }
            }
        });

        return super.onStartCommand(intent, flags, startId);
    }
}
