package com.huidr.HuiDrDoctor.activity.main.Consult.fragment;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import androidx.annotation.NonNull;


import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.alibaba.fastjson.JSONObject;
import com.chad.library.adapter.base.BaseQuickAdapter;
import com.chad.library.adapter.base.BaseViewHolder;
import com.google.gson.Gson;
import com.huidr.HuiDrDoctor.activity.ConsultReplyActivity;
import com.huidr.HuiDrDoctor.debug.BuildConfig;
import com.huidr.HuiDrDoctor.debug.R;
import com.huidr.HuiDrDoctor.module.consult.ConsultOrderList;
import com.huidr.HuiDrDoctor.module.consult.OrderDetail;
import com.huidr.HuiDrDoctor.util.LogUtil;
import com.huidr.HuiDrDoctor.util.ThreadPoolManager;
import com.scwang.smartrefresh.layout.SmartRefreshLayout;
import com.scwang.smartrefresh.layout.api.RefreshLayout;
import com.scwang.smartrefresh.layout.listener.OnLoadMoreListener;
import com.scwang.smartrefresh.layout.listener.OnRefreshListener;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

import androidx.annotation.Nullable;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import cn.jpush.im.android.api.JMessageClient;
import cn.jpush.im.android.api.content.TextContent;
import cn.jpush.im.android.api.model.Conversation;
import cn.jpush.im.android.api.model.UserInfo;
import cn.jpush.im.api.BasicCallback;
import jiguang.chat.activity.fragment.BaseFragment;
import jiguang.chat.utils.oss.SharedPreferenciesUtil;

/**
 * 咨询中 列表
 * 对话列表
 * <p>
 * 显示数量  空msg + unReadMsgCnt
 */
public class ConversationFragment extends BaseFragment {

    RecyclerView rvConversition;
    //    MyAdapter myAdapter;
    List<Conversation> mData;
    RelativeLayout rlEmpty;
    int unread = 0;
    long lastClick;
    Gson gson;
    String doctorId;

    int totalPage;//
    int currentPage;//
    List<ConsultOrderList.RetValueBean> allConversionList, tempConversionList;
    ConversionAdapter conversionAdapter;
    SmartRefreshLayout erl;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        doctorId = (String) SharedPreferenciesUtil.getData(jiguang.chat.utils.oss.Constants.SharedAccountConfig.ID, "0");
        View view = inflater.inflate(R.layout.fragment_conversation, container, false);

        judegLogin();
        gson = new Gson();
        allConversionList = new ArrayList<>();
        tempConversionList = new ArrayList<>();
        initData();
        initView(view);
        JMessageClient.registerEventReceiver(this);
        return view;
    }

    public void judegLogin() {
        UserInfo userInfo = JMessageClient.getMyInfo();

        if (userInfo == null) {
            String id = (String) SharedPreferenciesUtil.getData("id", "0");
            String pwd = (String) SharedPreferenciesUtil.getData("imPassword", "0");
            JMessageClient.login(id, pwd, new BasicCallback() {
                @Override
                public void gotResult(int i, String s) {

                }
            });
        }
    }


    /*appkey
     * 这里显示 患者的
     * 需要过滤  bd6ad187437010acb0639f85
     * */
    public void initData() {
        totalPage = 1;
        currentPage = 1;
        conversionAdapter = new ConversionAdapter(R.layout.item_consult_layout, allConversionList);

        getListByPage();
    }

    public void getListByPage() {
        ThreadPoolManager.getInstance().execute(new Runnable() {
            @Override
            public void run() {
                String result = checkConsult(doctorId, currentPage);
                ConsultOrderList consultOrderList = gson.fromJson(result, ConsultOrderList.class);
                tempConversionList = consultOrderList.getRetValue();
                if (currentPage == 1) {
                    handler.sendEmptyMessage(0);
                } else {
                    handler.sendEmptyMessage(1);
                }

            }
        });
    }

    public void initView(View view) {
        rvConversition = (RecyclerView) view.findViewById(R.id.rv_conversation);
        rlEmpty = (RelativeLayout) view.findViewById(R.id.rl_empty);
        rvConversition.setAdapter(conversionAdapter);
        rvConversition.setLayoutManager(new LinearLayoutManager(getContext()));
        erl = (SmartRefreshLayout) view.findViewById(R.id.erl);


        erl.setOnRefreshListener(new OnRefreshListener() {
            @Override
            public void onRefresh(@NonNull RefreshLayout refreshLayout) {
                currentPage = 1;
                getListByPage();
//                erl.finishRefresh();
            }
        });

        erl.setOnLoadMoreListener(new OnLoadMoreListener() {
            @Override
            public void onLoadMore(@NonNull RefreshLayout refreshLayout) {
                if (conversionAdapter.getData().size() > ((totalPage - 1) * 10)) {
                    Toast.makeText(mActivity, "已经加载全部", Toast.LENGTH_SHORT).show();
                    erl.finishLoadMore();
                } else {
                    currentPage += 1;
                    getListByPage();
//                    erl.closeLoadView();
                }
            }
        });

//        erl.addEasyEvent(new EasyRefreshLayout.EasyEvent() {
//            @Override
//            public void onLoadMore() {
//
//            }
//
//            @Override
//            public void onRefreshing() {
//
//
//            }
//        });
    }


    private Handler handler = new Handler() {
        @Override
        public void handleMessage(Message msg) {
            super.handleMessage(msg);
            switch (msg.what) {
                case 0:
                    if (conversionAdapter.getData().size() > 0) {
                        conversionAdapter.getData().clear();
                    }
                    conversionAdapter.getData().addAll(tempConversionList);
                    conversionAdapter.notifyDataSetChanged();

                    if (tempConversionList.size() == 0) {
                        erl.setVisibility(View.GONE);
                        rlEmpty.setVisibility(View.VISIBLE);
                    } else {
                        rlEmpty.setVisibility(View.GONE);
                        erl.setVisibility(View.VISIBLE);
                    }
                    tempConversionList.clear();
                    erl.finishRefresh();
                    break;
                case 1:
                    conversionAdapter.getData().addAll(tempConversionList);
                    conversionAdapter.notifyDataSetChanged();
                    tempConversionList.clear();
                    erl.finishLoadMore();
                    break;
            }
        }
    };

    public class ConversionAdapter extends BaseQuickAdapter<ConsultOrderList.RetValueBean, BaseViewHolder> {

        public ConversionAdapter(int layoutResId, @Nullable List<ConsultOrderList.RetValueBean> data) {
            super(layoutResId, data);
        }

        @Override
        protected void convert(BaseViewHolder helper, final ConsultOrderList.RetValueBean item) {
            RelativeLayout rlBottom = helper.getView(R.id.rl_bottom);
            rlBottom.setVisibility(View.GONE);
            final OrderDetail orderDetail = gson.fromJson(item.getOrderDetails(), OrderDetail.class);
            ((TextView) helper.getView(R.id.tv_name)).setText(orderDetail.getPatientName());
            ((TextView) helper.getView(R.id.tv_right)).setText("立即回复");
            ((TextView) helper.getView(R.id.tv_right)).setTextColor(getResources().getColor(R.color.black));
            Conversation conversation = JMessageClient.getSingleConversation(item.getBuyerId() + "", BuildConfig.patientAppkey);
            if (conversation == null) {
                conversation = Conversation.createSingleConversation(item.getBuyerId() + "", BuildConfig.patientAppkey);
            }


            ImageView imgUnRead = helper.getView(R.id.img_unread_count);


            if (conversation != null && conversation.getUnReadMsgCnt() > 0) {
                imgUnRead.setVisibility(View.VISIBLE);
            } else {
                imgUnRead.setVisibility(View.GONE);
            }

            TextView textView = helper.getView(R.id.tv_right);
            LinearLayout llItem = helper.getView(R.id.ll_item);
            llItem.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    long currentTime = System.currentTimeMillis();
                    if (currentTime - lastClick > 1000) {
                        Intent intent = new Intent(getActivity(), ConsultReplyActivity.class);
                        Bundle bundle = new Bundle();
                        bundle.putString("username", item.getBuyerId() + "");
                        bundle.putString("nickname", orderDetail.getPatientName());
                        bundle.putString("orderid", item.getOrderId());
                        bundle.putString("patientUid", item.getBuyerRelationId() + "");
                        intent.putExtras(bundle);
                        mContext.startActivity(intent);
                        lastClick = currentTime;
                    }
                }
            });


            if (conversation != null) {
                cn.jpush.im.android.api.model.Message msg = conversation.getLatestMessage();
                if (msg == null) {
//                ((TextView) helper.getView(R.id.tv_desc)).setText("这里是申请");
                } else {

                    switch (msg.getContentType().toString()) {

                        case "image":
                            ((TextView) helper.getView(R.id.tv_desc)).setText("图片");
                            break;
                        case "voice":
                            ((TextView) helper.getView(R.id.tv_desc)).setText("语音");
                            break;
                        case "custom":

                            break;
                        case "prompt":
                            ((TextView) helper.getView(R.id.tv_desc)).setText(msg.getContent().getStringExtra("promptText"));
                            break;
                        case "text":
                            ((TextView) helper.getView(R.id.tv_desc)).setText(((TextContent) msg.getContent()).getText());
                            break;
                        default:
                            ((TextView) helper.getView(R.id.tv_desc)).setText(msg.getContentType().toString());
                            break;
                    }
                }

            }

        }


    }


    //查询咨询中会话
    public String checkConsult(String doctorID, int page) {
        String result = "";
        StringBuffer buffer = new StringBuffer();
        String str = BuildConfig.baseUrl + "pay/orderSearch/searchOrder";
        HttpURLConnection connection = null;
        String jwt = (String) SharedPreferenciesUtil.getData("jwt", "");

        try {
            JSONObject jsonObject = new JSONObject();
            jsonObject.put("orderStatus", 2);
            jsonObject.put("orderStatusAction", 3);
            jsonObject.put("orderKind", 2);
            jsonObject.put("sellerId", doctorID);
            jsonObject.put("pageIndex", page);
            URL url = new URL(str);
            connection = (HttpURLConnection) url.openConnection();
            connection.setRequestMethod("POST");
            connection.setRequestProperty("Charset", "UTF-8");
            connection.setRequestProperty("jwt", jwt);

            connection.setRequestProperty("accept", "application/json");
            connection.setRequestProperty("Connection", "Keep-Alive");
            connection.setRequestProperty("Content-Type", "application/json");
            connection.setDoOutput(true);
            connection.setDoInput(true);
            connection.connect();
            OutputStream outputStream = connection.getOutputStream();
            outputStream.write(jsonObject.toString().getBytes());
            outputStream.flush();
            outputStream.close();

            if (connection.getResponseCode() == 200) {
                BufferedReader reader = new BufferedReader(new InputStreamReader(connection.getInputStream()));
                String str1;
                while ((str1 = reader.readLine()) != null) {
                    buffer.append(str1);
                }
                LogUtil.e("咨询中会话23", buffer.toString());
                result = buffer.toString();

            }
        } catch (Exception e) {
            e.printStackTrace();
            LogUtil.e("异常", e.toString());
        }
        return result;
    }


}
