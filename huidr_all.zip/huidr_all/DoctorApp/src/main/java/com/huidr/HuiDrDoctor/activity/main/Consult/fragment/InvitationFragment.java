package com.huidr.HuiDrDoctor.activity.main.Consult.fragment;

import android.content.Intent;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.os.Handler;
import android.os.Message;
import androidx.annotation.NonNull;

import android.text.Html;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.chad.library.adapter.base.BaseQuickAdapter;
import com.chad.library.adapter.base.BaseViewHolder;
import com.google.gson.Gson;
import com.huidr.HuiDrDoctor.activity.DealConsultActivity;
import com.huidr.HuiDrDoctor.activity.main.Consult.Model.InvitationModel;
import com.huidr.HuiDrDoctor.debug.BuildConfig;
import com.huidr.HuiDrDoctor.debug.R;
import com.huidr.HuiDrDoctor.module.consult.ConsultOrderList;
import com.huidr.HuiDrDoctor.module.consult.OrderDetail;
import com.huidr.HuiDrDoctor.util.LogUtil;
import com.huidr.HuiDrDoctor.util.ThreadPoolManager;
import com.scwang.smartrefresh.layout.SmartRefreshLayout;
import com.scwang.smartrefresh.layout.api.RefreshLayout;
import com.scwang.smartrefresh.layout.listener.OnLoadMoreListener;
import com.scwang.smartrefresh.layout.listener.OnRefreshListener;

import org.greenrobot.eventbus.EventBus;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.Serializable;
import java.net.HttpURLConnection;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

import androidx.annotation.Nullable;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import cn.jpush.im.android.api.JMessageClient;
import cn.jpush.im.android.api.event.ContactNotifyEvent;
import jiguang.chat.activity.fragment.BaseFragment;
import jiguang.chat.utils.event.BusEventMessage;
import jiguang.chat.utils.oss.SharedPreferenciesUtil;


/*
 * 图文咨询待接受
 * 显示 患者发送的咨询申请 添加好友申请
 * 可以  拒绝 或者同意
 * 拒绝或者同意后删除对应申请
 * */
public class InvitationFragment extends BaseFragment {

    private RecyclerView rvInvitation;
    private RelativeLayout rlEmpty;
    long lastClick;
    Gson gson;
    int hours = 0;
    int minutes = 0;
    int seconds = 0;
    String doctorId;
    CountDownTimer timer;
    List<InvitationModel> invitationModelList, tempInvitationList;
    InvitationAdapter invitationAdapter;

    SmartRefreshLayout erl;
    int totalPage;
    int currentPage;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        invitationModelList = new ArrayList<>();
        tempInvitationList = new ArrayList<>();
        doctorId = (String) SharedPreferenciesUtil.getData(jiguang.chat.utils.oss.Constants.SharedAccountConfig.ID, "0");

        View view = inflater.inflate(R.layout.fragment_invitation, container, false);
        JMessageClient.registerEventReceiver(this);
        initData();
        initView(view);
        return view;
    }


    public void initData() {
        totalPage = 1;
        currentPage = 1;
        invitationAdapter = new InvitationAdapter(R.layout.item_consult_layout, invitationModelList);
        gson = new Gson();
        getList();
    }


    public void getList() {
        invitationModelList.clear();

        if (timer != null) {
            timer.cancel();
        }
        ThreadPoolManager.getInstance().execute(new Runnable() {
            @Override
            public void run() {
                String result = checkConsult(currentPage);
                Gson gson = new Gson();
                ConsultOrderList list = gson.fromJson(result, ConsultOrderList.class);
                totalPage = list.getTotalPage();
                for (int i = 0; i < list.getRetValue().size(); i++) {
                    String orderDetailString = list.getRetValue().get(i).getOrderDetails();
                    OrderDetail orderDetail = gson.fromJson(orderDetailString, OrderDetail.class);
                    InvitationModel invitationModel = new InvitationModel();
                    invitationModel.setPatientName(orderDetail.getPatientName());
                    invitationModel.setDesc(orderDetail.getNeedHelp());
                    invitationModel.setPrice(list.getRetValue().get(i).getOrderPrice());
                    invitationModel.setCreateTime(list.getRetValue().get(i).getCreateTime());
                    invitationModel.setPatientId(orderDetail.getPatientId() + "");
                    invitationModel.setOrderId(list.getRetValue().get(i).getOrderId());
                    invitationModel.setPatientUserId(list.getRetValue().get(i).getBuyerId() + "");
                    invitationModel.setPics(orderDetail.getPics());
//                    LogUtil.e("咨询图片", orderDetail.getPics().toString());
                    tempInvitationList.add(invitationModel);
                }


                if (currentPage == 1) {
                    handler.sendEmptyMessage(2);
                } else {
                    handler.sendEmptyMessage(1);
                }
            }
        });
    }

    public void initView(View view) {
        rvInvitation = (RecyclerView) view.findViewById(R.id.rv_invitation);
        rlEmpty = (RelativeLayout) view.findViewById(R.id.rl_empty);
        rvInvitation.setLayoutManager(new LinearLayoutManager(getActivity()));
        rvInvitation.setAdapter(invitationAdapter);
        erl = (SmartRefreshLayout) view.findViewById(R.id.erl);

        erl.setOnLoadMoreListener(new OnLoadMoreListener() {
            @Override
            public void onLoadMore(@NonNull RefreshLayout refreshLayout) {
                if (invitationAdapter.getData().size() > (totalPage - 1) * 10) {
                    Toast.makeText(mActivity, "已经加载全部", Toast.LENGTH_SHORT).show();

                } else {
                    currentPage += 1;
                    getList();
                }
                erl.finishLoadMore();
//                erl.closeLoadView();
            }
        });

        erl.setOnRefreshListener(new OnRefreshListener() {
            @Override
            public void onRefresh(@NonNull RefreshLayout refreshLayout) {
                currentPage = 1;
                getList();
                erl.finishRefresh();
            }
        });


    }


    public class InvitationAdapter extends BaseQuickAdapter<InvitationModel, BaseViewHolder> {
        public InvitationAdapter(int layoutResId, @Nullable List<InvitationModel> data) {
            super(layoutResId, data);
        }

        @Override
        protected void convert(BaseViewHolder helper, final InvitationModel item) {
            ((TextView) helper.getView(R.id.tv_name)).setText(item.getPatientName());

            LinearLayout llItem = helper.getView(R.id.ll_item);

            TextView tvName = helper.getView(R.id.tv_name);
            TextView tvDesc = helper.getView(R.id.tv_desc);
            TextView tvPrice = helper.getView(R.id.tv_price);
            final TextView tvTime = helper.getView(R.id.tv_time);
            tvName.setText(item.getPatientName());
            String price = "咨询费用：<font color='#EB5463'>¥" + (item.getPrice() / 100) + "</font>";
            tvPrice.setText(Html.fromHtml(price));
            tvDesc.setText("问题：" + item.getDesc());
            TextView tvRight = (TextView) helper.getView(R.id.tv_right);
//           跳转处理订单页
            llItem.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    long currentTime = System.currentTimeMillis();
                    if (currentTime - lastClick > 1000) {
                        Intent intent = new Intent(getActivity(), DealConsultActivity.class);
                        intent.putExtra("username", item.getPatientName());
                        intent.putExtra("hours", hours);
                        intent.putExtra("minutes", minutes);
                        intent.putExtra("seconds", seconds);
                        intent.putExtra("desc", item.getDesc());
                        intent.putExtra("orderId", item.getOrderId());
                        intent.putExtra("imgs", (Serializable) item.getPics());
                        intent.putExtra("patientUserId", item.getPatientUserId());
                        intent.putExtra("patientId", item.getPatientId());
                        startActivity(intent);
                        lastClick = currentTime;
                    }
                }
            });
            try {

                String dateTime = item.getCreateTime() + " 123";
                Calendar calendar = Calendar.getInstance();
                calendar.setTime(new SimpleDateFormat("yyyy-MM-dd HH:mm:ss SSS").parse(dateTime));
                long alltime = System.currentTimeMillis() - calendar.getTimeInMillis();
                alltime = (1000 * 60 * 60 * 24) - alltime;

                if (alltime <= 0) {
                    hours = 0;
                    minutes = 0;
                    seconds = 0;
                    ((TextView) helper.getView(R.id.tv_time)).setText("距离结束：" + hours + ":" + minutes + ":" + seconds);
                } else {
                    timer = new CountDownTimer(alltime, 1000) {
                        @Override
                        public void onTick(long millisUntilFinished) {
                            hours = (int) (millisUntilFinished / 3600000);
                            minutes = (int) ((millisUntilFinished % 3600000) / 60000);
                            seconds = (int) ((millisUntilFinished % 60000) / 1000);
                            String showHours = hours + "";
                            String showMinute = minutes + "";
                            String showSecond = seconds + "";
                            if (hours < 10) {
                                showHours = "0" + showHours;
                            }

                            if (minutes < 10) {
                                showMinute = "0" + showMinute;
                            }

                            if (seconds < 10) {
                                showSecond = "0" + showSecond;
                            }
                            tvTime.setText("距离结束:" + showHours + ":" + showMinute + ":" + showSecond);
                        }

                        @Override
                        public void onFinish() {
                            tvTime.setText("订单已超时");
                        }
                    };
                    timer.start();
                }
            } catch (Exception e) {

            }

        }
    }


    /*
     * 过滤
     * */
    public void onEvent(ContactNotifyEvent event) {
        if (event.getType() == ContactNotifyEvent.Type.invite_received) {
            final String appKey = event.getfromUserAppKey();
            if (appKey.equals(BuildConfig.doctorAppkey)) {
                return;
            } else {
                handler.sendEmptyMessageDelayed(3, 3000);//本页内刷新页面
            }
        }
    }

    private Handler handler = new Handler() {
        @Override
        public void handleMessage(Message msg) {
            super.handleMessage(msg);
            switch (msg.what) {
                case 1:
                    invitationAdapter.getData().addAll(tempInvitationList);
                    invitationAdapter.notifyDataSetChanged();
                    tempInvitationList.clear();
//                    erl.finishRefresh();
                    break;

                case 2: //
                    if (invitationAdapter.getData().size() > 0) {
                        invitationAdapter.getData().clear();
                    }
                    if (tempInvitationList.size() > 0) {
                        EventBus.getDefault().post(new BusEventMessage("0"));
                        erl.setVisibility(View.VISIBLE);
                        rlEmpty.setVisibility(View.GONE);
                    } else {
                        EventBus.getDefault().post(new BusEventMessage("1"));
                        erl.setVisibility(View.GONE);
                        rlEmpty.setVisibility(View.VISIBLE);
                    }
                    invitationAdapter.getData().addAll(tempInvitationList);
                    invitationAdapter.notifyDataSetChanged();
                    tempInvitationList.clear();
//                    erl.finishLoadMore();
                    break;
                case 3://收到邀请 加载第一页数据
                    currentPage = 1;
                    getList();
                    break;

            }
        }
    };


    //查询邀请
    public String checkConsult(int page) {
        String result = "";
        StringBuffer buffer = new StringBuffer();
        String str = BuildConfig.baseUrl + "pay/orderSearch/searchOrder";
        HttpURLConnection connection = null;
        String jwt = (String) SharedPreferenciesUtil.getData("jwt", "");
        int buyerId = Integer.valueOf(SharedPreferenciesUtil.getData("id", "") + "");
        try {
            JSONObject jsonObject = new JSONObject();
            jsonObject.put("orderStatus", 1);
            jsonObject.put("orderStatusAction", 1);
            jsonObject.put("orderKind", 2);
            jsonObject.put("sellerId", doctorId);
            jsonObject.put("pageIndex", page);
            URL url = new URL(str);
            connection = (HttpURLConnection) url.openConnection();
            connection.setRequestMethod("POST");
            connection.setRequestProperty("Charset", "UTF-8");
            connection.setRequestProperty("jwt", jwt);

            connection.setRequestProperty("accept", "application/json");
            connection.setRequestProperty("Connection", "Keep-Alive");
            connection.setRequestProperty("Content-Type", "application/json");
            connection.setDoOutput(true);
            connection.setDoInput(true);
            connection.connect();
            OutputStream outputStream = connection.getOutputStream();
            outputStream.write(jsonObject.toString().getBytes());
            outputStream.flush();
            outputStream.close();

            if (connection.getResponseCode() == 200) {
                BufferedReader reader = new BufferedReader(new InputStreamReader(connection.getInputStream()));
                String str1;
                while ((str1 = reader.readLine()) != null) {
                    buffer.append(str1);
                }
                result = buffer.toString();
            }
            LogUtil.e("测试1", result);
        } catch (Exception e) {
            e.printStackTrace();
            LogUtil.e("异常", e.toString());
        }
        return result;
    }

}



