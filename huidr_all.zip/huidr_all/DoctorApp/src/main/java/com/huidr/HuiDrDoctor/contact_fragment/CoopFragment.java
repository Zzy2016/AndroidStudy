package com.huidr.HuiDrDoctor.contact_fragment;

import android.app.Dialog;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.BitmapShader;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.Shader;
import android.graphics.drawable.BitmapDrawable;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Message;
import androidx.annotation.NonNull;

import android.text.Html;
import android.util.Log;
import android.view.Display;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.ImageView;
import android.widget.TextView;

import com.alibaba.fastjson.JSONObject;
import com.chad.library.adapter.base.BaseQuickAdapter;
import com.chad.library.adapter.base.BaseViewHolder;
import com.google.gson.Gson;
import com.huidr.HuiDrDoctor.activity.WebActivity;
import com.huidr.HuiDrDoctor.activity.main.Consult.utils.PostAndGet;
import com.huidr.HuiDrDoctor.debug.BuildConfig;
import com.huidr.HuiDrDoctor.debug.R;
import com.huidr.HuiDrDoctor.module.home.CooperModel;
import com.huidr.HuiDrDoctor.module.home.SimpleResultModel;
import com.huidr.HuiDrDoctor.util.CircleImageView;
import com.huidr.HuiDrDoctor.util.LogUtil;
import com.huidr.HuiDrDoctor.util.MulityClickUtils;
import com.huidr.HuiDrDoctor.util.ThreadPoolManager;
import com.huidr.lib.commom.base.BaseFragment;
import com.huidr.lib.commom.util.Toast;
import com.scwang.smartrefresh.layout.SmartRefreshLayout;
import com.scwang.smartrefresh.layout.api.RefreshLayout;
import com.scwang.smartrefresh.layout.listener.OnLoadMoreListener;
import com.scwang.smartrefresh.layout.listener.OnRefreshListener;
import com.zyao89.view.zloading.ZLoadingDialog;
import com.zyao89.view.zloading.Z_TYPE;

import java.io.File;
import java.io.FileOutputStream;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import cn.jpush.im.android.api.JMessageClient;
import cn.jpush.im.android.api.content.TextContent;
import cn.jpush.im.android.api.model.Conversation;
import jiguang.chat.activity.ChatActivity;
import jiguang.chat.application.JGApplication;
import jiguang.chat.utils.oss.OssService;


//   getAssistDoctorList hospital/doctorGroup/getAssistDoctorList
//   item 头像、医生姓名、时间、科室、职称、消息的最近一条（默认显示18个字端，第18个字段为省略号）
//
//   列表 协同医生是医生通过左划列表（任意医生列表），点击添加协同后添加到该列表
//
//   2.在关注了某个患者后可以通过左滑点击取消协同进行取消协同，取消后将不再该列表里显示
//
//   操作 1.点击头像跳转医生详情
//
//   2.点击列表进入医生聊天页面
//
//   3.左划列表添加/取消协同医生

public class CoopFragment extends BaseFragment {


    SmartRefreshLayout srlLayout;
    RecyclerView rvListCoop;

    ConstraintLayout clEmptyCoop;
    TextView tvEmptyCoop1, tvEmptyCoop2;

    OssService ossService;

    String path;//协同医生列表
    String pathDelet;//删除协同医生

    int currentPage = 1;
    int totalPage = 1;
    List<CooperModel.RetValueBean> allCooperDoctorList;
    CooperModel cooperModel;
    Gson gson;

    ZLoadingDialog dialog, dialog1;

    String imgPath;
    Matrix matrix;

    Date date = new Date();
    String str = "yyyy-MM-dd";
    SimpleDateFormat simpleDateFormat = new SimpleDateFormat(str);

    @Override
    protected void initData() {

        matrix = new Matrix();
        matrix.setRotate(90);

        dialog = new ZLoadingDialog(getContext());
        dialog.setLoadingBuilder(Z_TYPE.STAR_LOADING)//设置类型
                .setLoadingColor(Color.BLUE)//颜色
                .setHintText("处理中,请稍候...").setHintTextSize(16) // 设置字体大小 dp
                .setHintTextColor(Color.GRAY)  // 设置字体颜色
                .setDurationTime(0.5) // 设置动画时间百分比 - 0.5倍
                .setCanceledOnTouchOutside(false).setCancelable(false);
        dialog1 = new ZLoadingDialog(getContext());
        dialog1.setLoadingBuilder(Z_TYPE.STAR_LOADING)//设置类型
                .setLoadingColor(Color.BLUE)//颜色
                .setHintText("正在加载,请稍候...").setHintTextSize(16) // 设置字体大小 dp
                .setHintTextColor(Color.GRAY)  // 设置字体颜色
                .setDurationTime(0.5) // 设置动画时间百分比 - 0.5倍
                .setCanceledOnTouchOutside(false).setCancelable(false).show();

//        path = "http://192.168.1.180:1189/doctorGroup/getAssistDoctorList";
        path = BuildConfig.baseUrl + "hospital/doctorGroup/getAssistDoctorList";
//        pathDelet = "http://192.168.1.180:1189/doctorGroup/removeAssistDoctor";
        pathDelet = BuildConfig.baseUrl + "hospital/doctorGroup/removeAssistDoctor";
        allCooperDoctorList = new ArrayList<>();
        cooperModel = new CooperModel();
        gson = new Gson();
        ossService = new OssService(getContext());
        imgPath = Environment.getExternalStorageDirectory() + "/" + getContext().getPackageName() + "/img/head/";

        getDataByPage();
    }

    @Override
    protected View setContentView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_coop, container, false);
    }

    @Override
    protected void findView(View parent) {
        srlLayout = parent.findViewById(R.id.srl_layout);
        rvListCoop = parent.findViewById(R.id.rv_list_coop);
        coopAdapter.setNewData(allCooperDoctorList);
        rvListCoop.setAdapter(coopAdapter);
        rvListCoop.setLayoutManager(new LinearLayoutManager(getActivity()));


        srlLayout.setOnRefreshListener(new OnRefreshListener() {
            @Override
            public void onRefresh(@NonNull RefreshLayout refreshLayout) {
                currentPage = 1;
                getDataByPage();
            }
        });

        srlLayout.setOnLoadMoreListener(new OnLoadMoreListener() {
            @Override
            public void onLoadMore(@NonNull RefreshLayout refreshLayout) {
//                if (cooperModel.getRetValue().size() < 20) {
//
//                } else {
//
//                }

                if (cooperModel.getRetValue().size() == 20 && currentPage < totalPage) {
                    currentPage += 1;
                    getDataByPage();
                } else {
                    srlLayout.finishLoadMore();
                    Toast.getInstance(getContext()).show("数据加载全部", 500);
                }
            }
        });


        clEmptyCoop = parent.findViewById(R.id.cl_empty_coop);
        tvEmptyCoop1 = parent.findViewById(R.id.tv_empty_coop1);
        tvEmptyCoop2 = parent.findViewById(R.id.tv_empty_coop2);

        tvEmptyCoop2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                currentPage = 1;
                getDataByPage();
            }
        });

    }


    private BaseQuickAdapter<CooperModel.RetValueBean, BaseViewHolder> coopAdapter = new BaseQuickAdapter<CooperModel.RetValueBean, BaseViewHolder>(R.layout.item_apply_layout) {

        @Override
        protected void convert(final BaseViewHolder helper, final CooperModel.RetValueBean item) {

            ConstraintLayout clItem = helper.getView(R.id.cl_item);

            clItem.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (JMessageClient.getMyInfo() == null) {
                        return;
                    }
                    if (MulityClickUtils.isFastClick()) {
                        addDoctorToRecent(item.getId() + "");
                        Intent intent = new Intent(getActivity(), ChatActivity.class);
                        Bundle bundle = new Bundle();
                        bundle.putString("targetId", item.getId() + "");
                        bundle.putString(JGApplication.CONV_TITLE, item.getUserName());
                        bundle.putString(JGApplication.TARGET_APP_KEY, BuildConfig.appkey);
                        intent.putExtras(bundle);
                        startActivity(intent);
                    }
                }
            });

            CircleImageView imgItemHead = helper.getView(R.id.img_item_head);
            ImageView imgNotice = helper.getView(R.id.img_notice);
            imgNotice.setVisibility(View.GONE);
            TextView tvItemName = helper.getView(R.id.tv_item_name);
            TextView tvItemAge = helper.getView(R.id.tv_item_age);
            TextView tvItemDate = helper.getView(R.id.tv_item_date);
            TextView tvItemMsg = helper.getView(R.id.tv_item_msg);


            Conversation conversation = JMessageClient.getSingleConversation(item.getId() + "");
            if (conversation != null) {
                cn.jpush.im.android.api.model.Message message = conversation.getLatestMessage();
                if (message != null) {
                    switch (message.getContentType()) {
                        case text:
                            tvItemMsg.setText(((TextContent) message.getContent()).getText());
                            break;
                        case voice:
                            tvItemMsg.setText("[语音消息]");
                            break;
                        case image:
                            tvItemMsg.setText("[图片]");
                            break;
                        case file:
                            tvItemMsg.setText("[文件]");
                            break;
                        case location:
                            tvItemMsg.setText("[位置]");
                            break;
                        default:
                            break;
                    }
                    date.setTime(message.getCreateTime());
                    tvItemDate.setText(simpleDateFormat.format(date));
                    tvItemDate.setVisibility(View.VISIBLE);
                } else {
                    tvItemMsg.setText("暂无聊天消息");
                    tvItemDate.setVisibility(View.GONE);
                }


//                控制红点显示
                if (conversation.getUnReadMsgCnt() > 0) {
//                    imgNotice.setVisibility(View.VISIBLE);
                } else {
//                    imgNotice.setVisibility(View.GONE);
                }

            } else {
                tvItemMsg.setText("暂无聊天消息");
                tvItemDate.setVisibility(View.GONE);
            }

            Bitmap defaultBitmap = BitmapFactory.decodeResource(getResources(), R.drawable.nantou);
            BitmapDrawable defaultDrawable = new BitmapDrawable(getResources(), defaultBitmap);
            imgItemHead.setBackgroundDrawable(defaultDrawable);

            if (item.getUserIcon() != null) {
                imgItemHead.setTag(item.getUserIcon());
                File file = new File(imgPath + item.getUserIcon());
                if (file.exists()) {
                    Bitmap bitmap1 = BitmapFactory.decodeFile(file.getAbsolutePath());
                    if (bitmap1 != null) {
                        bitmap1 = getCirleBitmap(bitmap1);
                        BitmapDrawable bitmapDrawable1 = new BitmapDrawable(getContext().getResources(), bitmap1);
                        if (item.getUserIcon().equals(imgItemHead.getTag())) {
                            imgItemHead.setBackgroundDrawable(bitmapDrawable1);
                        }
                    }
                } else {
                    BitmapWorkerTask bitmapWorkerTask = new BitmapWorkerTask(imgItemHead, file);
                    bitmapWorkerTask.execute(item.getUserIcon());
//                    Bitmap bitmap1 = ossService.downImageSyc(item.getUserIcon());
//                    if (bitmap1 != null) {
////                        if (item.getUserIcon().endsWith("img")) {
////                            bitmap1 = Bitmap.createBitmap(bitmap1, 0, 0, bitmap1.getWidth(), bitmap1.getHeight(), matrix, true);
////                        }
//                        imgItemHead.setImageBitmap(bitmap1);
//                        if (!file.getParentFile().exists()) {
//                            file.getParentFile().mkdirs();
//                        }
//                        try {
//                            file.createNewFile();
//                            FileOutputStream fileOutputStream = new FileOutputStream(file);
//                            bitmap1.compress(Bitmap.CompressFormat.PNG, 100, fileOutputStream);
//                            fileOutputStream.flush();
//                        } catch (Exception e) {
//
//                        }
//
//                    } else {
//                        imgItemHead.setBackgroundResource(R.drawable.nantou);
//                    }
                }
            } else {
                imgItemHead.setBackgroundDrawable(defaultDrawable);
            }

            imgItemHead.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (MulityClickUtils.isFastClick()) {
                        Intent intent1 = new Intent(getActivity(), WebActivity.class);
                        Bundle bundle = new Bundle();
                        bundle.putString("url", "personal.html?id=" + item.getId());
                        intent1.putExtras(bundle);
                        startActivity(intent1);
                    }
                }
            });

            tvItemName.setText(item.getUserName());
            tvItemAge.setText(item.getUserTitle() + " (" + item.getHospitalDepartment() + ")");


            TextView tvScrollRight = helper.getView(R.id.tv_scroll_right);
            TextView tvScrollDel = helper.getView(R.id.tv_scroll_del);
            tvScrollDel.setText(Html.fromHtml("<font>删<br>除<font>"));
            tvScrollDel.setVisibility(View.GONE);
            tvScrollRight.setBackgroundResource(R.drawable.shape_atten_gray);
            tvScrollRight.setText(Html.fromHtml("<font>取消<br>协同<font>"));

            tvScrollRight.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
//                    dialog.show();
//                    deleteCooperDoctor(item.getId() + "", helper.getAdapterPosition());
                    showCoopDialog(item.getId() + "", helper.getAdapterPosition());
                }
            });
        }
    };


    /*
     *
     * 图片加载类
     *
     *
     * */
    class BitmapWorkerTask extends AsyncTask<String, Void, BitmapDrawable> {

        private ImageView mImageView;
        private File file;

        public BitmapWorkerTask(ImageView imageView, File filem) {
            mImageView = imageView;
            file = filem;
        }

        @Override
        protected BitmapDrawable doInBackground(String... params) {
            String imageUrl = params[0];
            // 在后台开始下载图片
            Bitmap bitmap = downloadBitmap(imageUrl);
            BitmapDrawable drawable = new BitmapDrawable(bitmap);
//            addBitmapToMemoryCache(imageUrl, drawable);
            return drawable;
        }

        @Override
        protected void onPostExecute(BitmapDrawable drawable) {
            if (mImageView != null && drawable != null) {
                mImageView.setImageDrawable(drawable);
            }
        }

        /**
         * 建立HTTP请求，并获取Bitmap对象。
         *
         * @param imageUrl 图片的URL地址
         * @return 解析后的Bitmap对象
         */
        private Bitmap downloadBitmap(String imageUrl) {
            Log.e("下载图片url", imageUrl);
            Bitmap bitmap = ossService.downHeadImageSyc(imageUrl);

            if (imageUrl.equals(mImageView.getTag()) && bitmap != null) {

                bitmap = getCirleBitmap(bitmap);
                if (!file.getParentFile().exists()) {
                    file.getParentFile().mkdirs();
                }
                try {
                    file.createNewFile();
                    FileOutputStream fileOutputStream = new FileOutputStream(file);
                    bitmap.compress(Bitmap.CompressFormat.PNG, 50, fileOutputStream);
                    fileOutputStream.flush();
                } catch (Exception e) {

                }
                return bitmap;
            } else {
                return null;
            }

        }

    }

    /**
     * 获取圆形Bitmap
     *
     * @param bmp
     * @return
     */
    public Bitmap getCirleBitmap(Bitmap bmp) {
        //获取bmp的宽高 小的一个做为圆的直径r
        int w = bmp.getWidth();
        int h = bmp.getHeight();
        int r = Math.min(w, h);

        //创建一个paint
        Paint paint = new Paint();
        paint.setAntiAlias(true);

        //新创建一个Bitmap对象newBitmap 宽高都是r
        Bitmap newBitmap = Bitmap.createBitmap(r, r, Bitmap.Config.ARGB_8888);

        //创建一个使用newBitmap的Canvas对象
        Canvas canvas = new Canvas(newBitmap);

        //创建一个BitmapShader对象 使用传递过来的原Bitmap对象bmp
        BitmapShader bitmapShader = new BitmapShader(bmp, Shader.TileMode.CLAMP, Shader.TileMode.CLAMP);

        //paint设置shader
        paint.setShader(bitmapShader);

        //canvas画一个圆 使用设置了shader的paint
        canvas.drawCircle(r / 2, r / 2, r / 2, paint);

        return newBitmap;
    }


    @Override
    public void onStop() {
        super.onStop();
        coopAdapter.notifyDataSetChanged();
        if (dialog != null) {
            dialog.dismiss();
        }
    }


    //    添加最近查看医生

    /**
     * 添加医生到最近查看
     *
     * @param id 医生ID
     */
    public void addDoctorToRecent(final String id) {
        ThreadPoolManager.getInstance().execute(new Runnable() {
            @Override
            public void run() {
//                String path = "http://192.168.1.180:1189/doctorGroup/addRecentlyCheckDoctor";
                String path = BuildConfig.baseUrl + "hospital/doctorGroup/addRecentlyCheckDoctor";
                JSONObject jsonObject = new JSONObject();
                jsonObject.put("doctorId", id);
                String result = PostAndGet.doHttpPost(path, jsonObject);
                LogUtil.e("添加最近查看", result);
                if (result.equals("网络异常")) {

                } else {

                }
            }
        });
    }


    //分页获取协同医生 hospital/doctorGroup/getAssistDoctorList

    /**
     * 分页获取协同医生列表
     */
    public void getDataByPage() {
        ThreadPoolManager.getInstance().execute(new Runnable() {
            @Override
            public void run() {
                JSONObject jsonObject = new JSONObject();
                jsonObject.put("pageIndex", currentPage);
                jsonObject.put("pageSize", 20);
                cooperModel = new CooperModel();
                String result = PostAndGet.doHttpPost(path, jsonObject);
                LogUtil.e("协同医生", result);
                if (result.equals("网络异常")) {
                    handler.sendEmptyMessage(3);
                } else {
                    cooperModel = gson.fromJson(result, CooperModel.class);
                    if (cooperModel.getStatus() == 0) {
                        totalPage = cooperModel.getTotalPage();
                        handler.sendEmptyMessage(1);
                    } else {
                        handler.sendEmptyMessage(3);
                    }
                }
            }
        });
    }


    /**
     * 访问删除接口，删除某医生
     *
     * @param deleteId 删除医生的ID
     * @param position 删除医生的position
     */
    public void deleteCooperDoctor(final String deleteId, final int position) {
        ThreadPoolManager.getInstance().execute(new Runnable() {
            @Override
            public void run() {
                JSONObject jsonObject = new JSONObject();
                jsonObject.put("assistUid", deleteId);
                String result = PostAndGet.doHttpPost(pathDelet, jsonObject);
                if (result.equals("网络异常")) {
                    handler.sendEmptyMessage(6);
                } else {
                    SimpleResultModel simpleResultModel = gson.fromJson(result, SimpleResultModel.class);
                    if (simpleResultModel.getStatus() == 0) {
                        if (simpleResultModel.getRetValue() == 0) {
                            Message message = new Message();
                            message.arg1 = position;
                            message.what = 5;
                            handler.sendMessage(message);
                        } else {
                            handler.sendEmptyMessage(6);
                        }
                    } else {
                        handler.sendEmptyMessage(6);
                    }
                }
            }
        });
    }

    /**
     * handler事件
     */
    private Handler handler = new Handler() {
        @Override
        public void handleMessage(Message msg) {
            super.handleMessage(msg);
            switch (msg.what) {
                case 1:  //加载第一页数据或刷新成功
                    coopAdapter.getData().clear();
                    if (cooperModel.getRetValue() == null || cooperModel.getRetValue().size() == 0) {
                        srlLayout.setVisibility(View.GONE);
                        clEmptyCoop.setVisibility(View.VISIBLE);
                        tvEmptyCoop1.setText("暂无协同医生~");
                        tvEmptyCoop2.setText("");
                    } else {
                        srlLayout.setVisibility(View.VISIBLE);
                        clEmptyCoop.setVisibility(View.GONE);
                        coopAdapter.getData().addAll(cooperModel.getRetValue());
                        coopAdapter.notifyDataSetChanged();
                    }
                    srlLayout.finishRefresh();
                    if (dialog1 != null) {
                        dialog1.dismiss();
                    }
                    break;
                case 2:// 加载更多数据
                    coopAdapter.getData().addAll(cooperModel.getRetValue());
                    coopAdapter.notifyDataSetChanged();
                    srlLayout.finishLoadMore();
                    break;
                case 3://加载失败
                    srlLayout.setVisibility(View.GONE);
                    clEmptyCoop.setVisibility(View.VISIBLE);
                    tvEmptyCoop1.setText("网络错误");
                    String tip = "<font color='#248cfa'><u> 立即刷新 <u><font>";
                    tvEmptyCoop2.setText(Html.fromHtml(tip));
                    if (dialog1 != null) {
                        dialog1.dismiss();
                    }
                    break;

                case 5://删除协同医生成功
                    if (dialog != null) {
                        dialog.dismiss();
                    }
                    Toast.getInstance(getActivity()).show("取消协同成功", 500);
//                    coopAdapter.getData().remove(msg.arg1);
//                    coopAdapter.notifyDataSetChanged();
                    coopAdapter.remove(msg.arg1);
                    if (coopAdapter.getData().size() == 0) {
                        srlLayout.setVisibility(View.GONE);
                        clEmptyCoop.setVisibility(View.VISIBLE);
                        tvEmptyCoop1.setText("暂无协同医生~");
                        tvEmptyCoop2.setText("");
                    }
                    break;
                case 6://删除协同医生失败
                    if (dialog != null) {
                        dialog.dismiss();
                    }
                    Toast.getInstance(getActivity()).show("取消协同失败", 500);
                    break;
            }
        }
    };


    /**
     * 显示删除协同对话框
     *
     * @param id       协同医生ID
     * @param position 协同医生位置position
     */
    public void showCoopDialog(final String id, final int position) {

        final Dialog builder = new Dialog(getContext(), R.style.jmui_default_dialog_style);
        //final Dialog builder = new Dialog(this, R.style.jmui_default_dialog_style);
        View view = LayoutInflater.from(getContext()).inflate(R.layout.dialog_content, null);

        TextView tvTitle = view.findViewById(R.id.tv_title);
        TextView tvFooter1 = view.findViewById(R.id.tv_footer1);
        TextView tvFooter2 = view.findViewById(R.id.tv_footer2);

        tvTitle.setText("是否删除协同医生!");


//        取消
        tvFooter1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                builder.cancel();
                coopAdapter.notifyDataSetChanged();
            }
        });
//确定
        tvFooter2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                builder.cancel();
                deleteCooperDoctor(id, position);
            }
        });

        builder.setContentView(view);
        //builder.setCanceledOnTouchOutside(true);
        builder.show();
        Window window = builder.getWindow();
        WindowManager.LayoutParams lp = window.getAttributes();
        WindowManager windowManager = getActivity().getWindowManager();
        Display display = windowManager.getDefaultDisplay();
        lp.width = (int) (display.getWidth() * 0.7);
//        lp.height = (int) (display.getHeight() * 0.1);
        window.setAttributes(lp);
    }


//    SmartRefreshLayout srlLayout;
//    RecyclerView rvListCoop;
//
//    ConstraintLayout clEmptyCoop;
//    TextView tvEmptyCoop1, tvEmptyCoop2;
//
//    OssService ossService;
//
//    String path;//协同医生列表
//    String pathDelet;//删除协同医生
//
//    int currentPage = 1;
//    int totalPage = 1;
//    List<CooperModel.RetValueBean> allCooperDoctorList;
//    CooperModel cooperModel;
//    Gson gson;
//
//    ZLoadingDialog dialog, dialog1;
//
//    String imgPath;
//    Matrix matrix;
//
//    Date date = new Date();
//    String str = "yyyy-MM-dd";
//    SimpleDateFormat simpleDateFormat = new SimpleDateFormat(str);
//
//    @Override
//    protected void initData() {
//
//        matrix = new Matrix();
//        matrix.setRotate(90);
//
//        dialog = new ZLoadingDialog(getContext());
//        dialog.setLoadingBuilder(Z_TYPE.STAR_LOADING)//设置类型
//                .setLoadingColor(Color.BLUE)//颜色
//                .setHintText("处理中,请稍候...").setHintTextSize(16) // 设置字体大小 dp
//                .setHintTextColor(Color.GRAY)  // 设置字体颜色
//                .setDurationTime(0.5) // 设置动画时间百分比 - 0.5倍
//                .setCanceledOnTouchOutside(false).setCancelable(false);
//        dialog1 = new ZLoadingDialog(getContext());
//        dialog1.setLoadingBuilder(Z_TYPE.STAR_LOADING)//设置类型
//                .setLoadingColor(Color.BLUE)//颜色
//                .setHintText("正在加载,请稍候...").setHintTextSize(16) // 设置字体大小 dp
//                .setHintTextColor(Color.GRAY)  // 设置字体颜色
//                .setDurationTime(0.5) // 设置动画时间百分比 - 0.5倍
//                .setCanceledOnTouchOutside(false).setCancelable(false).show();
//
//
//        path = BuildConfig.baseUrl + "hospital/doctorGroup/getAssistDoctorList";
//
//        pathDelet = BuildConfig.baseUrl + "hospital/doctorGroup/removeAssistDoctor";
//        allCooperDoctorList = new ArrayList<>();
//        cooperModel = new CooperModel();
//        gson = new Gson();
//        ossService = new OssService(getContext());
//        imgPath = getContext().getExternalFilesDir("").getAbsolutePath() + "/img/head/";
//
//        getDataByPage();
//    }
//
//    @Override
//    protected View setContentView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
//        return inflater.inflate(R.layout.fragment_coop, container, false);
//    }
//
//    @Override
//    protected void findView(View parent) {
//        srlLayout = parent.findViewById(R.id.srl_layout);
//        rvListCoop = parent.findViewById(R.id.rv_list_coop);
//        coopAdapter.setNewData(allCooperDoctorList);
//        rvListCoop.setAdapter(coopAdapter);
//        rvListCoop.setLayoutManager(new LinearLayoutManager(getActivity()));
//
//
//        srlLayout.setOnRefreshListener(new OnRefreshListener() {
//            @Override
//            public void onRefresh(@NonNull RefreshLayout refreshLayout) {
//                currentPage = 1;
//                getDataByPage();
//            }
//        });
//
//        srlLayout.setOnLoadMoreListener(new OnLoadMoreListener() {
//            @Override
//            public void onLoadMore(@NonNull RefreshLayout refreshLayout) {
////                if (cooperModel.getRetValue().size() < 20) {
////
////                } else {
////
////                }
//
//                if (cooperModel.getRetValue().size() == 20 && currentPage < totalPage) {
//                    currentPage += 1;
//                    getDataByPage();
//                } else {
//                    srlLayout.finishLoadMore();
//                    Toast.getInstance(getContext()).show("数据加载全部", 500);
//                }
//            }
//        });
//
//
//        clEmptyCoop = parent.findViewById(R.id.cl_empty_coop);
//        tvEmptyCoop1 = parent.findViewById(R.id.tv_empty_coop1);
//        tvEmptyCoop2 = parent.findViewById(R.id.tv_empty_coop2);
//
//        tvEmptyCoop2.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                currentPage = 1;
//                getDataByPage();
//            }
//        });
//
//    }
//
//
//    private BaseQuickAdapter<CooperModel.RetValueBean, BaseViewHolder> coopAdapter = new BaseQuickAdapter<CooperModel.RetValueBean, BaseViewHolder>(R.layout.item_apply_layout) {
//
//        @Override
//        protected void convert(final BaseViewHolder helper, final CooperModel.RetValueBean item) {
//
//            ConstraintLayout clItem = helper.getView(R.id.cl_item);
//
//            clItem.setOnClickListener(new View.OnClickListener() {
//                @Override
//                public void onClick(View v) {
//                    if (JMessageClient.getMyInfo() == null) {
//                        return;
//                    }
//                    if (MulityClickUtils.isFastClick()) {
//                        addDoctorToRecent(item.getId() + "");
//                        Intent intent = new Intent(getActivity(), ChatActivity.class);
//                        Bundle bundle = new Bundle();
//                        bundle.putString("targetId", item.getId() + "");
//                        bundle.putString(JGApplication.CONV_TITLE, item.getUserName());
//                        bundle.putString(JGApplication.TARGET_APP_KEY, BuildConfig.appkey);
//                        intent.putExtras(bundle);
//                        startActivity(intent);
//                    }
//                }
//            });
//
//            CircleImageView imgItemHead = helper.getView(R.id.img_item_head);
//            ImageView imgNotice = helper.getView(R.id.img_notice);
//            imgNotice.setVisibility(View.GONE);
//            TextView tvItemName = helper.getView(R.id.tv_item_name);
//            TextView tvItemAge = helper.getView(R.id.tv_item_age);
//            TextView tvItemDate = helper.getView(R.id.tv_item_date);
//            TextView tvItemMsg = helper.getView(R.id.tv_item_msg);
//
//
//            Conversation conversation = JMessageClient.getSingleConversation(item.getId() + "");
//            if (conversation != null) {
//                cn.jpush.im.android.api.model.Message message = conversation.getLatestMessage();
//                if (message != null) {
//                    switch (message.getContentType()) {
//                        case text:
//                            tvItemMsg.setText(((TextContent) message.getContent()).getText());
//                            break;
//                        case voice:
//                            tvItemMsg.setText("[语音消息]");
//                            break;
//                        case image:
//                            tvItemMsg.setText("[图片]");
//                            break;
//                        case file:
//                            tvItemMsg.setText("[文件]");
//                            break;
//                        case location:
//                            tvItemMsg.setText("[位置]");
//                            break;
//                        default:
//                            break;
//                    }
//                    date.setTime(message.getCreateTime());
//                    tvItemDate.setText(simpleDateFormat.format(date));
//                    tvItemDate.setVisibility(View.VISIBLE);
//                } else {
//                    tvItemMsg.setText("暂无聊天消息");
//                    tvItemDate.setVisibility(View.GONE);
//                }
//
//
////                控制红点显示
//                if (conversation.getUnReadMsgCnt() > 0) {
////                    imgNotice.setVisibility(View.VISIBLE);
//                } else {
////                    imgNotice.setVisibility(View.GONE);
//                }
//
//            } else {
//                tvItemMsg.setText("暂无聊天消息");
//                tvItemDate.setVisibility(View.GONE);
//            }
//
//            Bitmap defaultBitmap = BitmapFactory.decodeResource(getResources(), R.drawable.nantou);
//            BitmapDrawable defaultDrawable = new BitmapDrawable(getResources(), defaultBitmap);
//            imgItemHead.setBackgroundDrawable(defaultDrawable);
//
//            if (item.getUserIcon() != null) {
//                imgItemHead.setTag(item.getUserIcon());
//                File file = new File(imgPath + item.getUserIcon());
//                if (file.exists()) {
//                    Bitmap bitmap1 = BitmapFactory.decodeFile(file.getAbsolutePath());
//                    if (bitmap1 != null) {
//                        bitmap1 = getCirleBitmap(bitmap1);
//                        BitmapDrawable bitmapDrawable1 = new BitmapDrawable(getContext().getResources(), bitmap1);
//                        if (item.getUserIcon().equals(imgItemHead.getTag())) {
//                            imgItemHead.setBackgroundDrawable(bitmapDrawable1);
//                        }
//                    }
//                } else {
//                    DownLoadImg.BitmapWorkerTask bitmapWorkerTask = new DownLoadImg.BitmapWorkerTask(imgItemHead, file, ossService);
//                    bitmapWorkerTask.execute(item.getUserIcon());
////                    Bitmap bitmap1 = ossService.downImageSyc(item.getUserIcon());
////                    if (bitmap1 != null) {
//////                        if (item.getUserIcon().endsWith("img")) {
//////                            bitmap1 = Bitmap.createBitmap(bitmap1, 0, 0, bitmap1.getWidth(), bitmap1.getHeight(), matrix, true);
//////                        }
////                        imgItemHead.setImageBitmap(bitmap1);
////                        if (!file.getParentFile().exists()) {
////                            file.getParentFile().mkdirs();
////                        }
////                        try {
////                            file.createNewFile();
////                            FileOutputStream fileOutputStream = new FileOutputStream(file);
////                            bitmap1.compress(Bitmap.CompressFormat.PNG, 100, fileOutputStream);
////                            fileOutputStream.flush();
////                        } catch (Exception e) {
////
////                        }
////
////                    } else {
////                        imgItemHead.setBackgroundResource(R.drawable.nantou);
////                    }
//                }
//            } else {
//                imgItemHead.setBackgroundDrawable(defaultDrawable);
//            }
//
//            imgItemHead.setOnClickListener(new View.OnClickListener() {
//                @Override
//                public void onClick(View v) {
//                    if (MulityClickUtils.isFastClick()) {
//                        Intent intent1 = new Intent(getActivity(), WebActivity.class);
//                        Bundle bundle = new Bundle();
//                        bundle.putString("url", "personal.html?id=" + item.getId());
//                        intent1.putExtras(bundle);
//                        startActivity(intent1);
//                    }
//                }
//            });
//
//            tvItemName.setText(item.getUserName());
//            tvItemAge.setText(item.getUserTitle() + " (" + item.getHospitalDepartment() + ")");
//
//
//            TextView tvScrollRight = helper.getView(R.id.tv_scroll_right);
//            TextView tvScrollDel = helper.getView(R.id.tv_scroll_del);
//            tvScrollDel.setText(Html.fromHtml("<font>删<br>除<font>"));
//            tvScrollDel.setVisibility(View.GONE);
//            tvScrollRight.setBackgroundResource(R.drawable.shape_atten_gray);
//            tvScrollRight.setText(Html.fromHtml("<font>取消<br>协同<font>"));
//
//            tvScrollRight.setOnClickListener(new View.OnClickListener() {
//                @Override
//                public void onClick(View v) {
////                    dialog.show();
////                    deleteCooperDoctor(item.getId() + "", helper.getAdapterPosition());
//                    showCoopDialog(item.getId() + "", helper.getAdapterPosition());
//                }
//            });
//        }
//    };
//
//
//    @Override
//    public void onStop() {
//        super.onStop();
//        coopAdapter.notifyDataSetChanged();
//        if (dialog != null) {
//            dialog.dismiss();
//        }
//    }
//
//
//    //    添加最近查看医生
//
//    /**
//     * 添加医生到最近查看
//     *
//     * @param id 医生ID
//     */
//    public void addDoctorToRecent(final String id) {
//        ThreadPoolManager.getInstance().execute(new Runnable() {
//            @Override
//            public void run() {
//                String path = BuildConfig.baseUrl + "hospital/doctorGroup/addRecentlyCheckDoctor";
//                JSONObject jsonObject = new JSONObject();
//                jsonObject.put("doctorId", id);
//                String result = PostAndGet.doHttpPost(path, jsonObject);
//                LogUtil.e("添加最近查看", result);
//                if (result.equals("网络异常")) {
//
//                } else {
//
//                }
//            }
//        });
//    }
//
//
//    //分页获取协同医生 hospital/doctorGroup/getAssistDoctorList
//
//    /**
//     * 分页获取协同医生列表
//     */
//    public void getDataByPage() {
//        ThreadPoolManager.getInstance().execute(new Runnable() {
//            @Override
//            public void run() {
//                JSONObject jsonObject = new JSONObject();
//                jsonObject.put("pageIndex", currentPage);
//                jsonObject.put("pageSize", 20);
//                cooperModel = new CooperModel();
//                String result = PostAndGet.doHttpPost(path, jsonObject);
//                LogUtil.e("协同医生", result);
//                if (result.equals("网络异常")) {
//                    handler.sendEmptyMessage(3);
//                } else {
//                    cooperModel = gson.fromJson(result, CooperModel.class);
//                    if (cooperModel.getStatus() == 0) {
//                        totalPage = cooperModel.getTotalPage();
//                        handler.sendEmptyMessage(1);
//                    } else {
//                        handler.sendEmptyMessage(3);
//                    }
//                }
//            }
//        });
//    }
//
//
//    /**
//     * 访问删除接口，删除某医生
//     *
//     * @param deleteId 删除医生的ID
//     * @param position 删除医生的position
//     */
//    public void deleteCooperDoctor(final String deleteId, final int position) {
//        ThreadPoolManager.getInstance().execute(new Runnable() {
//            @Override
//            public void run() {
//                JSONObject jsonObject = new JSONObject();
//                jsonObject.put("assistUid", deleteId);
//                String result = PostAndGet.doHttpPost(pathDelet, jsonObject);
//                if (result.equals("网络异常")) {
//                    handler.sendEmptyMessage(6);
//                } else {
//                    SimpleResultModel simpleResultModel = gson.fromJson(result, SimpleResultModel.class);
//                    if (simpleResultModel.getStatus() == 0) {
//                        if (simpleResultModel.getRetValue() == 0) {
//                            Message message = new Message();
//                            message.arg1 = position;
//                            message.what = 5;
//                            handler.sendMessage(message);
//                        } else {
//                            handler.sendEmptyMessage(6);
//                        }
//                    } else {
//                        handler.sendEmptyMessage(6);
//                    }
//                }
//            }
//        });
//    }
//
//    /**
//     * handler事件
//     */
//    private Handler handler = new Handler() {
//        @Override
//        public void handleMessage(Message msg) {
//            super.handleMessage(msg);
//            switch (msg.what) {
//                case 1:  //加载第一页数据或刷新成功
//                    coopAdapter.getData().clear();
//                    if (cooperModel.getRetValue() == null || cooperModel.getRetValue().size() == 0) {
//                        srlLayout.setVisibility(View.GONE);
//                        clEmptyCoop.setVisibility(View.VISIBLE);
//                        tvEmptyCoop1.setText("暂无协同医生~");
//                        tvEmptyCoop2.setText("");
//                    } else {
//                        srlLayout.setVisibility(View.VISIBLE);
//                        clEmptyCoop.setVisibility(View.GONE);
//                        coopAdapter.getData().addAll(cooperModel.getRetValue());
//                        coopAdapter.notifyDataSetChanged();
//                    }
//                    srlLayout.finishRefresh();
//                    if (dialog1 != null) {
//
//                        new Handler().postDelayed(new Runnable() {
//                            @Override
//                            public void run() {
//                                dialog1.dismiss();
//                            }
//                        }, 500);
//                    }
//                    break;
//                case 2:// 加载更多数据
//                    coopAdapter.getData().addAll(cooperModel.getRetValue());
//                    coopAdapter.notifyDataSetChanged();
//                    srlLayout.finishLoadMore();
//                    break;
//                case 3://加载失败
//                    srlLayout.setVisibility(View.GONE);
//                    clEmptyCoop.setVisibility(View.VISIBLE);
//                    tvEmptyCoop1.setText("网络错误");
//                    String tip = "<font color='#248cfa'><u> 立即刷新 <u><font>";
//                    tvEmptyCoop2.setText(Html.fromHtml(tip));
//                    if (dialog1 != null) {
//                        new Handler().postDelayed(new Runnable() {
//                            @Override
//                            public void run() {
//                                dialog1.dismiss();
//                            }
//                        }, 500);
//                    }
//                    break;
//
//                case 5://删除协同医生成功
//                    if (dialog != null) {
//                        dialog.dismiss();
//                    }
//                    Toast.getInstance(getActivity()).show("取消协同成功", 500);
////                    coopAdapter.getData().remove(msg.arg1);
////                    coopAdapter.notifyDataSetChanged();
//                    coopAdapter.remove(msg.arg1);
//                    if (coopAdapter.getData().size() == 0) {
//                        srlLayout.setVisibility(View.GONE);
//                        clEmptyCoop.setVisibility(View.VISIBLE);
//                        tvEmptyCoop1.setText("暂无协同医生~");
//                        tvEmptyCoop2.setText("");
//                    }
//                    break;
//                case 6://删除协同医生失败
//                    if (dialog != null) {
//                        dialog.dismiss();
//                    }
//                    Toast.getInstance(getActivity()).show("取消协同失败", 500);
//                    break;
//            }
//        }
//    };
//
//
//    /**
//     * 显示删除协同对话框
//     *
//     * @param id       协同医生ID
//     * @param position 协同医生位置position
//     */
//    public void showCoopDialog(final String id, final int position) {
//
//        final Dialog builder = new Dialog(getContext(), R.style.jmui_default_dialog_style);
//        //final Dialog builder = new Dialog(this, R.style.jmui_default_dialog_style);
//        View view = LayoutInflater.from(getContext()).inflate(R.layout.dialog_content, null);
//
//        TextView tvTitle = view.findViewById(R.id.tv_title);
//        TextView tvFooter1 = view.findViewById(R.id.tv_footer1);
//        TextView tvFooter2 = view.findViewById(R.id.tv_footer2);
//
//        tvTitle.setText("是否删除协同医生!");
//
//
////        取消
//        tvFooter1.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                builder.cancel();
//                coopAdapter.notifyDataSetChanged();
//            }
//        });
////确定
//        tvFooter2.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//
//                builder.cancel();
//                deleteCooperDoctor(id, position);
//            }
//        });
//
//        builder.setContentView(view);
//        //builder.setCanceledOnTouchOutside(true);
//        builder.show();
//        Window window = builder.getWindow();
//        WindowManager.LayoutParams lp = window.getAttributes();
//        WindowManager windowManager = getActivity().getWindowManager();
//        Display display = windowManager.getDefaultDisplay();
//        lp.width = (int) (display.getWidth() * 0.7);
////        lp.height = (int) (display.getHeight() * 0.1);
//        window.setAttributes(lp);
//    }

}
