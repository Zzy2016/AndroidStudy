package com.huidr.HuiDrDoctor.activity.main.Consult.utils;

import com.huidr.HuiDrDoctor.activity.main.Consult.utils.UserStateBean;

import okhttp3.ResponseBody;
import retrofit2.Call;
import retrofit2.http.GET;
import retrofit2.http.Path;

public interface Api {

    /*获取好友在线信息*/
    @GET("/v1/users/{username}/userstat")
    Call<UserStateBean> isFriendState(
            @Path("username") String username);



    /*获取用户资料*/
    @GET("/v1/users/{username}")
    Call<ResponseBody> userInfo(
            @Path("username") String username);
}
