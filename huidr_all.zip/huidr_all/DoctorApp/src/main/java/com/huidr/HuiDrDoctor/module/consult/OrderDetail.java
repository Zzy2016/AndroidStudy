package com.huidr.HuiDrDoctor.module.consult;

import java.util.List;

/*
* 图文咨询 单条咨询详情
*
* */
public class OrderDetail {

    /**
     * doctorHeadImg : system/doctor/8177-72-12160.jpg
     * doctorHospital : 复旦大学附属中山医院
     * doctorId : 100140
     * doctorName : 测试骨科1
     * hospitalDepartment : 骨科
     * needHelp : 测试测试测试测试23741测试
     * patientHospital : 复旦大学附属中山医院
     * patientId : 69889
     * patientName : 钟慧娟
     * pics : []
     * position : 副主任医师
     */

    private String doctorHeadImg;
    private String doctorHospital;
    private int doctorId;
    private String doctorName;
    private String hospitalDepartment;
    private String needHelp;
    private String patientHospital;
    private int patientId;
    private String patientName;
    private String position;
    private List<?> pics;

    public String getDoctorHeadImg() {
        return doctorHeadImg;
    }

    public void setDoctorHeadImg(String doctorHeadImg) {
        this.doctorHeadImg = doctorHeadImg;
    }

    public String getDoctorHospital() {
        return doctorHospital;
    }

    public void setDoctorHospital(String doctorHospital) {
        this.doctorHospital = doctorHospital;
    }

    public int getDoctorId() {
        return doctorId;
    }

    public void setDoctorId(int doctorId) {
        this.doctorId = doctorId;
    }

    public String getDoctorName() {
        return doctorName;
    }

    public void setDoctorName(String doctorName) {
        this.doctorName = doctorName;
    }

    public String getHospitalDepartment() {
        return hospitalDepartment;
    }

    public void setHospitalDepartment(String hospitalDepartment) {
        this.hospitalDepartment = hospitalDepartment;
    }

    public String getNeedHelp() {
        return needHelp;
    }

    public void setNeedHelp(String needHelp) {
        this.needHelp = needHelp;
    }

    public String getPatientHospital() {
        return patientHospital;
    }

    public void setPatientHospital(String patientHospital) {
        this.patientHospital = patientHospital;
    }

    public int getPatientId() {
        return patientId;
    }

    public void setPatientId(int patientId) {
        this.patientId = patientId;
    }

    public String getPatientName() {
        return patientName;
    }

    public void setPatientName(String patientName) {
        this.patientName = patientName;
    }

    public String getPosition() {
        return position;
    }

    public void setPosition(String position) {
        this.position = position;
    }

    public List<?> getPics() {
        return pics;
    }

    public void setPics(List<?> pics) {
        this.pics = pics;
    }

    @Override
    public String toString() {
        return "OrderDetail{" + "doctorHeadImg='" + doctorHeadImg + '\'' + ", doctorHospital='" + doctorHospital + '\'' + ", doctorId=" + doctorId + ", doctorName='" + doctorName + '\'' + ", hospitalDepartment='" + hospitalDepartment + '\'' + ", needHelp='" + needHelp + '\'' + ", patientHospital='" + patientHospital + '\'' + ", patientId=" + patientId + ", patientName='" + patientName + '\'' + ", position='" + position + '\'' + ", pics=" + pics + '}';
    }
}
