package com.huidr.HuiDrDoctor;

import android.app.ActivityManager;
import android.content.Context;
import android.graphics.Point;
import android.os.Build;

import android.util.Log;
import android.view.WindowManager;
import android.webkit.WebView;
import android.widget.Toast;

import com.activeandroid.ActiveAndroid;
import com.alibaba.sdk.android.feedback.impl.FeedbackAPI;
import com.alibaba.sdk.android.feedback.util.ErrorCode;
import com.alibaba.sdk.android.feedback.util.FeedbackErrorCallback;
import com.alibaba.sdk.android.man.MANService;
import com.alibaba.sdk.android.man.MANServiceProvider;
import com.huidr.HuiDrDoctor.debug.BuildConfig;
import com.huidr.HuiDrDoctor.util.CrashUtil;
import com.huidr.HuiDrDoctor.util.ScreenAdaptation;
import com.huidr.lib.commom.base.BaseMainApplication;
import com.huidr.lib.commom.util.HbuildUtil;
import com.tendcloud.tenddata.TCAgent;
import com.umeng.analytics.AnalyticsConfig;

import org.litepal.LitePal;

import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.concurrent.Callable;

import androidx.annotation.RequiresApi;
import androidx.multidex.MultiDex;
import cn.jpush.im.android.api.JMessageClient;
import jiguang.chat.entity.NotificationClickEventReceiver;
import jiguang.chat.pickerimage.utils.ScreenUtil;
import jiguang.chat.pickerimage.utils.StorageUtil;
import jiguang.chat.utils.SharePreferenceManager;
import jiguang.chat.utils.oss.Constants;
import jiguang.chat.utils.oss.SharedPreferenciesUtil;

public class MainApplication extends BaseMainApplication {
    private static final String JCHAT_CONFIGS = "JChat_configs";

    public static long id = 0;

    @RequiresApi(api = Build.VERSION_CODES.P)
    @Override
    public void onCreate() {

        super.onCreate();


        closeAndroidPDialog();
        disableAPIDialog();

        LitePal.initialize(this);
        //im
        StorageUtil.init(getApplicationContext(), null);
        JMessageClient.init(this, true);
        JMessageClient.setDebugMode(true);
        SharePreferenceManager.init(getApplicationContext(), JCHAT_CONFIGS);


        //设置Notification的模式
        JMessageClient.setNotificationFlag(JMessageClient.FLAG_NOTIFY_WITH_SOUND | JMessageClient.FLAG_NOTIFY_WITH_LED | JMessageClient.FLAG_NOTIFY_WITH_VIBRATE);
        //注册Notification点击的接收器
        new NotificationClickEventReceiver(getApplicationContext());

        ScreenUtil.initital(getApplicationContext());
        SharedPreferenciesUtil.getInstance(getApplicationContext(), Constants.SharedAccountConfig.SP_NAME);

        CrashUtil crashUtil = CrashUtil.getInstance();
        crashUtil.init(this);

        //复制文件
        HbuildUtil.copyApps(getApplicationContext(), BuildConfig.Version);
        ActiveAndroid.initialize(this);
        //initManService();
        initAliFeedBack();


        //talkingdata 统计
        String channelName = "huiyi医生";
        channelName = AnalyticsConfig.getChannel(this);
        TCAgent.LOG_ON = true;
        TCAgent.init(this, "4F3E926E06C14D5C9FF438E871B06C10", channelName);
        TCAgent.setReportUncaughtExceptions(true);


//        webviewSetPath(getApplicationContext());
//        WebView.setWebContentsDebuggingEnabled(true);
//        new ScreenAdaptation(this,720,1280).register();


    }


//    @RequiresApi(api = 28)
//    public void webviewSetPath(Context context) {
//        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
//            String processName = getProcessName(context);
//            if (!"com.huidr.HuiDrDoctor".equals(processName)) {//判断不等于默认进程名称
//                WebView.setDataDirectorySuffix(processName);
//                WebView.setWebContentsDebuggingEnabled(true);
//            }
//
//        }
//    }
//
//
//    public String getProcessName(Context context) {
//        if (context == null) return null;
//        ActivityManager manager = (ActivityManager) context.getSystemService(Context.ACTIVITY_SERVICE);
//        for (ActivityManager.RunningAppProcessInfo processInfo : manager.getRunningAppProcesses()) {
//            if (processInfo.pid == android.os.Process.myPid()) {
//                return processInfo.processName;
//            }
//        }
//        return null;
//    }

    private void initManService() {
        /**
         * 初始化Mobile Analytics服务
         */
        // 获取MAN服务
        MANService manService = MANServiceProvider.getService();
        // 打开调试日志
        manService.getMANAnalytics().turnOnDebug();
        // MAN初始化方法之一，通过插件接入后直接在下发json中获取appKey和appSecret初始化
        manService.getMANAnalytics().init(this, getApplicationContext());
        // 若需要关闭 SDK 的自动异常捕获功能可进行如下操作,详见文档5.4
        //manService.getMANAnalytics().turnOffCrashReporter();
        // 通过此接口关闭页面自动打点功能，详见文档4.2
        manService.getMANAnalytics().turnOffAutoPageTrack();
    }


    private void initAliFeedBack() {
        /**
         * 添加自定义的error handler
         */
        FeedbackAPI.addErrorCallback(new FeedbackErrorCallback() {
            @Override
            public void onError(Context context, String errorMessage, ErrorCode code) {
                Toast.makeText(context, "ErrMsg is: " + errorMessage, Toast.LENGTH_SHORT).show();
            }
        });
        FeedbackAPI.addLeaveCallback(new Callable() {
            @Override
            public Object call() {
                Log.d("DemoApplication", "custom leave callback");
                return null;
            }
        });
        /**
         * 建议放在此处做初始化
         */
        FeedbackAPI.init(this);
        /**
         * 以下是设置UI
         */
        //沉浸式任务栏，控制台设置为true之后此方法才能生效
        FeedbackAPI.setTranslucent(true);
    }

    @Override
    public void onTerminate() {
        super.onTerminate();
        ActiveAndroid.dispose();
        Log.e("onterminate", "onterminate");
    }

    //去除API弹窗
    private void closeAndroidPDialog() {
        try {
            Class aClass = Class.forName("android.content.pm.PackageParser$Package");
            Constructor declaredConstructor = aClass.getDeclaredConstructor(String.class);
            declaredConstructor.setAccessible(true);
        } catch (Exception e) {
            e.printStackTrace();
        }
        try {
            Class cls = Class.forName("android.app.ActivityThread");
            Method declaredMethod = cls.getDeclaredMethod("currentActivityThread");
            declaredMethod.setAccessible(true);
            Object activityThread = declaredMethod.invoke(null);
            Field mHiddenApiWarningShown = cls.getDeclaredField("mHiddenApiWarningShown");
            mHiddenApiWarningShown.setAccessible(true);
            mHiddenApiWarningShown.setBoolean(activityThread, true);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    //分包
    @Override
    protected void attachBaseContext(Context context) {
        super.attachBaseContext(context);
        MultiDex.install(context);
    }

    private void disableAPIDialog() {
        if (Build.VERSION.SDK_INT < 28) return;
        try {
            Class clazz = Class.forName("android.app.ActivityThread");
            Method currentActivityThread = clazz.getDeclaredMethod("currentActivityThread");
            currentActivityThread.setAccessible(true);
            Object activityThread = currentActivityThread.invoke(null);
            Field mHiddenApiWarningShown = clazz.getDeclaredField("mHiddenApiWarningShown");
            mHiddenApiWarningShown.setAccessible(true);
            mHiddenApiWarningShown.setBoolean(activityThread, true);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }


}
