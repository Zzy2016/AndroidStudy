package com.huidr.HuiDrDoctor.module.home;

import java.util.List;

/**
 * @author: Administrator
 * @date: 2019-11-28
 */
public class NewConsultOrderList {


    /**
     * status : 0
     * page : 1
     * totalPage : 12
     * retValue : {"isOpen":1,"orderInfoList":[{"orderId":"2019120215370311706600","orderStatusAction":13,"orderStatus":102,"orderTopic":"图文咨询","orderDetails":"{\"doctorHeadImg\":\"/storage/emulated/0/com.huidr.HuiDrDoctor.debug/img/head//storage/emulated/0/com.huidr.HuiDrDoctor.debug/img/head/article/uploadImg/eeb23b49-534c-4d84-84d8-8eba04b1bd97.jpg\",\"doctorHospital\":\"复旦大学附属中山医院\",\"doctorId\":100227,\"doctorName\":\"欧阳云开\",\"hospitalDepartment\":\"普外科\",\"needHelp\":\"测试测试测试测试测试\",\"patientId\":85458,\"patientName\":\"患者段\",\"pics\":[],\"position\":\"主治医师 \"}","orderKind":2,"payOrderId":"2019120215370311706600","payPlatformKind":3,"createTime":"2019-12-02 15:37:04","buyerId":141162,"sellerId":100227,"buyerRelationId":85458,"addressInfo":{},"orderPrice":1000,"couponPrice":0,"integralPrice":0,"payTime":"2019-12-02 15:37:08","freight":0,"age":9,"userIcon":"141162/patient/1575949092400733.png","sex":1},{"orderId":"2019111318253262274909","orderStatusAction":12,"orderStatus":3,"orderTopic":"图文咨询","orderDetails":"{\"doctorHeadImg\":\"article/uploadImg/eeb23b49-534c-4d84-84d8-8eba04b1bd97.jpg\",\"doctorHospital\":\"复旦大学附属中山医院\",\"doctorId\":100227,\"doctorName\":\"欧阳云开\",\"hospitalDepartment\":\"普外科\",\"needHelp\":\"测试肝肿瘤外科医生怎么说呢，，，，\",\"patientId\":85458,\"patientName\":\"患者段\",\"pics\":[],\"position\":\"主治医师 \"}","orderKind":2,"payOrderId":"2019111318253262274909","payPlatformKind":3,"createTime":"2019-11-13 18:25:33","buyerId":141162,"sellerId":100227,"buyerRelationId":85458,"addressInfo":{},"orderPrice":1000,"couponPrice":0,"integralPrice":0,"payTime":"2019-11-13 18:25:36","freight":0,"age":9,"userIcon":"141162/patient/1575949092400733.png","sex":1},{"orderId":"2019111318235871934755","orderStatusAction":5,"orderStatus":3,"orderTopic":"图文咨询","orderDetails":"{\"doctorHeadImg\":\"article/uploadImg/eeb23b49-534c-4d84-84d8-8eba04b1bd97.jpg\",\"doctorHospital\":\"复旦大学附属中山医院\",\"doctorId\":100227,\"doctorName\":\"欧阳云开\",\"hospitalDepartment\":\"普外科\",\"needHelp\":\"1334466455999764664646646544654\",\"patientId\":85458,\"patientName\":\"患者段\",\"pics\":[],\"position\":\"主治医师 \"}","orderKind":2,"payOrderId":"2019111318235871934755","payPlatformKind":3,"createTime":"2019-11-13 18:23:58","buyerId":141162,"sellerId":100227,"buyerRelationId":85458,"addressInfo":{},"orderPrice":1000,"couponPrice":0,"integralPrice":0,"payTime":"2019-11-13 18:24:02","freight":0,"age":9,"userIcon":"141162/patient/1575949092400733.png","sex":1,"suggestion":"1把"},{"orderId":"2019111318181085546957","orderStatusAction":4,"orderStatus":102,"orderTopic":"图文咨询","orderDetails":"{\"doctorHeadImg\":\"article/uploadImg/eeb23b49-534c-4d84-84d8-8eba04b1bd97.jpg\",\"doctorHospital\":\"复旦大学附属中山医院\",\"doctorId\":100227,\"doctorName\":\"欧阳云开\",\"hospitalDepartment\":\"普外科\",\"needHelp\":\"丁经理里login匿名ing敏敏进\",\"patientId\":85458,\"patientName\":\"患者段\",\"pics\":[],\"position\":\"主治医师 \"}","orderKind":2,"payOrderId":"2019111318181085546957","payPlatformKind":3,"createTime":"2019-11-13 18:18:10","buyerId":141162,"sellerId":100227,"buyerRelationId":85458,"addressInfo":{},"orderPrice":1000,"couponPrice":0,"integralPrice":0,"payTime":"2019-11-13 18:18:14","freight":0,"age":9,"userIcon":"141162/patient/1575949092400733.png","sex":1},{"orderId":"2019110811465869622061","orderStatusAction":4,"orderStatus":102,"orderTopic":"图文咨询","orderDetails":"{\"doctorHeadImg\":\"article/uploadImg/eeb23b49-534c-4d84-84d8-8eba04b1bd97.jpg\",\"doctorHospital\":\"复旦大学附属中山医院\",\"doctorId\":100227,\"doctorName\":\"欧阳云开\",\"hospitalDepartment\":\"普外科\",\"needHelp\":\"不不敌我热外婆和我哦给我弟利息呢你现在佩服我\",\"patientId\":85844,\"patientName\":\"伊泽瑞尔\",\"pics\":[\"141209/patient/15731848170000.jpg\"],\"position\":\"主治医师 \"}","orderKind":2,"payOrderId":"2019110811465869622061","payPlatformKind":3,"createTime":"2019-11-08 11:46:59","buyerId":141209,"sellerId":100227,"buyerRelationId":85844,"addressInfo":{},"orderPrice":1000,"couponPrice":0,"integralPrice":0,"payTime":"2019-11-08 11:47:02","freight":0,"age":23,"userIcon":"141209/patient/1575949225246281.png","sex":1},{"orderId":"2019110811423685560207","orderStatusAction":5,"orderStatus":3,"orderTopic":"图文咨询","orderDetails":"{\"doctorHeadImg\":\"article/uploadImg/eeb23b49-534c-4d84-84d8-8eba04b1bd97.jpg\",\"doctorHospital\":\"复旦大学附属中山医院\",\"doctorId\":100227,\"doctorName\":\"欧阳云开\",\"hospitalDepartment\":\"普外科\",\"needHelp\":\"大明湖畔大明湖畔大明湖畔的的的的的的的的的的的\",\"patientId\":85844,\"patientName\":\"伊泽瑞尔\",\"pics\":[\"141209/patient/157318455600031.jpg\"],\"position\":\"主治医师 \"}","orderKind":2,"payOrderId":"2019110811423685560207","payPlatformKind":3,"createTime":"2019-11-08 11:42:37","buyerId":141209,"sellerId":100227,"buyerRelationId":85844,"addressInfo":{},"orderPrice":1000,"couponPrice":0,"integralPrice":0,"payTime":"2019-11-08 11:42:40","freight":0,"age":23,"userIcon":"141209/patient/1575949225246281.png","sex":1,"suggestion":"结束对话干嘛"},{"orderId":"2019110810514194745087","orderStatusAction":12,"orderStatus":3,"orderTopic":"图文咨询","orderDetails":"{\"doctorHeadImg\":\"article/uploadImg/eeb23b49-534c-4d84-84d8-8eba04b1bd97.jpg\",\"doctorHospital\":\"复旦大学附属中山医院\",\"doctorId\":100227,\"doctorName\":\"欧阳云开\",\"hospitalDepartment\":\"普外科\",\"needHelp\":\"东方国际结婚的大大方方嘎嘎嘎\",\"patientId\":85951,\"patientName\":\"fgh \",\"pics\":[],\"position\":\"主治医师 \"}","orderKind":2,"payOrderId":"2019110810514194745087","payPlatformKind":3,"createTime":"2019-11-08 10:51:41","buyerId":100137,"sellerId":100227,"buyerRelationId":85951,"addressInfo":{},"orderPrice":1000,"couponPrice":0,"integralPrice":0,"payTime":"2019-11-08 10:51:45","freight":0,"age":34,"userIcon":"100137/patient/1574059352187315.png","sex":1},{"orderId":"2019110810384414272406","orderStatusAction":12,"orderStatus":3,"orderTopic":"图文咨询","orderDetails":"{\"doctorHeadImg\":\"article/uploadImg/eeb23b49-534c-4d84-84d8-8eba04b1bd97.jpg\",\"doctorHospital\":\"复旦大学附属中山医院\",\"doctorId\":100227,\"doctorName\":\"欧阳云开\",\"hospitalDepartment\":\"普外科\",\"needHelp\":\"不是新股一对一呢银色提着心情亏咩\",\"patientId\":85845,\"patientName\":\"徐力\",\"pics\":[\"141214/patient/157318072300094.jpg\",\"141214/patient/15731807230003.jpg\",\"141214/patient/157318072300059.jpg\"],\"position\":\"主治医师 \"}","orderKind":2,"payOrderId":"2019110810384414272406","payPlatformKind":3,"createTime":"2019-11-08 10:38:45","buyerId":141214,"sellerId":100227,"buyerRelationId":85845,"addressInfo":{},"orderPrice":1000,"couponPrice":0,"integralPrice":0,"payTime":"2019-11-08 10:38:49","freight":0,"age":41,"sex":1,"suggestion":"到底反反复复"},{"orderId":"2019110510363612158553","orderStatusAction":13,"orderStatus":102,"orderTopic":"图文咨询","orderDetails":"{\"doctorHeadImg\":\"article/uploadImg/eeb23b49-534c-4d84-84d8-8eba04b1bd97.jpg\",\"doctorHospital\":\"复旦大学附属中山医院\",\"doctorId\":100227,\"doctorName\":\"欧阳云开\",\"hospitalDepartment\":\"普外科\",\"needHelp\":\"回来了叽叽咕咕哈哈哈哈哈哈哈哈\",\"patientId\":85840,\"patientName\":\"亚索\",\"pics\":[],\"position\":\"主治医师 \"}","orderKind":2,"payOrderId":"2019110510363612158553","payPlatformKind":3,"createTime":"2019-11-05 10:36:37","buyerId":141207,"sellerId":100227,"buyerRelationId":85840,"addressInfo":{},"orderPrice":1000,"couponPrice":0,"integralPrice":0,"payTime":"2019-11-05 10:36:41","freight":0,"age":44,"sex":1},{"orderId":"20191101181733106134547","orderStatusAction":13,"orderStatus":102,"orderTopic":"图文咨询","orderDetails":"{\"doctorHeadImg\":\"article/uploadImg/eeb23b49-534c-4d84-84d8-8eba04b1bd97.jpg\",\"doctorHospital\":\"复旦大学附属中山医院\",\"doctorId\":100227,\"doctorName\":\"欧阳云开\",\"hospitalDepartment\":\"普外科\",\"needHelp\":\"还是激动就快点快点空间设计奖\",\"patientId\":85844,\"patientName\":\"伊泽瑞尔\",\"pics\":[\"141209/patient/157260345300038.PNG\",\"141209/patient/157260345300050.PNG\",\"141209/patient/157260345300034.PNG\",\"141209/patient/157260345300010.PNG\",\"141209/patient/157260345300048.PNG\",\"141209/patient/157260345300037.PNG\",\"141209/patient/157260345300023.PNG\",\"141209/patient/157260345300074.jpg\",\"141209/patient/157260345300081.jpg\"],\"position\":\"主治医师 \"}","orderKind":2,"payOrderId":"20191101181733106134547","payPlatformKind":3,"createTime":"2019-11-01 18:17:34","buyerId":141209,"sellerId":100227,"buyerRelationId":85844,"addressInfo":{},"orderPrice":1000,"couponPrice":0,"integralPrice":0,"payTime":"2019-11-01 18:18:03","freight":0,"age":23,"userIcon":"141209/patient/1575949225246281.png","sex":1}]}
     */

    private int status;
    private int page;
    private int totalPage;
    private RetValueBean retValue;

    public int getStatus() {
        return status;
    }

    public void setStatus(int status) {
        this.status = status;
    }

    public int getPage() {
        return page;
    }

    public void setPage(int page) {
        this.page = page;
    }

    public int getTotalPage() {
        return totalPage;
    }

    public void setTotalPage(int totalPage) {
        this.totalPage = totalPage;
    }

    public RetValueBean getRetValue() {
        return retValue;
    }

    public void setRetValue(RetValueBean retValue) {
        this.retValue = retValue;
    }

    public static class RetValueBean {
        /**
         * isOpen : 1
         * orderInfoList : [{"orderId":"2019120215370311706600","orderStatusAction":13,"orderStatus":102,"orderTopic":"图文咨询","orderDetails":"{\"doctorHeadImg\":\"/storage/emulated/0/com.huidr.HuiDrDoctor.debug/img/head//storage/emulated/0/com.huidr.HuiDrDoctor.debug/img/head/article/uploadImg/eeb23b49-534c-4d84-84d8-8eba04b1bd97.jpg\",\"doctorHospital\":\"复旦大学附属中山医院\",\"doctorId\":100227,\"doctorName\":\"欧阳云开\",\"hospitalDepartment\":\"普外科\",\"needHelp\":\"测试测试测试测试测试\",\"patientId\":85458,\"patientName\":\"患者段\",\"pics\":[],\"position\":\"主治医师 \"}","orderKind":2,"payOrderId":"2019120215370311706600","payPlatformKind":3,"createTime":"2019-12-02 15:37:04","buyerId":141162,"sellerId":100227,"buyerRelationId":85458,"addressInfo":{},"orderPrice":1000,"couponPrice":0,"integralPrice":0,"payTime":"2019-12-02 15:37:08","freight":0,"age":9,"userIcon":"141162/patient/1575949092400733.png","sex":1},{"orderId":"2019111318253262274909","orderStatusAction":12,"orderStatus":3,"orderTopic":"图文咨询","orderDetails":"{\"doctorHeadImg\":\"article/uploadImg/eeb23b49-534c-4d84-84d8-8eba04b1bd97.jpg\",\"doctorHospital\":\"复旦大学附属中山医院\",\"doctorId\":100227,\"doctorName\":\"欧阳云开\",\"hospitalDepartment\":\"普外科\",\"needHelp\":\"测试肝肿瘤外科医生怎么说呢，，，，\",\"patientId\":85458,\"patientName\":\"患者段\",\"pics\":[],\"position\":\"主治医师 \"}","orderKind":2,"payOrderId":"2019111318253262274909","payPlatformKind":3,"createTime":"2019-11-13 18:25:33","buyerId":141162,"sellerId":100227,"buyerRelationId":85458,"addressInfo":{},"orderPrice":1000,"couponPrice":0,"integralPrice":0,"payTime":"2019-11-13 18:25:36","freight":0,"age":9,"userIcon":"141162/patient/1575949092400733.png","sex":1},{"orderId":"2019111318235871934755","orderStatusAction":5,"orderStatus":3,"orderTopic":"图文咨询","orderDetails":"{\"doctorHeadImg\":\"article/uploadImg/eeb23b49-534c-4d84-84d8-8eba04b1bd97.jpg\",\"doctorHospital\":\"复旦大学附属中山医院\",\"doctorId\":100227,\"doctorName\":\"欧阳云开\",\"hospitalDepartment\":\"普外科\",\"needHelp\":\"1334466455999764664646646544654\",\"patientId\":85458,\"patientName\":\"患者段\",\"pics\":[],\"position\":\"主治医师 \"}","orderKind":2,"payOrderId":"2019111318235871934755","payPlatformKind":3,"createTime":"2019-11-13 18:23:58","buyerId":141162,"sellerId":100227,"buyerRelationId":85458,"addressInfo":{},"orderPrice":1000,"couponPrice":0,"integralPrice":0,"payTime":"2019-11-13 18:24:02","freight":0,"age":9,"userIcon":"141162/patient/1575949092400733.png","sex":1,"suggestion":"1把"},{"orderId":"2019111318181085546957","orderStatusAction":4,"orderStatus":102,"orderTopic":"图文咨询","orderDetails":"{\"doctorHeadImg\":\"article/uploadImg/eeb23b49-534c-4d84-84d8-8eba04b1bd97.jpg\",\"doctorHospital\":\"复旦大学附属中山医院\",\"doctorId\":100227,\"doctorName\":\"欧阳云开\",\"hospitalDepartment\":\"普外科\",\"needHelp\":\"丁经理里login匿名ing敏敏进\",\"patientId\":85458,\"patientName\":\"患者段\",\"pics\":[],\"position\":\"主治医师 \"}","orderKind":2,"payOrderId":"2019111318181085546957","payPlatformKind":3,"createTime":"2019-11-13 18:18:10","buyerId":141162,"sellerId":100227,"buyerRelationId":85458,"addressInfo":{},"orderPrice":1000,"couponPrice":0,"integralPrice":0,"payTime":"2019-11-13 18:18:14","freight":0,"age":9,"userIcon":"141162/patient/1575949092400733.png","sex":1},{"orderId":"2019110811465869622061","orderStatusAction":4,"orderStatus":102,"orderTopic":"图文咨询","orderDetails":"{\"doctorHeadImg\":\"article/uploadImg/eeb23b49-534c-4d84-84d8-8eba04b1bd97.jpg\",\"doctorHospital\":\"复旦大学附属中山医院\",\"doctorId\":100227,\"doctorName\":\"欧阳云开\",\"hospitalDepartment\":\"普外科\",\"needHelp\":\"不不敌我热外婆和我哦给我弟利息呢你现在佩服我\",\"patientId\":85844,\"patientName\":\"伊泽瑞尔\",\"pics\":[\"141209/patient/15731848170000.jpg\"],\"position\":\"主治医师 \"}","orderKind":2,"payOrderId":"2019110811465869622061","payPlatformKind":3,"createTime":"2019-11-08 11:46:59","buyerId":141209,"sellerId":100227,"buyerRelationId":85844,"addressInfo":{},"orderPrice":1000,"couponPrice":0,"integralPrice":0,"payTime":"2019-11-08 11:47:02","freight":0,"age":23,"userIcon":"141209/patient/1575949225246281.png","sex":1},{"orderId":"2019110811423685560207","orderStatusAction":5,"orderStatus":3,"orderTopic":"图文咨询","orderDetails":"{\"doctorHeadImg\":\"article/uploadImg/eeb23b49-534c-4d84-84d8-8eba04b1bd97.jpg\",\"doctorHospital\":\"复旦大学附属中山医院\",\"doctorId\":100227,\"doctorName\":\"欧阳云开\",\"hospitalDepartment\":\"普外科\",\"needHelp\":\"大明湖畔大明湖畔大明湖畔的的的的的的的的的的的\",\"patientId\":85844,\"patientName\":\"伊泽瑞尔\",\"pics\":[\"141209/patient/157318455600031.jpg\"],\"position\":\"主治医师 \"}","orderKind":2,"payOrderId":"2019110811423685560207","payPlatformKind":3,"createTime":"2019-11-08 11:42:37","buyerId":141209,"sellerId":100227,"buyerRelationId":85844,"addressInfo":{},"orderPrice":1000,"couponPrice":0,"integralPrice":0,"payTime":"2019-11-08 11:42:40","freight":0,"age":23,"userIcon":"141209/patient/1575949225246281.png","sex":1,"suggestion":"结束对话干嘛"},{"orderId":"2019110810514194745087","orderStatusAction":12,"orderStatus":3,"orderTopic":"图文咨询","orderDetails":"{\"doctorHeadImg\":\"article/uploadImg/eeb23b49-534c-4d84-84d8-8eba04b1bd97.jpg\",\"doctorHospital\":\"复旦大学附属中山医院\",\"doctorId\":100227,\"doctorName\":\"欧阳云开\",\"hospitalDepartment\":\"普外科\",\"needHelp\":\"东方国际结婚的大大方方嘎嘎嘎\",\"patientId\":85951,\"patientName\":\"fgh \",\"pics\":[],\"position\":\"主治医师 \"}","orderKind":2,"payOrderId":"2019110810514194745087","payPlatformKind":3,"createTime":"2019-11-08 10:51:41","buyerId":100137,"sellerId":100227,"buyerRelationId":85951,"addressInfo":{},"orderPrice":1000,"couponPrice":0,"integralPrice":0,"payTime":"2019-11-08 10:51:45","freight":0,"age":34,"userIcon":"100137/patient/1574059352187315.png","sex":1},{"orderId":"2019110810384414272406","orderStatusAction":12,"orderStatus":3,"orderTopic":"图文咨询","orderDetails":"{\"doctorHeadImg\":\"article/uploadImg/eeb23b49-534c-4d84-84d8-8eba04b1bd97.jpg\",\"doctorHospital\":\"复旦大学附属中山医院\",\"doctorId\":100227,\"doctorName\":\"欧阳云开\",\"hospitalDepartment\":\"普外科\",\"needHelp\":\"不是新股一对一呢银色提着心情亏咩\",\"patientId\":85845,\"patientName\":\"徐力\",\"pics\":[\"141214/patient/157318072300094.jpg\",\"141214/patient/15731807230003.jpg\",\"141214/patient/157318072300059.jpg\"],\"position\":\"主治医师 \"}","orderKind":2,"payOrderId":"2019110810384414272406","payPlatformKind":3,"createTime":"2019-11-08 10:38:45","buyerId":141214,"sellerId":100227,"buyerRelationId":85845,"addressInfo":{},"orderPrice":1000,"couponPrice":0,"integralPrice":0,"payTime":"2019-11-08 10:38:49","freight":0,"age":41,"sex":1,"suggestion":"到底反反复复"},{"orderId":"2019110510363612158553","orderStatusAction":13,"orderStatus":102,"orderTopic":"图文咨询","orderDetails":"{\"doctorHeadImg\":\"article/uploadImg/eeb23b49-534c-4d84-84d8-8eba04b1bd97.jpg\",\"doctorHospital\":\"复旦大学附属中山医院\",\"doctorId\":100227,\"doctorName\":\"欧阳云开\",\"hospitalDepartment\":\"普外科\",\"needHelp\":\"回来了叽叽咕咕哈哈哈哈哈哈哈哈\",\"patientId\":85840,\"patientName\":\"亚索\",\"pics\":[],\"position\":\"主治医师 \"}","orderKind":2,"payOrderId":"2019110510363612158553","payPlatformKind":3,"createTime":"2019-11-05 10:36:37","buyerId":141207,"sellerId":100227,"buyerRelationId":85840,"addressInfo":{},"orderPrice":1000,"couponPrice":0,"integralPrice":0,"payTime":"2019-11-05 10:36:41","freight":0,"age":44,"sex":1},{"orderId":"20191101181733106134547","orderStatusAction":13,"orderStatus":102,"orderTopic":"图文咨询","orderDetails":"{\"doctorHeadImg\":\"article/uploadImg/eeb23b49-534c-4d84-84d8-8eba04b1bd97.jpg\",\"doctorHospital\":\"复旦大学附属中山医院\",\"doctorId\":100227,\"doctorName\":\"欧阳云开\",\"hospitalDepartment\":\"普外科\",\"needHelp\":\"还是激动就快点快点空间设计奖\",\"patientId\":85844,\"patientName\":\"伊泽瑞尔\",\"pics\":[\"141209/patient/157260345300038.PNG\",\"141209/patient/157260345300050.PNG\",\"141209/patient/157260345300034.PNG\",\"141209/patient/157260345300010.PNG\",\"141209/patient/157260345300048.PNG\",\"141209/patient/157260345300037.PNG\",\"141209/patient/157260345300023.PNG\",\"141209/patient/157260345300074.jpg\",\"141209/patient/157260345300081.jpg\"],\"position\":\"主治医师 \"}","orderKind":2,"payOrderId":"20191101181733106134547","payPlatformKind":3,"createTime":"2019-11-01 18:17:34","buyerId":141209,"sellerId":100227,"buyerRelationId":85844,"addressInfo":{},"orderPrice":1000,"couponPrice":0,"integralPrice":0,"payTime":"2019-11-01 18:18:03","freight":0,"age":23,"userIcon":"141209/patient/1575949225246281.png","sex":1}]
         */

        private int isOpen;
        private List<OrderInfoListBean> orderInfoList;

        public int getIsOpen() {
            return isOpen;
        }

        public void setIsOpen(int isOpen) {
            this.isOpen = isOpen;
        }

        public List<OrderInfoListBean> getOrderInfoList() {
            return orderInfoList;
        }

        public void setOrderInfoList(List<OrderInfoListBean> orderInfoList) {
            this.orderInfoList = orderInfoList;
        }

        public static class OrderInfoListBean {
            /**
             * orderId : 2019120215370311706600
             * orderStatusAction : 13
             * orderStatus : 102
             * orderTopic : 图文咨询
             * orderDetails : {"doctorHeadImg":"/storage/emulated/0/com.huidr.HuiDrDoctor.debug/img/head//storage/emulated/0/com.huidr.HuiDrDoctor.debug/img/head/article/uploadImg/eeb23b49-534c-4d84-84d8-8eba04b1bd97.jpg","doctorHospital":"复旦大学附属中山医院","doctorId":100227,"doctorName":"欧阳云开","hospitalDepartment":"普外科","needHelp":"测试测试测试测试测试","patientId":85458,"patientName":"患者段","pics":[],"position":"主治医师 "}
             * orderKind : 2
             * payOrderId : 2019120215370311706600
             * payPlatformKind : 3
             * createTime : 2019-12-02 15:37:04
             * buyerId : 141162
             * sellerId : 100227
             * buyerRelationId : 85458
             * addressInfo : {}
             * orderPrice : 1000
             * couponPrice : 0
             * integralPrice : 0
             * payTime : 2019-12-02 15:37:08
             * freight : 0
             * age : 9
             * userIcon : 141162/patient/1575949092400733.png
             * sex : 1
             * suggestion : 1把
             */

            private String orderId;
            private int orderStatusAction;
            private int orderStatus;
            private String orderTopic;
            private String orderDetails;
            private int orderKind;
            private String payOrderId;
            private int payPlatformKind;
            private String createTime;
            private int buyerId;
            private int sellerId;
            private int buyerRelationId;
            private AddressInfoBean addressInfo;
            private int orderPrice;
            private int couponPrice;
            private int integralPrice;
            private String payTime;
            private int freight;
            private int age;
            private String userIcon;
            private int sex;
            private String suggestion;

            public String getOrderId() {
                return orderId;
            }

            public void setOrderId(String orderId) {
                this.orderId = orderId;
            }

            public int getOrderStatusAction() {
                return orderStatusAction;
            }

            public void setOrderStatusAction(int orderStatusAction) {
                this.orderStatusAction = orderStatusAction;
            }

            public int getOrderStatus() {
                return orderStatus;
            }

            public void setOrderStatus(int orderStatus) {
                this.orderStatus = orderStatus;
            }

            public String getOrderTopic() {
                return orderTopic;
            }

            public void setOrderTopic(String orderTopic) {
                this.orderTopic = orderTopic;
            }

            public String getOrderDetails() {
                return orderDetails;
            }

            public void setOrderDetails(String orderDetails) {
                this.orderDetails = orderDetails;
            }

            public int getOrderKind() {
                return orderKind;
            }

            public void setOrderKind(int orderKind) {
                this.orderKind = orderKind;
            }

            public String getPayOrderId() {
                return payOrderId;
            }

            public void setPayOrderId(String payOrderId) {
                this.payOrderId = payOrderId;
            }

            public int getPayPlatformKind() {
                return payPlatformKind;
            }

            public void setPayPlatformKind(int payPlatformKind) {
                this.payPlatformKind = payPlatformKind;
            }

            public String getCreateTime() {
                return createTime;
            }

            public void setCreateTime(String createTime) {
                this.createTime = createTime;
            }

            public int getBuyerId() {
                return buyerId;
            }

            public void setBuyerId(int buyerId) {
                this.buyerId = buyerId;
            }

            public int getSellerId() {
                return sellerId;
            }

            public void setSellerId(int sellerId) {
                this.sellerId = sellerId;
            }

            public int getBuyerRelationId() {
                return buyerRelationId;
            }

            public void setBuyerRelationId(int buyerRelationId) {
                this.buyerRelationId = buyerRelationId;
            }

            public AddressInfoBean getAddressInfo() {
                return addressInfo;
            }

            public void setAddressInfo(AddressInfoBean addressInfo) {
                this.addressInfo = addressInfo;
            }

            public int getOrderPrice() {
                return orderPrice;
            }

            public void setOrderPrice(int orderPrice) {
                this.orderPrice = orderPrice;
            }

            public int getCouponPrice() {
                return couponPrice;
            }

            public void setCouponPrice(int couponPrice) {
                this.couponPrice = couponPrice;
            }

            public int getIntegralPrice() {
                return integralPrice;
            }

            public void setIntegralPrice(int integralPrice) {
                this.integralPrice = integralPrice;
            }

            public String getPayTime() {
                return payTime;
            }

            public void setPayTime(String payTime) {
                this.payTime = payTime;
            }

            public int getFreight() {
                return freight;
            }

            public void setFreight(int freight) {
                this.freight = freight;
            }

            public int getAge() {
                return age;
            }

            public void setAge(int age) {
                this.age = age;
            }

            public String getUserIcon() {
                return userIcon;
            }

            public void setUserIcon(String userIcon) {
                this.userIcon = userIcon;
            }

            public int getSex() {
                return sex;
            }

            public void setSex(int sex) {
                this.sex = sex;
            }

            public String getSuggestion() {
                return suggestion;
            }

            public void setSuggestion(String suggestion) {
                this.suggestion = suggestion;
            }

            public static class AddressInfoBean {
            }
        }
    }
}
