package com.huidr.HuiDrDoctor.module.home;

import java.util.List;

/**
 * @author: Administrator
 * @date: 2019-11-22
 */
public class AttenModel {


    /**
     * status : 0
     * page : 1
     * totalPage : 1
     * retValue : [{"id":68541,"userName":"董莲","doctorId":100166,"isFollow":true},{"id":62398,"userName":"苏式稽","latelyAdmitNo":"1190182","latelyBed":"31","latelyAdmissionDiagnosis":"结直肠恶性肿瘤伴肝转移","latelyDischargeDiagnosis":"结肠癌伴肝转移","latelyDischargeTime":"2019-04-02","latelyVisitingDate":"2019-04-04","doctorId":100166,"isFollow":true},{"id":51706,"userName":"郑考英","latelyAdmitNo":"1119554","latelyBed":"13","latelyAdmissionDiagnosis":"肝恶性肿瘤(综合治疗),乙肝后肝硬化","latelyDischargeDiagnosis":"肝恶性肿瘤(综合治疗),乙肝后肝硬化","latelyDischargeTime":"2018-08-25","latelyVisitingDate":"2019-03-12","doctorId":100166,"followupName":"肝切除模板","isFollow":true},{"id":45833,"userName":"张丽微","latelyAdmitNo":"1148145","latelyBed":"10","latelyAdmissionDiagnosis":"肝恶性肿瘤(综合治疗)","latelyDischargeDiagnosis":"肝恶性肿瘤(综合治疗)","latelyDischargeTime":"2018-10-30","latelyVisitingDate":"2018-12-05","doctorId":100166,"bindUid":140980,"followupName":"肝切除模板","isFollow":true}]
     */

    private int status;
    private int page;
    private int totalPage;
    private List<RetValueBean> retValue;

    public int getStatus() {
        return status;
    }

    public void setStatus(int status) {
        this.status = status;
    }

    public int getPage() {
        return page;
    }

    public void setPage(int page) {
        this.page = page;
    }

    public int getTotalPage() {
        return totalPage;
    }

    public void setTotalPage(int totalPage) {
        this.totalPage = totalPage;
    }

    public List<RetValueBean> getRetValue() {
        return retValue;
    }

    public void setRetValue(List<RetValueBean> retValue) {
        this.retValue = retValue;
    }

    public static class RetValueBean {
        /**
         * id : 68541
         * userName : 董莲
         * doctorId : 100166
         * isFollow : true
         * latelyAdmitNo : 1190182
         * latelyBed : 31
         * latelyAdmissionDiagnosis : 结直肠恶性肿瘤伴肝转移
         * latelyDischargeDiagnosis : 结肠癌伴肝转移
         * latelyDischargeTime : 2019-04-02
         * latelyVisitingDate : 2019-04-04
         * followupName : 肝切除模板
         * bindUid : 140980
         */

        private int id;
        private String userName;
        private int doctorId;
        private boolean isFollow;
        private String latelyAdmitNo;
        private String latelyBed;
        private String latelyAdmissionDiagnosis;
        private String latelyDischargeDiagnosis;
        private String latelyDischargeTime;
        private String latelyVisitingDate;
        private String followupName;
        private int bindUid;

        public int getId() {
            return id;
        }

        public void setId(int id) {
            this.id = id;
        }

        public String getUserName() {
            return userName;
        }

        public void setUserName(String userName) {
            this.userName = userName;
        }

        public int getDoctorId() {
            return doctorId;
        }

        public void setDoctorId(int doctorId) {
            this.doctorId = doctorId;
        }

        public boolean isIsFollow() {
            return isFollow;
        }

        public void setIsFollow(boolean isFollow) {
            this.isFollow = isFollow;
        }

        public String getLatelyAdmitNo() {
            return latelyAdmitNo;
        }

        public void setLatelyAdmitNo(String latelyAdmitNo) {
            this.latelyAdmitNo = latelyAdmitNo;
        }

        public String getLatelyBed() {
            return latelyBed;
        }

        public void setLatelyBed(String latelyBed) {
            this.latelyBed = latelyBed;
        }

        public String getLatelyAdmissionDiagnosis() {
            return latelyAdmissionDiagnosis;
        }

        public void setLatelyAdmissionDiagnosis(String latelyAdmissionDiagnosis) {
            this.latelyAdmissionDiagnosis = latelyAdmissionDiagnosis;
        }

        public String getLatelyDischargeDiagnosis() {
            return latelyDischargeDiagnosis;
        }

        public void setLatelyDischargeDiagnosis(String latelyDischargeDiagnosis) {
            this.latelyDischargeDiagnosis = latelyDischargeDiagnosis;
        }

        public String getLatelyDischargeTime() {
            return latelyDischargeTime;
        }

        public void setLatelyDischargeTime(String latelyDischargeTime) {
            this.latelyDischargeTime = latelyDischargeTime;
        }

        public String getLatelyVisitingDate() {
            return latelyVisitingDate;
        }

        public void setLatelyVisitingDate(String latelyVisitingDate) {
            this.latelyVisitingDate = latelyVisitingDate;
        }

        public String getFollowupName() {
            return followupName;
        }

        public void setFollowupName(String followupName) {
            this.followupName = followupName;
        }

        public int getBindUid() {
            return bindUid;
        }

        public void setBindUid(int bindUid) {
            this.bindUid = bindUid;
        }
    }
}
