package com.huidr.HuiDrDoctor.activity.fastReply;

import android.view.KeyEvent;
import android.widget.EditText;
import android.widget.TextView;

import com.chad.library.adapter.base.BaseViewHolder;
import com.huidr.HuiDrDoctor.debug.R;
import com.huidr.HuiDrDoctor.module.base.adapter.BaseSwipeDraggableAdapter;

import java.util.List;

/**
 * Created by Laiyimin on 2016/10/20.
 */

public class FastReplyAdapter extends BaseSwipeDraggableAdapter<ReplyModel> {

    private TextView.OnEditorActionListener mOnEditorActionListener;

    public FastReplyAdapter(List<ReplyModel> data) {
        super(R.layout.item_list_fast_reply, data);

        mOnEditorActionListener = new TextView.OnEditorActionListener() {
            @Override
            public boolean onEditorAction(TextView v, int actionId, KeyEvent event) {
                return (event.getKeyCode() == KeyEvent.KEYCODE_ENTER);
            }
        };
    }

    @Override
    protected void convert(final BaseViewHolder holder, final ReplyModel replyModel) {

        holder.addOnClickListener(R.id.iv_edit);
        holder.addOnClickListener(R.id.img_edit_pen);

        EditText et_content = holder.getView(R.id.et_content);
        et_content.setText(replyModel.getContent());
        et_content.setClickable(false);
        //禁止换行
        et_content.setOnEditorActionListener(mOnEditorActionListener);

        holder.setVisible(R.id.iv_edit, false);
        replyModel.setEdit(false);


    }
}
