package com.huidr.HuiDrDoctor.SearchResult;

import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.BitmapDrawable;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import androidx.annotation.NonNull;

import android.text.Html;
import android.text.TextUtils;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.alibaba.fastjson.JSONObject;
import com.chad.library.adapter.base.BaseQuickAdapter;
import com.chad.library.adapter.base.BaseViewHolder;
import com.google.android.material.tabs.TabLayout;
import com.google.gson.Gson;
import com.guanaj.easyswipemenulibrary.EasySwipeMenuLayout;
import com.huidr.HuiDrDoctor.activity.main.Consult.utils.PostAndGet;
import com.huidr.HuiDrDoctor.debug.BuildConfig;
import com.huidr.HuiDrDoctor.debug.R;
import com.huidr.HuiDrDoctor.module.home.AllContractModel;
import com.huidr.HuiDrDoctor.util.CircleImageView;
import com.huidr.HuiDrDoctor.util.DownLoadImg;
import com.huidr.HuiDrDoctor.util.MulityClickUtils;
import com.huidr.HuiDrDoctor.util.ThreadPoolManager;
import com.huidr.lib.commom.base.BaseFragment;
import com.scwang.smartrefresh.layout.SmartRefreshLayout;
import com.scwang.smartrefresh.layout.api.RefreshLayout;
import com.scwang.smartrefresh.layout.listener.OnLoadMoreListener;
import com.scwang.smartrefresh.layout.listener.OnRefreshListener;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.Date;

import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import cn.jpush.im.android.api.JMessageClient;
import cn.jpush.im.android.api.content.TextContent;
import cn.jpush.im.android.api.model.Conversation;
import jiguang.chat.activity.ChatActivity;
import jiguang.chat.application.JGApplication;
import jiguang.chat.utils.oss.OssService;

import static com.huidr.HuiDrDoctor.util.DownLoadImg.getCirleBitmap;


public class DoctorSearchFragment extends BaseFragment implements View.OnClickListener {

    String path = BuildConfig.baseUrl + "hospital/doctorGroup/getContactsList";
    int currentPage = 1;
    int totalPage = 1;
    String key;
    SmartRefreshLayout srlDoctorSearch;
    RecyclerView rvDoctorSearch;
    ConstraintLayout clDoctorEmpty;
    Button btnLink;
    TextView tvEmpty2;
    AllContractModel allContractModel;
    Gson gson;
    Date date = new Date();
    String str = "yyyy-MM-dd";
    SimpleDateFormat simpleDateFormat = new SimpleDateFormat(str);
    OssService ossService;
    String imgPath = "";
    View footerView;
    DoctorInterface doctorInterface;
    TabLayout tabLayout;

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        doctorInterface = (DoctorInterface) context;
    }

    @Override
    protected void findView(View parent) {
        srlDoctorSearch = parent.findViewById(R.id.srl_doctor_search);
        rvDoctorSearch = parent.findViewById(R.id.rv_doctor_search);
        clDoctorEmpty = parent.findViewById(R.id.cl_doctor_empty);
        btnLink = parent.findViewById(R.id.btn_link);
        tvEmpty2 = parent.findViewById(R.id.tv_empty2);

        tvEmpty2.setText(Html.fromHtml("请<font color='#248cfa'>添加医生联系人</font>"));
        btnLink.setOnClickListener(this);
        srlDoctorSearch.setEnableLoadMore(true);
        srlDoctorSearch.setEnableRefresh(true);


        srlDoctorSearch.setOnLoadMoreListener(new OnLoadMoreListener() {
            @Override
            public void onLoadMore(@NonNull RefreshLayout refreshLayout) {
                if (currentPage < totalPage && allContractModel.getRetValue().size() == 20) {
                    currentPage += 1;
                    getDoctorList();
                } else {
                    srlDoctorSearch.finishLoadMore();
                    Toast.makeText(getContext(), "数据加载全部", Toast.LENGTH_SHORT).show();
                }
            }
        });

        srlDoctorSearch.setOnRefreshListener(new OnRefreshListener() {
            @Override
            public void onRefresh(@NonNull RefreshLayout refreshLayout) {
                currentPage = 1;
                getDoctorList();
            }
        });
        rvDoctorSearch.setAdapter(adapter);
        rvDoctorSearch.setLayoutManager(new LinearLayoutManager(getContext()));

        footerView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                doctorInterface.doFinish();
            }
        });

        tabLayout = parent.findViewById(R.id.tab);
        tabLayout.addTab(tabLayout.newTab().setText("患者"));
        tabLayout.addTab(tabLayout.newTab().setText("医生"));
        tabLayout.getTabAt(1).select();
        tabLayout.setOnTabSelectedListener(new TabLayout.OnTabSelectedListener() {
            @Override
            public void onTabSelected(TabLayout.Tab tab) {
                if (tab.getText().toString().equals("患者")) {
                    doctorInterface.switchPatient();
                }
            }

            @Override
            public void onTabUnselected(TabLayout.Tab tab) {

            }

            @Override
            public void onTabReselected(TabLayout.Tab tab) {

            }
        });
    }


    public void getDoctorList() {
        ThreadPoolManager.getInstance().execute(new Runnable() {
            @Override
            public void run() {
                JSONObject jsonObject = new JSONObject();
                jsonObject.put("pageIndex", currentPage);
                jsonObject.put("pageSize", 20);
                jsonObject.put("userName", key);
                String result = PostAndGet.doHttpPost(path, jsonObject);
                Log.e("123", result);
                if (result.equals("网络异常")) {
                    handler.sendEmptyMessage(3);
                } else {
                    allContractModel = gson.fromJson(result, AllContractModel.class);
                    if (allContractModel.getStatus() == 0) {
                        if (currentPage == 1) {
                            handler.sendEmptyMessage(1);
                        } else {
                            handler.sendEmptyMessage(2);
                        }
                        totalPage = allContractModel.getTotalPage();
                    } else {
                        handler.sendEmptyMessage(3);
                    }
                }
            }
        });
    }

    @Override
    protected void initData() {
        if (getArguments() != null) {
            key = getArguments().getString("key");
            Log.e("搜索关键字", key);
        }
        imgPath = getContext().getExternalFilesDir("").getAbsolutePath() + "/img/head/";
        ossService = new OssService(getContext());
        gson = new Gson();
        allContractModel = new AllContractModel();
        getDoctorList();
    }

    @Override
    protected View setContentView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_doctor_search, container, false);
        footerView = LayoutInflater.from(getContext()).inflate(R.layout.footer_doctor, container, false);
        return view;

    }


    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.btn_link:
                doctorInterface.doAddContract();
                break;
        }
    }


    Handler handler = new Handler() {
        @Override
        public void handleMessage(Message msg) {
            super.handleMessage(msg);
            switch (msg.what) {
                case 1://第一页
                    adapter.getData().clear();
                    if (allContractModel.getRetValue().size() == 0) {
//                        显示空
                        clDoctorEmpty.setVisibility(View.VISIBLE);
                        srlDoctorSearch.setVisibility(View.GONE);
                    } else {
                        clDoctorEmpty.setVisibility(View.GONE);
                        srlDoctorSearch.setVisibility(View.VISIBLE);
                        if (adapter.getFooterLayoutCount() == 0) {
                            adapter.addFooterView(footerView);
                        }
                        adapter.getData().addAll(allContractModel.getRetValue());
                        adapter.notifyDataSetChanged();
                    }
                    srlDoctorSearch.finishRefresh();
                    break;
                case 2://第二页以及以后
                    if (adapter.getFooterLayoutCount() == 0) {
                        adapter.addFooterView(footerView);
                    }
                    adapter.getData().addAll(allContractModel.getRetValue());
                    adapter.notifyDataSetChanged();
                    srlDoctorSearch.finishLoadMore();
                    break;
                case 3://网络异常
                    clDoctorEmpty.setVisibility(View.VISIBLE);
                    srlDoctorSearch.setVisibility(View.GONE);
                    srlDoctorSearch.finishLoadMore();
                    srlDoctorSearch.finishRefresh();
                    break;
            }
        }
    };


    //    添加最近查看医生
    public void addDoctorToRecent(final String id) {
        ThreadPoolManager.getInstance().execute(new Runnable() {
            @Override
            public void run() {
                String path = BuildConfig.baseUrl + "hospital/doctorGroup/addRecentlyCheckDoctor";
                JSONObject jsonObject = new JSONObject();
                jsonObject.put("doctorId", id);
                String result = PostAndGet.doHttpPost(path, jsonObject);

                if (result.equals("网络异常")) {

                } else {

                }
            }
        });
    }

    private BaseQuickAdapter<AllContractModel.RetValueBean, BaseViewHolder> adapter = new BaseQuickAdapter<AllContractModel.RetValueBean, BaseViewHolder>(R.layout.item_apply_layout) {
        @Override
        protected void convert(BaseViewHolder helper, final AllContractModel.RetValueBean item) {

            EasySwipeMenuLayout esml_item = helper.getView(R.id.esml_item);
            esml_item.setCanLeftSwipe(false);
            esml_item.setCanRightSwipe(false);
            ConstraintLayout cl_item = helper.getView(R.id.cl_item);
            cl_item.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (JMessageClient.getMyInfo() == null) {
                        return;
                    }

                    if (MulityClickUtils.isFastClick()) {
                        addDoctorToRecent(item.getContactsId() + "");
                        Intent intent = new Intent(getActivity(), ChatActivity.class);
                        Bundle bundle = new Bundle();
                        bundle.putString("targetId", item.getContactsId() + "");
                        bundle.putString(JGApplication.CONV_TITLE, item.getContactsName());
                        bundle.putString(JGApplication.TARGET_APP_KEY, BuildConfig.appkey);
                        intent.putExtras(bundle);
                        startActivity(intent);
                    }
                }
            });

            CircleImageView imgItemHead = helper.getView(R.id.img_item_head);
            imgItemHead.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (MulityClickUtils.isFastClick()) {
//                        Intent intent1 = new Intent(getActivity(), WebActivity.class);
//                        Bundle bundle = new Bundle();
//                        bundle.putString("url", "personal.html?id=" + item.getContactsId());
//                        intent1.putExtras(bundle);
//                        startActivity(intent1);

                        addDoctorToRecent(item.getContactsId() + "");
                        Intent intent = new Intent(getActivity(), ChatActivity.class);
                        Bundle bundle = new Bundle();
                        bundle.putString("targetId", item.getContactsId() + "");
                        bundle.putString(JGApplication.CONV_TITLE, item.getContactsName());
                        bundle.putString(JGApplication.TARGET_APP_KEY, BuildConfig.appkey);
                        intent.putExtras(bundle);
                        startActivity(intent);

                    }
                }
            });
            ImageView imgNotice = helper.getView(R.id.img_notice);
            imgNotice.setVisibility(View.GONE);
            TextView tvItemName = helper.getView(R.id.tv_item_name);
            tvItemName.setText(item.getContactsName());
            TextView tvItemAge = helper.getView(R.id.tv_item_age);
            tvItemAge.setText(item.getContactsTitle() + "(" + item.getContactsDepartment() + ")");
            TextView tvItemDate = helper.getView(R.id.tv_item_date);
            TextView tvItemMsg = helper.getView(R.id.tv_item_msg);
            Button btnApply = helper.getView(R.id.btn_apply);
            Button btnRefuse = helper.getView(R.id.btn_refuse);
            TextView tvScrollRight = helper.getView(R.id.tv_scroll_right);
            TextView tvScrollDel = helper.getView(R.id.tv_scroll_del);

            tvItemDate.setVisibility(View.VISIBLE);

            Conversation conversation = JMessageClient.getSingleConversation(item.getContactsId() + "");
            if (conversation == null) {
                tvItemMsg.setText("暂无聊天消息");
//                tvItemDate.setVisibility(View.GONE);
                if (!TextUtils.isEmpty(item.getCreateTime())) {
                    tvItemDate.setText(item.getCreateTime());
                }
//                imgNotice.setVisibility(View.GONE);
            } else {
                cn.jpush.im.android.api.model.Message message = conversation.getLatestMessage();
                if (message != null) {

                    switch (message.getContentType()) {
                        case text:
                            tvItemMsg.setText(((TextContent) message.getContent()).getText());
                            break;
                        case voice:
                            tvItemMsg.setText("[语音消息]");
                            break;
                        case image:
                            tvItemMsg.setText("[图片]");
                            break;
                        case file:
                            tvItemMsg.setText("[文件]");
                            break;
                        case location:
                            tvItemMsg.setText("[位置]");
                            break;
                        default:
                            break;
                    }

                    date.setTime(message.getCreateTime());
                    tvItemDate.setText(simpleDateFormat.format(date));
                    tvItemDate.setVisibility(View.VISIBLE);
                } else {
                    tvItemMsg.setText("暂无聊天消息");
                    tvItemDate.setVisibility(View.GONE);
                }

            }

            Bitmap defaultBitmap = BitmapFactory.decodeResource(getResources(), R.drawable.nantou);
            BitmapDrawable defaultDrawable = new BitmapDrawable(getResources(), defaultBitmap);
            imgItemHead.setBackgroundDrawable(defaultDrawable);

            if (item.getContactsIcon() != null) {

                imgItemHead.setTag(item.getContactsIcon());
                final File file = new File(imgPath + item.getContactsIcon());
                if (file.exists()) {
                    Bitmap bitmap1 = BitmapFactory.decodeFile(file.getAbsolutePath());

                    if (bitmap1 != null) {
                        bitmap1 = getCirleBitmap(bitmap1);
                        BitmapDrawable bitmapDrawable1 = new BitmapDrawable(getContext().getResources(), bitmap1);
                        if (item.getContactsIcon().equals(imgItemHead.getTag())) {
                            imgItemHead.setBackgroundDrawable(bitmapDrawable1);
                        }
                    }
                } else {
                    DownLoadImg.BitmapWorkerTask bitmapWorkerTask = new DownLoadImg.BitmapWorkerTask(imgItemHead, file, ossService);
                    bitmapWorkerTask.execute(item.getContactsIcon());

                }

            } else {
                Log.e("默认图片", (defaultDrawable == null) + "");
                imgItemHead.setBackgroundDrawable(defaultDrawable);
            }

        }
    };


    public interface DoctorInterface {
        void doFinish();

        void doAddContract();

        void switchPatient();
    }
}
