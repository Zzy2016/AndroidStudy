package com.huidr.HuiDrDoctor.contact_fragment;

import android.app.Dialog;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.Matrix;
import android.graphics.drawable.BitmapDrawable;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import androidx.annotation.NonNull;

import android.text.Html;
import android.view.Display;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import com.alibaba.fastjson.JSONObject;
import com.chad.library.adapter.base.BaseQuickAdapter;
import com.chad.library.adapter.base.BaseViewHolder;
import com.google.gson.Gson;
import com.huidr.HuiDrDoctor.activity.WebActivity;
import com.huidr.HuiDrDoctor.activity.main.Consult.utils.PostAndGet;
import com.huidr.HuiDrDoctor.debug.BuildConfig;
import com.huidr.HuiDrDoctor.debug.R;
import com.huidr.HuiDrDoctor.module.home.RecentDoctorModel;
import com.huidr.HuiDrDoctor.module.home.SimpleResultModel;
import com.huidr.HuiDrDoctor.util.CircleImageView;
import com.huidr.HuiDrDoctor.util.DownLoadImg;
import com.huidr.HuiDrDoctor.util.LogUtil;
import com.huidr.HuiDrDoctor.util.MulityClickUtils;
import com.huidr.HuiDrDoctor.util.ThreadPoolManager;
import com.huidr.lib.commom.base.BaseFragment;
import com.huidr.lib.commom.util.Toast;
import com.scwang.smartrefresh.layout.SmartRefreshLayout;
import com.scwang.smartrefresh.layout.api.RefreshLayout;
import com.scwang.smartrefresh.layout.listener.OnLoadMoreListener;
import com.scwang.smartrefresh.layout.listener.OnRefreshListener;
import com.zyao89.view.zloading.ZLoadingDialog;
import com.zyao89.view.zloading.Z_TYPE;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import cn.jpush.im.android.api.JMessageClient;
import cn.jpush.im.android.api.callback.GetUserInfoCallback;
import cn.jpush.im.android.api.content.TextContent;
import cn.jpush.im.android.api.model.Conversation;
import cn.jpush.im.android.api.model.UserInfo;
import cn.jpush.im.api.BasicCallback;
import jiguang.chat.activity.ChatActivity;
import jiguang.chat.application.JGApplication;
import jiguang.chat.utils.oss.OssService;
import jiguang.chat.utils.oss.SharedPreferenciesUtil;

import static com.huidr.HuiDrDoctor.util.DownLoadImg.getCirleBitmap;

/*
 * 最近查看
 *
 * item 头像、医生姓名、时间、科室、职称、消息的最近一条（默认显示18个端，第18个字段为省略号）
 *
 *医生最近点击联系人的医生列表（默认记录80条）
 *
 * 1.点击头像跳转医生详情

2.点击列表进入医生聊天页面

3.左划列表添加/取消协同医生
 * */
public class NewConversionFragment extends BaseFragment {

    SmartRefreshLayout srlLayout;
    RecyclerView rvListCon;
    List<RecentDoctorModel.RetValueBean> allRecentList;
    RecentDoctorModel recentDoctorModel;
    Gson gson;
    ConstraintLayout clEmptyCon;
    TextView tvEmptyCon1, tvEmptyCon2;

    String id;

    String path = BuildConfig.baseUrl + "hospital/doctorGroup/getRecentlyCheckDoctor";//最近查看
    String pathAdd = BuildConfig.baseUrl + "hospital/doctorGroup/addAssistDoctor";//添加协同
    String pathDelete = BuildConfig.baseUrl + "hospital/doctorGroup/removeAssistDoctor";//删除协同
    int currentPage = 1;
    int totalPage = 1;
    OssService ossService;
    ZLoadingDialog dialog, dialog1;
    String imgPath;
    Matrix matrix;

    Date date = new Date();
    String str = "yyyy-MM-dd";
    SimpleDateFormat simpleDateFormat = new SimpleDateFormat(str);

    @Override
    protected void initData() {
        matrix = new Matrix();
        matrix.setRotate(90);
        ossService = new OssService(getContext());
        dialog = new ZLoadingDialog(getContext());
        dialog.setLoadingBuilder(Z_TYPE.STAR_LOADING)//设置类型
                .setLoadingColor(Color.BLUE)//颜色
                .setHintText("处理中,请稍候...").setHintTextSize(16) // 设置字体大小 dp
                .setHintTextColor(Color.GRAY)  // 设置字体颜色
                .setDurationTime(0.5) // 设置动画时间百分比 - 0.5倍
                .setCanceledOnTouchOutside(false).setCancelable(false);

        dialog1 = new ZLoadingDialog(getContext());
        dialog1.setLoadingBuilder(Z_TYPE.STAR_LOADING)//设置类型
                .setLoadingColor(Color.BLUE)//颜色
                .setHintText("正在加载,请稍候...").setHintTextSize(16) // 设置字体大小 dp
                .setHintTextColor(Color.GRAY)  // 设置字体颜色
                .setDurationTime(0.5) // 设置动画时间百分比 - 0.5倍
                .setCanceledOnTouchOutside(false).setCancelable(false).show();

        id = (String) SharedPreferenciesUtil.getData("id", "");
        allRecentList = new ArrayList<>();
        recentDoctorModel = new RecentDoctorModel();
        conAdapter.setNewData(allRecentList);
        gson = new Gson();

        getDataByPage();
    }

    public void getDataByPage() {
        ThreadPoolManager.getInstance().execute(new Runnable() {
            @Override
            public void run() {
                JSONObject jsonObject = new JSONObject();
                jsonObject.put("checkDoctorId", id);
                jsonObject.put("pageIndex", currentPage);
                jsonObject.put("pageSize", 20);
                String result = PostAndGet.doHttpPost(path, jsonObject);
                recentDoctorModel = new RecentDoctorModel();
                LogUtil.e("医生最近查看", result);
                recentDoctorModel = null;
                if (result.equals("网络异常")) {
                    handler.sendEmptyMessage(3);
                } else {
                    recentDoctorModel = gson.fromJson(result, RecentDoctorModel.class);
                    if (recentDoctorModel.getStatus() == 0) {
                        totalPage = recentDoctorModel.getTotalPage();
                        if (currentPage == 1) {
                            handler.sendEmptyMessage(1);
                        } else {
                            handler.sendEmptyMessage(2);
                        }
                    } else {
                        handler.sendEmptyMessage(3);
                    }
                }
            }
        });
    }

    private Handler handler = new Handler() {
        @Override
        public void handleMessage(Message msg) {
            super.handleMessage(msg);
            switch (msg.what) {
                case 1:
                    conAdapter.getData().clear();
                    if (recentDoctorModel.getRetValue().size() == 0) {
                        clEmptyCon.setVisibility(View.VISIBLE);
                        srlLayout.setVisibility(View.GONE);
                        tvEmptyCon1.setText("暂无最近查看~");
                        tvEmptyCon2.setText("");
                    } else {
                        conAdapter.getData().addAll(recentDoctorModel.getRetValue());
                        conAdapter.notifyDataSetChanged();
                    }
                    srlLayout.finishRefresh();

                    if (dialog1 != null) {
                        new Handler().postDelayed(new Runnable() {
                            @Override
                            public void run() {
                                dialog1.dismiss();
                            }
                        }, 500);
                    }
                    break;
                case 2:
                    conAdapter.getData().addAll(recentDoctorModel.getRetValue());
                    conAdapter.notifyDataSetChanged();
                    srlLayout.finishLoadMore();
                    break;
                case 3:
                    clEmptyCon.setVisibility(View.VISIBLE);
                    srlLayout.setVisibility(View.GONE);
                    tvEmptyCon1.setText("网络错误~");
                    String str = "<font color='#248cfa'><u>立即刷新<u><font>";
                    tvEmptyCon2.setText(Html.fromHtml(str));
                    srlLayout.finishRefresh();
                    srlLayout.finishLoadMore();
                    if (dialog1 != null) {
                        new Handler().postDelayed(new Runnable() {
                            @Override
                            public void run() {
                                dialog1.dismiss();
                            }
                        }, 500);
                    }
                    break;

//                    删除联系人成功
                case 4:
                    if (dialog != null) {
                        dialog.dismiss();
                    }
                    Toast.getInstance(getContext()).show("删除成功", 500);
                    conAdapter.remove(msg.arg1);
                    break;
                //                    删除联系人失败
                case 5:
                    if (dialog != null) {
                        dialog.dismiss();
                    }
                    Toast.getInstance(getContext()).show("删除失败", 500);
                    conAdapter.notifyItemChanged(msg.arg1);
                    break;
                //                    添加协同成功
                case 11:
                    conAdapter.getData().get(msg.arg1).setIsAssist(true);
                    if (dialog != null) {
                        dialog.dismiss();
                    }
                    com.huidr.lib.commom.util.Toast.getInstance(getContext()).show("添加协同医生成功", 500);
                    conAdapter.notifyItemChanged(msg.arg1);
                    break;
                //                    添加协同失败
                case 12:
                    if (dialog != null) {
                        dialog.dismiss();
                    }
                    com.huidr.lib.commom.util.Toast.getInstance(getContext()).show("添加协同医生失败", 500);
                    break;
                //                    删除协同成功
                case 13:
                    conAdapter.getData().get(msg.arg1).setIsAssist(false);
                    if (dialog != null) {
                        dialog.dismiss();
                    }
                    com.huidr.lib.commom.util.Toast.getInstance(getContext()).show("删除协同医生成功", 500);
                    conAdapter.notifyItemChanged(msg.arg1);
                    break;
                //                    删除协同失败
                case 14:
                    if (dialog != null) {
                        dialog.dismiss();
                    }
                    com.huidr.lib.commom.util.Toast.getInstance(getContext()).show("删除协同医生失败", 500);
                    break;
            }
        }
    };


    @Override
    protected View setContentView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_new_conversion, container, false);
    }

    @Override
    protected void findView(View parent) {
        srlLayout = parent.findViewById(R.id.srl_layout);
        rvListCon = parent.findViewById(R.id.rv_list_con);

        rvListCon.setAdapter(conAdapter);
        rvListCon.setLayoutManager(new LinearLayoutManager(getContext()));

        clEmptyCon = parent.findViewById(R.id.cl_empty_con);
        tvEmptyCon1 = parent.findViewById(R.id.tv_empty_con1);
        tvEmptyCon2 = parent.findViewById(R.id.tv_empty_con2);

        tvEmptyCon2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                currentPage = 1;
                getDataByPage();
            }
        });

        srlLayout.setOnLoadMoreListener(new OnLoadMoreListener() {
            @Override
            public void onLoadMore(@NonNull RefreshLayout refreshLayout) {
                if (recentDoctorModel.getRetValue().size() == 20 && currentPage < totalPage) {
                    currentPage += 1;
                    getDataByPage();
                } else {
                    Toast.getInstance(getContext()).show("数据加载全部", 500);
                    srlLayout.finishLoadMore();
                }
            }
        });

        srlLayout.setOnRefreshListener(new OnRefreshListener() {
            @Override
            public void onRefresh(@NonNull RefreshLayout refreshLayout) {
                currentPage = 1;
                getDataByPage();
            }
        });
    }


    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        imgPath = getContext().getExternalFilesDir("").getAbsolutePath() + "/img/head/";
        ossService = new OssService(getContext());
    }

    private BaseQuickAdapter<RecentDoctorModel.RetValueBean, BaseViewHolder> conAdapter = new BaseQuickAdapter<RecentDoctorModel.RetValueBean, BaseViewHolder>(R.layout.item_apply_layout) {

        @Override
        protected void convert(final BaseViewHolder helper, final RecentDoctorModel.RetValueBean item) {

            ConstraintLayout clItem = helper.getView(R.id.cl_item);

            clItem.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (JMessageClient.getMyInfo() == null) {
                        return;
                    }
                    if (MulityClickUtils.isFastClick()) {
                        Intent intent = new Intent(getActivity(), ChatActivity.class);
                        Bundle bundle = new Bundle();
                        bundle.putString("targetId", item.getContactsId() + "");
                        bundle.putString(JGApplication.CONV_TITLE, item.getContactsName());
                        bundle.putString(JGApplication.TARGET_APP_KEY, BuildConfig.appkey);
                        intent.putExtras(bundle);
                        startActivity(intent);
                    }

                }
            });

            String add = "<font>添加<br>协同</font>";
            String cancel = "<font>取消<br>协同</font>";
            TextView tvItemName = helper.getView(R.id.tv_item_name);
            TextView tvItemAge = helper.getView(R.id.tv_item_age);
            tvItemAge.setText(item.getContactsTitle() + "(" + item.getContactsDepartment() + ")");
            TextView tvItemDate = helper.getView(R.id.tv_item_date);
            TextView tvItemMsg = helper.getView(R.id.tv_item_msg);
            Button btnApply = helper.getView(R.id.btn_apply);
            Button btnRefuse = helper.getView(R.id.btn_refuse);
            TextView tvScrollRight = helper.getView(R.id.tv_scroll_right);
            TextView tvScrollDel = helper.getView(R.id.tv_scroll_del);

            CircleImageView imgItemHead = helper.getView(R.id.img_item_head);
            ImageView imgNotice = helper.getView(R.id.img_notice);
            imgNotice.setVisibility(View.GONE);
            imgItemHead.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (MulityClickUtils.isFastClick()) {
                        Intent intent1 = new Intent(getActivity(), WebActivity.class);
                        Bundle bundle = new Bundle();
                        bundle.putString("url", "personal.html?id=" + item.getContactsId());
                        intent1.putExtras(bundle);
                        startActivity(intent1);
                    }
                }
            });


            Conversation conversation = JMessageClient.getSingleConversation(item.getContactsId() + "");
            if (conversation == null) {
                tvItemMsg.setText("暂无聊天消息");
                tvItemDate.setVisibility(View.GONE);
//                imgNotice.setVisibility(View.GONE);
            } else {
                cn.jpush.im.android.api.model.Message message = conversation.getLatestMessage();
                if (message != null) {
//                    tvItemMsg.setText(((TextContent) message.getContent()).getText());
                    switch (message.getContentType()) {
                        case text:
                            tvItemMsg.setText(((TextContent) message.getContent()).getText());
                            break;
                        case voice:
                            tvItemMsg.setText("[语音消息]");
                            break;
                        case image:
                            tvItemMsg.setText("[图片]");
                            break;
                        case file:
                            tvItemMsg.setText("[文件]");
                            break;
                        case location:
                            tvItemMsg.setText("[位置]");
                            break;
                        default:
                            break;
                    }
                    date.setTime(message.getCreateTime());
                    tvItemDate.setText(simpleDateFormat.format(date));
                    tvItemDate.setVisibility(View.VISIBLE);
                } else {
                    tvItemMsg.setText("暂无聊天消息");
                    tvItemDate.setVisibility(View.GONE);
                }
            }


            Bitmap defaultBitmap = BitmapFactory.decodeResource(getResources(), R.drawable.nantou);

            BitmapDrawable defaultDrawable = new BitmapDrawable(getResources(), defaultBitmap);
            imgItemHead.setBackgroundDrawable(defaultDrawable);
            if (item.getContactsIcon() != null) {
                imgItemHead.setTag(item.getContactsIcon());
                final File file = new File(imgPath + item.getContactsIcon());
                if (file.exists()) {
                    Bitmap bitmap1 = BitmapFactory.decodeFile(file.getAbsolutePath());

                    if (bitmap1 != null) {
                        bitmap1 = getCirleBitmap(bitmap1);
                        BitmapDrawable bitmapDrawable = new BitmapDrawable(getResources(), bitmap1);
                        if (imgItemHead.getTag().equals(item.getContactsIcon())) {
                            imgItemHead.setBackgroundDrawable(bitmapDrawable);
                        }

                    } else {

                    }
                } else {
                    DownLoadImg.BitmapWorkerTask bitmapWorkerTask = new DownLoadImg.BitmapWorkerTask(imgItemHead, file, ossService);
                    bitmapWorkerTask.execute(item.getContactsIcon());
                }

            } else {
                imgItemHead.setBackgroundDrawable(defaultDrawable);
            }

            tvItemName.setText(item.getContactsName());

            String str = "";
            if (item.isIsAssist()) {
                str = "<font>取消<br>协同</font>";
                tvScrollRight.setBackgroundResource(R.drawable.shape_atten_gray);
            } else {
                str = "<font>添加<br>协同</font>";
                tvScrollRight.setBackgroundResource(R.drawable.add_coop_back);
            }
            tvScrollRight.setText(Html.fromHtml(str));


            tvScrollRight.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {

                    showCoopDialog(item.getContactsId() + "", helper.getAdapterPosition(), item.isIsAssist());

                }
            });


            String del = "<font>删除<br>好友<font>";
            tvScrollDel.setText(Html.fromHtml(del));
            tvScrollDel.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
//                    dialog.show();
//                    imDeleteContract(item.getContactsId() + "", item.getId() + "", helper.getAdapterPosition());
                    showDialog1(item.getContactsId() + "", item.getId() + "", helper.getAdapterPosition(), item.isIsAssist());
                }
            });
        }
    };


    //   IM 删除联系人
    public void imDeleteContract(final String targetId, final String id, final int position, final boolean isAssist) {
        JMessageClient.getUserInfo(targetId, new GetUserInfoCallback() {
            @Override
            public void gotResult(int i, String s, UserInfo userInfo) {
                if (i == 0) {
                    userInfo.removeFromFriendList(new BasicCallback() {
                        @Override
                        public void gotResult(int i, String s) {
                            if (i == 0) {
                                deleteContract(id, position, isAssist);
                            } else {
                                LogUtil.e("IM删除联系人", s);
                                if (s.equals("user not friend")) {
                                    deleteContract(id, position, isAssist);
                                }
                            }
                        }
                    });
                }
            }
        });
    }

    //    访问删除接口  删除好友
//    doctorGroup/deleteContacts
    public void deleteContract(final String targetId, final int position, final boolean isAssist) {
        ThreadPoolManager.getInstance().execute(new Runnable() {
            @Override
            public void run() {
//                String path = "http://192.168.1.180:1189/doctorGroup/deleteContacts";
                String path = BuildConfig.baseUrl + "hospital/doctorGroup/deleteContacts";
                JSONObject jsonObject = new JSONObject();
                jsonObject.put("id", targetId);
                jsonObject.put("isAssist", isAssist);
                String result = PostAndGet.doHttpPost(path, jsonObject);
                Message message = new Message();
                message.arg1 = position;
                LogUtil.e("删除联系人", result);
                if (result.equals("网络异常")) {
                    message.what = 5;
                    handler.sendMessage(message);
                } else {
                    SimpleResultModel simpleResultModel = new SimpleResultModel();
                    simpleResultModel = gson.fromJson(result, SimpleResultModel.class);
                    if (simpleResultModel.getStatus() == 0) {
                        if (simpleResultModel.getRetValue() == 0) {

                            message.what = 4;
                            message.arg1 = position;
                            handler.sendMessage(message);
                        } else {
                            message.what = 5;
                            handler.sendMessage(message);
                        }
                    } else {
                        message.what = 5;
                        handler.sendMessage(message);
                    }
                }
            }
        });
    }


    //    添加协同  String path = "http://192.168.1.180:1189/doctorGroup/addAssistDoctor";
    public void addAssistDoctor(final String id, final int position) {
        ThreadPoolManager.getInstance().execute(new Runnable() {
            @Override
            public void run() {
                JSONObject jsonObject = new JSONObject();
                int uid = Integer.valueOf(id);
                int[] a = new int[]{uid};
                jsonObject.put("assistUids", a);

                String result = PostAndGet.doHttpPost(pathAdd, jsonObject);
                LogUtil.e("添加协同医生", result);
                Message msg = new Message();
                msg.arg1 = position;
                if (result.equals("网络异常")) {
                    msg.what = 12;
                    handler.sendMessage(msg);
                } else {
                    SimpleResultModel simpleResultModel = gson.fromJson(result, SimpleResultModel.class);
                    if (simpleResultModel.getStatus() == 0) {
                        if (simpleResultModel.getRetValue() == 0) {//
                            msg.what = 11;
                            handler.sendMessage(msg);
                        } else {
                            msg.what = 12;
                            handler.sendMessage(msg);
                        }
                    } else {
                        msg.what = 12;
                        handler.sendMessage(msg);
                    }
                }
            }
        });
    }


    //    删除协同医生
    public void deleteCooperDoctor(final String deleteId, final int position) {
        ThreadPoolManager.getInstance().execute(new Runnable() {
            @Override
            public void run() {
                JSONObject jsonObject = new JSONObject();
                jsonObject.put("assistUid", deleteId);
                String result = PostAndGet.doHttpPost(pathDelete, jsonObject);
                LogUtil.e("取消xietong ", result);
                Message message = new Message();
                message.arg1 = position;
                if (result.equals("网络异常")) {
                    message.what = 14;
                    handler.sendMessage(message);
                } else {
                    SimpleResultModel simpleResultModel = gson.fromJson(result, SimpleResultModel.class);
                    if (simpleResultModel.getStatus() == 0) {
                        if (simpleResultModel.getRetValue() == 0) {

                            message.what = 13;
                            handler.sendMessage(message);
                        } else {
                            message.what = 14;
                            handler.sendMessage(message);
                        }
                    } else {
                        message.what = 14;
                        handler.sendMessage(message);
                    }
                }
            }
        });
    }


    //    删除好友 对话框
    public void showDialog1(final String id, final String id1, final int position, final boolean isAssist) {

        final Dialog builder = new Dialog(getContext(), R.style.jmui_default_dialog_style);
        //final Dialog builder = new Dialog(this, R.style.jmui_default_dialog_style);
        View view = LayoutInflater.from(getContext()).inflate(R.layout.dialog_content, null);

        TextView tvTitle = view.findViewById(R.id.tv_title);
        TextView tvFooter1 = view.findViewById(R.id.tv_footer1);
        TextView tvFooter2 = view.findViewById(R.id.tv_footer2);

        tvTitle.setText("是否删除此联系人");

//        取消
        tvFooter1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                builder.cancel();
                conAdapter.notifyItemChanged(position);
            }
        });
//确定
        tvFooter2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                imDeleteContract(id, id1, position, isAssist);
                builder.cancel();
            }
        });

        builder.setContentView(view);
        //builder.setCanceledOnTouchOutside(true);
        builder.show();
        Window window = builder.getWindow();
        WindowManager.LayoutParams lp = window.getAttributes();
        WindowManager windowManager = getActivity().getWindowManager();
        Display display = windowManager.getDefaultDisplay();
        lp.width = (int) (display.getWidth() * 0.7);
//        lp.height = (int) (display.getHeight() * 0.1);
        window.setAttributes(lp);
    }

    //    取消添加协同对话框
    public void showCoopDialog(final String id, final int position, final boolean isCoop) {

        final Dialog builder = new Dialog(getContext(), R.style.jmui_default_dialog_style);
        //final Dialog builder = new Dialog(this, R.style.jmui_default_dialog_style);
        View view = LayoutInflater.from(getContext()).inflate(R.layout.dialog_content, null);

        TextView tvTitle = view.findViewById(R.id.tv_title);
        TextView tvFooter1 = view.findViewById(R.id.tv_footer1);
        TextView tvFooter2 = view.findViewById(R.id.tv_footer2);

        if (isCoop) {
            tvTitle.setText("是否删除协同医生!");
        } else {
            tvTitle.setText("是否添加协同医生!");
        }


//        取消
        tvFooter1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                builder.cancel();
                conAdapter.notifyItemChanged(position);
            }
        });
//确定
        tvFooter2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                builder.cancel();
                if (isCoop) {
                    deleteCooperDoctor(id, position);
                } else {
                    addAssistDoctor(id, position);
                }
            }
        });

        builder.setContentView(view);
        //builder.setCanceledOnTouchOutside(true);
        builder.show();
        Window window = builder.getWindow();
        WindowManager.LayoutParams lp = window.getAttributes();
        WindowManager windowManager = getActivity().getWindowManager();
        Display display = windowManager.getDefaultDisplay();
        lp.width = (int) (display.getWidth() * 0.7);
//        lp.height = (int) (display.getHeight() * 0.1);
        window.setAttributes(lp);
    }


    @Override
    public void onStop() {
        super.onStop();
        conAdapter.notifyDataSetChanged();
        if (dialog != null) {
            dialog.dismiss();
        }
        if (dialog1 != null) {
            dialog1.dismiss();
        }
    }
}
