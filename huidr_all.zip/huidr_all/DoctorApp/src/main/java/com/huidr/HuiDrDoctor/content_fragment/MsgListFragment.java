package com.huidr.HuiDrDoctor.content_fragment;

import android.app.Dialog;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Matrix;
import android.graphics.drawable.BitmapDrawable;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import androidx.annotation.NonNull;

import android.text.Html;
import android.util.Log;
import android.view.Display;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.ImageView;
import android.widget.TextView;

import com.chad.library.adapter.base.BaseQuickAdapter;
import com.chad.library.adapter.base.BaseViewHolder;
import com.google.gson.Gson;
import com.huidr.HuiDrDoctor.activity.ConsultRecordActivity;
import com.huidr.HuiDrDoctor.activity.WebActivity;
import com.huidr.HuiDrDoctor.debug.BuildConfig;
import com.huidr.HuiDrDoctor.debug.R;
import com.huidr.HuiDrDoctor.module.home.MessageModel;
import com.huidr.HuiDrDoctor.module.home.NewMessageModel;
import com.huidr.HuiDrDoctor.util.CircleImageView;
import com.huidr.HuiDrDoctor.util.DowmImageUtils;
import com.huidr.HuiDrDoctor.util.EventBusMessage;
import com.huidr.HuiDrDoctor.util.FormatTime;
import com.huidr.HuiDrDoctor.util.LogUtil;
import com.huidr.HuiDrDoctor.util.MulityClickUtils;
import com.huidr.lib.commom.base.BaseFragment;
import com.huidr.lib.commom.util.Toast;
import com.scwang.smartrefresh.layout.SmartRefreshLayout;
import com.scwang.smartrefresh.layout.api.RefreshLayout;
import com.scwang.smartrefresh.layout.listener.OnLoadMoreListener;
import com.scwang.smartrefresh.layout.listener.OnRefreshListener;
import com.tendcloud.tenddata.TCAgent;

import org.greenrobot.eventbus.EventBus;
import org.greenrobot.eventbus.Subscribe;
import org.greenrobot.eventbus.ThreadMode;
import org.litepal.LitePal;

import java.io.File;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import jiguang.chat.activity.ChatActivity;
import jiguang.chat.application.JGApplication;

import jiguang.chat.utils.oss.OssService;
import jiguang.chat.utils.oss.SharedPreferenciesUtil;

import static com.huidr.HuiDrDoctor.util.DownLoadImg.getCirleBitmap;

/**
 * 消 息 列 表
 */
public class MsgListFragment extends BaseFragment {


    private RecyclerView rvListMsg;
    private SmartRefreshLayout srlLayout;
    private ConstraintLayout clLayoutEmpty;

    private List<NewMessageModel> allMessageList = new ArrayList<>();
    private List<NewMessageModel> tempMessageList = new ArrayList<>();
    private int page = 1;
    private boolean loadAll = false;
    String rootPath;

    OssService ossService;
    Gson gson = new Gson();
    String id;
    Matrix matrix;

    boolean isVisible = false;

    double Length;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        matrix = new Matrix();
        matrix.setRotate(90);

        Length=1000*60*60*24*180;
        id = (String) SharedPreferenciesUtil.getData("id", "0");

        EventBus.getDefault().register(this);

    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        EventBus.getDefault().unregister(this);
    }

    @Subscribe(threadMode = ThreadMode.MAIN)
    public void getMessage(EventBusMessage message) {
        Log.e("收到消息——msglist" + isVisible, message.message);
        if (message.message.equals("refresh_list")) {
            if (isVisible) {
                getListData();
            }
        }
    }

    @Override
    protected void initData() {
        rootPath = getContext().getExternalFilesDir("").getAbsolutePath() + "/image/patient/";
        ossService = new OssService(getContext());
    }

    @Override
    protected View setContentView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_msg_list, container, false);
        LogUtil.e("消息列表", "setContentView");
        return view;
    }


    @Override
    public void setUserVisibleHint(boolean isVisibleToUser) {
        super.setUserVisibleHint(isVisibleToUser);

        LogUtil.e("消息列表", "setUserVisibleHint1" + "    " + isVisibleToUser);
        LogUtil.e("测试1", "消息列表可见");

        if (isVisibleToUser) {
            isVisible = true;
//            page = 1;
//            msgAdapter.getData().clear();
//            getAllSysMessage();
//            getPageSysMessage(page);
//            Log.e("加载page", page + "");
//            Message message = new Message();
//            message.what = 0;
//            message.arg1 = tempMessageList.size();
//            handler.sendMessage(message);
            getListData();
        } else {
            isVisible = false;
        }
    }


    public void getListData() {
        page = 1;
        msgAdapter.getData().clear();
        getAllSysMessage();
        getPageSysMessage(page);
        Log.e("加载page", page + "");
        Message message = new Message();
        message.what = 0;
        message.arg1 = tempMessageList.size();
        handler.sendMessage(message);
    }


    Handler handler = new Handler() {
        @Override
        public void handleMessage(Message msg) {
            super.handleMessage(msg);

            switch (msg.what) {
                case 0:

                    if (allMessageList.size() == 0) {
                        clLayoutEmpty.setVisibility(View.VISIBLE);
                        srlLayout.setVisibility(View.GONE);

                    } else {
                        clLayoutEmpty.setVisibility(View.GONE);
                        srlLayout.setVisibility(View.VISIBLE);

                    }
                    break;
            }
        }
    };

    @Override
    protected void findView(View parent) {
        LogUtil.e("消息列表", "findView");
        srlLayout = parent.findViewById(R.id.srl_layout);
        rvListMsg = parent.findViewById(R.id.rv_list_msg);
        clLayoutEmpty = parent.findViewById(R.id.cl_layout_empty);
        rvListMsg.setAdapter(msgAdapter);

        rvListMsg.setLayoutManager(new LinearLayoutManager(getContext()));

        msgAdapter.setNewData(tempMessageList);

        srlLayout.setEnableRefresh(true);
        srlLayout.setEnableLoadMore(true);

//        刷新
        srlLayout.setOnRefreshListener(new OnRefreshListener() {
            @Override
            public void onRefresh(@NonNull RefreshLayout refreshLayout) {
                page = 1;
                loadAll = false;
                msgAdapter.getData().clear();
                getAllSysMessage();
                getPageSysMessage(page);
                srlLayout.finishRefresh();
                msgAdapter.notifyDataSetChanged();
                TCAgent.onEvent(getContext(), "点击消息列表的次数 ", "点击消息列表的次数 ");
            }
        });
        // 加载更多
        srlLayout.setOnLoadMoreListener(new OnLoadMoreListener() {
            @Override
            public void onLoadMore(@NonNull RefreshLayout refreshLayout) {
                if (loadAll) {
                    Toast.getInstance(getContext()).show("加载全部", 1000);
                } else {
                    getPageSysMessage(++page);
                    msgAdapter.notifyDataSetChanged();
                }
                srlLayout.finishLoadMore();
            }
        });
    }

    //    消息适配器
    private BaseQuickAdapter<NewMessageModel, BaseViewHolder> msgAdapter = new BaseQuickAdapter<NewMessageModel, BaseViewHolder>(R.layout.msg_item_layout) {
        @Override
        protected void convert(final BaseViewHolder helper, final NewMessageModel item) {

            helper.setIsRecyclable(false);

            ConstraintLayout clLayout = helper.getView(R.id.cl_layout);

            ImageView imgNotice = helper.getView(R.id.img_notice);

            CircleImageView imgItemHead = helper.getView(R.id.img_item_head);
            TextView textViewName = helper.getView(R.id.tv_item_name);
            final ImageView imgGender = helper.getView(R.id.image_item_gender);
            TextView textViewAge = helper.getView(R.id.tv_item_age);
            TextView textViewState = helper.getView(R.id.tv_item_state);
            TextView textDate = helper.getView(R.id.tv_item_date);
            TextView textDesc = helper.getView(R.id.tv_item_msg);

            textDate.setText(FormatTime.getTime(item.getDate()));

            if (item.getIsRead() == 0) {
                imgNotice.setVisibility(View.VISIBLE);
            } else {
                imgNotice.setVisibility(View.GONE);
            }

            Bitmap defaultBitmap = BitmapFactory.decodeResource(getResources(), R.drawable.default_ico);
            BitmapDrawable defaultBitmapDrawable = new BitmapDrawable(getResources(), defaultBitmap);
            imgItemHead.setBackgroundDrawable(defaultBitmapDrawable);


            if (item.getOrderStatusAction() == null) {  //申请
                try {
                    final MessageModel messageModel = gson.fromJson(item.getContent(), MessageModel.class);

                    if (messageModel.getUserIcon() != null && !messageModel.getUserIcon().equals("null")) {
                        imgItemHead.setTag(messageModel.getUserIcon());
                        File file = new File(rootPath + messageModel.getUserIcon());
                        if (file.exists()) {
                            Bitmap bitmap = BitmapFactory.decodeFile(file.getAbsolutePath());
                            if (bitmap == null) {
                                if (messageModel.getType() == 1) {
                                    imgItemHead.setBackgroundResource(R.drawable.followgroup);
                                } else {
                                    imgItemHead.setBackgroundResource(R.drawable.nantou);
                                }

                            } else {
//                                imgItemHead.setImageBitmap(bitmap);
                                bitmap = getCirleBitmap(bitmap);
                                BitmapDrawable bitmapDrawable = new BitmapDrawable(getResources(), bitmap);
                                if (imgItemHead.getTag().equals(messageModel.getUserIcon())) {
                                    imgItemHead.setBackgroundDrawable(bitmapDrawable);
                                }
                            }


                        } else {
                            DowmImageUtils.BitmapWorkerTask bitmapWorkerTask = new DowmImageUtils.BitmapWorkerTask(imgItemHead, file, ossService);
                            bitmapWorkerTask.execute(messageModel.getUserIcon());
//
                        }
                    } else {


                        if (messageModel.getType() == 1) {
                            imgItemHead.setBackgroundResource(R.drawable.followgroup);
                        } else {
                            Bitmap bitmap = BitmapFactory.decodeResource(getResources(), R.drawable.head);
                            imgItemHead.setImageBitmap(bitmap);


                        }


                    }
                    switch (messageModel.getType()) {

                        case 1:  //随访组
                            textViewName.setText(messageModel.getUserName());
                            textViewAge.setVisibility(View.VISIBLE);
                            textViewAge.setText(messageModel.getUserTitle() + "(" + messageModel.getDepartment() + ")");
                            textDesc.setText(messageModel.getInfo());

                            clLayout.setOnClickListener(new View.OnClickListener() {
                                @Override
                                public void onClick(View v) {
                                    if (MulityClickUtils.isFastClick()) {
                                        item.setIsRead(1);
                                        item.save();
                                        notifyDataSetChanged();
                                        Intent intent = new Intent(getActivity(), WebActivity.class);
                                        Bundle bundle = new Bundle();
                                        bundle.putString("url", item.getUrl());
                                        intent.putExtras(bundle);
                                        startActivity(intent);
                                    }
                                }
                            });

                            break;


                        case 2:
                            textViewName.setText(messageModel.getUserName());
                            textViewAge.setVisibility(View.VISIBLE);
                            textViewAge.setText(messageModel.getUserTitle() + "(" + messageModel.getDepartment() + ")");
                            textDesc.setText(messageModel.getInfo());

                            clLayout.setOnClickListener(new View.OnClickListener() {
                                @Override
                                public void onClick(View v) {
                                    if (MulityClickUtils.isFastClick()) {
                                        item.setIsRead(1);
                                        item.save();
                                        notifyDataSetChanged();
                                        Intent intent = new Intent(getActivity(), WebActivity.class);
                                        Bundle bundle = new Bundle();
                                        bundle.putString("url", item.getUrl());
                                        intent.putExtras(bundle);
                                        startActivity(intent);
                                    }
                                }
                            });
                            break;

                        case 14: //收到某某的申请
                            textViewName.setText(messageModel.getUserName());
                            textViewAge.setVisibility(View.VISIBLE);
                            textViewAge.setText(messageModel.getUserTitle() + "(" + messageModel.getDepartment() + ")");
                            textDesc.setText(messageModel.getInfo());
                            clLayout.setOnClickListener(new View.OnClickListener() {
                                @Override
                                public void onClick(View v) {
                                    if (MulityClickUtils.isFastClick()) {
                                        item.setIsRead(1);
                                        item.save();
                                        notifyDataSetChanged();
//                                        EventBus.getDefault().post(new BusEventMessage("1"));
                                        EventBus.getDefault().post(EventBusMessage.getInstance("1"));
                                    }
                                }
                            });

                            break;
                        case 13://某某 拒绝了自己的申请
                            textViewName.setText(messageModel.getUserName());
                            textViewAge.setVisibility(View.VISIBLE);
                            textViewAge.setText(messageModel.getUserTitle() + "(" + messageModel.getDepartment() + ")");
                            textDesc.setText(messageModel.getInfo());
                            clLayout.setOnClickListener(new View.OnClickListener() {
                                @Override
                                public void onClick(View v) {
                                    if (MulityClickUtils.isFastClick()) {
                                        item.setIsRead(1);
                                        item.save();
                                        notifyDataSetChanged();
                                        showDialog1(messageModel.getUserName() + "拒绝了你的添加申请");
                                    }
                                }
                            });
                            break;
                        case 12://某某 接受了自己的申请
                            textViewName.setText(messageModel.getUserName());
                            textViewAge.setVisibility(View.VISIBLE);
                            textViewAge.setText(messageModel.getUserTitle() + "(" + messageModel.getDepartment() + ")");
                            textDesc.setText(messageModel.getInfo());
                            clLayout.setOnClickListener(new View.OnClickListener() {
                                @Override
                                public void onClick(View v) {
                                    if (MulityClickUtils.isFastClick()) {
                                        item.setIsRead(1);
                                        item.save();
                                        Intent intent = new Intent(getActivity(), ChatActivity.class);
                                        Bundle bundle = new Bundle();
                                        bundle.putString("targetId", messageModel.getId() + "");
                                        bundle.putString(JGApplication.CONV_TITLE, messageModel.getUserName());
                                        bundle.putString(JGApplication.TARGET_APP_KEY, BuildConfig.appkey);
                                        intent.putExtras(bundle);
                                        startActivity(intent);
                                    }
                                }
                            });
                            break;
                        case 11:// 图文咨询

                            break;
                        case 10:// 患者提交随访报到
                            textViewName.setText(messageModel.getUserName());
                            imgGender.setVisibility(View.VISIBLE);
                            if (messageModel.getUserSex() == 1) {
                                imgGender.setBackgroundResource(R.drawable.gender_man);
                            } else {
                                imgGender.setBackgroundResource(R.drawable.gender_w);
                            }
                            textViewAge.setText(messageModel.getAge() + "岁");
                            textViewAge.setVisibility(View.VISIBLE);
                            textDesc.setText(messageModel.getInfo());
                            clLayout.setOnClickListener(new View.OnClickListener() {
                                @Override
                                public void onClick(View v) {
                                    if (MulityClickUtils.isFastClick()) {
                                        item.setIsRead(1);
                                        item.save();
                                        notifyDataSetChanged();
                                        Intent intent1 = new Intent(getContext(), WebActivity.class);
                                        Bundle bundle = new Bundle();
                                        bundle.putString("url", item.getUrl());
                                        intent1.putExtras(bundle);
                                        startActivity(intent1);
                                    }
                                }
                            });
                            break;
                        case 9:// 精卫提交心里自测问卷
                            textViewName.setText(messageModel.getUserName());
                            if (messageModel.getUserSex() == 1) {
                                imgGender.setBackgroundResource(R.drawable.gender_man);
                            } else {
                                imgGender.setBackgroundResource(R.drawable.gender_w);
                            }
                            imgGender.setVisibility(View.VISIBLE);
                            textViewAge.setText(messageModel.getAge() + "岁");
                            textViewAge.setVisibility(View.VISIBLE);
                            textDesc.setText(messageModel.getInfo());

                            clLayout.setOnClickListener(new View.OnClickListener() {
                                @Override
                                public void onClick(View v) {
                                    if (MulityClickUtils.isFastClick()) {
                                        item.setIsRead(1);
                                        item.save();
                                        notifyDataSetChanged();
                                        Intent intent1 = new Intent(getContext(), WebActivity.class);
                                        Bundle bundle = new Bundle();
                                        bundle.putString("url", item.getUrl());
                                        intent1.putExtras(bundle);
                                        startActivity(intent1);
                                    }
                                }
                            });

                            break;
                        case 8:// 精卫建立就诊关系
                            textViewName.setText(messageModel.getUserName());
                            if (messageModel.getUserSex() == 1) {
                                imgGender.setBackgroundResource(R.drawable.gender_man);
                            } else {
                                imgGender.setBackgroundResource(R.drawable.gender_w);
                            }
                            imgGender.setVisibility(View.VISIBLE);
                            textViewAge.setText(messageModel.getAge() + "岁");
                            textViewAge.setVisibility(View.VISIBLE);
                            textDesc.setText(messageModel.getInfo());

                            clLayout.setOnClickListener(new View.OnClickListener() {
                                @Override
                                public void onClick(View v) {
                                    if (MulityClickUtils.isFastClick()) {
                                        item.setIsRead(1);
                                        item.save();
                                        notifyDataSetChanged();
                                        Intent intent1 = new Intent(getContext(), WebActivity.class);
                                        Bundle bundle = new Bundle();
                                        bundle.putString("url", item.getUrl());
                                        intent1.putExtras(bundle);
                                        startActivity(intent1);
                                    }
                                }
                            });

                            break;
                    }

                } catch (Exception e) {
                    if (item.getContent() != null && item.getContent().contains("欢迎")) {
                        imgItemHead.setImageBitmap(BitmapFactory.decodeResource(getResources(), R.drawable.default_ico));
                        textViewName.setText("荟医消息");
                        textDesc.setText(item.getContent());
                        textViewState.setText("欢迎");
                        textViewState.setBackgroundResource(R.drawable.state_back_yellow);
                        textViewState.setVisibility(View.VISIBLE);
                        clLayout.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {
                                if (MulityClickUtils.isFastClick()) {
                                    item.setIsRead(1);
                                    item.save();
                                    notifyDataSetChanged();
                                    showDialog1(item.getContent());
                                }
                            }
                        });

                    } else {
                        imgItemHead.setImageBitmap(BitmapFactory.decodeResource(getResources(), R.drawable.logo));
                        textViewName.setText("荟医消息");
                        textDesc.setText(item.getContent());
                        clLayout.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {
                                if (MulityClickUtils.isFastClick()) {
                                    item.setIsRead(1);
                                    item.save();
                                    notifyDataSetChanged();
                                    showDialog1(item.getContent());
                                }
                            }
                        });
                    }
                }


            } else if (item.getOrderKind().equals("3")) { //提现
                imgItemHead.setBackgroundResource(R.drawable.logo);
                if (item.getOrderStatusAction().equals("10")) {
                    textViewName.setText(Html.fromHtml("<font color='#248cfa'>荟医消息</font>"));
                    textViewState.setBackgroundResource(R.drawable.state_back_blue);
                    textViewState.setText("未通过");
                    textViewState.setVisibility(View.VISIBLE);
                    textDesc.setText(item.getContent());
                } else if (item.getOrderStatusAction().equals("3")) {
                    textViewName.setText(Html.fromHtml("<font color='#248cfa'>荟医消息</font>"));
                    textViewState.setBackgroundResource(R.drawable.state_back_green);
                    textViewState.setText("已通过");
                    textViewState.setVisibility(View.VISIBLE);
                    textDesc.setText(item.getContent());
                } else {
                    textViewName.setText(Html.fromHtml("<font color='#248cfa'>荟医消息</font>"));
                    textViewState.setBackgroundResource(R.drawable.state_back_green);
                    textViewState.setText("审核中");
                    textViewState.setVisibility(View.VISIBLE);
                    textDesc.setText(item.getContent());
                }

                clLayout.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        if (MulityClickUtils.isFastClick()) {
                            item.setIsRead(1);
                            item.save();
                            notifyDataSetChanged();
                            showDialog1(item.getContent());
                        }

                    }
                });

            } else if (item.getOrderKind().equals("2")) {
                imgItemHead.setBackgroundResource(R.drawable.logo);
                textViewName.setText("荟医消息");
                textDesc.setText(item.getContent());
                clLayout.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        if (MulityClickUtils.isFastClick()) {
                            item.setIsRead(1);
                            item.save();
                            notifyDataSetChanged();
                            Intent intent1 = new Intent(getActivity(), ConsultRecordActivity.class);
                            startActivity(intent1);
                        }
                    }
                });
            }
        }
    };


    /*
     * 获取所有系统消息
     * */
    public void getAllSysMessage() {
        LogUtil.e("消息列表", "getAllSysMessage");

        if ((boolean) SharedPreferenciesUtil.getData("firstLogin", false)) {
            NewMessageModel newMessageModel = new NewMessageModel();
            newMessageModel.setContent("欢迎您入住荟医平台，您的加入将使荟医更美好");
            newMessageModel.setType("systemMessage");
            newMessageModel.setDate(System.currentTimeMillis());
            newMessageModel.setIsRead(0);
            newMessageModel.save();
            SharedPreferenciesUtil.putData("firstLogin", false);
        }

        allMessageList = LitePal.findAll(NewMessageModel.class);
//        clearMsg(allMessageList);

        Collections.reverse(allMessageList);
        LogUtil.e("测试1", "全部消息" + allMessageList.size());


    }

    /*清理 消息*/
    public void clearMsg(List<NewMessageModel> allMessageList) {
        for (int i = 0; i < allMessageList.size(); i++) {
            Log.e("时间  "+i,System.currentTimeMillis()+"   "+allMessageList.get(i).getDate()+"   "+(System.currentTimeMillis() - allMessageList.get(i).getDate())+"   "+((System.currentTimeMillis() - allMessageList.get(i).getDate()) > (1000 * 60 * 60 * 24 * 180))+"   "+(1000*60*60*24*180));
            if (allMessageList.get(i).getDate() != 0) {

                if ((System.currentTimeMillis() - allMessageList.get(i).getDate()) > Length) {

                    allMessageList.remove(allMessageList.get(i));
                }
            }
        }
    }


    @Override
    public void onResume() {
        super.onResume();
        LogUtil.e("消息列表", "onResume");
    }

    /*
     * 分页获取数据
     * */
    public void getPageSysMessage(int page) {
//        msgAdapter.getData().clear();
        if (allMessageList.size() > (page * 10)) {
            tempMessageList.addAll(allMessageList.subList((page - 1) * 10, page * 10));
        } else {
            loadAll = true;
            tempMessageList.addAll(allMessageList.subList((page - 1) * 10, allMessageList.size()));
        }
        msgAdapter.notifyDataSetChanged();

    }

    @Override
    public void onHiddenChanged(boolean hidden) {
        LogUtil.e("onHidder", "1");
        super.onHiddenChanged(hidden);
    }


    //    删除好友 对话框
    public void showDialog1(final String str) {

        final Dialog builder = new Dialog(getContext(), R.style.jmui_default_dialog_style);
        //final Dialog builder = new Dialog(this, R.style.jmui_default_dialog_style);
        View view = LayoutInflater.from(getContext()).inflate(R.layout.dialog_content, null);

        TextView tvTitle = view.findViewById(R.id.tv_title);
        TextView tvFooter1 = view.findViewById(R.id.tv_footer1);
        TextView tvFooter2 = view.findViewById(R.id.tv_footer2);
        TextView tvDivider = view.findViewById(R.id.tv_divider);
        tvTitle.setText(str);

        tvDivider.setVisibility(View.GONE);
        tvFooter1.setVisibility(View.GONE);
//        取消

//确定
        tvFooter2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                builder.cancel();
            }
        });


        builder.setContentView(view);
        //builder.setCanceledOnTouchOutside(true);
        builder.show();
        Window window = builder.getWindow();
        WindowManager.LayoutParams lp = window.getAttributes();
        WindowManager windowManager = getActivity().getWindowManager();
        Display display = windowManager.getDefaultDisplay();
        lp.width = (int) (display.getWidth() * 0.7);
//        lp.height = (int) (display.getHeight() * 0.1);
        window.setAttributes(lp);
    }

}
