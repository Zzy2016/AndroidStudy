package com.huidr.HuiDrDoctor.module.home;

import java.util.List;

/**
 * @author: Administrator
 * @date: 2019-11-22
 */
public class ReportModel {


    /**
     * status : 0
     * page : 1
     * totalPage : 78
     * retValue : {"follows":[{"id":69907,"userName":"啦啦哦","userSex":1,"bindUserRelationship":"丈夫","doctorId":100137,"bindUid":140843,"followupState":2,"isFollow":false},{"id":85458,"userName":"患者段","userSex":1,"userIcon":"141162/patient/1575962226050471.png","bindUserRelationship":"其他","doctorId":100137,"bindUid":141162,"followupState":2,"isFollow":true},{"id":85951,"userName":"fgh ","userSex":1,"userIcon":"100137/patient/1574059352187315.png","bindUserRelationship":"其他","doctorId":100137,"bindUid":100137,"followupState":2,"isFollow":false},{"id":85822,"userName":"我们一起","userSex":2,"bindUserRelationship":"丈夫","doctorId":100137,"bindUid":141065,"followupState":2,"isFollow":false},{"id":69889,"userName":"钟慧娟","userSex":2,"latelyAdmitNo":"1198187","latelyBed":"101","bindUserRelationship":"其他","latelyAdmissionDiagnosis":"腰椎间盘突出","latelyVisitingDate":"2019-04-24","doctorId":100137,"bindUid":100137,"followupState":2,"isFollow":false},{"id":81188,"userName":"东皇","userSex":1,"bindUserRelationship":"本人","doctorId":100137,"bindUid":141061,"followupState":2,"isFollow":false},{"id":45839,"userName":"钱进军","userSex":1,"latelyAdmitNo":"1147756","latelyBed":"15","bindUserRelationship":"丈夫","latelyAdmissionDiagnosis":"肝占位性病变","latelyDischargeDiagnosis":"肝占位性病变","latelyDischargeTime":"2018-09-14","latelyVisitingDate":"2018-09-14","doctorId":100137,"bindUid":100162,"followupState":2,"isFollow":false},{"id":45846,"userName":"沈铭昌","userSex":1,"latelyAdmitNo":"692170","latelyBed":"13","bindUserRelationship":"本人","latelyAdmissionDiagnosis":"结直肠恶性肿瘤伴肝转移,肺转移性肿瘤,高血压,前列腺增生","latelyDischargeDiagnosis":"结直肠恶性肿瘤伴肝转移,肺转移性肿瘤(IV期),高血压,前列腺增生","latelyDischargeTime":"2019-04-24","latelyVisitingDate":"2019-04-23","doctorId":100137,"bindUid":141024,"followupState":2,"isFollow":true},{"id":70555,"userName":"糖糖","userSex":2,"bindUserRelationship":"妻子","doctorId":100137,"bindUid":140956,"followupState":2,"isFollow":false},{"id":70168,"userName":"走走","userSex":1,"bindUserRelationship":"其他","doctorId":100137,"bindUid":140968,"followupState":2,"isFollow":false},{"id":70015,"userName":"来咯","userSex":2,"bindUserRelationship":"丈夫","doctorId":100137,"bindUid":140904,"followupState":2,"isFollow":false},{"id":70090,"userName":"测试测试测试","userSex":1,"bindUserRelationship":"其他","doctorId":100137,"bindUid":140928,"followupState":2,"isFollow":false},{"id":68635,"userName":"测试","userSex":1,"bindUserRelationship":"其他","doctorId":100137,"bindUid":100223,"followupState":2,"isFollow":false},{"id":70086,"userName":"某某某","userSex":1,"bindUserRelationship":"其他","doctorId":100137,"bindUid":140926,"followupState":2,"isFollow":false},{"id":45833,"userName":"张丽微","userSex":2,"latelyAdmitNo":"1148145","latelyBed":"10","bindUserRelationship":"本人","latelyAdmissionDiagnosis":"肝恶性肿瘤(综合治疗)","latelyDischargeDiagnosis":"肝恶性肿瘤(综合治疗)","latelyDischargeTime":"2018-10-30","latelyVisitingDate":"2018-12-05","doctorId":100137,"bindUid":140980,"followupState":2,"isFollow":false},{"id":45832,"userName":"徐炳荣","userSex":1,"latelyAdmitNo":"830627","latelyBed":"118","bindUserRelationship":"丈夫","latelyAdmissionDiagnosis":"肝占位性病变","latelyDischargeDiagnosis":"肝占位性病变","latelyDischargeTime":"2016-01-05","latelyVisitingDate":"2019-04-22","doctorId":100137,"bindUid":100295,"followupState":2,"isFollow":false},{"id":45828,"userName":"周玉梅","userSex":2,"latelyAdmitNo":"890313","latelyBed":"108","bindUserRelationship":"其他","latelyAdmissionDiagnosis":"肝囊肿,胆囊结石","latelyDischargeDiagnosis":"肝囊肿,胆囊结石","latelyDischargeTime":"2015-02-09","latelyVisitingDate":"2019-02-22","doctorId":100137,"bindUid":100137,"followupState":2,"isFollow":false},{"id":68627,"userName":"何童鹤","userSex":2,"latelyAdmitNo":"1197110","latelyBed":"41","latelyAdmissionDiagnosis":"肝血管瘤","latelyVisitingDate":"2019-04-20","doctorId":100137,"followupState":2,"isFollow":false},{"id":68623,"userName":"周云山","userSex":1,"latelyAdmitNo":"682201","latelyBed":"29","latelyAdmissionDiagnosis":"左侧肝占位性病变,右侧肝囊肿,2型糖尿病","latelyVisitingDate":"2019-04-19","doctorId":100137,"followupState":2,"isFollow":true},{"id":68608,"userName":"金正荣","userSex":1,"latelyAdmitNo":"1196607","latelyBed":"37","latelyAdmissionDiagnosis":"肝占位性病变","latelyVisitingDate":"2019-04-18","doctorId":100137,"followupState":2,"isFollow":false}],"followNum":5}
     */

    private int status;
    private int page;
    private int totalPage;
    private RetValueBean retValue;

    public int getStatus() {
        return status;
    }

    public void setStatus(int status) {
        this.status = status;
    }

    public int getPage() {
        return page;
    }

    public void setPage(int page) {
        this.page = page;
    }

    public int getTotalPage() {
        return totalPage;
    }

    public void setTotalPage(int totalPage) {
        this.totalPage = totalPage;
    }

    public RetValueBean getRetValue() {
        return retValue;
    }

    public void setRetValue(RetValueBean retValue) {
        this.retValue = retValue;
    }

    public static class RetValueBean {
        /**
         * follows : [{"id":69907,"userName":"啦啦哦","userSex":1,"bindUserRelationship":"丈夫","doctorId":100137,"bindUid":140843,"followupState":2,"isFollow":false},{"id":85458,"userName":"患者段","userSex":1,"userIcon":"141162/patient/1575962226050471.png","bindUserRelationship":"其他","doctorId":100137,"bindUid":141162,"followupState":2,"isFollow":true},{"id":85951,"userName":"fgh ","userSex":1,"userIcon":"100137/patient/1574059352187315.png","bindUserRelationship":"其他","doctorId":100137,"bindUid":100137,"followupState":2,"isFollow":false},{"id":85822,"userName":"我们一起","userSex":2,"bindUserRelationship":"丈夫","doctorId":100137,"bindUid":141065,"followupState":2,"isFollow":false},{"id":69889,"userName":"钟慧娟","userSex":2,"latelyAdmitNo":"1198187","latelyBed":"101","bindUserRelationship":"其他","latelyAdmissionDiagnosis":"腰椎间盘突出","latelyVisitingDate":"2019-04-24","doctorId":100137,"bindUid":100137,"followupState":2,"isFollow":false},{"id":81188,"userName":"东皇","userSex":1,"bindUserRelationship":"本人","doctorId":100137,"bindUid":141061,"followupState":2,"isFollow":false},{"id":45839,"userName":"钱进军","userSex":1,"latelyAdmitNo":"1147756","latelyBed":"15","bindUserRelationship":"丈夫","latelyAdmissionDiagnosis":"肝占位性病变","latelyDischargeDiagnosis":"肝占位性病变","latelyDischargeTime":"2018-09-14","latelyVisitingDate":"2018-09-14","doctorId":100137,"bindUid":100162,"followupState":2,"isFollow":false},{"id":45846,"userName":"沈铭昌","userSex":1,"latelyAdmitNo":"692170","latelyBed":"13","bindUserRelationship":"本人","latelyAdmissionDiagnosis":"结直肠恶性肿瘤伴肝转移,肺转移性肿瘤,高血压,前列腺增生","latelyDischargeDiagnosis":"结直肠恶性肿瘤伴肝转移,肺转移性肿瘤(IV期),高血压,前列腺增生","latelyDischargeTime":"2019-04-24","latelyVisitingDate":"2019-04-23","doctorId":100137,"bindUid":141024,"followupState":2,"isFollow":true},{"id":70555,"userName":"糖糖","userSex":2,"bindUserRelationship":"妻子","doctorId":100137,"bindUid":140956,"followupState":2,"isFollow":false},{"id":70168,"userName":"走走","userSex":1,"bindUserRelationship":"其他","doctorId":100137,"bindUid":140968,"followupState":2,"isFollow":false},{"id":70015,"userName":"来咯","userSex":2,"bindUserRelationship":"丈夫","doctorId":100137,"bindUid":140904,"followupState":2,"isFollow":false},{"id":70090,"userName":"测试测试测试","userSex":1,"bindUserRelationship":"其他","doctorId":100137,"bindUid":140928,"followupState":2,"isFollow":false},{"id":68635,"userName":"测试","userSex":1,"bindUserRelationship":"其他","doctorId":100137,"bindUid":100223,"followupState":2,"isFollow":false},{"id":70086,"userName":"某某某","userSex":1,"bindUserRelationship":"其他","doctorId":100137,"bindUid":140926,"followupState":2,"isFollow":false},{"id":45833,"userName":"张丽微","userSex":2,"latelyAdmitNo":"1148145","latelyBed":"10","bindUserRelationship":"本人","latelyAdmissionDiagnosis":"肝恶性肿瘤(综合治疗)","latelyDischargeDiagnosis":"肝恶性肿瘤(综合治疗)","latelyDischargeTime":"2018-10-30","latelyVisitingDate":"2018-12-05","doctorId":100137,"bindUid":140980,"followupState":2,"isFollow":false},{"id":45832,"userName":"徐炳荣","userSex":1,"latelyAdmitNo":"830627","latelyBed":"118","bindUserRelationship":"丈夫","latelyAdmissionDiagnosis":"肝占位性病变","latelyDischargeDiagnosis":"肝占位性病变","latelyDischargeTime":"2016-01-05","latelyVisitingDate":"2019-04-22","doctorId":100137,"bindUid":100295,"followupState":2,"isFollow":false},{"id":45828,"userName":"周玉梅","userSex":2,"latelyAdmitNo":"890313","latelyBed":"108","bindUserRelationship":"其他","latelyAdmissionDiagnosis":"肝囊肿,胆囊结石","latelyDischargeDiagnosis":"肝囊肿,胆囊结石","latelyDischargeTime":"2015-02-09","latelyVisitingDate":"2019-02-22","doctorId":100137,"bindUid":100137,"followupState":2,"isFollow":false},{"id":68627,"userName":"何童鹤","userSex":2,"latelyAdmitNo":"1197110","latelyBed":"41","latelyAdmissionDiagnosis":"肝血管瘤","latelyVisitingDate":"2019-04-20","doctorId":100137,"followupState":2,"isFollow":false},{"id":68623,"userName":"周云山","userSex":1,"latelyAdmitNo":"682201","latelyBed":"29","latelyAdmissionDiagnosis":"左侧肝占位性病变,右侧肝囊肿,2型糖尿病","latelyVisitingDate":"2019-04-19","doctorId":100137,"followupState":2,"isFollow":true},{"id":68608,"userName":"金正荣","userSex":1,"latelyAdmitNo":"1196607","latelyBed":"37","latelyAdmissionDiagnosis":"肝占位性病变","latelyVisitingDate":"2019-04-18","doctorId":100137,"followupState":2,"isFollow":false}]
         * followNum : 5
         */

        private int followNum;
        private List<FollowsBean> follows;

        public int getFollowNum() {
            return followNum;
        }

        public void setFollowNum(int followNum) {
            this.followNum = followNum;
        }

        public List<FollowsBean> getFollows() {
            return follows;
        }

        public void setFollows(List<FollowsBean> follows) {
            this.follows = follows;
        }

        public static class FollowsBean {
            /**
             * id : 69907
             * userName : 啦啦哦
             * userSex : 1
             * bindUserRelationship : 丈夫
             * doctorId : 100137
             * bindUid : 140843
             * followupState : 2
             * isFollow : false
             * userIcon : 141162/patient/1575962226050471.png
             * latelyAdmitNo : 1198187
             * latelyBed : 101
             * latelyAdmissionDiagnosis : 腰椎间盘突出
             * latelyVisitingDate : 2019-04-24
             * latelyDischargeDiagnosis : 肝占位性病变
             * latelyDischargeTime : 2018-09-14
             */

            private int id;
            private String userName;
            private int userSex;
            private String bindUserRelationship;
            private int doctorId;
            private int bindUid;
            private int followupState;
            private boolean isFollow;
            private String userIcon;
            private String latelyAdmitNo;
            private String latelyBed;
            private String latelyAdmissionDiagnosis;
            private String latelyVisitingDate;
            private String latelyDischargeDiagnosis;
            private String latelyDischargeTime;

            public int getId() {
                return id;
            }

            public void setId(int id) {
                this.id = id;
            }

            public String getUserName() {
                return userName;
            }

            public void setUserName(String userName) {
                this.userName = userName;
            }

            public int getUserSex() {
                return userSex;
            }

            public void setUserSex(int userSex) {
                this.userSex = userSex;
            }

            public String getBindUserRelationship() {
                return bindUserRelationship;
            }

            public void setBindUserRelationship(String bindUserRelationship) {
                this.bindUserRelationship = bindUserRelationship;
            }

            public int getDoctorId() {
                return doctorId;
            }

            public void setDoctorId(int doctorId) {
                this.doctorId = doctorId;
            }

            public int getBindUid() {
                return bindUid;
            }

            public void setBindUid(int bindUid) {
                this.bindUid = bindUid;
            }

            public int getFollowupState() {
                return followupState;
            }

            public void setFollowupState(int followupState) {
                this.followupState = followupState;
            }

            public boolean isIsFollow() {
                return isFollow;
            }

            public void setIsFollow(boolean isFollow) {
                this.isFollow = isFollow;
            }

            public String getUserIcon() {
                return userIcon;
            }

            public void setUserIcon(String userIcon) {
                this.userIcon = userIcon;
            }

            public String getLatelyAdmitNo() {
                return latelyAdmitNo;
            }

            public void setLatelyAdmitNo(String latelyAdmitNo) {
                this.latelyAdmitNo = latelyAdmitNo;
            }

            public String getLatelyBed() {
                return latelyBed;
            }

            public void setLatelyBed(String latelyBed) {
                this.latelyBed = latelyBed;
            }

            public String getLatelyAdmissionDiagnosis() {
                return latelyAdmissionDiagnosis;
            }

            public void setLatelyAdmissionDiagnosis(String latelyAdmissionDiagnosis) {
                this.latelyAdmissionDiagnosis = latelyAdmissionDiagnosis;
            }

            public String getLatelyVisitingDate() {
                return latelyVisitingDate;
            }

            public void setLatelyVisitingDate(String latelyVisitingDate) {
                this.latelyVisitingDate = latelyVisitingDate;
            }

            public String getLatelyDischargeDiagnosis() {
                return latelyDischargeDiagnosis;
            }

            public void setLatelyDischargeDiagnosis(String latelyDischargeDiagnosis) {
                this.latelyDischargeDiagnosis = latelyDischargeDiagnosis;
            }

            public String getLatelyDischargeTime() {
                return latelyDischargeTime;
            }

            public void setLatelyDischargeTime(String latelyDischargeTime) {
                this.latelyDischargeTime = latelyDischargeTime;
            }
        }
    }
}
