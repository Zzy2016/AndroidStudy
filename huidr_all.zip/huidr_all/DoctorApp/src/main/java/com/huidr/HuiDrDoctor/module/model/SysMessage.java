package com.huidr.HuiDrDoctor.module.model;

import org.litepal.crud.LitePalSupport;

/*
 *   患者 随访报到 问卷提交   未读标识 姓名 性别 年龄 日期 文字
 *   医生 联系人申请 拒绝     未读标示 姓名  职称科室 日期
 *
 *   荟医消息 提现
 *
 *   初始消息
 *
 * */
public class SysMessage extends LitePalSupport {

    int readFlag;  //0未读  1已读
    String name;
    String time;
    String sysMsgContent;
    String headImage;
    int sysType;//消息类型  0患者 1医生 2提现 3初始欢迎
    String url;
    String gender;//性别
    String age;//年龄
    String title;//职称
    String dept;//科室

    public String getHeadImage() {
        return headImage;
    }

    public void setHeadImage(String headImage) {
        this.headImage = headImage;
    }

    public int getSysType() {
        return sysType;
    }

    public void setSysType(int sysType) {
        this.sysType = sysType;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public String getAge() {
        return age;
    }

    public void setAge(String age) {
        this.age = age;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getDept() {
        return dept;
    }

    public void setDept(String dept) {
        this.dept = dept;
    }

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state;
    }

    String state;//状态


    public int getReadFlag() {
        return readFlag;
    }

    public void setReadFlag(int readFlag) {
        this.readFlag = readFlag;
    }

    public String getSysMsgContent() {
        return sysMsgContent;
    }

    public void setSysMsgContent(String sysMsgContent) {
        this.sysMsgContent = sysMsgContent;
    }


    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    @Override
    public String toString() {
        return "SysMessage{" + "readFlag=" + readFlag + ", name='" + name + '\'' + ", time='" + time + '\'' + ", sysMsgContent='" + sysMsgContent + '\'' + ", headImage='" + headImage + '\'' + ", sysType=" + sysType + ", url='" + url + '\'' + ", gender='" + gender + '\'' + ", age='" + age + '\'' + ", title='" + title + '\'' + ", dept='" + dept + '\'' + ", state='" + state + '\'' + '}';
    }
}
