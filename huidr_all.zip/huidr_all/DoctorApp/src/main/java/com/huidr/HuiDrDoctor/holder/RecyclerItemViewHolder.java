package com.huidr.HuiDrDoctor.holder;


import android.view.View;
import android.widget.TextView;

import com.huidr.HuiDrDoctor.debug.R;

import androidx.recyclerview.widget.RecyclerView;

/**
 * @author: Administrator
 * @date: 2019-11-13
 */
public class RecyclerItemViewHolder extends RecyclerView.ViewHolder {

    private final TextView mItemTextView;

    public RecyclerItemViewHolder(final View parent, TextView itemTextView) {
        super(parent);
        mItemTextView = itemTextView;
    }

    public static RecyclerItemViewHolder newInstance(View parent) {
        TextView itemTextView = (TextView) parent.findViewById(R.id.tv_item_name);
        return new RecyclerItemViewHolder(parent, itemTextView);
    }

    public void setItemText(CharSequence text) {
        mItemTextView.setText(text);
    }

}
