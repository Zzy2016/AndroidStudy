package com.huidr.HuiDrDoctor.activity;

import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;

import androidx.appcompat.app.AppCompatActivity;
import android.view.View;
import android.view.WindowManager;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.alibaba.fastjson.JSONObject;
import com.google.gson.Gson;
import com.huidr.HuiDrDoctor.activity.main.Consult.fragment.CompleteFragment;
import com.huidr.HuiDrDoctor.activity.main.Consult.fragment.ConversationFragment;
import com.huidr.HuiDrDoctor.activity.main.Consult.fragment.InvitationFragment;
import com.huidr.HuiDrDoctor.activity.main.Consult.utils.PostAndGet;
import com.huidr.HuiDrDoctor.debug.BuildConfig;
import com.huidr.HuiDrDoctor.debug.R;
import com.huidr.HuiDrDoctor.module.consult.ConsultOrderList;
import com.huidr.HuiDrDoctor.util.LogUtil;
import com.huidr.HuiDrDoctor.util.ThreadPoolManager;
import com.tendcloud.tenddata.TCAgent;

import org.greenrobot.eventbus.EventBus;
import org.greenrobot.eventbus.Subscribe;
import org.greenrobot.eventbus.ThreadMode;

import java.util.List;

import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;
import cn.jpush.im.android.api.JMessageClient;
import cn.jpush.im.android.api.event.ContactNotifyEvent;
import cn.jpush.im.android.api.event.MessageEvent;
import cn.jpush.im.android.api.event.OfflineMessageEvent;
import cn.jpush.im.android.api.model.Conversation;
import cn.jpush.im.api.BasicCallback;
import jiguang.chat.database.FriendRecommendEntry;
import jiguang.chat.database.UserEntry;
import jiguang.chat.utils.event.BusEventMessage;
import jiguang.chat.utils.oss.Constants;
import jiguang.chat.utils.oss.SharedPreferenciesUtil;

/*
 * 咨询记录
 *
 * 待接受
 * 咨询中
 * 已结束
 */
public class ConsultRecordActivity extends AppCompatActivity implements View.OnClickListener {


    ImageView imgBack;
    TextView tvRight;
    TextView tv1, tv2, tv3;
    ImageView imgRead1, imgRead2, imgRead3;
    RelativeLayout rl1, rl2, rl3;
    FragmentManager fm;
    FragmentTransaction ft;
    int currentIndex = 3;
    UserEntry userEntry;
    private List<FriendRecommendEntry> mList;//邀请
    private List<Conversation> conversationList;//对话
    private int allUnRead;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
            getWindow().addFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS);
        }

        JMessageClient.registerEventReceiver(this);
        if (JMessageClient.getMyInfo() == null) {
            String id = (String) SharedPreferenciesUtil.getData(Constants.SharedAccountConfig.ID, "0");
            String impassword = (String) SharedPreferenciesUtil.getData(Constants.SharedAccountConfig.ImPassword, "0");
            JMessageClient.login(id, impassword, new BasicCallback() {
                @Override
                public void gotResult(int i, String s) {

                }
            });
        }

        EventBus.getDefault().register(this);
        setContentView(R.layout.activity_consult_record);
    }

    public void changeFragment(int page) {
        fm = getSupportFragmentManager();
        ft = fm.beginTransaction();
        switch (page) {
            case 0:
                ft.replace(R.id.rl_content, new InvitationFragment());
                currentIndex = 0;
                break;
            case 1:
                ft.replace(R.id.rl_content, new ConversationFragment());
                currentIndex = 1;
                break;
            case 2:
                ft.replace(R.id.rl_content, new CompleteFragment());
                currentIndex = 2;
                break;
        }

//        ft.commit();
        ft.commitAllowingStateLoss();
    }


    public void initView() {
        imgBack = (ImageView) findViewById(R.id.img_back);
        tvRight = (TextView) findViewById(R.id.tv_right);
        tv1 = (TextView) findViewById(R.id.tv1);
        tv2 = (TextView) findViewById(R.id.tv2);
        tv3 = (TextView) findViewById(R.id.tv3);
        imgRead1 = (ImageView) findViewById(R.id.img_read1);
        imgRead2 = (ImageView) findViewById(R.id.img_read2);
        imgRead3 = (ImageView) findViewById(R.id.img_read3);
        rl1 = (RelativeLayout) findViewById(R.id.rl1);
        rl2 = (RelativeLayout) findViewById(R.id.rl2);
        rl3 = (RelativeLayout) findViewById(R.id.rl3);
        imgBack.setOnClickListener(this);
        tvRight.setOnClickListener(this);
        rl1.setOnClickListener(this);
        rl2.setOnClickListener(this);
        rl3.setOnClickListener(this);
        getInvitationList();
    }


    /*
     * 查询未读 邀请 会话
     查询待接收 咨询中列表
     并循环列表 查询是否有未读消息 如果有 显示红点
     * 1 1 待接收
     * 2 3 咨询中
     * */
    public void getInvitationList() {
        final String doctorID = (String) SharedPreferenciesUtil.getData("id", "0");
        ThreadPoolManager.getInstance().execute(new Runnable() {
            @Override
            public void run() {
                String str = BuildConfig.baseUrl + "pay/orderSearch/searchOrder";
                JSONObject jsonObject = new JSONObject();
                jsonObject.put("orderStatus", 1);
                jsonObject.put("orderStatusAction", 1);
                jsonObject.put("orderKind", 2);
                jsonObject.put("sellerId", doctorID);
                jsonObject.put("pageIndex", 1);
                String invitationResult = PostAndGet.doHttpPost(str, jsonObject);
                JSONObject jsonObject1 = new JSONObject();
                jsonObject1.put("orderStatus", 2);
                jsonObject.put("orderStatusAction", 3);
                jsonObject1.put("orderKind", 2);
                jsonObject1.put("sellerId", doctorID);
                jsonObject1.put("pageIndex", 1);
                String conversionResult = PostAndGet.doHttpPost(str, jsonObject1);
                Gson gson = new Gson();
                ConsultOrderList invitationList = gson.fromJson(invitationResult, ConsultOrderList.class);
                ConsultOrderList conversionList = gson.fromJson(conversionResult, ConsultOrderList.class);
                if (invitationList.getRetValue().size() == 0) {
                    EventBus.getDefault().post(new BusEventMessage("1"));
                } else {
                    EventBus.getDefault().post(new BusEventMessage("0"));
                }
                int unReadCount = 0;
                for (int i = 0; i < conversionList.getRetValue().size(); i++) {
                    ConsultOrderList.RetValueBean item = conversionList.getRetValue().get(i);
                    Conversation conversation = JMessageClient.getSingleConversation(item.getBuyerId() + "", BuildConfig.patientAppkey);
                    if (conversation != null) {
                        unReadCount += conversation.getUnReadMsgCnt();
                    }
                }
                if (unReadCount == 0) {
                    EventBus.getDefault().post(new BusEventMessage("3"));
                } else {
                    EventBus.getDefault().post(new BusEventMessage("2"));
                }
            }
        });
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.img_back:
                finish();
                break;
            case R.id.tv_right:
                TCAgent.onEvent(this, "点击图文设置次数", "点击图文设置次数");

                Intent intent = new Intent(ConsultRecordActivity.this, WebActivity.class);
                Bundle bundle = new Bundle();
                bundle.putString("url", "consultation.html");
                intent.putExtras(bundle);
                startActivity(intent);
//                finish();
                break;
            case R.id.rl1:
                TCAgent.onEvent(this, "待接受咨询状态点击次数", "待接受咨询状态点击次数");

                tv1.setTextColor(getResources().getColor(R.color.colorPrimary));
                tv2.setTextColor(getResources().getColor(R.color.gray));
                tv3.setTextColor(getResources().getColor(R.color.gray));
                changeFragment(0);
                break;
            case R.id.rl2:
                TCAgent.onEvent(this, "咨询中咨询状态点击次数", "咨询中咨询状态点击次数");

                tv1.setTextColor(getResources().getColor(R.color.gray));
                tv2.setTextColor(getResources().getColor(R.color.colorPrimary));
                tv3.setTextColor(getResources().getColor(R.color.gray));
                changeFragment(1);
                break;
            case R.id.rl3:
                TCAgent.onEvent(this, "已结束咨询状态点击次数", "已结束咨询状态点击次数");

                tv1.setTextColor(getResources().getColor(R.color.gray));
                tv2.setTextColor(getResources().getColor(R.color.gray));
                tv3.setTextColor(getResources().getColor(R.color.colorPrimary));
                changeFragment(2);
                break;
        }
    }

    /*
     * 显示消息红点
     * 0 待接受显示
     * 1 待接收隐藏
     * 2 咨询中显示
     * 3 咨询中隐藏
     * 4 已结束显示
     * 5 已结束隐藏
     *
     * */
    @Subscribe(threadMode = ThreadMode.MAIN)
    public void onEvent(BusEventMessage message) {
        LogUtil.e("红点", message.getEventType());
        switch (message.getEventType()) {
            case "0":
                imgRead1.setVisibility(View.VISIBLE);
                break;
            case "1":
                imgRead1.setVisibility(View.GONE);
                break;
            case "2":
                imgRead2.setVisibility(View.VISIBLE);
                break;
            case "3":
                imgRead2.setVisibility(View.GONE);
                break;
            case "4":

                break;
            case "5":

                break;

        }

    }


    @Override
    protected void onDestroy() {
        super.onDestroy();
        EventBus.getDefault().unregister(this);
    }

    /*
     * currentIndex 刷新页面
     * 如果currentIndex不等于3
     * 刷新页面    *
     * */
    @Override
    protected void onResume() {
        super.onResume();
        if (currentIndex != 3) {
            changeFragment(currentIndex);
        } else {
            changeFragment(0);
        }
        LogUtil.e("未读resume", "weiduresume" + currentIndex);
        initView();
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
    }

    public void onEvent(MessageEvent event) {
        if (event.getMessage().getFromAppKey().equals(BuildConfig.patientAppkey)) {
            getInvitationList();
        }
    }


    /**
     * 接收离线消息
     *
     * @param event 离线消息事件
     */
    public void onEvent(OfflineMessageEvent event) {
        if (event.getConversation().getTargetAppKey().equals(BuildConfig.patientAppkey)) {
            getInvitationList();
        }
    }


    //    收到邀请
    public void onEvent(ContactNotifyEvent event) {
        if (event.getfromUserAppKey().equals(BuildConfig.patientAppkey)) {
            new Handler().postDelayed(new Runnable() {
                @Override
                public void run() {
                    getInvitationList();
                }
            }, 2000);
        }
    }


}
