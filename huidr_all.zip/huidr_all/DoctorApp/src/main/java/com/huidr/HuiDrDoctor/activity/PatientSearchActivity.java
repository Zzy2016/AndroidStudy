package com.huidr.HuiDrDoctor.activity;

import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import androidx.annotation.NonNull;

import androidx.appcompat.app.AppCompatActivity;

import android.text.Editable;
import android.text.Html;
import android.text.TextWatcher;
import android.util.Log;
import android.view.Display;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.alibaba.fastjson.JSONObject;
import com.chad.library.adapter.base.BaseQuickAdapter;
import com.chad.library.adapter.base.BaseViewHolder;
import com.google.android.flexbox.FlexDirection;
import com.google.android.flexbox.FlexWrap;
import com.google.android.flexbox.FlexboxLayoutManager;
import com.google.gson.Gson;
import com.huidr.HuiDrDoctor.activity.main.Consult.utils.PostAndGet;
import com.huidr.HuiDrDoctor.debug.BuildConfig;
import com.huidr.HuiDrDoctor.debug.R;
import com.huidr.HuiDrDoctor.module.home.DeleteHisModel;
import com.huidr.HuiDrDoctor.module.home.HisSearchModel;
import com.huidr.HuiDrDoctor.module.home.PatientSearchModel;
import com.huidr.HuiDrDoctor.module.home.SimpleResultModel;
import com.huidr.HuiDrDoctor.util.LogUtil;
import com.huidr.HuiDrDoctor.util.ThreadPoolManager;
import com.scwang.smartrefresh.layout.SmartRefreshLayout;
import com.scwang.smartrefresh.layout.api.RefreshLayout;
import com.scwang.smartrefresh.layout.listener.OnLoadMoreListener;
import com.scwang.smartrefresh.layout.listener.OnRefreshListener;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Pattern;

import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import jiguang.chat.utils.oss.SharedPreferenciesUtil;

/*
 * 患者池搜索
 *
 * */
public class PatientSearchActivity extends AppCompatActivity implements View.OnClickListener {


    ImageView imgSearch, imgClear;
    EditText etSearch;
    TextView tvCancel;

    SmartRefreshLayout srlLayout;
    RecyclerView rvSearch;
    ConstraintLayout clHis;
    RecyclerView rvHisSearch;

    ConstraintLayout clEmptyHis;
    TextView tvEmptyHis1, tvEmptyHis2;


    ConstraintLayout clEmpty;

    InputMethodManager imm;

    //    空态
    TextView tvEmpty;
    TextView tvEmpty1;
    Button btnLink;

    boolean showSearch;//显示搜索 true

    List<HisSearchModel.RetValueBean> searchHis;//搜索历史
    HisSearchModel hisSearchModel;

    List<PatientSearchModel.RetValueBean> searchResultList;

    int currentPage = 1;
    int totalPage = 1;

    Gson gson;
    PatientSearchModel patientSearchModel;


    String path = BuildConfig.baseUrl + "patient/doctorPatientMedical/getFollowUpPoolList"; //患者搜索

    String pathHis = BuildConfig.baseUrl + "hospital/search/searchHis";//历史搜索

    long lastClick = 0;
    Pattern pattern;

    String searchStr;//搜索关键字

    ImageView imgDeleteHis;//img_delete_his

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_patient_search);

        imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
        pattern = Pattern.compile("^\\s*$");
        initDate();
        initEmptyView();
        initSearchResultView();
        initHisSearch();
        initView();

    }

    //    隐藏软键盘
    public void hideImm(EditText editText) {
        if (imm != null) {
            imm.hideSoftInputFromWindow(editText.getWindowToken(), 0);
        }
    }

    public void initDate() {
        gson = new Gson();
        patientSearchModel = new PatientSearchModel();
        searchHis = new ArrayList<>();
        hisSearchModel = new HisSearchModel();

        hisAdapter.setNewData(searchHis);

        searchResultList = new ArrayList<>();
        searchAdapter.setNewData(searchResultList);

        getHisSearch();
    }

    //    获取搜索历史
    public void getHisSearch() {
        ThreadPoolManager.getInstance().execute(new Runnable() {
            @Override
            public void run() {
                JSONObject jsonObject = new JSONObject();
                jsonObject.put("searchType", 7);
                String result = PostAndGet.doHttpPost(pathHis, jsonObject);
                LogUtil.e("搜索历史", result);
                if (result.equals("网络异常")) {
                    handler.sendEmptyMessage(7);
                } else {
                    hisSearchModel = gson.fromJson(result, HisSearchModel.class);
                    if (hisSearchModel.getStatus() == 0) {
                        handler.sendEmptyMessage(6);
                    } else {
                        handler.sendEmptyMessage(7);
                    }
                }
            }
        });
    }

    //    空态页
    public void initEmptyView() {
        clEmpty = (ConstraintLayout) findViewById(R.id.cl_empty);
    }


    //    搜索结果
    public void initSearchResultView() {
        srlLayout = (SmartRefreshLayout) findViewById(R.id.srl_layout);
        srlLayout.setEnableRefresh(true);
        srlLayout.setEnableLoadMore(true);

        srlLayout.setOnRefreshListener(new OnRefreshListener() {
            @Override
            public void onRefresh(@NonNull RefreshLayout refreshLayout) {
//                srlLayout.finishRefresh();
                currentPage = 1;
                getDataByPage();
            }
        });

        srlLayout.setOnLoadMoreListener(new OnLoadMoreListener() {
            @Override
            public void onLoadMore(@NonNull RefreshLayout refreshLayout) {
//                srlLayout.finishLoadMore();
                if (patientSearchModel.getRetValue().size() == 20 && currentPage < totalPage) {
                    currentPage += 1;
                    getDataByPage();
                } else {
                    com.huidr.lib.commom.util.Toast.getInstance(PatientSearchActivity.this).show("数据加载全部", 500);
                    srlLayout.finishLoadMore();
                }
            }
        });

        rvSearch = (RecyclerView) findViewById(R.id.rv_search);
        rvSearch.setAdapter(searchAdapter);
        rvSearch.setLayoutManager(new LinearLayoutManager(this));

    }

    //    历史搜索
    public void initHisSearch() {
        clHis = (ConstraintLayout) findViewById(R.id.cl_his);
        rvHisSearch = (RecyclerView) findViewById(R.id.rv_his_search);

        rvHisSearch.setAdapter(hisAdapter);
//        rvHisSearch.setLayoutManager(new GridLayoutManager(this, 4));

        FlexboxLayoutManager manager = new FlexboxLayoutManager(this, FlexDirection.ROW, FlexWrap.WRAP) {
            @Override
            public boolean canScrollVertically() {
                return false;
            }
        };

        rvHisSearch.setLayoutManager(manager);

        clEmptyHis = (ConstraintLayout) findViewById(R.id.cl_empty_his);
        tvEmptyHis1 = (TextView) findViewById(R.id.tv_empty_his1);
        tvEmptyHis2 = (TextView) findViewById(R.id.tv_empty_his2);

    }

    public void initView() {

        imgSearch = (ImageView) findViewById(R.id.image_search);
        imgClear = (ImageView) findViewById(R.id.image_clear);
        etSearch = (EditText) findViewById(R.id.et_search);
        tvCancel = (TextView) findViewById(R.id.tv_cancel);

        tvEmpty = (TextView) findViewById(R.id.tv_empty);
        tvEmpty1 = (TextView) findViewById(R.id.tv_empty1);
        btnLink = (Button) findViewById(R.id.btn_link);

        imgSearch.setOnClickListener(this);
        imgClear.setOnClickListener(this);
        tvCancel.setOnClickListener(this);

        btnLink.setOnClickListener(this);

        etSearch.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {
                if (etSearch.getText().toString().length() > 0) {
                    imgClear.setVisibility(View.VISIBLE);
                } else {
                    imgClear.setVisibility(View.GONE);
                }
            }
        });

        /*
         * doKeySearch();  键盘监听
         * */
        etSearch.setOnEditorActionListener(new TextView.OnEditorActionListener() {
            @Override
            public boolean onEditorAction(TextView v, int actionId, KeyEvent event) {
                if (actionId == 3) {//
//                    if (etSearch.getText().toString().length() == 0 || pattern.matcher(etSearch.getText().toString()).matches()) {
//
//                        return true;
//                    } else {
//                        doKeySearch();
//
//                        return true;
//                    }

                    searchStr = etSearch.getText().toString();
                    if (searchStr.length() > 0) {
                        if (pattern.matcher(searchStr).matches()) {
                            Toast.makeText(PatientSearchActivity.this, "请重新输入", Toast.LENGTH_SHORT).show();
                            etSearch.setText("");
                        } else {
                            doKeySearch();
                        }
                    }
                    return true;

                } else {
                    return false;
                }
            }
        });

        imgDeleteHis = (ImageView) findViewById(R.id.img_delete_his);
        imgDeleteHis.setOnClickListener(this);


    }

    private Handler handler = new Handler() {
        @Override
        public void handleMessage(Message msg) {
            super.handleMessage(msg);

            switch (msg.what) {
//                获取搜索结果成功
                case 1:
                    searchAdapter.getData().clear();
                    if (patientSearchModel.getRetValue().size() == 0) {
                        clEmpty.setVisibility(View.VISIBLE);
                        srlLayout.setVisibility(View.GONE);
                        tvEmpty1.setText("暂未搜索到该患者~");
                    } else {
                        clEmpty.setVisibility(View.GONE);
                        srlLayout.setVisibility(View.VISIBLE);
                        searchAdapter.getData().addAll(patientSearchModel.getRetValue());
                        searchAdapter.notifyDataSetChanged();
                    }
                    srlLayout.finishRefresh();
                    break;
                //                获取搜索结果成功
                case 2:
                    searchAdapter.getData().addAll(patientSearchModel.getRetValue());
                    searchAdapter.notifyDataSetChanged();
                    srlLayout.finishLoadMore();
                    break;
                //                获取搜索结果报错
                case 3:
                    clEmpty.setVisibility(View.VISIBLE);
                    srlLayout.setVisibility(View.GONE);
                    srlLayout.finishLoadMore();
                    srlLayout.finishRefresh();
                    tvEmpty1.setText("网络错误~");
                    break;
//关注患者成功
                case 4:
                    String tip = "";
                    Boolean atten = (Boolean) msg.obj;
                    if (atten) {
                        tip = "关注患者成功";
                        searchAdapter.getData().get(msg.arg1).setIsFollow(true);
                    } else {
                        tip = "取消成功";
                        searchAdapter.getData().get(msg.arg1).setIsFollow(false);
                    }
                    com.huidr.lib.commom.util.Toast.getInstance(PatientSearchActivity.this).show(tip, 500);
                    searchAdapter.notifyDataSetChanged();
                    break;
//                    关注患者失败
                case 5:
                    String str = "";
                    Boolean atten1 = (Boolean) msg.obj;
                    if (atten1) {
                        str = "关注患者失败";
                    } else {
                        str = "取消失败";
                    }
                    com.huidr.lib.commom.util.Toast.getInstance(PatientSearchActivity.this).show(str, 500);
                    break;


//                    获取历史搜索成功
                case 6:
                    hisAdapter.getData().clear();
                    if (hisSearchModel.getRetValue().size() == 0) {
                        rvHisSearch.setVisibility(View.GONE);
                        clEmptyHis.setVisibility(View.VISIBLE);
                        tvEmpty1.setText("暂无搜索历史~");
                        imgDeleteHis.setVisibility(View.GONE);
                    } else {
                        rvHisSearch.setVisibility(View.VISIBLE);
                        clEmptyHis.setVisibility(View.GONE);
                        hisAdapter.getData().addAll(hisSearchModel.getRetValue());
                        hisAdapter.notifyDataSetChanged();
                        imgDeleteHis.setVisibility(View.VISIBLE);
                    }

                    break;
//                    获取搜索历史网络错误
                case 7:
                    rvHisSearch.setVisibility(View.GONE);
                    clEmptyHis.setVisibility(View.VISIBLE);
                    tvEmptyHis1.setText("网络错误~");
                    imgDeleteHis.setVisibility(View.GONE);
                    break;

                /*删除历史记录成功*/
                case 12:
//                    imgDeleteHis.setVisibility(View.GONE);
//                    clEmptyHis.setVisibility(View.VISIBLE);
//                    tvEmpty1.setText("暂无搜索历史~");

                    getHisSearch();
                    break;
                /*删除历史记录失败*/
                case 13:
                    Toast.makeText(PatientSearchActivity.this, "删除历史失败，请稍后重试", Toast.LENGTH_SHORT).show();
                    break;
            }
        }
    };


    @Override
    protected void onStop() {
        super.onStop();
        searchAdapter.notifyDataSetChanged();
    }

    /*
        * 搜索
        * 清除
          取消
        *
        * */
    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.image_search:

                if (etSearch.getText().toString().length() > 0) {
                    Pattern pattern = Pattern.compile("^\\s*$");
                    if (pattern.matcher(etSearch.getText().toString()).matches()) {
                        Toast.makeText(PatientSearchActivity.this, "请重新输入", Toast.LENGTH_SHORT).show();
                        etSearch.setText("");
                    } else {
                        doKeySearch();
                    }
                } else {
                    Toast.makeText(PatientSearchActivity.this, "请重新输入", Toast.LENGTH_SHORT).show();
                }
                break;
            case R.id.image_clear:
                searchAdapter.getData().clear();
                searchAdapter.notifyDataSetChanged();
                etSearch.setText("");
                showSearch = false;
                refreshPage();
                getHisSearch();
                break;
            case R.id.tv_cancel:
//                searchAdapter.notifyDataSetChanged();
//                showSearch = false;
//                etSearch.setText("");
//                refreshPage();
                finish();
                break;

            /*删除历史搜索记录*/
            case R.id.img_delete_his:
                deleteHis();
                break;
        }
    }

    /*删除历史搜索记录*/
    public void deleteHis() {
        ThreadPoolManager.getInstance().execute(new Runnable() {
            @Override
            public void run() {
                String deleteUrl = BuildConfig.baseUrl + "hospital/search/delSearchHis";
                JSONObject jsonObject = new JSONObject();
                jsonObject.put("uid", (String) SharedPreferenciesUtil.getData("id", "0"));
                jsonObject.put("searchType", 7);
                String result = PostAndGet.doHttpPost(deleteUrl, jsonObject);
                Log.e("123456", result);
                if (result.equals("网络异常")) {//删除历史记录失败
                    handler.sendEmptyMessage(13);
                } else {//删除历史记录成功
                    DeleteHisModel simpleResultModel = gson.fromJson(result, DeleteHisModel.class);
                    if (simpleResultModel.getStatus() == 0) {
                        handler.sendEmptyMessage(12);
                    } else {
                        handler.sendEmptyMessage(13);
                    }
                }
            }
        });
    }

    /*
     * 关键字搜索
     * 加载第一页
     * */
    public void doKeySearch() {
        showSearch = true;
        hideImm(etSearch);
        refreshPage();
        getDataByPage();
    }

    //    分页展示搜索结果
    public void getDataByPage() {
        ThreadPoolManager.getInstance().execute(new Runnable() {
            @Override
            public void run() {
                String result = PostAndGet.doGetHttp(path + "?pageSize=20&pageIndex=" + currentPage + "&userName=" + etSearch.getText().toString());
                LogUtil.e("搜索", result);
                if (result.equals("网络异常")) {
                    handler.sendEmptyMessage(3);
                } else {
                    patientSearchModel = gson.fromJson(result, PatientSearchModel.class);
                    if (patientSearchModel.getStatus() == 0) {
                        totalPage = patientSearchModel.getTotalPage();
                        if (currentPage == 1) {
                            handler.sendEmptyMessage(1);
                        } else {
                            handler.sendEmptyMessage(2);
                        }
                    } else {
                        handler.sendEmptyMessage(3);
                    }
                }
            }
        });
    }

    /*
     * 刷新显示
     * true  显示搜索结果 搜索结果为空 显示空态页
     * false 隐藏搜搜结果页 显示搜索历史
     *
     */
    public void refreshPage() {
        if (showSearch) {
            clHis.setVisibility(View.GONE);
            srlLayout.setVisibility(View.VISIBLE);
        } else {
            clHis.setVisibility(View.VISIBLE);
            srlLayout.setVisibility(View.GONE);
            clEmpty.setVisibility(View.GONE);
            clEmptyHis.setVisibility(View.GONE);
        }
    }


    /*
     * 历史搜索 适配
     * */
    private BaseQuickAdapter<HisSearchModel.RetValueBean, BaseViewHolder> hisAdapter = new BaseQuickAdapter<HisSearchModel.RetValueBean, BaseViewHolder>(R.layout.item_tip) {
        @Override
        protected void convert(BaseViewHolder helper, final HisSearchModel.RetValueBean item) {
            TextView tvTip = helper.getView(R.id.tv_tip);
            tvTip.setText(item.getSearchContent());

            tvTip.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    etSearch.setText(item.getSearchContent());
//                    showSearch = true;
                    doKeySearch();
                }
            });
        }
    };


    /*
     * 搜索结果  适配
     *
     * */
    private BaseQuickAdapter<PatientSearchModel.RetValueBean, BaseViewHolder> searchAdapter = new BaseQuickAdapter<PatientSearchModel.RetValueBean, BaseViewHolder>(R.layout.item_scroll_layout) {
        @Override
        protected void convert(final BaseViewHolder helper, final PatientSearchModel.RetValueBean item) {

            ImageView imgItemHead = helper.getView(R.id.img_item_head);
            setPatientImage(imgItemHead, item.getBindUserRelationship(), item.getUserSex());
            ImageView imgNotice = helper.getView(R.id.img_notice);
            imgNotice.setVisibility(View.GONE);
            ImageView imageItemGender = helper.getView(R.id.image_item_gender);
            imageItemGender.setVisibility(View.VISIBLE);
            if (item.getUserSex() == 1) {
                imageItemGender.setBackgroundResource(R.drawable.gender_man);
            } else if (item.getUserSex() == 2) {
                imageItemGender.setBackgroundResource(R.drawable.gender_w);
            } else {

            }

            TextView tvItemName = helper.getView(R.id.tv_item_name);
            tvItemName.setText(item.getUserName());
            TextView tvItemAge = helper.getView(R.id.tv_item_age);
            tvItemAge.setText(item.getLatelyAdmitNo());
            TextView tvItemState = helper.getView(R.id.tv_item_state);
            TextView tvItemDate = helper.getView(R.id.tv_item_date);
            tvItemDate.setText(item.getLatelyVisitingDate());
            TextView tvItemMsg = helper.getView(R.id.tv_item_msg);

            tvItemMsg.setText(item.getLatelyAdmissionDiagnosis());

            TextView tvItemMode = helper.getView(R.id.tv_item_model);
            tvItemMode.setText(item.getFollowupName());

            TextView tvScrollRight = helper.getView(R.id.tv_scroll_right);

            Button btnApply = helper.getView(R.id.btn_apply);
            btnApply.setVisibility(View.GONE);

            String tip = "";
            if (item.isIsFollow()) {
                tip = "<font>已<br>关注<font>";
                tvScrollRight.setBackgroundResource(R.drawable.shape_atten_gray);
            } else {
                tip = "<font>关注<br>患者<font>";
            }
            tvScrollRight.setText(Html.fromHtml(tip));
            tvScrollRight.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (item.isIsFollow()) { //已经关注 取消关注
//                        modifyAttent(false, helper.getAdapterPosition(), item.getId());
                        searchAdapter.notifyDataSetChanged();
                        Toast.makeText(PatientSearchActivity.this, "该患者已关注", Toast.LENGTH_SHORT).show();
                    } else {  //未关注 添加关注
//                        modifyAttent(true, helper.getAdapterPosition(), item.getId());
                        showCoopDialog(true, helper.getAdapterPosition(), item.getId());
                    }
                }
            });

            ConstraintLayout clItem = helper.getView(R.id.cl_item);
            clItem.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (System.currentTimeMillis() - lastClick > 1000) {
                        JSONObject jsonObject = new JSONObject();
                        jsonObject.put("id", item.getId());
                        SharedPreferenciesUtil.putData("psearchID", jsonObject.toJSONString());
                        SharedPreferenciesUtil.putData("followDoctorId", item.getDoctorId());

                        Intent intent1 = new Intent(PatientSearchActivity.this, WebActivity.class);
                        Bundle bundle = new Bundle();
                        bundle.putString("url", "patientData.html");
                        intent1.putExtras(bundle);
                        startActivity(intent1);
                        lastClick = System.currentTimeMillis();
                    }
                }
            });

        }
    };

    //    取消添加协同对话框
    public void showCoopDialog(final boolean atten, final int position, final int patientId) {

        final Dialog builder = new Dialog(PatientSearchActivity.this, R.style.jmui_default_dialog_style);
        //final Dialog builder = new Dialog(this, R.style.jmui_default_dialog_style);
        View view = LayoutInflater.from(PatientSearchActivity.this).inflate(R.layout.dialog_content, null);

        TextView tvTitle = view.findViewById(R.id.tv_title);
        TextView tvFooter1 = view.findViewById(R.id.tv_footer1);
        TextView tvFooter2 = view.findViewById(R.id.tv_footer2);

        tvTitle.setText("是否关注该患者！");


//        取消
        tvFooter1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                builder.cancel();
                searchAdapter.notifyDataSetChanged();
            }
        });
//确定
        tvFooter2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                builder.cancel();
                modifyAttent(atten, position, patientId);
                searchAdapter.notifyDataSetChanged();
            }
        });

        builder.setContentView(view);
        //builder.setCanceledOnTouchOutside(true);
        builder.show();
        Window window = builder.getWindow();
        WindowManager.LayoutParams lp = window.getAttributes();
        WindowManager windowManager = getWindowManager();
        Display display = windowManager.getDefaultDisplay();
        lp.width = (int) (display.getWidth() * 0.7);
//        lp.height = (int) (display.getHeight() * 0.1);
        window.setAttributes(lp);
    }


    //  根据关系类型  设置默认图片
    public void setPatientImage(ImageView image, String ship, int sex) {
        if (ship == null) {
            image.setBackgroundResource(R.drawable.head_patient);
            return;
        }
        switch (ship) {
            case "本人":
                if (sex == 1) {
                    image.setBackgroundResource(R.drawable.my_him);
                } else {
                    image.setBackgroundResource(R.drawable.my_her);
                }
                break;
            case "丈夫":
                image.setBackgroundResource(R.drawable.husband);
                break;
            case "妻子":
                image.setBackgroundResource(R.drawable.wife);
                break;
            case "爸爸":
                image.setBackgroundResource(R.drawable.papa);
                break;
            case "妈妈":
                image.setBackgroundResource(R.drawable.mama);
                break;
            case "儿子":
                image.setBackgroundResource(R.drawable.son);
                break;
            case "女儿":
                image.setBackgroundResource(R.drawable.daughter);
                break;
//            case "其他":
//                image.setBackgroundResource(R.drawable.head_patient);
//                break;
            default:
                image.setBackgroundResource(R.drawable.head_patient);
                break;
        }
    }


    //    关注患者  取消关注
    public void modifyAttent(final boolean atten, final int position, final int patientId) {
        ThreadPoolManager.getInstance().execute(new Runnable() {
            @Override
            public void run() {
                String id = (String) SharedPreferenciesUtil.getData("id", "0");
                String path = BuildConfig.baseUrl + "patient/doctorPatientMedical/addRemarksAndFollow?doctorId=" + id + "&patientId=" + patientId + "&isFollow=" + atten;
                String result = PostAndGet.doGetHttp(path);

                LogUtil.e("关注", result);
                if (result.equals("网络异常")) {

                } else {
                    SimpleResultModel simpleResultModel = gson.fromJson(result, SimpleResultModel.class);
                    Message message = new Message();
                    message.obj = atten;
                    if (simpleResultModel.getStatus() == 0) {
                        message.what = 4;
                        message.arg1 = position;
                        handler.sendMessage(message);
                    } else {
                        message.what = 5;
                        handler.sendMessage(message);
                    }
                }

            }
        });
    }

}
