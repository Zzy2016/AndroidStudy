package com.huidr.HuiDrDoctor.activity;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.Rect;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Message;
import androidx.annotation.NonNull;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.text.Html;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.activeandroid.query.Delete;
import com.alibaba.fastjson.JSONObject;
import com.bumptech.glide.Glide;
import com.chad.library.adapter.base.BaseQuickAdapter;
import com.chad.library.adapter.base.BaseViewHolder;
import com.google.gson.Gson;
import com.huidr.HuiDrDoctor.activity.main.Consult.Model.PatientModel;
import com.huidr.HuiDrDoctor.activity.main.Consult.utils.PostAndGet;
import com.huidr.HuiDrDoctor.debug.BuildConfig;
import com.huidr.HuiDrDoctor.debug.R;
import com.huidr.HuiDrDoctor.util.LogUtil;
import com.huidr.HuiDrDoctor.util.ThreadPoolManager;
import com.tendcloud.tenddata.TCAgent;
import com.zyao89.view.zloading.ZLoadingDialog;
import com.zyao89.view.zloading.Z_TYPE;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.lang.reflect.Field;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Calendar;
import java.util.List;

import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.viewpager.widget.PagerAdapter;
import androidx.viewpager.widget.ViewPager;
import cn.jpush.im.android.api.ContactManager;
import cn.jpush.im.android.api.JMessageClient;
import cn.jpush.im.android.api.content.TextContent;
import cn.jpush.im.android.api.model.Conversation;
import cn.jpush.im.android.api.options.MessageSendingOptions;
import cn.jpush.im.api.BasicCallback;
import jiguang.chat.application.JGApplication;
import jiguang.chat.database.FriendRecommendEntry;
import jiguang.chat.database.UserEntry;
import jiguang.chat.utils.SharePreferenceManager;
import jiguang.chat.utils.oss.OssService;
import jiguang.chat.utils.oss.SharedPreferenciesUtil;

/*
 * 处理 患者发送的咨询申请  拒绝后者接受
 * 展示内容与好友申请相似*
 * */
public class DealConsultActivity extends AppCompatActivity implements View.OnClickListener {

    private ImageView imgBack;
    private TextView tvRight;
    private ImageView imgHead;
    private TextView tvName, tvGender, tvAge;
    private TextView tvDesc;
    private RecyclerView imgList;
    private TextView tvTip;
    private Button btnCancel, btnAccept;
    private ViewPager imgPreview;
    private MyAdapter myAdapter;
    private String username;
    private String appkey;
    UserEntry user = null;//
    FriendRecommendEntry friendRecommendEntry;
    Gson gson = new Gson();
    List<String> imgs;
    ImgAdapter imgAdapter;
    String orderId;//订单ID
    long time;//计时
    String createTime;

    int orderStatusAction;
    int orderStatus;

    int hours;
    int minutes;
    int seconds;

    ZLoadingDialog dialog;
    ZLoadingDialog dialogAccept;
    String desc;
    String patientUserId;//100137
    String patientId;//42458

    PatientModel patientModel;
    Context context;
    OssService ossService;
    private long lastRight;
    String patientUid;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_deal_consult);
        context = this;
        ossService = new OssService(context);
        dialog = new ZLoadingDialog(DealConsultActivity.this);
        dialogAccept = new ZLoadingDialog(DealConsultActivity.this);

        dialogAccept.setLoadingBuilder(Z_TYPE.STAR_LOADING)//设置类型
                .setLoadingColor(Color.BLUE)//颜色
                .setHintText("加载中...").setHintTextSize(16) // 设置字体大小 dp
                .setHintTextColor(Color.GRAY)  // 设置字体颜色
                .setDurationTime(0.5) // 设置动画时间百分比 - 0.5倍
                .setCanceledOnTouchOutside(false).setCancelable(false);

        initView();
        try {
            initData();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private Handler handler = new Handler() {
        @Override
        public void handleMessage(Message msg) {
            super.handleMessage(msg);
            switch (msg.what) {
                case 0:
                    if (imgs.size() > 0) {
                        dialog.setLoadingBuilder(Z_TYPE.DOUBLE_CIRCLE)//设置类型
                                .setLoadingColor(Color.BLUE)//颜色
                                .setHintText("加载中...").setHintTextSize(16) // 设置字体大小 dp
                                .setHintTextColor(Color.GRAY)  // 设置字体颜色
                                .setDurationTime(0.5) // 设置动画时间百分比 - 0.5倍
                                .setCanceledOnTouchOutside(false).setCancelable(false).show();
                    }
                    imgAdapter.setNewData(imgs);
                    imgList.setAdapter(imgAdapter);
                    imgList.setLayoutManager(new GridLayoutManager(DealConsultActivity.this, 4));
                    imgList.addItemDecoration(new SpacesItemDecoration(10));
                    myAdapter = new MyAdapter();
                    imgPreview.setAdapter(myAdapter);


                    break;
                case 1:  //拒绝成功
//                    if(dialogAccept!=null){
//                        dialogAccept.dismiss();
//                    }
                    refuseInvitation();
                    break;
                case 2:  //接受成功
//                    if(dialogAccept!=null){
//                        dialogAccept.dismiss();
//                    }
                    Conversation conversation = JMessageClient.getSingleConversation(patientUserId, BuildConfig.patientAppkey);
                    if (conversation != null) {
                        conversation.deleteAllMessage();
                    }
                    acceptInvitation();
                    break;
                case 3:

                    if (patientModel.getRetValue().getUserSex() == 1) {
                        tvGender.setText("男");
                    } else {
                        tvGender.setText("女");
                    }
                    Calendar calendar = Calendar.getInstance();
                    int year = calendar.get(Calendar.YEAR);
                    int month = calendar.get(Calendar.MONTH) + 1;
                    int day = calendar.get(Calendar.DATE);
                    calendar.setTimeInMillis(patientModel.getRetValue().getUserBirth());

                    int yearUser = calendar.get(Calendar.YEAR);
                    int monthUser = calendar.get(Calendar.MONTH) + 1;
                    int dayUser = calendar.get(Calendar.DATE);
                    int age = year - yearUser;

                    if (!(month >= monthUser && day >= dayUser)) {

                    } else {
                        age -= 1;
                    }
                    tvAge.setText(age + "岁");

                    break;
            }
        }
    };

    public void initView() {
        imgBack = (ImageView) findViewById(R.id.img_back);
        tvRight = (TextView) findViewById(R.id.tv_right);
        imgHead = (ImageView) findViewById(R.id.img_head);
        tvName = (TextView) findViewById(R.id.tv_name);
        tvAge = (TextView) findViewById(R.id.tv_age);
        tvGender = (TextView) findViewById(R.id.tv_gender);
        tvDesc = (TextView) findViewById(R.id.tv_desc);
        imgList = (RecyclerView) findViewById(R.id.img_list);
        tvTip = (TextView) findViewById(R.id.tv_tip);
        btnCancel = (Button) findViewById(R.id.btn_cancel);
        btnAccept = (Button) findViewById(R.id.btn_accept);
        imgPreview = (ViewPager) findViewById(R.id.img_preview);

        tvRight.setVisibility(View.GONE);

        imgBack.setOnClickListener(this);
        btnAccept.setOnClickListener(this);
        btnCancel.setOnClickListener(this);
        tvRight.setOnClickListener(this);

    }

    public void initData() {
        appkey = BuildConfig.patientAppkey;
        username = getIntent().getStringExtra("username");
        orderId = getIntent().getStringExtra("orderId");
        hours = getIntent().getIntExtra("hours", 0);
        minutes = getIntent().getIntExtra("minutes", 0);
        seconds = getIntent().getIntExtra("seconds", 0);
        imgs = (List<String>) getIntent().getSerializableExtra("imgs");
        patientUserId = getIntent().getStringExtra("patientUserId");
        patientId = getIntent().getStringExtra("patientId");
        desc = getIntent().getStringExtra("desc");

        imgAdapter = new ImgAdapter(R.layout.item_img, imgs);
        imgList.setAdapter(imgAdapter);
        imgList.setLayoutManager(new GridLayoutManager(DealConsultActivity.this, 4));
        imgList.addItemDecoration(new SpacesItemDecoration(10));

        myAdapter = new MyAdapter();
        imgPreview.setAdapter(myAdapter);


        tvName.setText(username);
        String descStr = "<font color='#248cfa'>问题:</font>" + desc;
        tvDesc.setText(Html.fromHtml(descStr));

        final String path = BuildConfig.baseUrl + "patient/patientHomepage/getPatient";
        final JSONObject jsonObject = new JSONObject();
        jsonObject.put("patientId", patientId);
        ThreadPoolManager.getInstance().execute(new Runnable() {
            @Override
            public void run() {
                String result = PostAndGet.doHttpPost(path, jsonObject);
                LogUtil.e("查询患者信息", result);

                patientModel = gson.fromJson(result, PatientModel.class);

                handler.sendEmptyMessage(3);
                LogUtil.e("患者信息", patientModel.getRetValue().getUserBirth() + "");
                LogUtil.e("患者信息", patientModel.getRetValue().getUserSex() + "");

            }
        });


    }

    /*
     * 点击事件
     *
     * /consult/consult/confirmOrder  接受
     *
     * /consult/consult/refuseOrder   拒绝
     *
     * */
    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.img_back:
                finish();
                break;
            case R.id.btn_accept:

                if (orderStatus == 102) {
                    if (orderStatusAction == 2 || orderStatusAction == 12 || orderStatusAction == 9) {
                        Toast.makeText(DealConsultActivity.this, "患者已取消咨询", Toast.LENGTH_SHORT).show();
                        DelayFinish();
                    } else if (orderStatusAction == 13) {
                        Toast.makeText(DealConsultActivity.this, "订单超时", Toast.LENGTH_SHORT).show();
                        DelayFinish();
                    }
                } else {
                    if (hours == 0 && minutes == 0 && seconds == 0) {
                        Toast.makeText(DealConsultActivity.this, "订单超时", Toast.LENGTH_SHORT).show();
                        DelayFinish();
                    } else {
                        dialogAccept.setHintText("正在处理，请稍侯").show();
                        new Thread(new Runnable() {
                            @Override
                            public void run() {
                                refuseOrAccept("接受咨询");
                            }
                        }).start();

                    }
                }


                break;
            case R.id.btn_cancel:

                if (orderStatus == 102) {
                    if (orderStatusAction == 2 || orderStatusAction == 12 || orderStatusAction == 9) {
                        Toast.makeText(DealConsultActivity.this, "患者已取消咨询", Toast.LENGTH_SHORT).show();
                        DelayFinish();
                    } else if (orderStatusAction == 13) {
                        Toast.makeText(DealConsultActivity.this, "订单超时", Toast.LENGTH_SHORT).show();
                        DelayFinish();
                    }
                } else {
                    if (hours == 0 && minutes == 0 && seconds == 0) {
                        Toast.makeText(DealConsultActivity.this, "订单超时", Toast.LENGTH_SHORT).show();
                        DelayFinish();
                        new Handler().postDelayed(new Runnable() {
                            @Override
                            public void run() {
                                finish();
                            }
                        }, 2000);
                    } else {
                        dialogAccept.setHintText("正在处理，请稍侯").show();
                        new Thread(new Runnable() {
                            @Override
                            public void run() {
                                refuseOrAccept("拒绝咨询");
                            }
                        }).start();
//                        refuseInvitation();
                    }
                }
                break;
            case R.id.tv_right:
                long currentTime1 = System.currentTimeMillis();
                if (currentTime1 - lastRight > 1000) {
                    TCAgent.onEvent(this, "沟通界面点击患者资料次数", "沟通界面点击患者资料次数");
//                    Intent intent1 = new Intent(DealConsultActivity.this, WebActivity.class);
////                    Bundle bundle = new Bundle();
////                    bundle.putString("url", "patientData.html?id=" + patientId);
////                    intent.putExtras(bundle);
////                    startActivity(intent);
//
//                    JSONObject jsonObject = new JSONObject();
//                    jsonObject.put("id", patientId);
//                    SharedPreferenciesUtil.putData("psearchID", jsonObject.toJSONString());
//                    SharedPreferenciesUtil.putData("followDoctorId", patientId);
//
//                    Bundle bundle = new Bundle();
//                    bundle.putString("url", "patientData.html");
//                    intent1.putExtras(bundle);
//                    startActivity(intent1);

                    lastRight = currentTime1;
                }
                break;
        }
    }

    /*
     * 已经取消的订单 延时关闭
     *
     * */
    public void DelayFinish() {
        new Delete().from(FriendRecommendEntry.class).where("username=?", username).execute();
        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                finish();
            }
        }, 2000);
    }

    /*
     * 接受邀请
     * */
    public void acceptInvitation() {
        ContactManager.acceptInvitation(patientUserId, appkey, new BasicCallback() {
            @Override
            public void gotResult(int i, String s) {
                if (i == 0) {
                    LogUtil.e("invitation", "接受邀请，请回答");
                    new Delete().from(FriendRecommendEntry.class).where("username=?", patientUserId).execute();
                    JGApplication.forAddFriend.remove(patientUserId);

//                    发送图文咨询开始

                    Conversation conversation = JMessageClient.getSingleConversation(patientUserId, appkey);
                    if (conversation == null) {
                        conversation = Conversation.createSingleConversation(patientUserId, appkey);
                    }
                    final TextContent content = new TextContent("[咨询]");
                    content.setStringExtra("des", desc);


                    String picStr = "";
                    for (int k = 0; k < imgs.size(); k++) {
                        if (k == (imgs.size() - 1)) {
                            picStr += imgs.get(k);
                        } else {
                            picStr += imgs.get(k) + ",";
                        }
                    }

//                    String imgStr = JSONArray.toJSONString(imgs);
                    content.setStringExtra("pic", picStr);
//                    content.setStringExtra("pic", imgStr.substring(1, imgStr.length() - 1));


                    cn.jpush.im.android.api.model.Message message = conversation.createSendMessage(content);
                    MessageSendingOptions options = new MessageSendingOptions();
                    options.setNeedReadReceipt(true);
                    JMessageClient.sendMessage(message, options);

                    message.setOnSendCompleteCallback(new BasicCallback() {
                        @Override
                        public void gotResult(int i, String s) {
                            if (i == 0) {
                                SharePreferenceManager.setIsOpen(true);
                                LogUtil.e("发送咨询",s);
//                                        Toast.makeText(ConversationActivity.this, "发送成功", Toast.LENGTH_SHORT).show();

                            } else {
//                                        HandleResponseCode.onHandle(ConversationActivity.this, i, false);
                                LogUtil.e("发送咨询",s);
                            }
                        }
                    });


                    //                    发送图文咨询结束

                } else {
                    LogUtil.e("invitation", "接受邀请失败" + s);
                }

                new Handler().postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        if (dialogAccept != null) {
                            dialogAccept.dismiss();
                        }
                        finish();
                    }
                }, 2000);
            }
        });

    }


    /*
     * 拒绝邀请
     * */
    public void refuseInvitation() {
        ContactManager.declineInvitation(patientUserId, appkey, "reason", new BasicCallback() {
            @Override
            public void gotResult(int i, String s) {

                if (i == 0) {
                    LogUtil.e("invitation", "拒绝邀请成功");
                    new Delete().from(FriendRecommendEntry.class).where("username=?", patientUserId).execute();
                    JGApplication.forAddFriend.remove(patientUserId);

                } else {
                    LogUtil.e("invitation", "拒绝邀请失败" + s);
                }

                new Handler().postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        if (dialogAccept != null) {
                            dialogAccept.dismiss();
                        }
                        finish();
                    }
                }, 2000);
            }
        });
    }


    /*
     * 接受 或者 拒绝
     * 更改订单状态
     * /consult/consult/confirmOrder  接受
     *
     * /consult/consult/refuseOrder   拒绝
     * */
    public void refuseOrAccept(String text) {

        StringBuffer buffer = new StringBuffer();
        String str;
        if (text.equals("拒绝咨询")) {
            str = "consult/consult/refuseOrder";
        } else {
            str = "consult/consult/confirmOrder";
        }

        HttpURLConnection connection = null;
        String jwt = (String) SharedPreferenciesUtil.getData("jwt", "");
        try {
            JSONObject jsonObject = new JSONObject();
            jsonObject.put("orderId", orderId);
            LogUtil.e("接受或者拒绝订单号", orderId + " ");
            URL url = new URL(BuildConfig.baseUrl + str);
            connection = (HttpURLConnection) url.openConnection();
            connection.setRequestMethod("POST");
            connection.setRequestProperty("Charset", "UTF-8");
            connection.setRequestProperty("jwt", jwt);
            connection.setRequestProperty("accept", "application/json");
            connection.setRequestProperty("Connection", "Keep-Alive");
            connection.setRequestProperty("Content-Type", "application/json");
            connection.setDoOutput(true);
            connection.setDoInput(true);
            connection.connect();
            OutputStream outputStream = connection.getOutputStream();
            outputStream.write(jsonObject.toString().getBytes());
            outputStream.flush();
            outputStream.close();


            if (connection.getResponseCode() == 200) {
                BufferedReader reader = new BufferedReader(new InputStreamReader(connection.getInputStream()));
                String str1 = null;

                while ((str1 = reader.readLine()) != null) {
                    buffer.append(str1);
                }

                LogUtil.e("接受或者拒绝", buffer.toString());
                Message message = new Message();
                if (text.equals("拒绝咨询")) {
                    message.what = 1;
                } else {
                    message.what = 2;
                }
                handler.sendMessage(message);
            }

        } catch (Exception e) {
            e.printStackTrace();
            LogUtil.e("接受或者拒绝异常", e.toString());
        }
    }


    /*
     * 图片适配
     * */
    public class ImgAdapter extends BaseQuickAdapter<String, BaseViewHolder> {
        public ImgAdapter(int layoutResId, @Nullable List<String> data) {
            super(layoutResId, data);
        }

        @Override
        protected void convert(final BaseViewHolder helper, final String item) {
            final ImageView imageView = helper.getView(R.id.img);


            try {
                File file = new File(Environment.getExternalStorageDirectory().getAbsolutePath() + "/" + context.getPackageName() + "/cache/consult/" + item);
                File fileParent = file.getParentFile();
                if (!fileParent.exists()) {
                    fileParent.mkdirs();
                }
                if (file.exists()) {
                    LogUtil.e("图片", "本地");
//                    Bitmap bitmap = BitmapFactory.decodeStream(new FileInputStream(file));
//                    imageView.setImageBitmap(bitmap);
                    Glide.with(mContext).load(file.getAbsoluteFile().toString()).into(imageView);
                } else {
                    LogUtil.e("图片", "网   络");
                    jiguang.chat.utils.oss.ImageLoader.getInstance(DealConsultActivity.this).loadPhoto(DealConsultActivity.this, imageView, item, R.drawable.image_default);
                    Bitmap bitmap = ossService.downImageSyc(item);
                    LogUtil.e("加载图片", (bitmap == null) + " ");
                    imageView.setImageBitmap(bitmap);
                    bitmap.compress(Bitmap.CompressFormat.JPEG, 100, new FileOutputStream(file));
                }

            } catch (Exception e) {
                LogUtil.e("处理咨询图片", e.toString());
            }
            if (helper.getPosition() == (imgs.size() - 1)) {
                dialog.dismiss();
            }
            imageView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    imgPreview.setVisibility(View.VISIBLE);
                    imgPreview.setCurrentItem(helper.getAdapterPosition(), false);
//                    setDefaultItem(helper.getPosition());
                }
            });

        }
    }

    /*
     * ViewPager 适配
     * */
    public class MyAdapter extends PagerAdapter {

        @Override
        public int getCount() {
            return imgs.size();
        }

        @Override
        public boolean isViewFromObject(@NonNull View view, @NonNull Object o) {
            return view == o;
        }

        @NonNull
        @Override
        public Object instantiateItem(@NonNull ViewGroup container, int position) {
            View view = View.inflate(DealConsultActivity.this, R.layout.img_pre_layout, null);
            ImageView img = view.findViewById(R.id.img);
            //jiguang.chat.utils.oss.ImageLoader.getInstance(DealConsultActivity.this).loadPhoto(DealConsultActivity.this, img, imgs.get(position), R.drawable.image_default);


            try {
                File file = new File(Environment.getExternalStorageDirectory().getAbsolutePath() + "/" + context.getPackageName() + "/cache/consult/" + imgs.get(position));
//                Bitmap bitmap = BitmapFactory.decodeStream(new FileInputStream(file));
//                img.setImageBitmap(bitmap);
                Glide.with(context).load(file.getAbsoluteFile().toString()).into(img);
            } catch (Exception e) {

            }

            img.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    imgPreview.setVisibility(View.GONE);
                }
            });
            container.addView(view);
            return view;
        }

        @Override
        public void destroyItem(@NonNull ViewGroup container, int position, @NonNull Object object) {
//            super.destroyItem(container, position, object);
            container.removeView((View) object);
        }


    }


    private void setDefaultItem(int position) {
        //我这里mViewpager是viewpager子类的实例。如果你是viewpager的实例，也可以这么干。
        try {
            Class c = Class.forName("android.support.v4.view.ViewPager");
            Field field = c.getDeclaredField("mCurItem");
            field.setAccessible(true);
            field.setInt(imgPreview, position);
        } catch (Exception e) {
            e.printStackTrace();
        }

        myAdapter.notifyDataSetChanged();

        imgPreview.setCurrentItem(position);
    }

    public class SpacesItemDecoration extends RecyclerView.ItemDecoration {
        private int space;

        public SpacesItemDecoration(int space) {
            this.space = space;
        }

        @Override
        public void getItemOffsets(Rect outRect, View view, RecyclerView parent, RecyclerView.State state) {

            outRect.top = space * 2;

            outRect.left = space;
            outRect.right = space;
        }
    }


}

