package com.huidr.HuiDrDoctor.module.home;

import java.util.List;

/**
 * @author: Administrator
 * @date: 2019-12-05
 */
public class HisSearchModel {

    /**
     * status : 0
     * page : 1
     * totalPage : 1
     * retValue : [{"id":40,"uid":100137,"searchContent":"周","searchType":7,"gmtCreate":"2019-12-05"},{"id":39,"uid":100137,"searchContent":"测试","searchType":7,"gmtCreate":"2019-12-05"},{"id":38,"uid":100137,"searchContent":"沈","searchType":7,"gmtCreate":"2019-12-05"},{"id":37,"uid":100137,"searchContent":"沈","searchType":7,"gmtCreate":"2019-12-05"}]
     */

    private int status;
    private int page;
    private int totalPage;
    private List<RetValueBean> retValue;

    public int getStatus() {
        return status;
    }

    public void setStatus(int status) {
        this.status = status;
    }

    public int getPage() {
        return page;
    }

    public void setPage(int page) {
        this.page = page;
    }

    public int getTotalPage() {
        return totalPage;
    }

    public void setTotalPage(int totalPage) {
        this.totalPage = totalPage;
    }

    public List<RetValueBean> getRetValue() {
        return retValue;
    }

    public void setRetValue(List<RetValueBean> retValue) {
        this.retValue = retValue;
    }

    public static class RetValueBean {
        /**
         * id : 40
         * uid : 100137
         * searchContent : 周
         * searchType : 7
         * gmtCreate : 2019-12-05
         */

        private int id;
        private int uid;
        private String searchContent;
        private int searchType;
        private String gmtCreate;

        public int getId() {
            return id;
        }

        public void setId(int id) {
            this.id = id;
        }

        public int getUid() {
            return uid;
        }

        public void setUid(int uid) {
            this.uid = uid;
        }

        public String getSearchContent() {
            return searchContent;
        }

        public void setSearchContent(String searchContent) {
            this.searchContent = searchContent;
        }

        public int getSearchType() {
            return searchType;
        }

        public void setSearchType(int searchType) {
            this.searchType = searchType;
        }

        public String getGmtCreate() {
            return gmtCreate;
        }

        public void setGmtCreate(String gmtCreate) {
            this.gmtCreate = gmtCreate;
        }
    }
}
