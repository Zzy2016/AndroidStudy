package com.huidr.HuiDrDoctor.module.home;

import java.util.List;

/**
 * @author: Administrator
 * @date: 2019-12-04
 */
public class CooperModel {

    /**
     * status : 0
     * page : 1
     * totalPage : 1
     * retValue : [{"id":100136,"mobile":"13600000112","userName":"周俭","userIcon":"system/doctor/8177-71-12421.jpg","userSex":1,"userTitle":"主任医师","userJobNumber":"12421","hospitalId":8177,"hospitalName":"复旦大学附属中山医院","departmentId":71,"hospitalDepartment":"肝肿瘤外科","expertise":"哦哦哦哦哦哦哦\n哦哦哦哦哦哦哦哦哦哦哦哦哦哦哦哦\n哦哦哦哦哦哦哦哦哦哦哦哦哦\n哦哦哦哦哦哦哦哦哦哦哦哦哦哦","honor":"我是属鼠的专家\n后改密码了吗咯咯\n咯 going 名\n\n咯公共咯哈","fabulousCount":13,"academicActivities":"院长你好。   啥事佩琦\n后改名字哦头咯哈\n狗狗你\nJohn","outpatientTimeList":"[{\"1\":{\"sel\":true},\"2\":{\"sel\":false},\"3\":{\"sel\":true},\"4\":{\"sel\":false},\"5\":{\"sel\":true},\"6\":{\"sel\":false},\"7\":{\"sel\":false}},{\"1\":{\"sel\":false},\"2\":{\"sel\":false},\"3\":{\"sel\":false},\"4\":{\"sel\":true},\"5\":{\"sel\":false},\"6\":{\"sel\":false},\"7\":{\"sel\":false}}]","imPassword":"nC6P04cP8v","doctorSearchDate":"2019-04-25 00:00:20","osName":"Android","isFollowup":true}]
     */

    private int status;
    private int page;
    private int totalPage;
    private List<RetValueBean> retValue;

    public int getStatus() {
        return status;
    }

    public void setStatus(int status) {
        this.status = status;
    }

    public int getPage() {
        return page;
    }

    public void setPage(int page) {
        this.page = page;
    }

    public int getTotalPage() {
        return totalPage;
    }

    public void setTotalPage(int totalPage) {
        this.totalPage = totalPage;
    }

    public List<RetValueBean> getRetValue() {
        return retValue;
    }

    public void setRetValue(List<RetValueBean> retValue) {
        this.retValue = retValue;
    }

    public static class RetValueBean {
        /**
         * id : 100136
         * mobile : 13600000112
         * userName : 周俭
         * userIcon : system/doctor/8177-71-12421.jpg
         * userSex : 1
         * userTitle : 主任医师
         * userJobNumber : 12421
         * hospitalId : 8177
         * hospitalName : 复旦大学附属中山医院
         * departmentId : 71
         * hospitalDepartment : 肝肿瘤外科
         * expertise : 哦哦哦哦哦哦哦
         哦哦哦哦哦哦哦哦哦哦哦哦哦哦哦哦
         哦哦哦哦哦哦哦哦哦哦哦哦哦
         哦哦哦哦哦哦哦哦哦哦哦哦哦哦
         * honor : 我是属鼠的专家
         后改密码了吗咯咯
         咯 going 名

         咯公共咯哈
         * fabulousCount : 13
         * academicActivities : 院长你好。   啥事佩琦
         后改名字哦头咯哈
         狗狗你
         John
         * outpatientTimeList : [{"1":{"sel":true},"2":{"sel":false},"3":{"sel":true},"4":{"sel":false},"5":{"sel":true},"6":{"sel":false},"7":{"sel":false}},{"1":{"sel":false},"2":{"sel":false},"3":{"sel":false},"4":{"sel":true},"5":{"sel":false},"6":{"sel":false},"7":{"sel":false}}]
         * imPassword : nC6P04cP8v
         * doctorSearchDate : 2019-04-25 00:00:20
         * osName : Android
         * isFollowup : true
         */

        private int id;
        private String mobile;
        private String userName;
        private String userIcon;
        private int userSex;
        private String userTitle;
        private String userJobNumber;
        private int hospitalId;
        private String hospitalName;
        private int departmentId;
        private String hospitalDepartment;
        private String expertise;
        private String honor;
        private int fabulousCount;
        private String academicActivities;
        private String outpatientTimeList;
        private String imPassword;
        private String doctorSearchDate;
        private String osName;
        private boolean isFollowup;

        public int getId() {
            return id;
        }

        public void setId(int id) {
            this.id = id;
        }

        public String getMobile() {
            return mobile;
        }

        public void setMobile(String mobile) {
            this.mobile = mobile;
        }

        public String getUserName() {
            return userName;
        }

        public void setUserName(String userName) {
            this.userName = userName;
        }

        public String getUserIcon() {
            return userIcon;
        }

        public void setUserIcon(String userIcon) {
            this.userIcon = userIcon;
        }

        public int getUserSex() {
            return userSex;
        }

        public void setUserSex(int userSex) {
            this.userSex = userSex;
        }

        public String getUserTitle() {
            return userTitle;
        }

        public void setUserTitle(String userTitle) {
            this.userTitle = userTitle;
        }

        public String getUserJobNumber() {
            return userJobNumber;
        }

        public void setUserJobNumber(String userJobNumber) {
            this.userJobNumber = userJobNumber;
        }

        public int getHospitalId() {
            return hospitalId;
        }

        public void setHospitalId(int hospitalId) {
            this.hospitalId = hospitalId;
        }

        public String getHospitalName() {
            return hospitalName;
        }

        public void setHospitalName(String hospitalName) {
            this.hospitalName = hospitalName;
        }

        public int getDepartmentId() {
            return departmentId;
        }

        public void setDepartmentId(int departmentId) {
            this.departmentId = departmentId;
        }

        public String getHospitalDepartment() {
            return hospitalDepartment;
        }

        public void setHospitalDepartment(String hospitalDepartment) {
            this.hospitalDepartment = hospitalDepartment;
        }

        public String getExpertise() {
            return expertise;
        }

        public void setExpertise(String expertise) {
            this.expertise = expertise;
        }

        public String getHonor() {
            return honor;
        }

        public void setHonor(String honor) {
            this.honor = honor;
        }

        public int getFabulousCount() {
            return fabulousCount;
        }

        public void setFabulousCount(int fabulousCount) {
            this.fabulousCount = fabulousCount;
        }

        public String getAcademicActivities() {
            return academicActivities;
        }

        public void setAcademicActivities(String academicActivities) {
            this.academicActivities = academicActivities;
        }

        public String getOutpatientTimeList() {
            return outpatientTimeList;
        }

        public void setOutpatientTimeList(String outpatientTimeList) {
            this.outpatientTimeList = outpatientTimeList;
        }

        public String getImPassword() {
            return imPassword;
        }

        public void setImPassword(String imPassword) {
            this.imPassword = imPassword;
        }

        public String getDoctorSearchDate() {
            return doctorSearchDate;
        }

        public void setDoctorSearchDate(String doctorSearchDate) {
            this.doctorSearchDate = doctorSearchDate;
        }

        public String getOsName() {
            return osName;
        }

        public void setOsName(String osName) {
            this.osName = osName;
        }

        public boolean isIsFollowup() {
            return isFollowup;
        }

        public void setIsFollowup(boolean isFollowup) {
            this.isFollowup = isFollowup;
        }
    }
}
