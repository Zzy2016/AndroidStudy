package com.huidr.HuiDrDoctor.activity;


import android.os.Build;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.View;
import android.view.Window;
import android.widget.FrameLayout;
import android.widget.Toast;

import com.huidr.HuiDrDoctor.util.LocalConstants;
import com.huidr.lib.commom.base.BaseWebActivity;
import com.huidr.lib.commom.base.HuidrActivityManager;
import com.huidr.lib.commom.util.HbuildUtil;

import io.dcloud.EntryProxy;
import io.dcloud.common.DHInterface.ICore;
import io.dcloud.common.DHInterface.IWebview;
import io.dcloud.common.DHInterface.IWebviewStateListener;
import io.dcloud.feature.internal.sdk.SDK;


/**
 * 作者：Administrator on 2018/12/11 10:18
 * <p>
 * 邮箱：914531679@qq.com
 */


public class LoginActivity extends BaseWebActivity {
    long lastTime = 0;
    private IWebview webview;
    private FrameLayout rootView;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        HuidrActivityManager.getInstance().finishAll();
        super.onCreate(savedInstanceState);
        if(Build.VERSION.SDK_INT>Build.VERSION_CODES.LOLLIPOP){
            getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR);
        }
        HuidrActivityManager.getInstance().finishSplashActivity();
    }

    @Override
    protected void initView() {
        super.initView();
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        rootView = new FrameLayout(this);
        setContentView(rootView);
    }

    @Override
    public void onCoreInitEnd(ICore coreHandler) {
        super.onCoreInitEnd(coreHandler);
        String url = LocalConstants.loginUrl;
        String appid = url.replace("./", "");
        webview = HuidrActivityManager.getInstance().getWebview(appid);
        String path=HbuildUtil.getUrl(getApplicationContext(), "Doctor", url);
        if (webview == null) {
            showDialog();
            webview = SDK.createWebview(this, HbuildUtil.getUrl(getApplicationContext(), "Doctor", url), appid, new IWebviewStateListener() {
                @Override
                public Object onCallBack(int pType, Object pArgs) {
                    switch (pType) {
                        case IWebviewStateListener.ON_WEBVIEW_READY:
                            break;
                        case IWebviewStateListener.ON_PAGE_STARTED:
                            break;
                        case IWebviewStateListener.ON_PROGRESS_CHANGED:
                            break;
                        case IWebviewStateListener.ON_PAGE_FINISHED:
                            dismissDialog();
                            break;
                    }
                    return null;
                }
            });

            HuidrActivityManager.getInstance().addWebview(appid, webview);
            SDK.attach(rootView, webview);
            webview.onRootViewGlobalLayout(rootView);
        } else {
            SDK.attach(rootView, webview);
            webview.onRootViewGlobalLayout(rootView);
            EntryProxy.getInstnace().onNewIntent(LoginActivity.this, getIntent());
        }
    }

    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if ((keyCode == KeyEvent.KEYCODE_BACK)) {
            long currentTime = System.currentTimeMillis();
            if ((currentTime - lastTime) > 2000) {
                // 两次点击间隔超过2秒
                Toast.makeText(this, "再点击一次退出应用", Toast.LENGTH_SHORT).show();
                // 记录时间
                lastTime = currentTime;
            } else {
                HuidrActivityManager.getInstance().finishAll();
            }
        }
        return super.onKeyDown(keyCode, event);
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (webview != null) {
            SDK.attach(rootView, webview);
            webview.onRootViewGlobalLayout(rootView);
        }
    }
}