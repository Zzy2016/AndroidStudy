package com.huidr.HuiDrDoctor.activity;

import android.app.Activity;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.view.Display;
import android.view.MotionEvent;
import android.view.WindowManager;
import android.widget.ImageView;

import com.huidr.HuiDrDoctor.debug.R;


public class ShowCodeActivity extends Activity {

    ImageView imageCode;
    String token;
    byte[] image;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_show_code);

        token = getIntent().getExtras().getString("token");
        image = getIntent().getExtras().getByteArray("image");

        WindowManager m = getWindowManager();
        Display d = m.getDefaultDisplay();  //为获取屏幕宽、高
        WindowManager.LayoutParams p = getWindow().getAttributes();  //获取对话框当前的参数值
        p.height = (int) (d.getHeight() * 0.8);   //高度设置为屏幕的1.0
        getWindow().setAttributes(p);
        imageCode = (ImageView) findViewById(R.id.image_code);
        Bitmap bitmap = BitmapFactory.decodeByteArray(image, 0, image.length);
        imageCode.setImageBitmap(bitmap);

    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        finish();
        return true;
    }

}
