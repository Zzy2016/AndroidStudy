package com.huidr.HuiDrDoctor.activity.main.contact;

import android.content.Intent;
import android.os.Bundle;


import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.PopupWindow;
import android.widget.TextView;

import com.HBuilder.integrate.h5tools.H5Bridge;
import com.google.android.material.tabs.TabLayout;
import com.huidr.HuiDrDoctor.debug.R;
import com.huidr.HuiDrDoctor.util.LogUtil;
import com.huidr.lib.commom.base.BaseFragment;
import com.huidr.lib.commom.view.DialogUtil;

import org.greenrobot.eventbus.EventBus;
import org.greenrobot.eventbus.Subscribe;
import org.greenrobot.eventbus.ThreadMode;

import java.util.List;

import androidx.fragment.app.Fragment;
import androidx.viewpager.widget.ViewPager;
import jiguang.chat.activity.SearchContactsActivity;
import jiguang.chat.activity.fragment.ConversationListFragment;
import jiguang.chat.utils.event.BusEventMessage;


/**
 * Created by jlyoua on 2018/11/30.
 * Description：联系人tab
 */
public class ContactsFragment extends BaseFragment implements View.OnClickListener {


    private List<Fragment> fragmentList;

    private TabLayout mTabLayout;

    private ImageView moreMenu; //添加

    private ViewPager vpContent;
    /**
     * 点击更多弹出来的view
     */
    private View pop_more;

    private PopupWindow mPopupWindow;

    private LinearLayout searchLayout;

    private View conversationListFragment;

    private View contactsFragment;

    private TextView conversionTab;
    private TextView contactTab;
    H5Bridge h5Bridge;

    private ImageView imgUnRead;
    private ImageView imgContact;

    long lastClick;
    long lastClickAdd;//添加联系人

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        LogUtil.e("联系人", "onCreate");
        EventBus.getDefault().register(this);
        h5Bridge = new H5Bridge();
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        LogUtil.e("联系人", "onCreateView");
        return super.onCreateView(inflater, container, savedInstanceState);
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        EventBus.getDefault().unregister(this);
    }

    @Override
    protected View setContentView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View mainView = inflater.inflate(R.layout.activity_contract, container);
        moreMenu = mainView.findViewById(R.id.add_menu);
        searchLayout = mainView.findViewById(R.id.search_title);
        imgUnRead = mainView.findViewById(R.id.img_unread);
        imgContact = mainView.findViewById(R.id.img_contacts);
        searchLayout.setOnClickListener(this);
        moreMenu.setOnClickListener(this);
        conversationListFragment = mainView.findViewById(R.id.conversion_frag);
        contactsFragment = mainView.findViewById(R.id.contact_frag);
        conversionTab = mainView.findViewById(R.id.tab_conversion);
        contactTab = mainView.findViewById(R.id.tab_contact);
        conversionTab.setOnClickListener(this);
        contactTab.setOnClickListener(this);
        return mainView;
    }


    @Override
    protected void initData() {

    }

    private void afterLoginSuc() {

    }


    @Override
    protected void findView(View parent) {

    }


    /**
     * 展开菜单
     *
     * @param holderView
     */
    public void showMorePop(View holderView) {
        if (pop_more == null) {
            pop_more = LayoutInflater.from(getContext()).inflate(R.layout.view_pop_main_more, null);
            pop_more.findViewById(R.id.tv_main_more_add_contact).setOnClickListener(this);
        }
        mPopupWindow = DialogUtil.getPopupWindow(pop_more);
        mPopupWindow.showAtLocation(holderView, Gravity.END | Gravity.TOP, 8, holderView.getBottom() * 3 / 2 + 66);
        mPopupWindow.setOnDismissListener(new PopupWindow.OnDismissListener() {
            @Override
            public void onDismiss() {
                WindowManager.LayoutParams params = getActivity().getWindow().getAttributes();
                params.alpha = 1f;
                getActivity().getWindow().clearFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND);
                getActivity().getWindow().setAttributes(params);
            }
        });

        WindowManager.LayoutParams params = getActivity().getWindow().getAttributes();
        params.alpha = 0.7f;
        getActivity().getWindow().addFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND);//huawei手机兼容，让窗口背景后面的任何东西变暗
        getActivity().getWindow().setAttributes(params);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            //跳转到H5 WebActivity
            case R.id.tv_main_more_add_contact:
                long currentTime1 = System.currentTimeMillis();
                if (currentTime1 - lastClickAdd > 1000) {
                    h5Bridge.OpenNewWeb("doctorSearch.html");
                    lastClickAdd = currentTime1;
                }
//                mPopupWindow.dismiss();

                break;
            case R.id.add_menu:
                /*    弹出添加联系人 */
                showMorePop(moreMenu);
                break;
            case R.id.search_title:  //搜索联系人

                long currentTime = System.currentTimeMillis();
                if (currentTime - lastClick > 1000) {
                    Intent itnt = new Intent();
                    itnt.setClass(getContext(), SearchContactsActivity.class);
                    getContext().startActivity(itnt);
                    lastClick = currentTime;
                }

                break;

//                我的会话
            case R.id.tab_conversion:
                conversationListFragment.bringToFront();
                jiguang.chat.activity.fragment.ContactsFragment.onBringToFront();
                conversionTab.setBackgroundDrawable(getContext().getResources().getDrawable(R.drawable.shape_tab_left_selected_drawable));
                conversionTab.setTextColor(getContext().getResources().getColor(R.color.main_blue));
                contactTab.setBackgroundDrawable(getContext().getResources().getDrawable(R.drawable.shape_tab_right_unselected_drawable));
                contactTab.setTextColor(getContext().getResources().getColor(R.color.white));
                break;

//                联系人
            case R.id.tab_contact:
                ConversationListFragment.onBringToFront();
                contactsFragment.bringToFront();

                conversionTab.setBackgroundDrawable(getContext().getResources().getDrawable(R.drawable.shape_tab_left_unselected_drawable));
                conversionTab.setTextColor(getContext().getResources().getColor(R.color.white));
                contactTab.setBackgroundDrawable(getContext().getResources().getDrawable(R.drawable.shape_tab_right_selected_drawable));
                contactTab.setTextColor(getContext().getResources().getColor(R.color.main_blue));
                break;
        }
    }

    /*unreadmessage    未读消息 好友邀请红点显示*/
    @Subscribe(threadMode = ThreadMode.MAIN)
    public void showImgUnRead(BusEventMessage event) {
        switch (event.getEventType()) {
            //消息已读 红点消失
            case "0":
                imgUnRead.setVisibility(View.GONE);
                break;
            //收到未读消息 显示红点
            case "unreadmsg":
                LogUtil.e("收到未读消息", "医生");
                imgUnRead.setVisibility(View.VISIBLE);
                break;
            //查看好友邀请 红点消失
            case "2":
                imgContact.setVisibility(View.GONE);
                break;
            //收到好友邀请 显示红点
            case "unreadinvi":
                LogUtil.e("收到未读邀请", "医生");
                imgContact.setVisibility(View.VISIBLE);
                break;
        }

    }

    @Override
    public void onResume() {
        super.onResume();
        LogUtil.e("联系人", "onResume");

    }

    @Override
    public void onPause() {
        super.onPause();
        LogUtil.e("联系人", "onPause");
    }

    @Override
    public void onStop() {
        super.onStop();

        if (mPopupWindow != null) {
            if (mPopupWindow.isShowing()) {
                mPopupWindow.dismiss();
            }
        }
        LogUtil.e("联系人", "onStop");
    }

    @Override
    public void onStart() {
        super.onStart();
        LogUtil.e("联系人", "onStart");
    }
}
