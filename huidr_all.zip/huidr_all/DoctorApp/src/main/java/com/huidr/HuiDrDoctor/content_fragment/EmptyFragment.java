package com.huidr.HuiDrDoctor.content_fragment;

import android.content.Intent;
import android.os.Bundle;
import android.text.Html;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import com.huidr.HuiDrDoctor.activity.WebActivity;
import com.huidr.HuiDrDoctor.debug.R;
import com.huidr.lib.commom.base.BaseFragment;

/**
 * 图文咨询未开启空态页
 * <p>
 * 打开图文咨询页面
 */
public class EmptyFragment extends BaseFragment {

    String tvLinkStr = "开启<font color='#248cfa'>图文咨询</font>";
    TextView tvShow;
    TextView tvLink;
    Button btnLink;

    @Override
    protected void initData() {

    }

    @Override
    public void onHiddenChanged(boolean hidden) {
        super.onHiddenChanged(hidden);
    }

    @Override
    protected View setContentView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_empty, container, false);
        return view;
    }

    @Override
    protected void findView(View parent) {
        tvShow = parent.findViewById(R.id.tv_empty);
        tvLink = parent.findViewById(R.id.tv_link);
        btnLink = parent.findViewById(R.id.btn_link);

        tvLink.setText(Html.fromHtml(tvLinkStr));

        btnLink.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent1 = new Intent(getActivity(), WebActivity.class);
                Bundle bundle = new Bundle();
                bundle.putString("url", "consultation.html");
                intent1.putExtras(bundle);
                startActivity(intent1);
            }
        });
    }
}
