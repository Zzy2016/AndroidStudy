package com.huidr.HuiDrDoctor.activity;

import android.app.Dialog;
import android.content.Intent;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.os.Bundle;

import android.util.DisplayMetrics;
import android.util.Log;
import android.view.KeyEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.RadioButton;

import com.huidr.HuiDrDoctor.debug.R;
import com.huidr.HuiDrDoctor.fragment.DoctorFragment;
import com.huidr.HuiDrDoctor.fragment.MessageFragment;
import com.huidr.HuiDrDoctor.fragment.PatientFragment;
import com.huidr.HuiDrDoctor.fragment.SettingFragment;
import com.huidr.HuiDrDoctor.util.EventBusMessage;
import com.huidr.HuiDrDoctor.util.LogUtil;
import com.huidr.lib.commom.base.BaseWebActivity;
import com.huidr.lib.commom.base.HuidrActivityManager;
import com.tendcloud.tenddata.TCAgent;

import org.greenrobot.eventbus.EventBus;
import org.greenrobot.eventbus.Subscribe;
import org.greenrobot.eventbus.ThreadMode;
import org.litepal.LitePal;
import org.litepal.LitePalDB;

import java.io.File;

import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;
import cn.jpush.android.api.JPushInterface;
import cn.jpush.im.android.api.JMessageClient;
import cn.jpush.im.android.api.event.LoginStateChangeEvent;
import cn.jpush.im.android.api.model.UserInfo;
import cn.jpush.im.api.BasicCallback;
import io.dcloud.EntryProxy;
import io.dcloud.common.DHInterface.ISysEventListener;
import jiguang.chat.database.UserEntry;
import jiguang.chat.utils.DialogCreator;
import jiguang.chat.utils.FileHelper;
import jiguang.chat.utils.ModulesConstants;
import jiguang.chat.utils.SharePreferenceManager;
import jiguang.chat.utils.ToastUtil;
import jiguang.chat.utils.event.BusEventMessage;
import jiguang.chat.utils.oss.Constants;
import jiguang.chat.utils.oss.SharedPreferenciesUtil;

public class MainActivity extends BaseWebActivity {
    public static MainActivity instance;

    private int currentId = 0;


    private int friendIndex = 5;

    private RadioButton btn_msg, btn_patient, btn_friend, btn_my;

    private FragmentManager fragmentManager;
    private FragmentTransaction fragmentTransaction;


    private static Dialog dialog;

    protected int mWidth;
    protected int mHeight;
    protected float mDensity;
    protected int mDensityDpi;


    private View.OnClickListener tabOnClickListener = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            changeTab(v.getId());
        }
    };

    MessageFragment messageFragment;
    SettingFragment settingFragment;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        HuidrActivityManager.getInstance().setMainActivity(this);
        EventBus.getDefault().register(this);
//        杀死进程重新打开 显示消息
        SharedPreferenciesUtil.putData("currentId", 0);


    }

    @Override
    protected void onStart() {

        super.onStart();
        Log.e("MainActivity", "onStart");
        String loginState = (String) SharedPreferenciesUtil.getData(Constants.SharedAccountConfig.IS_LOGIN, "0");

        if (loginState == null || loginState.equals("0")) {
            Intent intent1 = new Intent(MainActivity.this, LoginActivity.class);
            startActivity(intent1);
            finish();
        } else {
//            JMessageClient.registerEventReceiver(this);

            DisplayMetrics dm = new DisplayMetrics();
            getWindowManager().getDefaultDisplay().getMetrics(dm);
            mDensity = dm.density;
            mDensityDpi = dm.densityDpi;
            mWidth = dm.widthPixels;
            mHeight = dm.heightPixels;

//            mian 页面显示选项
            currentId = (int) SharedPreferenciesUtil.getData("currentId", 0);

            HuidrActivityManager.getInstance().finishSplashActivity();
            instance = this;
            setContentView(R.layout.activity_main);
//            SharedPreferenciesUtil.putData("friendIndex", 0);
            SharedPreferenciesUtil.putData("patientIndex", 0);
            SharedPreferenciesUtil.putData("currentFragment", 0);
            initPageView();
            String id = (String) SharedPreferenciesUtil.getData("id", "0");
            String pwd = (String) SharedPreferenciesUtil.getData(Constants.SharedAccountConfig.ImPassword, "0");
            LogUtil.e("登录状态id+pwd", id + "   " + pwd);
            LitePalDB litePalDB = LitePalDB.fromDefault(id + "");
            LitePal.use(litePalDB);
            loginJiguangIm(id, pwd);
            JPushInterface.setAlias(MainActivity.instance, 0, id);

        }

    }


    @Override
    protected void onResume() {
        super.onResume();
        Log.e("MainActivity", "onResume" + currentId);
        refreshPage();
    }

    @Override
    protected void onStop() {
        super.onStop();
        Log.e("MainActivity", "onStop" + currentId);

    }

    /*
     * 接收极光事件
     *
     * */
    public void onEventMainThread(LoginStateChangeEvent event) {
        final LoginStateChangeEvent.Reason reason = event.getReason();

        UserInfo myInfo = event.getMyInfo();
        if (myInfo != null) {
            String path;
            File avatar = myInfo.getAvatarFile();
            if (avatar != null && avatar.exists()) {
                path = avatar.getAbsolutePath();
            } else {
                path = FileHelper.getUserAvatarPath(myInfo.getUserName());
            }
            SharePreferenceManager.setCachedUsername(myInfo.getUserName());
            SharePreferenceManager.setCachedAvatarPath(path);
            JMessageClient.logout();
        }
        switch (reason) {
            case user_logout:
                View.OnClickListener listener = new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {

                        if (v.getId() == R.id.jmui_cancel_btn) {

                            ToastUtil.shortToast(MainActivity.this, "顶号登录-取消登录");
                            dialog.cancel();
                            BusEventMessage busEventMessage = new BusEventMessage(ModulesConstants.RE_LOGIN);
                            EventBus.getDefault().post(busEventMessage);
                        }
                        if (v.getId() == R.id.jmui_commit_btn) {

                            JMessageClient.login(SharePreferenceManager.getCachedUsername(), SharePreferenceManager.getCachedPsw(), new BasicCallback() {
                                @Override
                                public void gotResult(int responseCode, String responseMessage) {
                                    if (responseCode == 0) {
                                        ToastUtil.shortToast(MainActivity.this, "顶号登录-确认登录");
                                        dialog.dismiss();
                                        dialog.cancel();
                                        BusEventMessage busEventMessage = new BusEventMessage(ModulesConstants.JG_LOGIN_SUC);
                                        EventBus.getDefault().post(busEventMessage);
                                    }
                                }
                            });
                        }
                    }
                };
                if (dialog == null) {
                    Log.e("重复登录", "activity");
                    dialog = DialogCreator.createLogoutStatusDialog(MainActivity.this, "您的账号在其他设备上登陆", listener);
                    dialog.getWindow().setLayout((int) (0.8 * mWidth), WindowManager.LayoutParams.WRAP_CONTENT);
                    dialog.setCanceledOnTouchOutside(false);
                    dialog.show();
                }
                break;
            case user_password_change:
                // Intent intent = new Intent(BaseActivity.this, LoginActivity.class);
                // startActivity(intent);
                break;
        }
    }


    @Subscribe(threadMode = ThreadMode.MAIN)
    public void onEvent(EventBusMessage message) {
        Log.e("收到消息—Main", message.message);

        switch (message.message) {
            case "1":
//                friendIndex = 2;
//                changeTab(R.id.tab_friend);


//                btn_patient.setChecked(true);
//                fragmentTransaction.replace(R.id.fl_content, new PatientFragment());
//
////                currentId = 1;

//                LogUtil.e("current-id1", currentId + " ");
//                btn_msg.setClickable(true);
//                btn_patient.setClickable(false);
//                btn_friend.setClickable(true);
//                btn_my.setClickable(true);
                currentId = 2;
                SharedPreferenciesUtil.putData("friendIndex", 2);
                refreshPage();

                break;

//            case "show_icon":
//                Log.e("收到推送", "收到推送");
//                ImageView imageView = messageFragment.getView().findViewById(R.id.img_notice_que);
//                imageView.setVisibility(View.VISIBLE);
//                break;
        }
    }


    @Override
    protected void onDestroy() {
        super.onDestroy();


        HuidrActivityManager.getInstance().setMainActivity(null);
        if (dialog != null) {
            dialog.dismiss();
        }
    }

    @Override
    protected void onNewIntent(Intent intent) {
        setIntent(intent);
    }

    /*
     * 初始化页面按钮
     * */
    public void initPageView() {
        btn_msg = (RadioButton) findViewById(R.id.tab_message);
        btn_patient = (RadioButton) findViewById(R.id.tab_follow);
        btn_friend = (RadioButton) findViewById(R.id.tab_friend);
        btn_my = (RadioButton) findViewById(R.id.tab_me);

        btn_msg.setOnClickListener(tabOnClickListener);
        btn_patient.setOnClickListener(tabOnClickListener);
        btn_friend.setOnClickListener(tabOnClickListener);
        btn_my.setOnClickListener(tabOnClickListener);
        reSize(btn_msg);
        reSize(btn_patient);
        reSize(btn_friend);
        reSize(btn_my);
    }

    //   设置页面显示  刷新页面
//    currentId  0 1 2 对应底部按钮
    public void refreshPage() {
        switch (currentId) {
            case 0:
                changeTab(R.id.tab_message);
                break;
            case 1:
                changeTab(R.id.tab_follow);
                break;
            case 2:
                changeTab(R.id.tab_friend);
                break;
            case 3:
                changeTab(R.id.tab_me);
                break;
        }
//        完成跳转后 设置currentId为0  避免出现杀死重新打开显示 currentId页
//        SharedPreferenciesUtil.putData("currentId", 0);
    }


    /*
     * 切换页面
     * 点击事件
     *
     * 消息
     * 随访
     * 联系人
     * 我
     * */
    public void changeTab(int id) {
        fragmentManager = getSupportFragmentManager();
        fragmentTransaction = fragmentManager.beginTransaction();
        settingFragment = new SettingFragment();
        switch (id) {
            case R.id.tab_message:
                TCAgent.onEvent(MainActivity.this, "点击消息列表的次数 ", "点击消息列表的次数 ");
                btn_msg.setChecked(true);
                messageFragment = new MessageFragment();
                fragmentTransaction.replace(R.id.fl_content, messageFragment);
                currentId = 0;
                SharedPreferenciesUtil.putData("currentId", 0);
                LogUtil.e("current-id0", currentId + " ");
                btn_msg.setClickable(false);
                btn_patient.setClickable(true);
                btn_friend.setClickable(true);
                btn_my.setClickable(true);
                break;
            case R.id.tab_follow:
                btn_patient.setChecked(true);
                fragmentTransaction.replace(R.id.fl_content, new PatientFragment());
                currentId = 1;
                SharedPreferenciesUtil.putData("currentId", 1);
                LogUtil.e("current-id1", currentId + " ");
                btn_msg.setClickable(true);
                btn_patient.setClickable(false);
                btn_friend.setClickable(true);
                btn_my.setClickable(true);
                break;
            case R.id.tab_friend:
                btn_friend.setChecked(true);
                DoctorFragment doctorFragment = new DoctorFragment();
                Bundle bundle = new Bundle();
                bundle.putInt("key", friendIndex);
                doctorFragment.setArguments(bundle);
                fragmentTransaction.replace(R.id.fl_content, doctorFragment);
                currentId = 2;
                SharedPreferenciesUtil.putData("currentId", 2);
                btn_msg.setClickable(true);
                btn_patient.setClickable(true);
                btn_friend.setClickable(false);
                btn_my.setClickable(true);
                friendIndex = 5;
                break;
            case R.id.tab_me:

                btn_my.setChecked(true);
                fragmentTransaction.replace(R.id.fl_content, settingFragment);
                currentId = 3;
                SharedPreferenciesUtil.putData("currentId", 3);
                LogUtil.e("current-id3", currentId + " ");
                btn_msg.setClickable(true);
                btn_patient.setClickable(true);
                btn_friend.setClickable(true);
                btn_my.setClickable(false);
                break;
        }
        fragmentTransaction.commit();
    }

    /*
     * 设置radiobutton  drawableTop大小
     * */
    public void reSize(RadioButton radioButton) {
        Rect rect = new Rect();
        rect.set(0, 0, 60, 60);
        Drawable[] drawables = radioButton.getCompoundDrawables();
        drawables[1].setBounds(rect);
        radioButton.setCompoundDrawables(null, drawables[1], null, null);
    }


    /*
     * 登录极光IM
     * */
    private void loginJiguangIm(final String name, String password) {

        LogUtil.e("登录状态开始", name + "    " + password);
        JMessageClient.login(name, password, new BasicCallback() {
            @Override
            public void gotResult(int responseCode, String responseMessage) {
                if (responseCode == 0) {

                    LogUtil.e("登录成功", "dengluchenggong");
                    SharePreferenceManager.setCachedPsw("123456");
                    UserInfo myInfo = JMessageClient.getMyInfo();
                    File avatarFile = myInfo.getAvatarFile();
                    //登陆成功,如果用户有头像就把头像存起来,没有就设置null
                    if (avatarFile != null) {
                        SharePreferenceManager.setCachedAvatarPath(avatarFile.getAbsolutePath());
                    } else {
                        SharePreferenceManager.setCachedAvatarPath(null);
                    }
                    String username = myInfo.getUserName();
                    String appKey = myInfo.getAppKey();
                    UserEntry user = UserEntry.getUser(username, appKey);
                    if (null == user) {
                        user = new UserEntry(username, appKey);
                        user.save();
                    }
                    BusEventMessage busEventMessage = new BusEventMessage(ModulesConstants.JG_LOGIN_SUC);
                    EventBus.getDefault().post(busEventMessage);
                } else {
                    LogUtil.e("im", "登录失败" + responseCode + "        " + responseMessage);
                }
            }
        });
    }


    /*
     * 返回事件点击
     * */
    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if ((keyCode == KeyEvent.KEYCODE_BACK)) {
            HuidrActivityManager.getInstance().finishAll();
//            long currentTime = System.currentTimeMillis();
//            if ((currentTime - lastTime) > 2000) {
//                // 两次点击间隔超过2秒
//                Toast.makeText(this, "再点击一次退出应用", Toast.LENGTH_SHORT).show();
//                // 记录时间
//                lastTime = currentTime;
//            } else {
//                // 两次点击再2秒内, 即退出
//                HuidrActivityManager.getInstance().finishAll();
//            }
        }
        boolean _ret = EntryProxy.getInstnace().onActivityExecute(this, ISysEventListener.SysEventType.onKeyDown, new Object[]{keyCode, event});
        return _ret ? _ret : super.onKeyDown(keyCode, event);
    }


    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        settingFragment.onActivityResult(requestCode, resultCode, data);
    }


}