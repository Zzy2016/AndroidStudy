package com.huidr.HuiDrDoctor.content_fragment;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.BitmapDrawable;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import androidx.annotation.NonNull;

import android.text.Html;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.alibaba.fastjson.JSONObject;
import com.chad.library.adapter.base.BaseQuickAdapter;
import com.chad.library.adapter.base.BaseViewHolder;
import com.google.gson.Gson;
import com.huidr.HuiDrDoctor.activity.ConsultReplyActivity;
import com.huidr.HuiDrDoctor.activity.DealConsultActivity;
import com.huidr.HuiDrDoctor.activity.WebActivity;
import com.huidr.HuiDrDoctor.activity.main.Consult.utils.PostAndGet;
import com.huidr.HuiDrDoctor.debug.BuildConfig;
import com.huidr.HuiDrDoctor.debug.R;
import com.huidr.HuiDrDoctor.module.home.NewConsultOrderList;
import com.huidr.HuiDrDoctor.module.consult.OrderDetail;
import com.huidr.HuiDrDoctor.util.CircleImageView;
import com.huidr.HuiDrDoctor.util.DownLoadImg;
import com.huidr.HuiDrDoctor.util.LogUtil;
import com.huidr.HuiDrDoctor.util.MulityClickUtils;
import com.huidr.HuiDrDoctor.util.ThreadPoolManager;
import com.huidr.lib.commom.base.BaseFragment;
import com.scwang.smartrefresh.layout.SmartRefreshLayout;
import com.scwang.smartrefresh.layout.api.RefreshLayout;
import com.scwang.smartrefresh.layout.listener.OnLoadMoreListener;
import com.scwang.smartrefresh.layout.listener.OnRefreshListener;

import java.io.File;
import java.io.Serializable;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import androidx.annotation.RequiresApi;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import cn.jpush.im.android.api.JMessageClient;
import cn.jpush.im.android.api.content.TextContent;
import cn.jpush.im.android.api.model.Conversation;
import jiguang.chat.utils.oss.OssService;
import jiguang.chat.utils.oss.SharedPreferenciesUtil;

import static com.huidr.HuiDrDoctor.util.DownLoadImg.getCirleBitmap;
import static com.huidr.HuiDrDoctor.util.FormatTime.getTime;

/**
 * 图文咨询列表
 */
public class ConListFragment extends BaseFragment {

    private SmartRefreshLayout srlLayout;
    private RecyclerView rvListCon;
    private List<NewConsultOrderList.RetValueBean.OrderInfoListBean> allConList;
    private List<NewConsultOrderList.RetValueBean.OrderInfoListBean> temConList;
    private Gson gson;
    private int page = 1;
    private int totalPage = 1;

    private ConstraintLayout clEmptyLayout;
    private TextView tvEmpty, tvLink;
    private Button btnLink;

    private int consultOpen;//图文咨询是否开启 1开启 0关闭
    OssService ossService;

    String rootPath;//文件保存根目录
    File file;//图片文件

    long lastClick = 0;


    @Override
    protected void initData() {

        rootPath = getContext().getExternalFilesDir("").getAbsolutePath() + "/image/patient/";

        ossService = new OssService(getContext());
        allConList = new ArrayList<>();
        temConList = new ArrayList<>();
        gson = new Gson();


    }

    @Override
    protected View setContentView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_con_list, container, false);
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        LogUtil.e("获取图文咨询状态", 1 + " onCreate");
    }

    @Override
    public void onResume() {
        super.onResume();
//        LogUtil.e("获取图文咨询状态", 1 + "onResume ");
    }

    //    空态页组件 设置显示 监听
//       根据 按钮显示跳转不同url
    public void initEmptyView(View view) {
        clEmptyLayout = view.findViewById(R.id.cl_layout_empty);
        tvEmpty = view.findViewById(R.id.tv_empty);
        tvLink = view.findViewById(R.id.tv_link);
        btnLink = view.findViewById(R.id.btn_link);

        btnLink.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (MulityClickUtils.isFastClick()) {
                    Intent intent = new Intent(getActivity(), WebActivity.class);
                    Bundle bundle = new Bundle();
                    if (btnLink.getText().toString().equals("图文咨询")) {
                        bundle.putString("url", "consultation.html");
                        intent.putExtras(bundle);
                        startActivity(intent);
                    } else {
//                    bundle.putString("url", "");
                        Toast.makeText(getContext(), "暂未开通", Toast.LENGTH_SHORT).show();
                    }
                }

            }
        });
    }


    @Override
    protected void findView(View parent) {
        srlLayout = parent.findViewById(R.id.srl_layout);
        rvListCon = parent.findViewById(R.id.rv_list_con);

        srlLayout.setEnableLoadMore(true);
        srlLayout.setEnableRefresh(true);

        rvListCon.setAdapter(adapter);

        rvListCon.setLayoutManager(new LinearLayoutManager(getContext()));

        srlLayout.setOnLoadMoreListener(new OnLoadMoreListener() {
            @Override
            public void onLoadMore(@NonNull RefreshLayout refreshLayout) {

                if (temConList.size() == 10 && page < totalPage) {
                    getConsultListByPage(++page);
                } else {
                    srlLayout.finishLoadMore();
                    com.huidr.lib.commom.util.Toast.getInstance(getActivity()).show("加载全部", 500);
                }

            }
        });


        srlLayout.setOnRefreshListener(new OnRefreshListener() {
            @Override
            public void onRefresh(@NonNull RefreshLayout refreshLayout) {
                adapter.getData().clear();
                page = 1;
                getConsultListByPage(page);
            }
        });

        initEmptyView(parent);
    }

    //    分页获取图文咨询
    public void getConsultListByPage(final int page) {
        ThreadPoolManager.getInstance().execute(new Runnable() {
            @Override
            public void run() {
                String path = BuildConfig.baseUrl + "pay/orderSearch/searchConsult";
                String id = (String) SharedPreferenciesUtil.getData("id", "0");
                JSONObject jsonObject = new JSONObject();
                jsonObject.put("sellerId", id);
                jsonObject.put("pageIndex", page);
                String result = PostAndGet.doHttpPost(path, jsonObject);

                if (result.equals("网络异常")) {
                    handler.sendEmptyMessage(100);
                } else {
                    NewConsultOrderList list = gson.fromJson(result, NewConsultOrderList.class);
                    Message message = new Message();
                    if (list.getStatus() == 0) {
                        totalPage = list.getTotalPage();
                        if (page == 1) {  //刷新第一页
                            message.what = 1;
                        } else {  //加载更多
                            message.what = 2;
                        }
                        temConList = list.getRetValue().getOrderInfoList();
                        consultOpen = list.getRetValue().getIsOpen();
                    } else {
                        message.what = 100;
                        message.arg1 = list.getStatus();
                    }
                    handler.sendMessage(message);
                }
            }
        });
    }


    /*
     * 1  刷新  有数据 无数据
     * 2  加载更多
     * 100  报错
     *
     * */
    private Handler handler = new Handler() {
        @Override
        public void handleMessage(Message msg) {
            super.handleMessage(msg);

            switch (msg.what) {
                case 1:
                    /*
                     * 医生打开图文咨询功能 1  显示列表 列表可能为空
                     * 医生关闭图文咨询功能 0  显示 提示打开页
                     * */
                    if (consultOpen == 0) {
                        clEmptyLayout.setVisibility(View.VISIBLE);
                        srlLayout.setVisibility(View.GONE);
                        tvEmpty.setText("抱歉您还未开启图文咨询设置");
                        tvLink.setText(Html.fromHtml("开启<font color='#248cfa'>图文咨询</font>"));
                        btnLink.setText("图文咨询");
                        if (btnLink.getVisibility() == View.GONE) {
                            btnLink.setVisibility(View.VISIBLE);
                        }
                    } else {
                        adapter.getData().clear();
//                        列表为空
                        if (temConList.size() == 0) {
                            clEmptyLayout.setVisibility(View.VISIBLE);
                            srlLayout.setVisibility(View.GONE);
                            String tvEmptyStr = "抱歉您还未收到图文咨询申请";
                            String tvLinkStr = "先去<font color='color'>一问医答</font>看看吧!";
                            tvEmpty.setText(tvEmptyStr);
                            tvLink.setText(Html.fromHtml(tvLinkStr));
                            btnLink.setText("一问医答");
                            if (btnLink.getVisibility() == View.GONE) {
                                btnLink.setVisibility(View.VISIBLE);
                            }
                        } else {
                            if (srlLayout.getVisibility() == View.GONE) {
                                srlLayout.setVisibility(View.VISIBLE);
                                clEmptyLayout.setVisibility(View.GONE);
                            }
                            adapter.getData().addAll(temConList);
                            adapter.notifyDataSetChanged();

//                            allConList.addAll(temConList);
//                            consultAdapter.notifyDataSetChanged();
                        }
                    }

                    srlLayout.finishRefresh();
                    break;

                case 2:
                    adapter.getData().addAll(temConList);
                    adapter.notifyDataSetChanged();

//                    allConList.addAll(temConList);
//                    consultAdapter.notifyDataSetChanged();

                    srlLayout.finishLoadMore();
                    break;
                case 100:
                    srlLayout.finishRefresh();
                    srlLayout.finishLoadMore();

                    if (msg.arg1 == -2) {

                    } else {
                        clEmptyLayout.setVisibility(View.VISIBLE);
                        srlLayout.setVisibility(View.GONE);
                        tvEmpty.setText("网络错误~");
                        String str = "<font color='#248cfa'><u>立即刷新</u><font>";
                        tvLink.setText(Html.fromHtml(str));
                        btnLink.setVisibility(View.GONE);
                        tvLink.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {
                                if (MulityClickUtils.isFastClick()) {
                                    getConsultListByPage(1);
                                    com.huidr.lib.commom.util.Toast.getInstance(getContext()).show("正在刷新", 500);
                                }
                            }
                        });
                    }

                    break;
            }
        }
    };

    @Override
    public void setUserVisibleHint(boolean isVisibleToUser) {
        if (isVisibleToUser) {
            getConsultListByPage(page);
        }
    }

    private BaseQuickAdapter<NewConsultOrderList.RetValueBean.OrderInfoListBean, BaseViewHolder> adapter = new BaseQuickAdapter<NewConsultOrderList.RetValueBean.OrderInfoListBean, BaseViewHolder>(R.layout.msg_item_layout) {
        @RequiresApi(api = Build.VERSION_CODES.KITKAT)
        @SuppressLint("ResourceAsColor")
        @Override
        protected void convert(final BaseViewHolder helper, final NewConsultOrderList.RetValueBean.OrderInfoListBean item) {


            helper.setIsRecyclable(false);

            ConstraintLayout clLayout = helper.getView(R.id.cl_layout);

            final CircleImageView imgItemHead = helper.getView(R.id.img_item_head);

            Bitmap defaultBitmap = BitmapFactory.decodeResource(getResources(), R.drawable.head_patient);
            BitmapDrawable defaultBitmapDrawable = new BitmapDrawable(getResources(), defaultBitmap);
            imgItemHead.setBackgroundDrawable(defaultBitmapDrawable);

            if (item.getUserIcon() != null) {
                imgItemHead.setTag(item.getUserIcon());
                file = new File(rootPath + item.getUserIcon());
                if (file.exists()) {
                    Bitmap bitmap = BitmapFactory.decodeFile(file.getAbsolutePath());
                    if (bitmap != null) {
                        bitmap = getCirleBitmap(bitmap);
                        BitmapDrawable bitmapDrawable = new BitmapDrawable(getResources(), bitmap);
                        if (imgItemHead.getTag().equals(item.getUserIcon())) {
                            imgItemHead.setBackgroundDrawable(bitmapDrawable);
                        }
                    }

                } else {
                    DownLoadImg.BitmapWorkerTask bitmapWorkerTask = new DownLoadImg.BitmapWorkerTask(imgItemHead, file, ossService);
                    bitmapWorkerTask.execute(item.getUserIcon());
                }
            } else {
                imgItemHead.setBackgroundDrawable(defaultBitmapDrawable);
            }

            ImageView imgNotice = helper.getView(R.id.img_notice);

            TextView textViewName = helper.getView(R.id.tv_item_name);
            ImageView imgGender = helper.getView(R.id.image_item_gender);
            if (item.getSex() == 1) {
                imgGender.setBackgroundResource(R.drawable.gender_man);
            } else {
                imgGender.setBackgroundResource(R.drawable.gender_w);
            }
            TextView textViewAge = helper.getView(R.id.tv_item_age);
            textViewAge.setVisibility(View.VISIBLE);
            textViewAge.setText(item.getAge() + "岁");
            final TextView textViewState = helper.getView(R.id.tv_item_state);
            TextView textDate = helper.getView(R.id.tv_item_date);
            TextView textDesc = helper.getView(R.id.tv_item_msg);


            final OrderDetail orderDetail = gson.fromJson(item.getOrderDetails(), OrderDetail.class);


            final int patientID = orderDetail.getPatientId();
            final String nickName = orderDetail.getPatientName();

            textViewName.setText(orderDetail.getPatientName());

            imgGender.setVisibility(View.VISIBLE);
            textViewState.setVisibility(View.VISIBLE);

            if (item.getCreateTime() != null) {

                SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
                Date date = null;
                try {
                    date = format.parse(item.getCreateTime());
                } catch (ParseException e) {
                    e.printStackTrace();
                }
                textDate.setText(getTime(date.getTime()));
            }


            int action = item.getOrderStatusAction();
            int status = item.getOrderStatus();

            if (status == 0) {
                textViewState.setText("待支付");
            } else if (status == 1) {
                textViewState.setText("向您咨询");
                textViewState.setBackgroundResource(R.drawable.state_back_wait);

                textDesc.setText(orderDetail.getNeedHelp());

            } else if (status == 2) {
                if (action == 3) {
                    textViewState.setText("咨询中"); //咨询中\
                    textViewState.setBackgroundResource(R.drawable.state_back_ing);

                    Conversation conversation = JMessageClient.getSingleConversation(item.getBuyerId() + "", BuildConfig.patientAppkey);
                    if (conversation != null) {
                        conversation = Conversation.createSingleConversation(item.getBuyerId() + "", BuildConfig.patientAppkey);

                        cn.jpush.im.android.api.model.Message message = conversation.getLatestMessage();
                        if (message != null) {

                            switch (message.getContentType()) {
                                case text:
                                    textDesc.setText(((TextContent) message.getContent()).getText());
                                    break;
                                case voice:
                                    textDesc.setText("[语音消息]");
                                    break;
                                case image:
                                    textDesc.setText("[图片]");
                                    break;
                                case file:
                                    textDesc.setText("[文件]");
                                    break;
                                case location:
                                    textDesc.setText("[位置]");
                                    break;
                                default:

                                    break;
                            }
                        } else {
                            textDesc.setText("暂无聊天消息");
                        }


                        textDate.setText(getTime(conversation.getLastMsgDate()));

                        if (conversation.getUnReadMsgCnt() > 0) {
                            imgNotice.setVisibility(View.VISIBLE);
                        } else {
                            imgNotice.setVisibility(View.GONE);
                        }

                    } else {
                        textDesc.setText("");
                    }

                }
            } else if (status == 3) {
                if (action == 12 || action == 5) {
                    textViewState.setText("已结束"); //已结束
                    textViewState.setBackgroundResource(R.drawable.state_back_end);

                    String suggest = "";
                    if (item.getSuggestion() != null) {
                        suggest = "<font color='#248cfa'>" + item.getSuggestion() + "</font>";
                    } else {
                        suggest = "<font color='#248cfa'>无建议</font>";
                    }
                    textDesc.setText(Html.fromHtml(suggest));

                }
            } else if (status == 101) {
                if (action == 9) {
                    textViewState.setText("已取消");
                    textViewState.setBackgroundResource(R.drawable.state_back_end_con);
                } else if (action == 2) {
                    textViewState.setText("患者主动取消");
                    textViewState.setBackgroundResource(R.drawable.state_back_end_con);
                }
                textDesc.setText(orderDetail.getNeedHelp());
            } else if (status == 102) {
                if (action == 2) {
                    textViewState.setText("已取消");
                    textViewState.setBackgroundResource(R.drawable.state_back_end_con);
                } else if (action == 13) {
                    textViewState.setText("已取消");
                    textViewState.setBackgroundResource(R.drawable.state_back_end_con);
                } else if (action == 4) {
                    textViewState.setText("已取消");
                    textViewState.setBackgroundResource(R.drawable.state_back_end_con);
                }
                textDesc.setText(orderDetail.getNeedHelp());
            } else {
                textViewState.setText("其他");
            }

            clLayout.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {

                    if (JMessageClient.getMyInfo() == null) {
                        return;
                    }

                    long currentClick = System.currentTimeMillis();
                    if (currentClick - lastClick > 1000) {
                        lastClick = currentClick;
                        if (textViewState.getText().toString().equals("咨询中")) {
                            Intent intent1 = new Intent(getActivity(), ConsultReplyActivity.class);
                            Bundle bundle = new Bundle();
                            bundle.putString("username", item.getBuyerId() + "");
                            bundle.putString("nickname", nickName);
                            bundle.putString("orderid", item.getOrderId());
                            bundle.putString("patientUid", patientID + "");
                            bundle.putInt("state", 1);
                            intent1.putExtras(bundle);
                            startActivity(intent1);
                        } else if (textViewState.getText().toString().equals("向您咨询")) {
                            String dateTime = item.getCreateTime() + " 123";
                            Calendar calendar = Calendar.getInstance();
                            try {
                                calendar.setTime(new SimpleDateFormat("yyyy-MM-dd HH:mm:ss SSS").parse(dateTime));
                            } catch (ParseException e) {
                                e.printStackTrace();
                            }
                            long alltime = System.currentTimeMillis() - calendar.getTimeInMillis();

                            alltime = (1000 * 60 * 60 * 24) - alltime;
                            Intent intent1 = new Intent(getActivity(), DealConsultActivity.class);
                            Bundle bundle = new Bundle();
                            bundle.putString("username", nickName);  //患者姓名
                            bundle.putString("orderId", item.getOrderId());   //订单号
                            if (alltime <= 0) {
                                bundle.putInt("hours", 0);     //小时
                                bundle.putInt("minutes", 0);    //分钟
                                bundle.putInt("seconds", 0);    //秒
                            } else {
                                bundle.putInt("hours", (int) (alltime / 3600000));     //小时
                                bundle.putInt("minutes", (int) ((alltime % 3600000) / 60000));    //分钟
                                bundle.putInt("seconds", (int) ((alltime % 60000) / 1000));    //秒
                            }
                            bundle.putSerializable("imgs", (Serializable) orderDetail.getPics());//图片
                            bundle.putString("patientUserId", item.getBuyerId() + "");//患者ID  100148
                            bundle.putString("patientId", item.getBuyerRelationId() + "");//患者ID  62444
                            bundle.putString("desc", orderDetail.getNeedHelp());//主诉
                            intent1.putExtras(bundle);
                            startActivity(intent1);
                        } else if (textViewState.getText().toString().equals("已结束")) {
                            Intent intent1 = new Intent(getActivity(), ConsultReplyActivity.class);
                            Bundle bundle = new Bundle();
                            bundle.putString("username", item.getBuyerId() + "");
                            bundle.putString("nickname", nickName);
                            bundle.putString("orderid", item.getOrderId());
                            bundle.putString("patientUid", patientID + "");
                            bundle.putInt("state", 0);
                            intent1.putExtras(bundle);
                            startActivity(intent1);
                        }
                    }
                }
            });
        }
    };

}
