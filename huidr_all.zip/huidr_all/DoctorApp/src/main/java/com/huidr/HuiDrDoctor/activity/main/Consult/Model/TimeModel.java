package com.huidr.HuiDrDoctor.activity.main.Consult.Model;

public class TimeModel {

    /**
     * status : 0
     * retValue : {"id":2588,"orderId":"2019092820580927402608","pathologyUrl":null,"commitTime":1569675555000,"consultContent":"医生已经接受您的咨询申请，赶快向医生咨询吧","userType":1,"contentType":4,"isSuggest":false,"suggest":"测试测试测试测试测试123","doctorUid":null,"doctorName":null,"patientUid":null,"patientName":null}
     */

    private int status;
    private RetValueBean retValue;

    public int getStatus() {
        return status;
    }

    public void setStatus(int status) {
        this.status = status;
    }

    public RetValueBean getRetValue() {
        return retValue;
    }

    public void setRetValue(RetValueBean retValue) {
        this.retValue = retValue;
    }

    public static class RetValueBean {
        /**
         * id : 2588
         * orderId : 2019092820580927402608
         * pathologyUrl : null
         * commitTime : 1569675555000
         * consultContent : 医生已经接受您的咨询申请，赶快向医生咨询吧
         * userType : 1
         * contentType : 4
         * isSuggest : false
         * suggest : 测试测试测试测试测试123
         * doctorUid : null
         * doctorName : null
         * patientUid : null
         * patientName : null
         */

        private int id;
        private String orderId;
        private Object pathologyUrl;
        private long commitTime;
        private String consultContent;
        private int userType;
        private int contentType;
        private boolean isSuggest;
        private String suggest;
        private Object doctorUid;
        private Object doctorName;
        private Object patientUid;
        private Object patientName;

        public int getId() {
            return id;
        }

        public void setId(int id) {
            this.id = id;
        }

        public String getOrderId() {
            return orderId;
        }

        public void setOrderId(String orderId) {
            this.orderId = orderId;
        }

        public Object getPathologyUrl() {
            return pathologyUrl;
        }

        public void setPathologyUrl(Object pathologyUrl) {
            this.pathologyUrl = pathologyUrl;
        }

        public long getCommitTime() {
            return commitTime;
        }

        public void setCommitTime(long commitTime) {
            this.commitTime = commitTime;
        }

        public String getConsultContent() {
            return consultContent;
        }

        public void setConsultContent(String consultContent) {
            this.consultContent = consultContent;
        }

        public int getUserType() {
            return userType;
        }

        public void setUserType(int userType) {
            this.userType = userType;
        }

        public int getContentType() {
            return contentType;
        }

        public void setContentType(int contentType) {
            this.contentType = contentType;
        }

        public boolean isIsSuggest() {
            return isSuggest;
        }

        public void setIsSuggest(boolean isSuggest) {
            this.isSuggest = isSuggest;
        }

        public String getSuggest() {
            return suggest;
        }

        public void setSuggest(String suggest) {
            this.suggest = suggest;
        }

        public Object getDoctorUid() {
            return doctorUid;
        }

        public void setDoctorUid(Object doctorUid) {
            this.doctorUid = doctorUid;
        }

        public Object getDoctorName() {
            return doctorName;
        }

        public void setDoctorName(Object doctorName) {
            this.doctorName = doctorName;
        }

        public Object getPatientUid() {
            return patientUid;
        }

        public void setPatientUid(Object patientUid) {
            this.patientUid = patientUid;
        }

        public Object getPatientName() {
            return patientName;
        }

        public void setPatientName(Object patientName) {
            this.patientName = patientName;
        }
    }
}
