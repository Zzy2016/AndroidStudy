package com.huidr.HuiDrDoctor.activity;

import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.BitmapShader;
import android.graphics.Canvas;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.Shader;
import android.graphics.drawable.BitmapDrawable;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Message;
import androidx.annotation.NonNull;

import androidx.appcompat.app.AppCompatActivity;

import android.text.Editable;
import android.text.Html;
import android.text.TextWatcher;
import android.view.Display;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.alibaba.fastjson.JSONObject;
import com.chad.library.adapter.base.BaseQuickAdapter;
import com.chad.library.adapter.base.BaseViewHolder;
import com.google.android.flexbox.FlexDirection;
import com.google.android.flexbox.FlexWrap;
import com.google.android.flexbox.FlexboxLayoutManager;
import com.google.gson.Gson;
import com.guanaj.easyswipemenulibrary.EasySwipeMenuLayout;
import com.huidr.HuiDrDoctor.activity.main.Consult.utils.PostAndGet;
import com.huidr.HuiDrDoctor.debug.BuildConfig;
import com.huidr.HuiDrDoctor.debug.R;
import com.huidr.HuiDrDoctor.module.home.HisSearchModel;
import com.huidr.HuiDrDoctor.module.home.MessageSearchModel;
import com.huidr.HuiDrDoctor.module.home.SimpleResultModel;
import com.huidr.HuiDrDoctor.util.LogUtil;
import com.huidr.HuiDrDoctor.util.ThreadPoolManager;
import com.scwang.smartrefresh.layout.SmartRefreshLayout;
import com.scwang.smartrefresh.layout.api.RefreshLayout;
import com.scwang.smartrefresh.layout.listener.OnLoadMoreListener;
import com.scwang.smartrefresh.layout.listener.OnRefreshListener;
import com.tendcloud.tenddata.TCAgent;

import java.io.File;
import java.io.FileOutputStream;
import java.util.ArrayList;
import java.util.List;

import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import jiguang.chat.utils.oss.OssService;
import jiguang.chat.utils.oss.SharedPreferenciesUtil;

/*
 * 搜索页
 * 显示 搜索历史
 *     搜搜结果
 *     空态页(开启随访,未开启随访)
 *
 * */
public class SearchActivity extends AppCompatActivity implements View.OnClickListener {

//    private ImageView imgSearch, imgClear;
//    private EditText etSearch;
//    private TextView tvCancel;
//    private ConstraintLayout clHis;
//    private RecyclerView rvHisSearch;
//    private InputMethodManager imm;
//    //    空态
//    private ConstraintLayout clEmpty;
//    private TextView tvEmpty;
//    private TextView tvEmpty1;
//    private Button btnLink;
//    //    历史搜索空态
//    private ConstraintLayout cl_empty_his;
//    private TextView tv_empty_his1, tv_empty_his2;
//    private boolean showSearch;//显示搜索 true
//    private HisSearchModel hisSearchModel;
//    private List<HisSearchModel.RetValueBean> hisSearchList;
//    private MessageSearchModel messageSearchModel;
//    private List<MessageSearchModel.RetValueBean.DoctorBean> doctorList;
//    private List<MessageSearchModel.RetValueBean.PatientBean> patientList;
//    private Gson gson;
//    private String pathHis = BuildConfig.baseUrl + "hospital/search/searchHis";//历史搜索
//
//    private OssService ossService;
//    private String doctorId = (String) SharedPreferenciesUtil.getData("id", "0");
//    private long lastClick = 0;
//    private long lastClick2 = 0;
//    private String path;
//    private Matrix matrix;
//    private TabLayout tabTitle;
//    private ConstraintLayout clSearch;
//    private RecyclerView rvDoctor, rvPatient;
//    private int searchIndex = 0; //0  患者 1 医生
//    private TextView tvPatientLink, tvDoctorLink;
//    private ImageView imgDeleteHis;
//
//    @Override
//    protected void onCreate(Bundle savedInstanceState) {
//        super.onCreate(savedInstanceState);
//        setContentView(R.layout.activity_search);
//        matrix = new Matrix();
//        matrix.setRotate(90);
//        TCAgent.onEvent(this, "医生进入搜索页面的次数", "医生进入搜索页面的次数");
//        imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
//        path = getExternalFilesDir("").getAbsolutePath() + "/img/head/";
//        ossService = new OssService(SearchActivity.this);
//
//
//        initDate();
//        initEmptyView();
//        initSearchResultView();
//        initHisSearch();
//        initView();
//    }
//
//    //    隐藏软键盘
//    public void hideImm(EditText editText) {
//        if (imm != null) {
//            imm.hideSoftInputFromWindow(editText.getWindowToken(), 0);
//        }
//    }
//
//    public void initDate() {
//
//        gson = new Gson();
//        hisSearchModel = new HisSearchModel();
//        hisSearchList = new ArrayList<>();
//        messageSearchModel = new MessageSearchModel();
//        doctorList = new ArrayList<>();
//        patientList = new ArrayList<>();
//        hisAdapter.setNewData(hisSearchList);
//
//        getHisAdapter();
//    }
//
//
//    /*
//     * 获取历史搜索记录
//     * */
//    public void getHisAdapter() {
//        ThreadPoolManager.getInstance().execute(new Runnable() {
//            @Override
//            public void run() {
//                JSONObject jsonObject = new JSONObject();
//                jsonObject.put("searchType", 1);
//                String result = PostAndGet.doHttpPost(pathHis, jsonObject);
////                LogUtil.e("搜索历史", result);
//                if (result.equals("网络异常")) {
//                    handler.sendEmptyMessage(7);
//                } else {
//                    hisSearchModel = gson.fromJson(result, HisSearchModel.class);
//                    if (hisSearchModel.getStatus() == 0) {
//                        handler.sendEmptyMessage(6);
//                    } else {
//                        handler.sendEmptyMessage(7);
//                    }
//                }
//            }
//        });
//    }
//
//    //    空态页
//    public void initEmptyView() {
//        clEmpty = (ConstraintLayout) findViewById(R.id.cl_empty);
//        tvEmpty = (TextView) findViewById(R.id.tv_empty);
//        tvEmpty1 = (TextView) findViewById(R.id.tv_empty1);
//
//        tvEmpty1.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                doKeySearch();
//            }
//        });
//
//        cl_empty_his = (ConstraintLayout) findViewById(R.id.cl_empty_his);
//        tv_empty_his1 = (TextView) findViewById(R.id.tv_empty_his1);
//        tv_empty_his2 = (TextView) findViewById(R.id.tv_empty_his2);
//
//        tv_empty_his2.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                getHisAdapter();
//            }
//        });
//    }
//
//
//    //    搜索结果
//    public void initSearchResultView() {
//
//        rvPatient = (RecyclerView) findViewById(R.id.rv_search_patient);
//        rvDoctor = (RecyclerView) findViewById(R.id.rv_search_doctor);
//        rvPatient.setAdapter(searchAdapter);
//        rvPatient.setLayoutManager(new LinearLayoutManager(this));
//        rvDoctor.setAdapter(doctorAdapter);
//        rvDoctor.setLayoutManager(new LinearLayoutManager(this));
//    }
//
//    //    历史搜索
//    public void initHisSearch() {
//        clHis = (ConstraintLayout) findViewById(R.id.cl_his);
//        rvHisSearch = (RecyclerView) findViewById(R.id.rv_his_search);
//
//        rvHisSearch.setAdapter(hisAdapter);
//        FlexboxLayoutManager manager = new FlexboxLayoutManager(this, FlexDirection.ROW, FlexWrap.WRAP) {
//            @Override
//            public boolean canScrollVertically() {
//                return false;
//            }
//        };
//        rvHisSearch.setLayoutManager(manager);
//    }
//
//
//    private void switchSearchResult() {
//        if (searchIndex == 0) {
//            rvDoctor.setVisibility(View.GONE);
//            tvDoctorLink.setVisibility(View.GONE);
//            if (searchAdapter.getData().size() > 0) {
//                rvPatient.setVisibility(View.VISIBLE);
//                tvPatientLink.setVisibility(View.VISIBLE);
//            } else {
//                clEmpty.setVisibility(View.VISIBLE);
//                tvPatientLink.setVisibility(View.GONE);
//                showPatientEmpty();
//            }
//        } else {
//            rvPatient.setVisibility(View.GONE);
//            tvPatientLink.setVisibility(View.GONE);
//            if (doctorAdapter.getData().size() > 0) {
//                rvDoctor.setVisibility(View.VISIBLE);
//                tvDoctorLink.setVisibility(View.VISIBLE);
//            } else {
//                clEmpty.setVisibility(View.VISIBLE);
//                tvDoctorLink.setVisibility(View.GONE);
//                showDoctorEmpty();
//
//            }
//        }
//    }
//
//    public void initView() {
//
//        imgSearch = (ImageView) findViewById(R.id.image_search);
//        imgClear = (ImageView) findViewById(R.id.image_clear);
//        etSearch = (EditText) findViewById(R.id.et_search);
//        tvCancel = (TextView) findViewById(R.id.tv_cancel);
//
//        tvEmpty = (TextView) findViewById(R.id.tv_empty);
//        tvEmpty1 = (TextView) findViewById(R.id.tv_empty1);
//        btnLink = (Button) findViewById(R.id.btn_link);
//
//
//        clSearch = (ConstraintLayout) findViewById(R.id.cl_search);
//
//        tabTitle = (TabLayout) findViewById(R.id.tab_title);
//        tabTitle.addTab(tabTitle.newTab().setText("患者"));
//        tabTitle.addTab(tabTitle.newTab().setText("医生"));
//
//
//        tabTitle.setOnTabSelectedListener(new TabLayout.OnTabSelectedListener() {
//            @Override
//            public void onTabSelected(TabLayout.Tab tab) {
//                if (tab.getText().toString().equals("患者")) {
//                    searchIndex = 0;
//                } else {
//                    searchIndex = 1;
//                }
//                switchSearchResult();
//            }
//
//            @Override
//            public void onTabUnselected(TabLayout.Tab tab) {
//
//            }
//
//            @Override
//            public void onTabReselected(TabLayout.Tab tab) {
//
//            }
//        });
//
//        tvPatientLink = (TextView) findViewById(R.id.tv_patient_link);
//        tvDoctorLink = (TextView) findViewById(R.id.tv_doctor_link);
//
//        tvPatientLink.setOnClickListener(this);
//        tvDoctorLink.setOnClickListener(this);
//
//        imgSearch.setOnClickListener(this);
//        imgClear.setOnClickListener(this);
//        tvCancel.setOnClickListener(this);
//
//        btnLink.setOnClickListener(this);
//
//        etSearch.addTextChangedListener(new TextWatcher() {
//            @Override
//            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
//
//            }
//
//            @Override
//            public void onTextChanged(CharSequence s, int start, int before, int count) {
//
//            }
//
//            @Override
//            public void afterTextChanged(Editable s) {
//                if (etSearch.getText().toString().length() > 0) {
//                    imgClear.setVisibility(View.VISIBLE);
//                } else {
//                    imgClear.setVisibility(View.GONE);
//                }
//            }
//        });
//
//        /*
//         * doKeySearch();  键盘监听
//         * */
//        etSearch.setOnEditorActionListener(new TextView.OnEditorActionListener() {
//            @Override
//            public boolean onEditorAction(TextView v, int actionId, KeyEvent event) {
//                if (actionId == 3) {//
//                    if (etSearch.getText().toString().length() > 0) {
//
//                        Pattern pattern = Pattern.compile("^\\s*$");
//                        if (pattern.matcher(etSearch.getText().toString()).matches()) {
//                            Toast.makeText(SearchActivity.this, "请重新输入", Toast.LENGTH_LONG).show();
//                            etSearch.setText("");
//                        } else {
//                            doKeySearch();
//                        }
//
//                    }
//
//                    return true;
//                } else {
//                    return false;
//                }
//            }
//        });
//
//        imgDeleteHis = (ImageView) findViewById(R.id.img_delete_his);
//
//        imgDeleteHis.setOnClickListener(this);
//
//
//    }
//
//
//    /*显示患者搜索为空*/
//    public void showPatientEmpty() {
//        tvEmpty.setText("暂未搜索到该患者，您可以去");
//        String test = "开启患者<font color='#248cfa'>随访报到</font>";
//        tvEmpty1.setText(Html.fromHtml(test));
//        btnLink.setText("随访报到");
//    }
//
//    /*显示医生搜索为空*/
//    public void showDoctorEmpty() {
//        tvEmpty.setText("暂未搜索到该医生");
//        String test = "请<font color='#248cfa'>添加医生联系人</font>";
//        tvEmpty1.setText(Html.fromHtml(test));
//        btnLink.setText("添加联系人");
//    }
//
//    private Handler handler = new Handler() {
//        @Override
//        public void handleMessage(Message msg) {
//            super.handleMessage(msg);
//
//            switch (msg.what) {
//
//                case 1:
//                    searchAdapter.getData().clear();
//                    doctorAdapter.getData().clear();
//
//                    if (messageSearchModel.getRetValue().getPatient().size() == 0) {
//                        clEmpty.setVisibility(View.VISIBLE);
//                        tvPatientLink.setVisibility(View.GONE);
//                        showPatientEmpty();
//                    } else {
//                        searchAdapter.setNewData(messageSearchModel.getRetValue().getPatient());
//                        clEmpty.setVisibility(View.GONE);
//                    }
//
//                    if (messageSearchModel.getRetValue().getDoctor().size() == 0) {
//                        clEmpty.setVisibility(View.VISIBLE);
//                        tvDoctorLink.setVisibility(View.GONE);
//                    } else {
//                        clSearch.setVisibility(View.VISIBLE);
//                        doctorAdapter.setNewData(messageSearchModel.getRetValue().getDoctor());
//                        clEmpty.setVisibility(View.GONE);
//                    }
//
//                    tabTitle.getTabAt(0).select();
//                    switchSearchResult();
//
//                    break;
//
//                case 3:
//                    clSearch.setVisibility(View.GONE);
//                    clEmpty.setVisibility(View.VISIBLE);
//                    tvEmpty.setText("网络错误~");
//                    tvEmpty1.setText(Html.fromHtml("<font color='#248cfa'><u>立即刷新<u><font>"));
//                    break;
//
//                //关注患者成功
//                case 4:
//                    String tip = "";
//                    Boolean atten = (Boolean) msg.obj;
//                    if (atten) {
//                        tip = "关注患者成功";
//                        searchAdapter.getData().get(msg.arg1).setIsFollow(true);
//                    } else {
//                        tip = "取消成功";
//                        searchAdapter.getData().get(msg.arg1).setIsFollow(false);
//                    }
//                    com.huidr.lib.commom.util.Toast.getInstance(SearchActivity.this).show(tip, 500);
//                    searchAdapter.notifyDataSetChanged();
//                    break;
////                    关注患者失败
//                case 5:
//                    String str = "";
//                    Boolean atten1 = (Boolean) msg.obj;
//                    if (atten1) {
//                        str = "关注患者失败";
//                    } else {
//                        str = "取消失败";
//                    }
//                    com.huidr.lib.commom.util.Toast.getInstance(SearchActivity.this).show(str, 500);
//                    break;
//
//                case 6:
//                    hisAdapter.getData().clear();
//                    if (hisSearchModel.getRetValue().size() == 0) {
//                        rvHisSearch.setVisibility(View.GONE);
//                        cl_empty_his.setVisibility(View.VISIBLE);
//                        tv_empty_his1.setText("暂无搜索记录~");
//                        tv_empty_his2.setText("");
//                    } else {
//                        rvHisSearch.setVisibility(View.VISIBLE);
//                        cl_empty_his.setVisibility(View.GONE);
//                        clEmpty.setVisibility(View.GONE);
//                        hisAdapter.getData().addAll(hisSearchModel.getRetValue());
//                        hisAdapter.notifyDataSetChanged();
//                    }
//                    break;
//                case 7:
//                    rvHisSearch.setVisibility(View.GONE);
//                    cl_empty_his.setVisibility(View.VISIBLE);
//                    tv_empty_his1.setText("网络错误~");
//                    String tip1 = "<font color='#248cfa'><u>立即刷新<u><font>";
//                    tv_empty_his2.setText(Html.fromHtml(tip1));
//                    break;
//            }
//        }
//    };
//
//    /*
//    * 搜索
//    * 清除
//      取消
//    *
//    * */
//    @Override
//    public void onClick(View v) {
//        switch (v.getId()) {
//            case R.id.image_search:
////                showSearch = true;
//                if (etSearch.getText().toString().length() > 0) {
//                    Pattern pattern = Pattern.compile("^\\s*$");
//                    if (pattern.matcher(etSearch.getText().toString()).matches()) {
//                        Toast.makeText(SearchActivity.this, "请重新输入", Toast.LENGTH_LONG).show();
//                        etSearch.setText("");
//                    } else {
//                        doKeySearch();
//                    }
//                } else {
//                    Toast.makeText(SearchActivity.this, "请重新输入", Toast.LENGTH_LONG).show();
//                }
//
//                break;
//            case R.id.image_clear:
//                searchAdapter.getData().clear();
//                searchAdapter.notifyDataSetChanged();
//                doctorAdapter.getData().clear();
//                doctorAdapter.notifyDataSetChanged();
//                showSearch = false;
//                etSearch.setText("");
//                refreshPage();
//                getHisAdapter();
//                break;
//            case R.id.tv_cancel:
//                finish();
//                break;
//
//            case R.id.tv_patient_link:
////                跳转患者池 全部患者
//                SharedPreferenciesUtil.putData("currentId", 1);
//                finish();
//                break;
//            case R.id.tv_doctor_link:
////联系人 全部联系人
//                SharedPreferenciesUtil.putData("currentId", 2);
//                finish();
//                break;
//
//            case R.id.btn_link:
//                if (btnLink.getText().toString().equals("随访报到")) {
//                    SharedPreferenciesUtil.putData("currentId", 3);
//                } else {//联系人 申请添加
//                    SharedPreferenciesUtil.putData("currentId", 2);
//                    SharedPreferenciesUtil.putData("friendIndex", 3);
//                }
//                finish();
//                break;
//            case R.id.img_delete_his:
//                /*删除历史记录*/
//                break;
//
//        }
//    }
//
//    /*
//     * 关键字搜索
//     * */
//    public void doKeySearch() {
//        TCAgent.onEvent(this, "医生搜索的次数", "医生搜索的次数");
//        showSearch = true;
//        hideImm(etSearch);
//        refreshPage();
//
//        ThreadPoolManager.getInstance().execute(new Runnable() {
//            @Override
//            public void run() {
//                String path = BuildConfig.baseUrl + "hospital/search/search?queryTag=doctor_point&page=1&query=" + etSearch.getText().toString() + "&doctorId=" + doctorId;
//                String result = PostAndGet.doGetHttp(path);
//                LogUtil.e("首页搜搜", result);
//                if (result.equals("网络异常")) {
//                    handler.sendEmptyMessage(3);
//                } else {
//                    messageSearchModel = gson.fromJson(result, MessageSearchModel.class);
//                    if (messageSearchModel.getStatus() == 0) {
//                        handler.sendEmptyMessage(1);
//                    } else {
//                        handler.sendEmptyMessage(3);
//                    }
//                }
//            }
//        });
//    }
//
//    /*
//     * 刷新显示
//     * true  显示搜索结果 搜索结果为空 显示空态页
//     * false 隐藏搜搜结果页 显示搜索历史
//     *
//     */
//    public void refreshPage() {
//        if (showSearch) {
//            clHis.setVisibility(View.GONE);
//            clSearch.setVisibility(View.VISIBLE);
//        } else {
//            clHis.setVisibility(View.VISIBLE);
//            clSearch.setVisibility(View.GONE);
//        }
//    }
//
//
//    /*
//     * 历史搜索 适配
//     * */
//    private BaseQuickAdapter<HisSearchModel.RetValueBean, BaseViewHolder> hisAdapter = new BaseQuickAdapter<HisSearchModel.RetValueBean, BaseViewHolder>(R.layout.item_tip) {
//        @Override
//        protected void convert(BaseViewHolder helper, final HisSearchModel.RetValueBean item) {
//            TextView tvTip = helper.getView(R.id.tv_tip);
//            tvTip.setText(item.getSearchContent());
//
//            tvTip.setOnClickListener(new View.OnClickListener() {
//                @Override
//                public void onClick(View v) {
//                    etSearch.setText(item.getSearchContent());
////                    showSearch = true;
//                    doKeySearch();
//                    TCAgent.onEvent(SearchActivity.this, "历史搜索的点击次数", "历史搜索的点击次数");
//                }
//            });
//        }
//    };
//
//
//    /*
//     * 搜索结果  患者  适配
//     *
//     * */
//    private BaseQuickAdapter<MessageSearchModel.RetValueBean.PatientBean, BaseViewHolder> searchAdapter = new BaseQuickAdapter<MessageSearchModel.RetValueBean.PatientBean, BaseViewHolder>(R.layout.item_scroll_layout) {
//
//        @Override
//        protected void convert(final BaseViewHolder helper, final MessageSearchModel.RetValueBean.PatientBean item) {
////            TextView textView = helper.getView(R.id.tv_scroll_right);
////            String st = "<font>添加<br />协同</font>";
////            textView.setText(Html.fromHtml(st));
//
//            ImageView imgItemHead = helper.getView(R.id.img_item_head);
//
//
//            if (item.getBindUserRelationship() == null || item.getBindUserRelationship().equals("")) {
//                imgItemHead.setBackgroundResource(R.drawable.head_patient);
//            } else {
//                switch (item.getBindUserRelationship()) {
//                    case "本人":
//                        if (item.getUserSex() == 1) {
//                            imgItemHead.setBackgroundResource(R.drawable.my_him);
//                        } else {
//                            imgItemHead.setBackgroundResource(R.drawable.my_her);
//                        }
//                        break;
//                    case "丈夫":
//                        imgItemHead.setBackgroundResource(R.drawable.husband);
//                        break;
//                    case "妻子":
//                        imgItemHead.setBackgroundResource(R.drawable.wife);
//                        break;
//                    case "爸爸":
//                        imgItemHead.setBackgroundResource(R.drawable.papa);
//                        break;
//                    case "妈妈":
//                        imgItemHead.setBackgroundResource(R.drawable.mama);
//                        break;
//                    case "儿子":
//                        imgItemHead.setBackgroundResource(R.drawable.son);
//                        break;
//                    case "女儿":
//                        imgItemHead.setBackgroundResource(R.drawable.daughter);
//                        break;
////                    case "其他":
////                        imgItemHead.setBackgroundResource(R.drawable.head_patient);
////                        break;
//                    default:
//                        imgItemHead.setBackgroundResource(R.drawable.head_patient);
//                        break;
//                }
//            }
//
//
//            ImageView imgNotice = helper.getView(R.id.img_notice);
//            imgNotice.setVisibility(View.GONE);
//            ImageView imageItemGender = helper.getView(R.id.image_item_gender);
//            imageItemGender.setVisibility(View.GONE);
//
////            if (item.getUserSex() == 1) {
////                imageItemGender.setBackgroundResource(R.drawable.gender_man);
////            } else if (item.getUserSex() == 2) {
////                imageItemGender.setBackgroundResource(R.drawable.gender_w);
////            } else {
////
////            }
//
//            TextView tvItemName = helper.getView(R.id.tv_item_name);
//            tvItemName.setText(item.getUserName());
//            TextView tvItemAge = helper.getView(R.id.tv_item_age);
//            tvItemAge.setText(item.getLatelyAdmitNo());
//            tvItemAge.setTypeface(Typeface.defaultFromStyle(Typeface.NORMAL));
//            tvItemAge.setTextColor(Color.parseColor("#666666"));
//            TextView tvItemState = helper.getView(R.id.tv_item_state);
//            TextView tvItemDate = helper.getView(R.id.tv_item_date);
//            tvItemDate.setText(item.getLatelyVisitingDate());
//            tvItemDate.setTextColor(Color.parseColor("#999999"));
//            TextView tvItemMsg = helper.getView(R.id.tv_item_msg);
//            tvItemMsg.setText(item.getLatelyAdmissionDiagnosis());
//            tvItemMsg.setTextColor(Color.parseColor("#666666"));
//
//            TextView tvItemMode = helper.getView(R.id.tv_item_model);
//            tvItemMode.setText("");
////
//            TextView tvScrollRight = helper.getView(R.id.tv_scroll_right);
////
////            Button btnApply = helper.getView(R.id.btn_apply);
////            btnApply.setVisibility(View.GONE);
////
//            String tip = "";
//            if (item.isIsFollow()) {
////                tip = "<font>取消<br>关注<font>";
//                tip = "<font>已<br>关注<font>";
//                tvScrollRight.setBackgroundResource(R.drawable.shape_atten_gray);
//            } else {
//                tip = "<font>关注<br>患者<font>";
//            }
//            tvScrollRight.setText(Html.fromHtml(tip));
//            tvScrollRight.setOnClickListener(new View.OnClickListener() {
//                @Override
//                public void onClick(View v) {
//                    if (item.isIsFollow()) { //已经关注 取消关注
////                        modifyAttent(false, helper.getAdapterPosition(), item.getId());
//                        searchAdapter.notifyDataSetChanged();
//                        Toast.makeText(SearchActivity.this, "该患者已关注", Toast.LENGTH_SHORT).show();
//                    } else {  //未关注 添加关注
////                        modifyAttent(true, helper.getAdapterPosition(), item.getId());
//                        showCoopDialog(true, helper.getAdapterPosition(), item.getId());
//                    }
//                }
//            });
//
//            ConstraintLayout clItem = helper.getView(R.id.cl_item);
//            clItem.setOnClickListener(new View.OnClickListener() {
//                @Override
//                public void onClick(View v) {
//                    if (System.currentTimeMillis() - lastClick > 1000) {
//                        JSONObject jsonObject = new JSONObject();
//                        jsonObject.put("id", item.getId());
//                        SharedPreferenciesUtil.putData("psearchID", jsonObject.toJSONString());
//                        SharedPreferenciesUtil.putData("followDoctorId", item.getDoctorId());
//
//                        Intent intent1 = new Intent(SearchActivity.this, WebActivity.class);
//                        Bundle bundle = new Bundle();
//                        bundle.putString("url", "patientData.html");
//                        intent1.putExtras(bundle);
//                        startActivity(intent1);
//                        lastClick = System.currentTimeMillis();
//                    }
//                }
//            });
//
//            Button btnApply = helper.getView(R.id.btn_apply);
//            btnApply.setVisibility(View.GONE);
//        }
//    };
//
//
//    //    取消添加协同对话框
//    public void showCoopDialog(final boolean atten, final int position, final int patientId) {
//
//        final Dialog builder = new Dialog(SearchActivity.this, R.style.jmui_default_dialog_style);
//        //final Dialog builder = new Dialog(this, R.style.jmui_default_dialog_style);
//        View view = LayoutInflater.from(SearchActivity.this).inflate(R.layout.dialog_content, null);
//
//        TextView tvTitle = view.findViewById(R.id.tv_title);
//        TextView tvFooter1 = view.findViewById(R.id.tv_footer1);
//        TextView tvFooter2 = view.findViewById(R.id.tv_footer2);
//
//        tvTitle.setText("是否关注该患者！");
//
//
////        取消
//        tvFooter1.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                builder.cancel();
//                searchAdapter.notifyDataSetChanged();
//            }
//        });
////确定
//        tvFooter2.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                builder.cancel();
//                modifyAttent(atten, position, patientId);
//                searchAdapter.notifyDataSetChanged();
//            }
//        });
//
//        builder.setContentView(view);
//        //builder.setCanceledOnTouchOutside(true);
//        builder.show();
//        Window window = builder.getWindow();
//        WindowManager.LayoutParams lp = window.getAttributes();
//        WindowManager windowManager = getWindowManager();
//        Display display = windowManager.getDefaultDisplay();
//        lp.width = (int) (display.getWidth() * 0.7);
////        lp.height = (int) (display.getHeight() * 0.1);
//        window.setAttributes(lp);
//    }
//
//
//    //    关注患者  取消关注
//    public void modifyAttent(final boolean atten, final int position, final int patientId) {
//        ThreadPoolManager.getInstance().execute(new Runnable() {
//            @Override
//            public void run() {
//                String id = (String) SharedPreferenciesUtil.getData("id", "0");
//
//                String path = BuildConfig.baseUrl + "patient/doctorPatientMedical/addRemarksAndFollow?doctorId=" + id + "&patientId=" + patientId + "&isFollow=" + atten;
//                String result = PostAndGet.doGetHttp(path);
//
////                LogUtil.e("关注", result);
//                if (result.equals("网络异常")) {
//
//                } else {
//                    SimpleResultModel simpleResultModel = gson.fromJson(result, SimpleResultModel.class);
//                    Message message = new Message();
//                    message.obj = atten;
//                    if (simpleResultModel.getStatus() == 0) {
//                        message.what = 4;
//                        message.arg1 = position;
//                        handler.sendMessage(message);
//                    } else {
//                        message.what = 5;
//                        handler.sendMessage(message);
//                    }
//                }
//
//            }
//        });
//    }
//
//    /*
//     * 医生搜索结果
//     * */ BaseQuickAdapter<MessageSearchModel.RetValueBean.DoctorBean, BaseViewHolder> doctorAdapter = new BaseQuickAdapter<MessageSearchModel.RetValueBean.DoctorBean, BaseViewHolder>(R.layout.item_scroll_layout) {
//        @Override
//        protected void convert(BaseViewHolder helper, final MessageSearchModel.RetValueBean.DoctorBean item) {
//
//            helper.setIsRecyclable(false);
//
//            EasySwipeMenuLayout esml_item = helper.getView(R.id.esml_item);
//            esml_item.setCanLeftSwipe(false);
//            esml_item.setCanRightSwipe(false);
//
//            ImageView imgItemHead = helper.getView(R.id.img_item_head);
//
//
//            Bitmap defaultBitmap = BitmapFactory.decodeResource(getResources(), R.drawable.nantou);
//            BitmapDrawable defaultDrawable = new BitmapDrawable(getResources(), defaultBitmap);
//            imgItemHead.setBackgroundDrawable(defaultDrawable);
//            if (item.getUserIcon() != null) {
//                imgItemHead.setTag(item.getUserIcon());
//                File file = new File(path + item.getUserIcon());
//                if (file.exists()) {
//                    Bitmap bitmap1 = BitmapFactory.decodeFile(file.getAbsolutePath());
//                    if (bitmap1 != null) {
//                        if (imgItemHead.getTag().equals(item.getUserIcon())) {
//                            bitmap1 = getCirleBitmap(bitmap1);
//                            BitmapDrawable bitmapDrawable = new BitmapDrawable(getResources(), bitmap1);
//                            imgItemHead.setBackgroundDrawable(bitmapDrawable);
//                        }
//                    }
//                } else {
//                    DownLoadImg.BitmapWorkerTask bitmapWorkerTask = new DownLoadImg.BitmapWorkerTask(imgItemHead, file,ossService);
//                    bitmapWorkerTask.execute(item.getUserIcon());
//                }
//
//            } else {
//                imgItemHead.setBackgroundDrawable(defaultDrawable);
//            }
//
//            ImageView imgNotice = helper.getView(R.id.img_notice);
//            imgNotice.setVisibility(View.GONE);
//            ImageView imageItemGender = helper.getView(R.id.image_item_gender);
//            TextView tvItemName = helper.getView(R.id.tv_item_name);
//            tvItemName.setText(item.getUserName());
//            TextView tvItemAge = helper.getView(R.id.tv_item_age);
//
//            tvItemAge.setText(item.getHospitalDepartment() + "(" + item.getUserTitle() + ")");
//            TextView tvItemState = helper.getView(R.id.tv_item_state);
//            TextView tvItemDate = helper.getView(R.id.tv_item_date);
//            tvItemDate.setText("");
//
//            TextView tvItemMsg = helper.getView(R.id.tv_item_msg);
//
//            tvItemMsg.setText("");
//            TextView tvItemMode = helper.getView(R.id.tv_item_model);
//            tvItemMode.setText("");
////
//            TextView tvScrollRight = helper.getView(R.id.tv_scroll_right);
////
////            Button btnApply = helper.getView(R.id.btn_apply);
////            btnApply.setVisibility(View.GONE);
////
//            String tip = "";
////            if (item.isIsFollow()) {
////                tip = "<font>取消<br>关注<font>";
////                tvScrollRight.setBackgroundResource(R.drawable.shape_atten_gray);
////            } else {
////                tip = "<font>关注<br>患者<font>";
////            }
////            tvScrollRight.setText(Html.fromHtml(tip));
////            tvScrollRight.setOnClickListener(new View.OnClickListener() {
////                @Override
////                public void onClick(View v) {
////                    if (item.isIsFollow()) { //已经关注 取消关注
////                        modifyAttent(false, helper.getAdapterPosition(), item.getId());
////                    } else {  //未关注 添加关注
////                        modifyAttent(true, helper.getAdapterPosition(), item.getId());
////                    }
////                }
////            });
//
//            ConstraintLayout clItem = helper.getView(R.id.cl_item);
//            clItem.setOnClickListener(new View.OnClickListener() {
//                @Override
//                public void onClick(View v) {
//                    if (System.currentTimeMillis() - lastClick2 > 1000) {
//                        Intent intent1 = new Intent(SearchActivity.this, WebActivity.class);
//                        Bundle bundle = new Bundle();
//                        bundle.putString("url", "personal.html?id=" + item.getId());
//                        intent1.putExtras(bundle);
//                        startActivity(intent1);
//                        lastClick2 = System.currentTimeMillis();
//                    }
//                }
//            });
//
//            Button btnApply = helper.getView(R.id.btn_apply);
//            btnApply.setVisibility(View.GONE);
//        }
//    };

    ImageView imgSearch, imgClear;
    EditText etSearch;
    TextView tvCancel;

    SmartRefreshLayout srlLayout;
    RecyclerView rvSearch;
    ConstraintLayout clHis;
    RecyclerView rvHisSearch;


    InputMethodManager imm;

    //    空态
    ConstraintLayout clEmpty;
    TextView tvEmpty;
    TextView tvEmpty1;
    Button btnLink;

    //    历史搜索空态
    ConstraintLayout cl_empty_his;
    TextView tv_empty_his1, tv_empty_his2;


    boolean showSearch;//显示搜索 true

    HisSearchModel hisSearchModel;
    List<HisSearchModel.RetValueBean> hisSearchList;

    MessageSearchModel messageSearchModel;
    List<MessageSearchModel.RetValueBean.DoctorBean> doctorList;
    List<MessageSearchModel.RetValueBean.PatientBean> patientList;

    Gson gson;

    //    String pathHis = "http://192.168.1.180:1189/search/searchHis";//历史搜索
    String pathHis = BuildConfig.baseUrl + "hospital/search/searchHis";//历史搜索

    View itemView;
    RecyclerView rvDoctorList;

    OssService ossService;

    String doctorId = (String) SharedPreferenciesUtil.getData("id", "0");

    long lastClick = 0;
    long lastClick2 = 0;

    String path;
    Matrix matrix;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_search);
        matrix = new Matrix();
        matrix.setRotate(90);
        TCAgent.onEvent(this, "医生进入搜索页面的次数", "医生进入搜索页面的次数");
        imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
        path = Environment.getExternalStorageDirectory() + "/" + getPackageName() + "/img/head/";
        ossService = new OssService(SearchActivity.this);

        itemView = LayoutInflater.from(SearchActivity.this).inflate(R.layout.rv_doctor_list, null);
        rvDoctorList = itemView.findViewById(R.id.rv_doctor);
        rvDoctorList.setAdapter(doctorAdapter);
        rvDoctorList.setLayoutManager(new LinearLayoutManager(SearchActivity.this));

        initDate();
        initEmptyView();
        initSearchResultView();
        initHisSearch();
        initView();
    }

    //    隐藏软键盘
    public void hideImm(EditText editText) {
        if (imm != null) {
            imm.hideSoftInputFromWindow(editText.getWindowToken(), 0);
        }
    }

    public void initDate() {

        gson = new Gson();

        hisSearchModel = new HisSearchModel();
        hisSearchList = new ArrayList<>();

        messageSearchModel = new MessageSearchModel();
        doctorList = new ArrayList<>();
        patientList = new ArrayList<>();


        hisAdapter.setNewData(hisSearchList);
        searchAdapter.setNewData(patientList);

        getHisAdapter();
    }


    /*
     * 获取历史搜索记录
     * */
    public void getHisAdapter() {
        ThreadPoolManager.getInstance().execute(new Runnable() {
            @Override
            public void run() {
                JSONObject jsonObject = new JSONObject();
                jsonObject.put("searchType", 1);
                String result = PostAndGet.doHttpPost(pathHis, jsonObject);
//                LogUtil.e("搜索历史", result);
                if (result.equals("网络异常")) {
                    handler.sendEmptyMessage(7);
                } else {
                    hisSearchModel = gson.fromJson(result, HisSearchModel.class);
                    if (hisSearchModel.getStatus() == 0) {
                        handler.sendEmptyMessage(6);
                    } else {
                        handler.sendEmptyMessage(7);
                    }
                }
            }
        });
    }

    //    空态页
    public void initEmptyView() {
        clEmpty = (ConstraintLayout) findViewById(R.id.cl_empty);
        tvEmpty = (TextView) findViewById(R.id.tv_empty);
        tvEmpty1 = (TextView) findViewById(R.id.tv_empty1);

        tvEmpty1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                doKeySearch();
            }
        });

        cl_empty_his = (ConstraintLayout) findViewById(R.id.cl_empty_his);
        tv_empty_his1 = (TextView) findViewById(R.id.tv_empty_his1);
        tv_empty_his2 = (TextView) findViewById(R.id.tv_empty_his2);

        tv_empty_his2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                getHisAdapter();
            }
        });
    }


    //    搜索结果
    public void initSearchResultView() {
        srlLayout = (SmartRefreshLayout) findViewById(R.id.srl_layout);
        srlLayout.setEnableRefresh(false);
        srlLayout.setEnableLoadMore(false);

        srlLayout.setOnRefreshListener(new OnRefreshListener() {
            @Override
            public void onRefresh(@NonNull RefreshLayout refreshLayout) {
                srlLayout.finishRefresh();
            }
        });

        srlLayout.setOnLoadMoreListener(new OnLoadMoreListener() {
            @Override
            public void onLoadMore(@NonNull RefreshLayout refreshLayout) {
                srlLayout.finishLoadMore();
            }
        });

        rvSearch = (RecyclerView) findViewById(R.id.rv_search);
        rvSearch.setAdapter(searchAdapter);
        rvSearch.setLayoutManager(new LinearLayoutManager(this));


    }

    //    历史搜索
    public void initHisSearch() {
        clHis = (ConstraintLayout) findViewById(R.id.cl_his);
        rvHisSearch = (RecyclerView) findViewById(R.id.rv_his_search);

        rvHisSearch.setAdapter(hisAdapter);
//        rvHisSearch.setLayoutManager(new GridLayoutManager(this, 4));
        FlexboxLayoutManager manager = new FlexboxLayoutManager(this, FlexDirection.ROW, FlexWrap.WRAP) {
            @Override
            public boolean canScrollVertically() {
                return false;
            }
        };
        rvHisSearch.setLayoutManager(manager);
    }

    public void initView() {

        imgSearch = (ImageView) findViewById(R.id.image_search);
        imgClear = (ImageView) findViewById(R.id.image_clear);
        etSearch = (EditText) findViewById(R.id.et_search);
        tvCancel = (TextView) findViewById(R.id.tv_cancel);

        tvEmpty = (TextView) findViewById(R.id.tv_empty);
        tvEmpty1 = (TextView) findViewById(R.id.tv_empty1);
        btnLink = (Button) findViewById(R.id.btn_link);

        imgSearch.setOnClickListener(this);
        imgClear.setOnClickListener(this);
        tvCancel.setOnClickListener(this);

        btnLink.setOnClickListener(this);

        etSearch.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {
                if (etSearch.getText().toString().length() > 0) {
                    imgClear.setVisibility(View.VISIBLE);
                } else {
                    imgClear.setVisibility(View.GONE);
                }
            }
        });

        /*
         * doKeySearch();  键盘监听
         * */
        etSearch.setOnEditorActionListener(new TextView.OnEditorActionListener() {
            @Override
            public boolean onEditorAction(TextView v, int actionId, KeyEvent event) {
                if (actionId == 3) {//
                    if (etSearch.getText().toString().length() > 0) {
                        doKeySearch();
                    }

                    return true;
                } else {
                    return false;
                }
            }
        });


    }

    private Handler handler = new Handler() {
        @Override
        public void handleMessage(Message msg) {
            super.handleMessage(msg);

            switch (msg.what) {

                case 1:
                    searchAdapter.getData().clear();
                    if (messageSearchModel.getRetValue().getPatient().size() == 0 && messageSearchModel.getRetValue().getDoctor().size() == 0) {
                        srlLayout.setVisibility(View.GONE);
                        clEmpty.setVisibility(View.VISIBLE);
                        tvEmpty.setText("搜索结果为空~");
                        tvEmpty1.setText("");
                    } else {

                        srlLayout.setVisibility(View.VISIBLE);
                        clEmpty.setVisibility(View.GONE);
                        searchAdapter.getData().addAll(messageSearchModel.getRetValue().getPatient());
                        searchAdapter.notifyDataSetChanged();
                        searchAdapter.removeAllFooterView();
                        searchAdapter.addFooterView(itemView);
                        doctorAdapter.getData().clear();
                        doctorAdapter.getData().addAll(messageSearchModel.getRetValue().getDoctor());
                        doctorAdapter.notifyDataSetChanged();
                    }
                    break;
                case 3:
                    srlLayout.setVisibility(View.GONE);
                    clEmpty.setVisibility(View.VISIBLE);
                    tvEmpty.setText("网络错误~");
                    tvEmpty1.setText(Html.fromHtml("<font color='#248cfa'><u>立即刷新<u><font>"));
                    break;

                //关注患者成功
                case 4:
                    String tip = "";
                    Boolean atten = (Boolean) msg.obj;
                    if (atten) {
                        tip = "关注患者成功";
                        searchAdapter.getData().get(msg.arg1).setIsFollow(true);
                    } else {
                        tip = "取消成功";
                        searchAdapter.getData().get(msg.arg1).setIsFollow(false);
                    }
                    com.huidr.lib.commom.util.Toast.getInstance(SearchActivity.this).show(tip, 500);
                    searchAdapter.notifyDataSetChanged();
                    break;
//                    关注患者失败
                case 5:
                    String str = "";
                    Boolean atten1 = (Boolean) msg.obj;
                    if (atten1) {
                        str = "关注患者失败";
                    } else {
                        str = "取消失败";
                    }
                    com.huidr.lib.commom.util.Toast.getInstance(SearchActivity.this).show(str, 500);
                    break;

                case 6:
                    hisAdapter.getData().clear();
                    if (hisSearchModel.getRetValue().size() == 0) {
                        rvHisSearch.setVisibility(View.GONE);
                        cl_empty_his.setVisibility(View.VISIBLE);
                        tv_empty_his1.setText("暂无搜索记录~");
                        tv_empty_his2.setText("");
                    } else {
                        rvHisSearch.setVisibility(View.VISIBLE);
                        cl_empty_his.setVisibility(View.GONE);
                        hisAdapter.getData().addAll(hisSearchModel.getRetValue());
                        hisAdapter.notifyDataSetChanged();
                    }
                    break;
                case 7:
                    rvHisSearch.setVisibility(View.GONE);
                    cl_empty_his.setVisibility(View.VISIBLE);
                    tv_empty_his1.setText("网络错误~");
                    String tip1 = "<font color='#248cfa'><u>立即刷新<u><font>";
                    tv_empty_his2.setText(Html.fromHtml(tip1));
                    break;
            }
        }
    };

    /*
    * 搜索
    * 清除
      取消
    *
    * */
    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.image_search:
//                showSearch = true;
                doKeySearch();
                break;
            case R.id.image_clear:
                searchAdapter.getData().clear();
                searchAdapter.notifyDataSetChanged();
                doctorAdapter.getData().clear();
                doctorAdapter.notifyDataSetChanged();
                showSearch = false;
                etSearch.setText("");
                refreshPage();
                getHisAdapter();
                break;
            case R.id.tv_cancel:
                finish();
                break;
        }
    }

    /*
     * 关键字搜索
     * */
    public void doKeySearch() {
        TCAgent.onEvent(this, "医生搜索的次数", "医生搜索的次数");
        showSearch = true;
        hideImm(etSearch);
        refreshPage();
//        searchAdapter.getData().clear();
//
//        searchAdapter.notifyDataSetChanged();
        ThreadPoolManager.getInstance().execute(new Runnable() {
            @Override
            public void run() {
                String path = BuildConfig.baseUrl + "hospital/search/search?queryTag=doctor_point&page=1&query=" + etSearch.getText().toString() + "&doctorId=" + doctorId;
                String result = PostAndGet.doGetHttp(path);
                LogUtil.e("首页搜搜", result);
                if (result.equals("网络异常")) {
                    handler.sendEmptyMessage(3);
                } else {
                    messageSearchModel = gson.fromJson(result, MessageSearchModel.class);
                    if (messageSearchModel.getStatus() == 0) {
                        handler.sendEmptyMessage(1);
                    } else {
                        handler.sendEmptyMessage(3);
                    }
                }
            }
        });
    }

    /*
     * 刷新显示
     * true  显示搜索结果 搜索结果为空 显示空态页
     * false 隐藏搜搜结果页 显示搜索历史
     *
     */
    public void refreshPage() {
        if (showSearch) {
            clHis.setVisibility(View.GONE);
            srlLayout.setVisibility(View.VISIBLE);
        } else {
            clHis.setVisibility(View.VISIBLE);
            srlLayout.setVisibility(View.GONE);
        }
    }


    /*
     * 历史搜索 适配
     * */
    private BaseQuickAdapter<HisSearchModel.RetValueBean, BaseViewHolder> hisAdapter = new BaseQuickAdapter<HisSearchModel.RetValueBean, BaseViewHolder>(R.layout.item_tip) {
        @Override
        protected void convert(BaseViewHolder helper, final HisSearchModel.RetValueBean item) {
            TextView tvTip = helper.getView(R.id.tv_tip);
            tvTip.setText(item.getSearchContent());

            tvTip.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    etSearch.setText(item.getSearchContent());
//                    showSearch = true;
                    doKeySearch();
                    TCAgent.onEvent(SearchActivity.this, "历史搜索的点击次数", "历史搜索的点击次数");
                }
            });
        }
    };


    /*
     * 搜索结果  患者  适配
     *
     * */
    private BaseQuickAdapter<MessageSearchModel.RetValueBean.PatientBean, BaseViewHolder> searchAdapter = new BaseQuickAdapter<MessageSearchModel.RetValueBean.PatientBean, BaseViewHolder>(R.layout.item_scroll_layout) {

        @Override
        protected void convert(final BaseViewHolder helper, final MessageSearchModel.RetValueBean.PatientBean item) {
//            TextView textView = helper.getView(R.id.tv_scroll_right);
//            String st = "<font>添加<br />协同</font>";
//            textView.setText(Html.fromHtml(st));

            ImageView imgItemHead = helper.getView(R.id.img_item_head);


            if (item.getBindUserRelationship() == null || item.getBindUserRelationship().equals("")) {
                imgItemHead.setBackgroundResource(R.drawable.head_patient);
            } else {
                switch (item.getBindUserRelationship()) {
                    case "本人":
                        if (item.getUserSex() == 1) {
                            imgItemHead.setBackgroundResource(R.drawable.my_him);
                        } else {
                            imgItemHead.setBackgroundResource(R.drawable.my_her);
                        }
                        break;
                    case "丈夫":
                        imgItemHead.setBackgroundResource(R.drawable.husband);
                        break;
                    case "妻子":
                        imgItemHead.setBackgroundResource(R.drawable.wife);
                        break;
                    case "爸爸":
                        imgItemHead.setBackgroundResource(R.drawable.papa);
                        break;
                    case "妈妈":
                        imgItemHead.setBackgroundResource(R.drawable.mama);
                        break;
                    case "儿子":
                        imgItemHead.setBackgroundResource(R.drawable.son);
                        break;
                    case "女儿":
                        imgItemHead.setBackgroundResource(R.drawable.daughter);
                        break;
                    case "其他":
                        imgItemHead.setBackgroundResource(R.drawable.head_patient);
                        break;
                    default:
                        imgItemHead.setBackgroundResource(R.drawable.head_patient);
                        break;
                }
            }


            ImageView imgNotice = helper.getView(R.id.img_notice);
            imgNotice.setVisibility(View.GONE);
            ImageView imageItemGender = helper.getView(R.id.image_item_gender);
            imageItemGender.setVisibility(View.VISIBLE);

            if (item.getUserSex() == 1) {
                imageItemGender.setBackgroundResource(R.drawable.gender_man);
            } else if (item.getUserSex() == 2) {
                imageItemGender.setBackgroundResource(R.drawable.gender_w);
            } else {

            }

            TextView tvItemName = helper.getView(R.id.tv_item_name);
            tvItemName.setText(item.getUserName());
            TextView tvItemAge = helper.getView(R.id.tv_item_age);
            tvItemAge.setText(item.getLatelyAdmitNo());
            TextView tvItemState = helper.getView(R.id.tv_item_state);
            TextView tvItemDate = helper.getView(R.id.tv_item_date);
            tvItemDate.setText(item.getLatelyVisitingDate());

            TextView tvItemMsg = helper.getView(R.id.tv_item_msg);
            tvItemMsg.setText(item.getLatelyAdmissionDiagnosis());

            TextView tvItemMode = helper.getView(R.id.tv_item_model);
            tvItemMode.setText("");
//
            TextView tvScrollRight = helper.getView(R.id.tv_scroll_right);
//
//            Button btnApply = helper.getView(R.id.btn_apply);
//            btnApply.setVisibility(View.GONE);
//
            String tip = "";
            if (item.isIsFollow()) {
//                tip = "<font>取消<br>关注<font>";
                tip = "<font>已<br>关注<font>";
                tvScrollRight.setBackgroundResource(R.drawable.shape_atten_gray);
            } else {
                tip = "<font>关注<br>患者<font>";
            }
            tvScrollRight.setText(Html.fromHtml(tip));
            tvScrollRight.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (item.isIsFollow()) { //已经关注 取消关注
//                        modifyAttent(false, helper.getAdapterPosition(), item.getId());
                        searchAdapter.notifyDataSetChanged();
                        Toast.makeText(SearchActivity.this, "该患者已关注", Toast.LENGTH_SHORT).show();
                    } else {  //未关注 添加关注
//                        modifyAttent(true, helper.getAdapterPosition(), item.getId());
                        showCoopDialog(true, helper.getAdapterPosition(), item.getId());
                    }
                }
            });

            ConstraintLayout clItem = helper.getView(R.id.cl_item);
            clItem.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (System.currentTimeMillis() - lastClick > 1000) {
                        JSONObject jsonObject = new JSONObject();
                        jsonObject.put("id", item.getId());
                        SharedPreferenciesUtil.putData("psearchID", jsonObject.toJSONString());
                        SharedPreferenciesUtil.putData("followDoctorId", item.getDoctorId());

                        Intent intent1 = new Intent(SearchActivity.this, WebActivity.class);
                        Bundle bundle = new Bundle();
                        bundle.putString("url", "patientData.html");
                        intent1.putExtras(bundle);
                        startActivity(intent1);
                        lastClick = System.currentTimeMillis();
                    }
                }
            });

            Button btnApply = helper.getView(R.id.btn_apply);
            btnApply.setVisibility(View.GONE);
        }
    };


    //    取消添加协同对话框
    public void showCoopDialog(final boolean atten, final int position, final int patientId) {

        final Dialog builder = new Dialog(SearchActivity.this, R.style.jmui_default_dialog_style);
        //final Dialog builder = new Dialog(this, R.style.jmui_default_dialog_style);
        View view = LayoutInflater.from(SearchActivity.this).inflate(R.layout.dialog_content, null);

        TextView tvTitle = view.findViewById(R.id.tv_title);
        TextView tvFooter1 = view.findViewById(R.id.tv_footer1);
        TextView tvFooter2 = view.findViewById(R.id.tv_footer2);

        tvTitle.setText("是否关注该患者！");


//        取消
        tvFooter1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                builder.cancel();
                searchAdapter.notifyDataSetChanged();
            }
        });
//确定
        tvFooter2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                builder.cancel();
                modifyAttent(atten, position, patientId);
                searchAdapter.notifyDataSetChanged();
            }
        });

        builder.setContentView(view);
        //builder.setCanceledOnTouchOutside(true);
        builder.show();
        Window window = builder.getWindow();
        WindowManager.LayoutParams lp = window.getAttributes();
        WindowManager windowManager = getWindowManager();
        Display display = windowManager.getDefaultDisplay();
        lp.width = (int) (display.getWidth() * 0.7);
//        lp.height = (int) (display.getHeight() * 0.1);
        window.setAttributes(lp);
    }


    //    关注患者  取消关注
    public void modifyAttent(final boolean atten, final int position, final int patientId) {
        ThreadPoolManager.getInstance().execute(new Runnable() {
            @Override
            public void run() {
                String id = (String) SharedPreferenciesUtil.getData("id", "0");
//                String path = BuildConfig.baseUrl + "patient/doctorPatientMedical/addRemarksAndFollow?doctorId=" + id + "&patientId=" + patientId + "&isFollow=" + atten;
//                String path = "http://192.168.1.180:196/doctorPatientMedical/addRemarksAndFollow?doctorId=" + id + "&patientId=" + patientId + "&isFollow=" + atten;
                String path = BuildConfig.baseUrl + "patient/doctorPatientMedical/addRemarksAndFollow?doctorId=" + id + "&patientId=" + patientId + "&isFollow=" + atten;
                String result = PostAndGet.doGetHttp(path);

//                LogUtil.e("关注", result);
                if (result.equals("网络异常")) {

                } else {
                    SimpleResultModel simpleResultModel = gson.fromJson(result, SimpleResultModel.class);
                    Message message = new Message();
                    message.obj = atten;
                    if (simpleResultModel.getStatus() == 0) {
                        message.what = 4;
                        message.arg1 = position;
                        handler.sendMessage(message);
                    } else {
                        message.what = 5;
                        handler.sendMessage(message);
                    }
                }

            }
        });
    }

    /*
     * 医生搜索结果
     * */ BaseQuickAdapter<MessageSearchModel.RetValueBean.DoctorBean, BaseViewHolder> doctorAdapter = new BaseQuickAdapter<MessageSearchModel.RetValueBean.DoctorBean, BaseViewHolder>(R.layout.item_scroll_layout) {
        @Override
        protected void convert(BaseViewHolder helper, final MessageSearchModel.RetValueBean.DoctorBean item) {

            helper.setIsRecyclable(false);

            EasySwipeMenuLayout esml_item = helper.getView(R.id.esml_item);
            esml_item.setCanLeftSwipe(false);
            esml_item.setCanRightSwipe(false);

            ImageView imgItemHead = helper.getView(R.id.img_item_head);


            Bitmap defaultBitmap = BitmapFactory.decodeResource(getResources(), R.drawable.nantou);
            BitmapDrawable defaultDrawable = new BitmapDrawable(getResources(), defaultBitmap);
            imgItemHead.setBackgroundDrawable(defaultDrawable);
            if (item.getUserIcon() != null) {
                imgItemHead.setTag(item.getUserIcon());
                File file = new File(path + item.getUserIcon());
                if (file.exists()) {
                    Bitmap bitmap1 = BitmapFactory.decodeFile(file.getAbsolutePath());
                    if (bitmap1 != null) {
                        if (imgItemHead.getTag().equals(item.getUserIcon())) {
                            bitmap1 = getCirleBitmap(bitmap1);
                            BitmapDrawable bitmapDrawable = new BitmapDrawable(getResources(), bitmap1);
                            imgItemHead.setBackgroundDrawable(bitmapDrawable);
                        }
                    }
                } else {
                    BitmapWorkerTask bitmapWorkerTask = new BitmapWorkerTask(imgItemHead, file);
                    bitmapWorkerTask.execute(item.getUserIcon());
//                    Bitmap bitmap1 = ossService.downHeadImageSyc(item.getUserIcon());
//                    if (bitmap1 != null) {
//
//                        if (item.getUserIcon().endsWith("img")) {
//                            bitmap1 = Bitmap.createBitmap(bitmap1, 0, 0, bitmap1.getWidth(), bitmap1.getHeight(), matrix, true);
//                        }
//
//                        imgItemHead.setImageBitmap(bitmap1);
//                        if (!file.getParentFile().exists()) {
//                            file.getParentFile().mkdirs();
//                        }
//                        try {
//                            file.createNewFile();
//                            FileOutputStream fileOutputStream = new FileOutputStream(file);
//                            bitmap1.compress(Bitmap.CompressFormat.PNG, 100, fileOutputStream);
//                            fileOutputStream.flush();
//                        } catch (Exception e) {
//
//                        }
//
//                    } else {
//
//                        imgItemHead.setBackgroundResource(R.drawable.nantou);
//                    }
                }

            } else {
                imgItemHead.setBackgroundDrawable(defaultDrawable);
            }

            ImageView imgNotice = helper.getView(R.id.img_notice);
            imgNotice.setVisibility(View.GONE);
            ImageView imageItemGender = helper.getView(R.id.image_item_gender);
            TextView tvItemName = helper.getView(R.id.tv_item_name);
            tvItemName.setText(item.getUserName());
            TextView tvItemAge = helper.getView(R.id.tv_item_age);

            tvItemAge.setText(item.getHospitalDepartment() + "(" + item.getUserTitle() + ")");
            TextView tvItemState = helper.getView(R.id.tv_item_state);
            TextView tvItemDate = helper.getView(R.id.tv_item_date);
            tvItemDate.setText("");

            TextView tvItemMsg = helper.getView(R.id.tv_item_msg);

            tvItemMsg.setText("");
            TextView tvItemMode = helper.getView(R.id.tv_item_model);
            tvItemMode.setText("");
//
            TextView tvScrollRight = helper.getView(R.id.tv_scroll_right);
//
//            Button btnApply = helper.getView(R.id.btn_apply);
//            btnApply.setVisibility(View.GONE);
//
            String tip = "";
//            if (item.isIsFollow()) {
//                tip = "<font>取消<br>关注<font>";
//                tvScrollRight.setBackgroundResource(R.drawable.shape_atten_gray);
//            } else {
//                tip = "<font>关注<br>患者<font>";
//            }
//            tvScrollRight.setText(Html.fromHtml(tip));
//            tvScrollRight.setOnClickListener(new View.OnClickListener() {
//                @Override
//                public void onClick(View v) {
//                    if (item.isIsFollow()) { //已经关注 取消关注
//                        modifyAttent(false, helper.getAdapterPosition(), item.getId());
//                    } else {  //未关注 添加关注
//                        modifyAttent(true, helper.getAdapterPosition(), item.getId());
//                    }
//                }
//            });

            ConstraintLayout clItem = helper.getView(R.id.cl_item);
            clItem.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (System.currentTimeMillis() - lastClick2 > 1000) {
                        Intent intent1 = new Intent(SearchActivity.this, WebActivity.class);
                        Bundle bundle = new Bundle();
                        bundle.putString("url", "personal.html?id=" + item.getId());
                        intent1.putExtras(bundle);
                        startActivity(intent1);
                        lastClick2 = System.currentTimeMillis();
                    }
                }
            });

            Button btnApply = helper.getView(R.id.btn_apply);
            btnApply.setVisibility(View.GONE);
        }
    };


    class BitmapWorkerTask extends AsyncTask<String, Void, BitmapDrawable> {

        private ImageView mImageView;
        private File file;

        public BitmapWorkerTask(ImageView imageView, File filem) {
            mImageView = imageView;
            file = filem;
        }

        @Override
        protected BitmapDrawable doInBackground(String... params) {
            String imageUrl = params[0];
            // 在后台开始下载图片
            Bitmap bitmap = downloadBitmap(imageUrl);
            BitmapDrawable drawable = new BitmapDrawable(bitmap);
//            addBitmapToMemoryCache(imageUrl, drawable);
            return drawable;
        }

        @Override
        protected void onPostExecute(BitmapDrawable drawable) {
            if (mImageView != null && drawable != null) {
                mImageView.setImageDrawable(drawable);
            }
        }

        /**
         * 建立HTTP请求，并获取Bitmap对象。
         *
         * @param imageUrl 图片的URL地址
         * @return 解析后的Bitmap对象
         */
        private Bitmap downloadBitmap(String imageUrl) {

            Bitmap bitmap = ossService.downHeadImageSyc(imageUrl);

            if (imageUrl.equals(mImageView.getTag()) && bitmap != null) {

                bitmap = getCirleBitmap(bitmap);
                if (!file.getParentFile().exists()) {
                    file.getParentFile().mkdirs();
                }
                try {
                    file.createNewFile();
                    FileOutputStream fileOutputStream = new FileOutputStream(file);
                    bitmap.compress(Bitmap.CompressFormat.PNG, 50, fileOutputStream);
                    fileOutputStream.flush();
                } catch (Exception e) {

                }
                return bitmap;
            } else {
                return null;
            }

        }

    }

    public Bitmap getCirleBitmap(Bitmap bmp) {
        //获取bmp的宽高 小的一个做为圆的直径r
        int w = bmp.getWidth();
        int h = bmp.getHeight();
        int r = Math.min(w, h);

        //创建一个paint
        Paint paint = new Paint();
        paint.setAntiAlias(true);

        //新创建一个Bitmap对象newBitmap 宽高都是r
        Bitmap newBitmap = Bitmap.createBitmap(r, r, Bitmap.Config.ARGB_8888);

        //创建一个使用newBitmap的Canvas对象
        Canvas canvas = new Canvas(newBitmap);

        //创建一个BitmapShader对象 使用传递过来的原Bitmap对象bmp
        BitmapShader bitmapShader = new BitmapShader(bmp, Shader.TileMode.CLAMP, Shader.TileMode.CLAMP);

        //paint设置shader
        paint.setShader(bitmapShader);

        //canvas画一个圆 使用设置了shader的paint
        canvas.drawCircle(r / 2, r / 2, r / 2, paint);

        return newBitmap;
    }


}
