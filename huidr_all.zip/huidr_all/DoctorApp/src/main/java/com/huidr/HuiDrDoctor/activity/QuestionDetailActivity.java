package com.huidr.HuiDrDoctor.activity;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.AnimationDrawable;
import android.graphics.drawable.BitmapDrawable;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import androidx.annotation.NonNull;

import androidx.appcompat.app.AppCompatActivity;

import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.util.Log;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.alibaba.fastjson.JSONObject;
import com.chad.library.adapter.base.BaseQuickAdapter;
import com.chad.library.adapter.base.BaseViewHolder;
import com.google.gson.Gson;
import com.huidr.HuiDrDoctor.activity.main.Consult.utils.PostAndGet;
import com.huidr.HuiDrDoctor.debug.BuildConfig;
import com.huidr.HuiDrDoctor.debug.R;
import com.huidr.HuiDrDoctor.module.home.QuestionDetailModel;
import com.huidr.HuiDrDoctor.module.home.RelationQueListModel;
import com.huidr.HuiDrDoctor.module.home.SimpleResultStrModel;
import com.huidr.HuiDrDoctor.module.home.SumitAnswerModel;
import com.huidr.HuiDrDoctor.module.model.LoginResultForH5;
import com.huidr.HuiDrDoctor.sound_util.AudioRecorderButton;
import com.huidr.HuiDrDoctor.sound_util.MediaManager;
import com.huidr.HuiDrDoctor.util.DialogEnsureUtil;
import com.huidr.HuiDrDoctor.util.DialogShowImg;
import com.huidr.HuiDrDoctor.util.DownLoadImgRecent;
import com.huidr.HuiDrDoctor.util.LogUtil;
import com.huidr.HuiDrDoctor.util.MulityClickUtils;
import com.huidr.HuiDrDoctor.util.ThreadPoolManager;
import com.huidr.lib.commom.util.Toast;
import com.scwang.smartrefresh.layout.SmartRefreshLayout;
import com.scwang.smartrefresh.layout.api.RefreshLayout;
import com.scwang.smartrefresh.layout.listener.OnLoadMoreListener;
import com.scwang.smartrefresh.layout.listener.OnRefreshListener;

import java.io.File;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import jiguang.chat.utils.oss.Constants;
import jiguang.chat.utils.oss.OssService;
import jiguang.chat.utils.oss.SharedPreferenciesUtil;

public class QuestionDetailActivity extends AppCompatActivity implements View.OnClickListener {

    private ImageView imgBack;
    private TextView tvName;
    private TextView tvRight;


    private ImageView imgHead;
    private TextView tvName1;
    private ImageView imgGender;
    private TextView tvAge;
    private TextView tvAdd;//住院号
    private TextView tvHos, tvDep, tvDepart;
    private TextView tvContent;//问题描述
    private RecyclerView rvListImg;


    /*我的回答*/
    private ConstraintLayout clReply;//回答布局
    private TextView tvCount;//字数统计
    private TextView tvReply;//答案
    private TextView tvHint;//标示
    /*我的回答 声音布局*/
    private ConstraintLayout clSound;//声音
    private ImageView imgPlay;
    private TextView tvPlayState;
    private ImageView imgAni;
    private TextView tvSoundLength;
    private ImageView imgDeleteSound;


    /*输入框*/
//    private TextView tvBackBottom;
    private ConstraintLayout clBottom;
    private Button btnCommit;//提交按钮
    private ConstraintLayout clInput;//输入布局
    private ImageView imgInputType;//输入方式
    private AudioRecorderButton btnInput;//语音输入
    private EditText etInputKey;//文字输入
    private TextView tvComplete;//输入完成

    /*历史问答*/
    private RelativeLayout llHis;
    private RecyclerView rvListHis;


    private InputMethodManager inputMethodManager;

    private int showType = 0;// 0 问题 1历史回答
    private int showImm = 0;//  是否弹出键盘  0否 1是 2不可回答
    private boolean inputType = true;//true  键盘 false声音
    private boolean isReplyAble = false;//是否可回答


    private boolean isPlay;//播放状态  true 播放 false 暂停

    private String soundPath;//声音路径
    private float soundLength;//声音时长
    private boolean showSound;//显示声音

    private List imgList;//图片列表


    private DialogEnsureUtil dialogEnsureUtil;
    private OssService ossService;

    private AnimationDrawable animationDrawable;

    private DialogShowImg dialogShowImg;

    private TextView tvLock;


    private String path = BuildConfig.baseUrl + "recommend/askAnswerOptimizationDoctorController/getDoctorProblemDetails?id=";//获取问题详情
    private String pathLockDelete = BuildConfig.baseUrl + "recommend/askAnswerOptimizationDoctorController/delReplyProblemUnlock?id="; //删除问题锁
    private String pathSubmit = BuildConfig.baseUrl + "recommend/askAnswerOptimizationDoctorController/addReplyProblem";//提交答案


    private int queId;//问题Id

    private Gson gson;
    private QuestionDetailModel questionDetailModel;
    private List<String> imgPathList;
    private int answerType = 1;//答案类型 1文字 2语音
    private String doctorId;

    String fineName;//文件名  oss

    private int chaseId = 0;
    private int currentPage = 1;
    private int totalPage = 1;
    private List<RelationQueListModel.RetValueBean> relationList;
    private RelationQueListModel relationQueListModel;

    private SmartRefreshLayout srlHis;

    private String soundRootPath;
    private String imgRootPath;

    private Bitmap bitmap;

    private boolean isMyPatient;

    private TextView tvQuImg;//图片标示
    private View viewDivider1;//

    private String jobNum;
    private String doctorJobNum;

    private int showReturn;// 0隐藏  1显示


    /*提交答案    */
    public void submitAnswer() {
        ThreadPoolManager.getInstance().execute(new Runnable() {
            @Override
            public void run() {
                JSONObject jsonObject = new JSONObject();

                jsonObject.put("answerType", answerType);//答案类型   1文字 2语音
                jsonObject.put("id", queId);
                if (answerType == 1) {
                    jsonObject.put("answer", etInputKey.getText().toString());//答案  文字
                } else {  //doctorId + "/sounds"
                    fineName = doctorId + "/sounds" + soundPath.substring(soundPath.lastIndexOf("/"));
//                    ossService.asyncPutImage(fineName, soundPath);
                    ossService.asyncPutSound(fineName, soundPath);
                    jsonObject.put("answer", fineName);//答案   语音 文件路径
                    jsonObject.put("speechDuration", tvSoundLength.getText().toString());//录音时长
                }
                String result = PostAndGet.doHttpPost(pathSubmit, jsonObject);
                LogUtil.e("上传答案", result);

                if (TextUtils.isEmpty(result) || result.equals("网络异常")) {
                    handler.sendEmptyMessage(5);
                } else {
                    SumitAnswerModel sumitAnswerModel = gson.fromJson(result, SumitAnswerModel.class);
                    if (sumitAnswerModel.getStatus() == 0) {
                        handler.sendEmptyMessage(1);
                    } else {
                        handler.sendEmptyMessage(5);
                    }
                }


            }
        });
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
//        ActivityCompat.requestPermissions(this, permissions, 1);


        setContentView(R.layout.activity_question_detail);
        gson = new Gson();

        String userInfo = (String) SharedPreferenciesUtil.getData(Constants.SharedAccountConfig.USER_DOCTOR_INFO, "");

        LoginResultForH5 loginResult = gson.fromJson(userInfo, LoginResultForH5.class);

        doctorJobNum = loginResult.getValue().getUserJobNumber();

        imgRootPath = this.getExternalCacheDir().getAbsolutePath() + "/img/";  //一问医答 图片根路径
        soundRootPath = this.getExternalCacheDir().getAbsolutePath() + "/sounds/";  //一问医答 声音根路径

        doctorId = (String) SharedPreferenciesUtil.getData(Constants.SharedAccountConfig.ID, "");


        imgPathList = new ArrayList<>();
        questionDetailModel = new QuestionDetailModel();

        relationList = new ArrayList<>();
        relationQueListModel = new RelationQueListModel();
        inputMethodManager = (InputMethodManager) getSystemService(INPUT_METHOD_SERVICE);
        initView();
    }


    @Override
    protected void onStart() {
        super.onStart();


        showType = getIntent().getIntExtra("showType", 5);
        showImm = getIntent().getIntExtra("showImm", 5);
        queId = getIntent().getIntExtra("queId", 5);
        jobNum = getIntent().getStringExtra("jobnum");


        Log.e("医生工号", jobNum + "  123");
        if (showType == 5) {
            showType = (int) SharedPreferenciesUtil.getData("showType", 0);
        }

        if (showImm == 5) {
            showImm = (int) SharedPreferenciesUtil.getData("showImm", 0);
        }

        if (queId == 5) {
            queId = (int) SharedPreferenciesUtil.getData("queId", 0);
        }


        if (jobNum == null) {
            jobNum = (String) SharedPreferenciesUtil.getData("jobNum", "0");
        }

        getQuestionDetail();

//        getRelationQueList();
    }


    @Override
    protected void onStop() {
        super.onStop();
        SharedPreferenciesUtil.putData("showType", showType);
        SharedPreferenciesUtil.putData("showImm", showImm);
        SharedPreferenciesUtil.putData("queId", queId);
        SharedPreferenciesUtil.putData("isMyPatient", isMyPatient);
        SharedPreferenciesUtil.putData("jobNum", jobNum);
    }

    /*获取问题详情*/
    public void getQuestionDetail() {
        ThreadPoolManager.getInstance().execute(new Runnable() {
            @Override
            public void run() {

                String path = BuildConfig.baseUrl + "recommend/askAnswerOptimizationDoctorController/getDoctorProblemDetails?id=" + queId;
                String result = PostAndGet.doGetHttp(path);
                LogUtil.e("问题详情", result);
                if (result.equals("网络异常")) {

                } else {
                    questionDetailModel = gson.fromJson(result, QuestionDetailModel.class);
                    if (questionDetailModel.getStatus() == 0) {
                        handler.sendEmptyMessage(0);
                    } else {

                    }

                }
            }
        });
    }


    /*获取关联问题*/
    public void getRelationQueList() {
        ThreadPoolManager.getInstance().execute(new Runnable() {
            @Override
            public void run() {
                String pathRelationList = BuildConfig.baseUrl + "recommend/askAnswerOptimizationDoctorController/getMedicalAnswerRelationList?chaseId=" + chaseId + "&pageIndex=" + currentPage + "&pageSize=10&id=" + queId;
                String result = PostAndGet.doGetHttp(pathRelationList);
                LogUtil.e("关联问题", currentPage + "        " + result);
                relationQueListModel = new RelationQueListModel();
                if (TextUtils.isEmpty(result) || result.equals("网络异常")) {
                    handler.sendEmptyMessage(4);
                } else {
                    relationQueListModel = gson.fromJson(result, RelationQueListModel.class);
                    if (relationQueListModel.getStatus() == 0) {
                        totalPage = relationQueListModel.getTotalPage();
                        if (currentPage == 1) {
                            handler.sendEmptyMessage(2);
                        } else {
                            handler.sendEmptyMessage(3);
                        }
                    } else {
                        handler.sendEmptyMessage(4);
                    }
                }

            }
        });
    }


    /*删除锁*/
    public void deleteLock() {
        ThreadPoolManager.getInstance().execute(new Runnable() {
            @Override
            public void run() {
                pathLockDelete += queId;
                String result = PostAndGet.doGetHttp(pathLockDelete);
                LogUtil.e("问题详情 删除锁" + queId, result + "  " + pathLockDelete);
                if (result.equals("网络异常")) {

                } else {
                    SimpleResultStrModel simpleResultStrModel = gson.fromJson(result, SimpleResultStrModel.class);
                    if (simpleResultStrModel.getStatus() == 0) {
                        if (simpleResultStrModel.getRetValue().equals("SUCCESS")) {
                            finish();
                        }
                    } else {

                    }
                }
            }
        });
    }

    /*下载声音*/
    public void downSounds(String ossPath) {
        try {

            File file = new File(soundPath);
            if (!file.getParentFile().exists()) {
                file.getParentFile().mkdirs();
            }

            if (!file.exists()) {
                file.createNewFile();
                ossService.downSoundSyc(ossPath, file);


            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    /*下载声音*/
    public void customDownLoadSound(final String object) {
        ThreadPoolManager.getInstance().execute(new Runnable() {
            @Override
            public void run() {

                try {
                    File file = new File(soundPath);
                    if (!file.getParentFile().exists()) {
                        file.getParentFile().mkdirs();
                    }

                    if (!file.exists()) {
                        file.createNewFile();
                        ossService.customDownLoadSound(object, file);
                    }

                } catch (Exception e) {

                }
            }
        });
    }


    private Handler handler = new Handler() {
        @Override
        public void handleMessage(Message msg) {
            super.handleMessage(msg);
            switch (msg.what) {
                case 0://获取问题详情成功

                    tvName.setText(questionDetailModel.getRetValue().getUserName());
                    tvName1.setText(questionDetailModel.getRetValue().getUserName());

                    if (questionDetailModel.getRetValue().getUserAdmitNo() != null) {
                        tvAdd.setText("住院号：" + questionDetailModel.getRetValue().getUserAdmitNo());
                    }

                    tvHos.setText(questionDetailModel.getRetValue().getUserHospitalName());
                    tvDep.setText(questionDetailModel.getRetValue().getUserDepartmentName());
                    tvDepart.setText(questionDetailModel.getRetValue().getUserWardName());

                    if (questionDetailModel.getRetValue().getUserAge() != 0) {
                        tvAge.setText(questionDetailModel.getRetValue().getUserAge() + "岁");
                    }

                    if (questionDetailModel.getRetValue().getUserSex() == 0) {
                        imgGender.setVisibility(View.GONE);
                    } else if (questionDetailModel.getRetValue().getUserSex() == 1) {
                        imgGender.setBackgroundResource(R.drawable.gender_man);
                    } else {
                        imgGender.setBackgroundResource(R.drawable.gender_w);
                    }


                    Log.e("医生工号1", jobNum + "");
                    Log.e("医生工号2", doctorJobNum + "");

                    if (jobNum.equals(doctorJobNum)) {
                        tvRight.setVisibility(View.VISIBLE);
                    } else {
                        tvRight.setVisibility(View.GONE);
                    }

                    tvContent.setText("\t\t\t\t" + questionDetailModel.getRetValue().getProblemContent());


                    LogUtil.e("图片--", questionDetailModel.getRetValue().getDiseasePicturePaths() + "");


                    if (!TextUtils.isEmpty(questionDetailModel.getRetValue().getDiseasePicturePaths())) {
                        imgList = Arrays.asList(questionDetailModel.getRetValue().getDiseasePicturePaths().split(","));
                        imgAdapter.setNewData(imgList);
                    } else {
                        tvQuImg.setVisibility(View.GONE);
                        viewDivider1.setVisibility(View.GONE);
                    }

                    LogUtil.e("charsId----", questionDetailModel.getRetValue().getChaseId() + " ");

//                    chaseId
                    if (questionDetailModel.getRetValue().getChaseId() == 0) {
                        chaseId = questionDetailModel.getRetValue().getId();
                    } else {
                        chaseId = questionDetailModel.getRetValue().getChaseId();
                    }

//                    从 问题页进入 加载关联问题 从我的回答进入  0  新问题 1历史问答
                    if (showType == 0) {
                        getRelationQueList();

                        clBottom.setVisibility(View.VISIBLE);
                        clReply.setVisibility(View.GONE);
                        tvHint.setVisibility(View.GONE);
                        //llHis.setVisibility(View.VISIBLE);//历史问答
//            对入口判断  1  弹出键盘
                        if (showImm == 1) {

                            if (questionDetailModel.getRetValue().isIsAllowAnswerOperation()) {
                                startReply();
                            } else {
//                                提示不可回答
                                tvLock.setVisibility(View.VISIBLE);
                            }

                        } else {
                            isReplyAble = true;
                            if (isReplyAble) {
                                btnCommit.setText("我来回答");
                                btnCommit.setVisibility(View.VISIBLE);
                            } else {
                                tvLock.setVisibility(View.VISIBLE);
                            }
                        }

                    } else {

                        srlHis.setEnableRefresh(false);
                        srlHis.setEnableLoadMore(false);
                        clReply.setVisibility(View.VISIBLE);
                        tvHint.setVisibility(View.VISIBLE);
                        btnCommit.setVisibility(View.GONE);
                        llHis.setVisibility(View.GONE);//历史问答隐藏


                        showReturn = getIntent().getIntExtra("showReturn", 0);

                        if (showReturn == 0) {//隐藏
                            clBottom.setVisibility(View.GONE);
                        } else {//显示
                            clBottom.setVisibility(View.VISIBLE);
                            btnCommit.setVisibility(View.VISIBLE);
                            btnCommit.setText("返回");
                        }


                        /*答案类型  1文字 2语音  */
                        if (questionDetailModel.getRetValue().getAnswerType() == 1) {
//                        显示文字  显示答案
                            tvReply.setText(questionDetailModel.getRetValue().getAnswer());
                            tvCount.setText(questionDetailModel.getRetValue().getAnswer().length() + "/300");

                        } else {
////                        显示声音 隐藏声音删除
                            tvReply.setVisibility(View.GONE);
                            tvCount.setVisibility(View.GONE);
                            clSound.setVisibility(View.VISIBLE);
                            showSound();
                            imgDeleteSound.setVisibility(View.GONE);

                            soundPath = soundRootPath + questionDetailModel.getRetValue().getAnswer();


                            downSounds(questionDetailModel.getRetValue().getAnswer());
//                            customDownLoadSound(questionDetailModel.getRetValue().getAnswer());

                            if (questionDetailModel.getRetValue().getSpeechDuration() != null && !questionDetailModel.getRetValue().getSpeechDuration().equals("")) {
                                tvSoundLength.setText(questionDetailModel.getRetValue().getSpeechDuration());
                            }

                        }
                    }

                    srlHis.setVisibility(View.VISIBLE);

                    break;

//                    上传答案成功
                case 1:
                    clBottom.setVisibility(View.GONE);
                    if (answerType == 2) {
                        imgDeleteSound.setVisibility(View.GONE);
                    }
                    break;

//                    获取关联问题成功  刷新数据
                case 2:

                    hisAdapter.getData().clear();
                    if (relationQueListModel.getRetValue() == null || relationQueListModel.getRetValue().size() == 0) {
                        llHis.setVisibility(View.GONE);
                        srlHis.setEnableRefresh(false);
                        srlHis.setEnableLoadMore(false);

                    } else {
                        llHis.setVisibility(View.VISIBLE);
                        srlHis.setEnableRefresh(true);
                        srlHis.setEnableLoadMore(true);
                        hisAdapter.getData().addAll(relationQueListModel.getRetValue());
                        hisAdapter.notifyDataSetChanged();
                    }
                    srlHis.finishRefresh();
                    break;
//                    获取关联问题成功  加载更多
                case 3:
                    hisAdapter.getData().addAll(relationQueListModel.getRetValue());
                    hisAdapter.notifyDataSetChanged();
                    srlHis.finishLoadMore();
                    break;
//                    获取关联问题失败
                case 4:
                    srlHis.finishRefresh();
                    srlHis.finishLoadMore();
                    llHis.setVisibility(View.GONE);
                    srlHis.setEnableRefresh(false);
                    srlHis.setEnableLoadMore(false);
                    break;

//                    上传答案失败
                case 5:
                    Toast.getInstance(QuestionDetailActivity.this).show("上传失败，请稍后重试", 500);
                    break;
            }
        }
    };


    public void initView() {
        imgBack = (ImageView) findViewById(R.id.img_back_item);
        tvName = (TextView) findViewById(R.id.tv_name_item);
        tvRight = (TextView) findViewById(R.id.tv_right_item);
        tvName.setText("患者");
        tvRight.setText("患者资料");


        imgBack.setOnClickListener(this);
        tvRight.setOnClickListener(this);

        imgHead = (ImageView) findViewById(R.id.img_head);
        tvName1 = (TextView) findViewById(R.id.tv_name1);
        imgGender = (ImageView) findViewById(R.id.img_gender);
        tvAge = (TextView) findViewById(R.id.tv_age);
        tvAdd = (TextView) findViewById(R.id.tv_add);
        tvHos = (TextView) findViewById(R.id.tv_hos);
        tvDep = (TextView) findViewById(R.id.tv_dep);
        tvDepart = (TextView) findViewById(R.id.tv_depart);
        tvContent = (TextView) findViewById(R.id.tv_content);
        rvListImg = (RecyclerView) findViewById(R.id.rv_list_img);


        clReply = (ConstraintLayout) findViewById(R.id.cl_reply);
        tvCount = (TextView) findViewById(R.id.tv_count);
        tvReply = (TextView) findViewById(R.id.et_reply);
        tvHint = (TextView) findViewById(R.id.tv_hint);

        clSound = (ConstraintLayout) findViewById(R.id.cl_sound);
        imgPlay = (ImageView) findViewById(R.id.img_play);
        tvPlayState = (TextView) findViewById(R.id.tv_play_state);
        imgAni = (ImageView) findViewById(R.id.img_ani);
        animationDrawable = (AnimationDrawable) imgAni.getBackground();
        tvSoundLength = (TextView) findViewById(R.id.tv_sound_length);
        imgDeleteSound = (ImageView) findViewById(R.id.img_delete_sound);


        clBottom = (ConstraintLayout) findViewById(R.id.cl_bottom);
//        tvBackBottom = (TextView) findViewById(R.id.tv_back_bottom);
        btnCommit = (Button) findViewById(R.id.btn_commit);
        clInput = (ConstraintLayout) findViewById(R.id.cl_input);
        imgInputType = (ImageView) findViewById(R.id.img_input_type);
        btnInput = findViewById(R.id.btn_input);
        etInputKey = (EditText) findViewById(R.id.et_input_key);
        tvComplete = (TextView) findViewById(R.id.tv_complete);
        tvLock = (TextView) findViewById(R.id.tv_lock);


        llHis = (RelativeLayout) findViewById(R.id.ll_his);

        rvListHis = (RecyclerView) findViewById(R.id.rv_list_his);
        rvListHis.setNestedScrollingEnabled(false);
        rvListHis.setAdapter(hisAdapter);
        rvListHis.setLayoutManager(new LinearLayoutManager(this));


        btnCommit.setOnClickListener(this);

        tvComplete.setOnClickListener(this);

        tvReply.setOnClickListener(this);

        imgInputType.setOnClickListener(this);

        imgPlay.setOnClickListener(this);

        imgAni.setVisibility(View.GONE);


        imgDeleteSound.setOnClickListener(this);

        imgList = new ArrayList();
        rvListImg.setAdapter(imgAdapter);
        rvListImg.setLayoutManager(new GridLayoutManager(this, 5));

        etInputKey.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {
//                Log.e("键盘输入",s.toString()+"  "+s.);
                tvReply.setText("\t\t\t" + s.toString());
                tvCount.setText(s.toString().length() + "/300");
            }
        });

        btnInput.setAudioFinishRecorderListener(new AudioRecorderButton.AudioFinishRecorderListener() {
            @Override
            public void onFinish(float seconds, String filePath) {
                LogUtil.e("文件路径", filePath + "   " + seconds);
                soundPath = filePath;
                soundLength = seconds;
                showSound();
                formatLength((int) seconds);
            }
        });


        switchInputType();

        ossService = new OssService(this);


        srlHis = findViewById(R.id.srl_his);


        srlHis.setEnableLoadMore(true);
        srlHis.setEnableRefresh(true);

        srlHis.setOnLoadMoreListener(new OnLoadMoreListener() {
            @Override
            public void onLoadMore(@NonNull RefreshLayout refreshLayout) {
                if (currentPage < totalPage && relationQueListModel.getRetValue().size() == 10) {
                    currentPage += 1;
                    getRelationQueList();
                } else {
                    srlHis.finishLoadMore();
                    Toast.getInstance(QuestionDetailActivity.this).show("数据加载全部", 500);
                }
            }
        });

        srlHis.setOnRefreshListener(new OnRefreshListener() {
            @Override
            public void onRefresh(@NonNull RefreshLayout refreshLayout) {
                currentPage = 1;
                getRelationQueList();
            }
        });

        tvQuImg = (TextView) findViewById(R.id.tv_qu_img);
        viewDivider1 = (View) findViewById(R.id.view_divider1);

    }


    /*设置时长*/
    public void formatLength(int length) {
        if (length < 60) {
            tvSoundLength.setText(length + " \" ");
        } else {
            tvSoundLength.setText(length / 60 + "'" + length % 60 + "\"");
        }
    }


    /*键盘显示  布局加载过程中无法弹出软键盘,所以需要适当的延迟*/
    public void showKeyBoard() {
//        etInputKey.requestFocus();
        LogUtil.e("获取焦点", etInputKey.requestFocus() + " ");

        if (etInputKey.requestFocus()) {
            inputMethodManager.showSoftInput(etInputKey, 0);
        } else {
            handler.postDelayed(new Runnable() {
                @Override
                public void run() {
                    etInputKey.requestFocus();
                    inputMethodManager.showSoftInput(etInputKey, 0);
                }
            }, 500);
        }

    }

    /*键盘隐藏*/
    public void hideKeyBoard() {
        if (inputMethodManager.isActive()) {
            inputMethodManager.hideSoftInputFromWindow(etInputKey.getWindowToken(), 0);
        }
    }

    //图片 适配
    BaseQuickAdapter<String, BaseViewHolder> imgAdapter = new BaseQuickAdapter<String, BaseViewHolder>(R.layout.item_img_det) {
        @Override
        protected void convert(final BaseViewHolder helper, String item) {
            ImageView imageView = (ImageView) helper.getView(R.id.img);
//            imageView.setBackgroundResource(item);

            Bitmap bitmap1 = BitmapFactory.decodeResource(getResources(), R.drawable.loading_back);
            BitmapDrawable bitmapDrawable1 = new BitmapDrawable(getResources(), bitmap1);
            imageView.setBackgroundDrawable(bitmapDrawable1);

            imageView.setTag(item);
            File file = new File(imgRootPath + item);
            if (file.exists()) {
                bitmap = BitmapFactory.decodeFile(file.getAbsolutePath());
                if (bitmap != null) {
                    BitmapDrawable bitmapDrawable = new BitmapDrawable(getResources(), bitmap);
                    if (imageView.getTag().equals(item)) {
                        imageView.setBackgroundDrawable(bitmapDrawable);
                    }
                }
            } else {
                DownLoadImgRecent.BitmapWorkerTask bitmapWorkerTask = new DownLoadImgRecent.BitmapWorkerTask(imageView, file, ossService);
                bitmapWorkerTask.execute(item);
            }


            helper.getView(R.id.img).setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    dialogShowImg = new DialogShowImg(QuestionDetailActivity.this, imgList);
                    dialogShowImg.showImg(helper.getAdapterPosition());
                }
            });
        }
    };


    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            /*回答 提交*/
            case R.id.btn_commit:

                if (btnCommit.getText().toString().equals("我来回答")) {
                    if (questionDetailModel.getRetValue().isIsAllowAnswerOperation()) {
                        startReply();
                    } else {
                        tvLock.setVisibility(View.VISIBLE);
                        btnCommit.setVisibility(View.GONE);
                    }

                } else if (btnCommit.getText().toString().equals("提交")) {
                    dialogEnsureUtil = new DialogEnsureUtil(this);
                    dialogEnsureUtil.showEnsureDialog();

                    dialogEnsureUtil.setEnsureClick(new DialogEnsureUtil.EnsureClick() {
                        @Override
                        public void onEnsureListener() {
                            submitAnswer();
                        }

                        @Override
                        public void onCancelListener() {
//                            取消提交答案  显示输入

                            LogUtil.e("取消发送", "继续编辑" + answerType);
                            clInput.setVisibility(View.VISIBLE);
                            btnCommit.setVisibility(View.GONE);
                            if (answerType == 1) {
//                                showKeyBoard();
                                handler.postDelayed(new Runnable() {
                                    @Override
                                    public void run() {
                                        etInputKey.requestFocus();
                                        inputMethodManager.showSoftInput(etInputKey, 0);
                                    }
                                }, 500);
                            }
                        }
                    });
                } else if (btnCommit.getText().toString().equals("返回")) {
                    finish();
                }

                break;
            case R.id.tv_complete://完成输入 隐藏键盘 显示提交按钮

                LogUtil.e("完成", soundPath + "    " + etInputKey.getText());

                if (TextUtils.isEmpty(soundPath) && TextUtils.isEmpty(etInputKey.getText())) {

                } else {
                    clInput.setVisibility(View.GONE);
                    btnCommit.setVisibility(View.VISIBLE);
                    btnCommit.setText("提交");
                    hideKeyBoard();
                    Log.e("答案", "答案类型" + "  " + answerType + "   " + inputType);
                }


                break;
            case R.id.et_reply://回答 文字


                if (!(clBottom.getVisibility() == View.GONE)) {
                    if (showType == 0) {
                        startReply();
                    }
                }

                break;
            case R.id.img_input_type://切换输入方式 0  文字 1 声音
                inputType = !inputType;
                switchInputType();
                break;

            case R.id.img_play:
                File file1 = new File(soundRootPath + questionDetailModel.getRetValue().getAnswer());

                if (!file1.exists() || file1.length() == 0) {
                    Toast.getInstance(QuestionDetailActivity.this).show("正在缓冲，请稍后", 500);
                    return;
                }
                isPlay = !isPlay;
                playSound();
                break;

            case R.id.img_delete_sound:
//                删除录音
                File file = new File(soundPath);
                file.delete();
                hideSound();
                break;

            case R.id.img_back_item:
//                finish();
                if (showType == 0) {
                    //新的问题 需要删除锁定
                    deleteLock();
                } else {
                    //历史问题
                    finish();
                }
                break;
            case R.id.tv_right_item:
                if (MulityClickUtils.isFastClick()) {


                    JSONObject jsonObject = new JSONObject();
                    jsonObject.put("id", questionDetailModel.getRetValue().getPatientId());
                    SharedPreferenciesUtil.putData("psearchID", jsonObject.toJSONString());//患者ID
                    Log.e("患者-医生ID", questionDetailModel.getRetValue().getPatientId());
                    if (questionDetailModel.getRetValue().getDoctorId() == null) {
                        SharedPreferenciesUtil.putData("followDoctorId", doctorId);  //医生ID
                        Log.e("患者-医生", doctorId);
                    } else {
                        SharedPreferenciesUtil.putData("followDoctorId", questionDetailModel.getRetValue().getDoctorId());  //医生ID
                        Log.e("患者-医生ID2", questionDetailModel.getRetValue().getDoctorId());
                    }


                    Intent intent1 = new Intent(QuestionDetailActivity.this, WebActivity.class);
                    Bundle bundle = new Bundle();
                    bundle.putString("url", "patientData.html");
                    intent1.putExtras(bundle);
                    startActivity(intent1);

                }
                break;
        }
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        Log.e("返回键", "返回键");


        if (showType == 0) {
            //新的问题 需要删除锁定
            deleteLock();
        } else {
            //历史问题
        }
    }


    /*声音播放*/
    public void playSound() {
        if (isPlay) {
            MediaManager.playSound(soundPath, new MediaPlayer.OnCompletionListener() {
                @Override
                public void onCompletion(MediaPlayer mp) {
                    imgPlay.setBackgroundResource(R.drawable.play);
                    tvPlayState.setText("播放");
                    imgAni.setVisibility(View.GONE);
                    animationDrawable.stop();
                }
            });
            tvPlayState.setText("暂停");
            imgPlay.setBackgroundResource(R.drawable.pause);
            imgAni.setVisibility(View.VISIBLE);
            animationDrawable.start();
        } else {
            MediaManager.pause();
            imgPlay.setBackgroundResource(R.drawable.play);
            tvPlayState.setText("播放");
            imgAni.setVisibility(View.GONE);
            animationDrawable.stop();
        }
    }

    /*true  键盘 false 声音*/
    public void switchInputType() {

        if (clInput.getVisibility() == View.GONE) {
            return;
        }
        if (inputType) {//切换为 文字输入
            tvCount.setVisibility(View.VISIBLE);
            imgInputType.setBackgroundResource(R.drawable.sound_input);
            showKeyBoard();
            etInputKey.setVisibility(View.VISIBLE);
            btnInput.setVisibility(View.GONE);

            clSound.setVisibility(View.GONE);
            tvReply.setVisibility(View.VISIBLE);
            answerType = 1;
            Log.e("答案类型", answerType + "文字" + inputType);
        } else {  //切换为声音输入
            tvCount.setVisibility(View.GONE);
            imgInputType.setBackgroundResource(R.drawable.keyboard);
            hideKeyBoard();
            etInputKey.setVisibility(View.GONE);
            btnInput.setVisibility(View.VISIBLE);
            clSound.setVisibility(View.VISIBLE);

            if (TextUtils.isEmpty(soundPath)) {
                hideSound();
            } else {
                showSound();
            }

            tvReply.setVisibility(View.GONE);
            answerType = 2;
            Log.e("答案类型", answerType + "语音" + inputType);
        }
    }

    /*显示语音*/
    public void showSound() {
        imgPlay.setVisibility(View.VISIBLE);
        tvPlayState.setVisibility(View.VISIBLE);
//        imgAni.setVisibility(View.VISIBLE);/**/
        tvSoundLength.setVisibility(View.VISIBLE);
        imgDeleteSound.setVisibility(View.VISIBLE);
    }

    /*隐藏语音*/
    public void hideSound() {
        imgPlay.setVisibility(View.GONE);
        tvPlayState.setVisibility(View.GONE);
        imgAni.setVisibility(View.GONE);
        tvSoundLength.setVisibility(View.GONE);
        imgDeleteSound.setVisibility(View.GONE);
    }

    /*开始输入文字*/
    public void startReply() {
        btnCommit.setVisibility(View.GONE);
        clInput.setVisibility(View.VISIBLE);
        showKeyBoard();
        clReply.setVisibility(View.VISIBLE);
        tvHint.setVisibility(View.VISIBLE);
    }

    @Override
    protected void onPause() {
        super.onPause();
        Log.e("界面消失", "onPause");
        btnInput.hideAndDelete();

        if (isPlay) {
            isPlay = !isPlay;
            playSound();
        }
    }


    private BaseQuickAdapter<RelationQueListModel.RetValueBean, BaseViewHolder> hisAdapter = new BaseQuickAdapter<RelationQueListModel.RetValueBean, BaseViewHolder>(R.layout.item_his_reply) {
        @Override
        protected void convert(BaseViewHolder helper, final RelationQueListModel.RetValueBean item) {
            final TextView tv = helper.getView(R.id.tv_content);
            final ImageView btnOpen = (ImageView) helper.getView(R.id.btn_open);
            final Button btnClose = (Button) helper.getView(R.id.btn_close);
            btnOpen.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
//                    btnClose.setVisibility(View.VISIBLE);
//                    btnOpen.setVisibility(View.GONE);
//                    tv.setSingleLine(false);


                    if (MulityClickUtils.isFastClick()) {
                        Intent intent = new Intent(QuestionDetailActivity.this, QuestionDetailActivity.class);
                        intent.putExtra("showType", 1);
                        intent.putExtra("showImm", 0);
                        intent.putExtra("queId", item.getId());//
                        intent.putExtra("showReturn", 1);
                        startActivity(intent);
                    }
                }
            });

//            btnClose.setOnClickListener(new View.OnClickListener() {
//                @Override
//                public void onClick(View v) {
//                    btnClose.setVisibility(View.GONE);
//                    btnOpen.setVisibility(View.VISIBLE);
//                    tv.setSingleLine(true);
//                }
//            });

            TextView tvName = helper.getView(R.id.tv_name);
            tvName.setText(item.getUserName());
            TextView tvContent = helper.getView(R.id.tv_content);
            tvContent.setText("\t\t\t" + item.getProblemContent());

            TextView tvDate = helper.getView(R.id.tv_date);


            Log.e("时间", item.getReplyTime().split(" ")[0].replace("-", "/"));
            tvDate.setText(item.getReplyTime().split(" ")[0].replace("-", "/"));


        }
    };

}
