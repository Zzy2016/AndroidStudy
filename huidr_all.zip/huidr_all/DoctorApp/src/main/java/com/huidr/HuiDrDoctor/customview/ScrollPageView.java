package com.huidr.HuiDrDoctor.customview;

import android.content.Context;

import android.util.AttributeSet;
import android.view.MotionEvent;

import androidx.viewpager.widget.ViewPager;

/**
 * @author: Administrator
 * @date: 2019-11-13
 */
public class ScrollPageView extends ViewPager {

    private boolean scrollable = false;


    //是否可以进行滑动
    private boolean isSlide = false;

    public void setSlide(boolean slide) {
        isSlide = slide;
    }

    public ScrollPageView(Context context) {
        super(context);
    }

    public ScrollPageView(Context context, AttributeSet attrs) {
        super(context, attrs);
    }

    @Override
    public boolean onInterceptTouchEvent(MotionEvent ev) {
        return isSlide;
    }


    public void setScrollable(boolean scrollable) {
        this.scrollable = false;
    }

    @Override
    public boolean onTouchEvent(MotionEvent ev) {
        return false;
    }
}
