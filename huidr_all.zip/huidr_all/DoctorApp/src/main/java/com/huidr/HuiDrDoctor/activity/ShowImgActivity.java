package com.huidr.HuiDrDoctor.activity;

import android.app.Activity;
import android.content.Context;
import androidx.annotation.NonNull;
import androidx.viewpager.widget.PagerAdapter;
import androidx.viewpager.widget.ViewPager;


import android.os.Bundle;
import android.view.Display;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.ImageView;

import com.huidr.HuiDrDoctor.debug.R;

import java.util.List;

public class ShowImgActivity extends Activity {

    int position;
    List<Integer> imgs;
    private Context context;
    private ViewPager viewPager;
    MyViewPagerAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_show_img);


        context = this;
        position = getIntent().getExtras().getInt("index");
        imgs = (List<Integer>) getIntent().getExtras().getSerializable("img");



        WindowManager m = getWindowManager();
        Display d = m.getDefaultDisplay();  //为获取屏幕宽、高
        WindowManager.LayoutParams p = getWindow().getAttributes();  //获取对话框当前的参数值
        p.height = (int) (d.getHeight() * 0.8);   //高度设置为屏幕的1.0
        p.width = (int) (d.getWidth() * 0.8);    //宽度设置为屏幕的0.8

        getWindow().setAttributes(p);

        viewPager = (ViewPager) findViewById(R.id.view_pager);
        adapter = new MyViewPagerAdapter(imgs);

        viewPager.setAdapter(adapter);
        viewPager.setCurrentItem(position, false);

    }


    public class MyViewPagerAdapter extends PagerAdapter {

        public List<Integer> imgList;

        public MyViewPagerAdapter(List<Integer> imgList) {
            this.imgList = imgList;
        }

        @Override
        public int getCount() {
            return imgList.size();
        }

        @Override
        public boolean isViewFromObject(@NonNull View view, @NonNull Object o) {
            return view == o;
        }

        @NonNull
        @Override
        public Object instantiateItem(@NonNull ViewGroup container, int position) {
            View view = View.inflate(context, R.layout.img_item_big_layout, null);
            ImageView img = view.findViewById(R.id.img);
//            try {
//                File file = new File(Environment.getExternalStorageDirectory().getAbsolutePath() + "/" + context.getPackageName() + "/cache/consult/" + imgList.get(position));
//                if (file.exists()) {
//                    FileInputStream fis = new FileInputStream(file);
//                    Bitmap bitmap1 = BitmapFactory.decodeStream(fis);
//                    img.setImageBitmap(bitmap1);
//                }
//            } catch (Exception e) {
//                LogUtil.e("显示大图", e.toString());
//            }
            img.setBackgroundResource(Integer.valueOf(imgs.get(position)));
            img.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    finish();
                }
            });
            container.addView(view);
            return view;
        }

        @Override
        public void destroyItem(@NonNull ViewGroup container, int position, @NonNull Object object) {
//            super.destroyItem(container, position, object);
            container.removeView((View) object);
        }
    }
}
