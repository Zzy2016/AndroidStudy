package com.huidr.HuiDrDoctor.fragment;

import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import androidx.annotation.Nullable;


import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.RadioButton;

import com.google.android.material.tabs.TabLayout;
import com.google.gson.Gson;
import com.huidr.HuiDrDoctor.SearchResult.HomeSearchActivity;
import com.huidr.HuiDrDoctor.activity.QuestionListActivity;
import com.huidr.HuiDrDoctor.activity.WebActivity;
import com.huidr.HuiDrDoctor.activity.main.Consult.utils.PostAndGet;
import com.huidr.HuiDrDoctor.content_fragment.ConListFragment;
import com.huidr.HuiDrDoctor.content_fragment.MsgListFragment;
import com.huidr.HuiDrDoctor.customview.ScrollPageView;
import com.huidr.HuiDrDoctor.debug.BuildConfig;
import com.huidr.HuiDrDoctor.debug.R;
import com.huidr.HuiDrDoctor.module.home.BannerModel;
import com.huidr.HuiDrDoctor.module.home.NewMessageModel;
import com.huidr.HuiDrDoctor.util.EventBusMessage;
import com.huidr.HuiDrDoctor.util.GlideImageLoader;
import com.huidr.HuiDrDoctor.util.ModifyDrawable;
import com.huidr.HuiDrDoctor.util.MulityClickUtils;
import com.huidr.HuiDrDoctor.util.ThreadPoolManager;
import com.huidr.lib.commom.base.BaseFragment;
import com.tendcloud.tenddata.TCAgent;
import com.youth.banner.Banner;
import com.youth.banner.listener.OnBannerListener;

import org.greenrobot.eventbus.EventBus;
import org.greenrobot.eventbus.Subscribe;
import org.greenrobot.eventbus.ThreadMode;
import org.litepal.LitePal;

import java.io.File;
import java.io.FileOutputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.Timer;

import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentPagerAdapter;
import jiguang.chat.utils.oss.OssService;
import jiguang.chat.utils.oss.SharedPreferenciesUtil;


/**
 * TCAgent.onEvent(this, "咨询中咨询状态点击次数", "咨询中咨询状态点击次数");
 */
public class MessageFragment extends BaseFragment implements View.OnClickListener {


    private Context context;

    private RadioButton radioButton1, radioButton2, radioButton3, radioButton4;
    private ImageView imageSearch;

    private TabLayout tabTitle;
    private ScrollPageView listViewPager;//列表viewPager
    private List<Fragment> fragments;
    private List<String> titles;
    private ListFragmentAdapter adapter;  //消息 图文咨询fragment

    private Gson gson;

    private BannerModel bannerModel;
    private List<BannerModel.RetValueBean> bannerSource;
    private List<ImageView> imageViewList;
    private OssService ossService;
    private Timer timer;

    private Banner banner;

    private long lastClick1 = 0;
    private long lastClick2 = 0;
    private long lastClick3 = 0;
    private long lastClick4 = 0;

    private int currentFragmentPosition = 0;

    private ImageView msgNoticeQue;
    private boolean showNotice;

    @Override
    protected void initData() {
        bannerModel = new BannerModel();
        bannerSource = new ArrayList<>();
        gson = new Gson();
        titles = new ArrayList<>();
        titles.add("消息");
        titles.add("图文咨询");
        fragments = new ArrayList<>();
        fragments.add(new MsgListFragment());
        fragments.add(new ConListFragment());
        adapter = new ListFragmentAdapter(getChildFragmentManager(), fragments);
        ossService = new OssService(getContext());
        imageViewList = new ArrayList<>();

        showNotice = (boolean) SharedPreferenciesUtil.getData("showNotice", false);
    }


    /*
     * 初始化banner
     * */
    public void initViewPager() {

        List<String> list = new ArrayList<>();
        for (int i = 0; i < bannerSource.size(); i++) {
            File file = new File(context.getExternalFilesDir("").getAbsoluteFile() + "/banner/" + bannerSource.get(i).getShowPng());
            try {
                if (!file.getParentFile().exists()) {
                    file.getParentFile().mkdirs();
                }
                if (!file.exists()) {
                    file.createNewFile();
                    Bitmap bitmap = ossService.downImageSyc(bannerSource.get(i).getShowPng());
                    if (bitmap != null) {
                        bitmap.compress(Bitmap.CompressFormat.PNG, 100, new FileOutputStream(file));
                    }
                } else {

                }

            } catch (Exception e) {

            }
            list.add(file.getAbsolutePath());
        }

        banner.setImages(list);
        banner.setImageLoader(new GlideImageLoader());
        banner.setOnBannerListener(new OnBannerListener() {
            @Override
            public void OnBannerClick(int position) {
                if (MulityClickUtils.isFastClick()) {
                    Intent intent1 = new Intent(getActivity(), WebActivity.class);
                    Bundle bundle = new Bundle();
                    bundle.putString("url", bannerSource.get(position).getJumpUrl());
                    intent1.putExtras(bundle);
                    startActivity(intent1);
                }
            }
        });
        banner.start();
    }


    public void initViewPager1() {
        List list = new ArrayList();
        list.add("");
        banner.setImages(list);
        banner.setImageLoader(new GlideImageLoader());
        banner.start();
    }


    @Override
    protected void findView(View parent) {
        imageSearch = parent.findViewById(R.id.image_search);

        banner = parent.findViewById(R.id.banner);

        tabTitle = parent.findViewById(R.id.tab_title);
        listViewPager = (ScrollPageView) parent.findViewById(R.id.list_view_page);
        radioButton1 = parent.findViewById(R.id.image_pre);
        radioButton2 = parent.findViewById(R.id.image_que);
        radioButton3 = parent.findViewById(R.id.image_model);
        radioButton4 = parent.findViewById(R.id.image_cou);

        ModifyDrawable.reSize(radioButton1, 90);
        ModifyDrawable.reSize(radioButton2, 90);
        ModifyDrawable.reSize(radioButton3, 90);
        ModifyDrawable.reSize(radioButton4, 90);

        radioButton1.setOnClickListener(radioOnClick);
        radioButton2.setOnClickListener(toQue);
        radioButton3.setOnClickListener(radioOnClick);
        radioButton4.setOnClickListener(radioOnClick);

        imageSearch.setOnClickListener(this);

        listViewPager.setAdapter(adapter);

        currentFragmentPosition = (int) SharedPreferenciesUtil.getData("currentFragment", 0);
        listViewPager.setCurrentItem(currentFragmentPosition, false);


        listViewPager.setSlide(false);
        tabTitle.setupWithViewPager(listViewPager);
        tabTitle.addOnTabSelectedListener(new TabLayout.OnTabSelectedListener() {
            @Override
            public void onTabSelected(TabLayout.Tab tab) {
                if (tab.getText().toString().equals("消息")) {
                    currentFragmentPosition = 0;
                    listViewPager.setCurrentItem(0, false);
                } else {
                    currentFragmentPosition = 1;
                    listViewPager.setCurrentItem(1, false);
                }
            }

            @Override
            public void onTabUnselected(TabLayout.Tab tab) {

            }

            @Override
            public void onTabReselected(TabLayout.Tab tab) {

            }
        });

        msgNoticeQue = parent.findViewById(R.id.img_notice_que);


        if (showNotice) {
            msgNoticeQue.setVisibility(View.VISIBLE);
        } else {
            msgNoticeQue.setVisibility(View.GONE);
        }
    }

    /*
     * 功能区点击事件
     * */
    private View.OnClickListener radioOnClick = new View.OnClickListener() {
        @Override
        public void onClick(View v) {

            Intent intent = new Intent(getActivity(), WebActivity.class);
            Bundle bundle = new Bundle();
            long currentClick = System.currentTimeMillis();
            switch (v.getId()) {
                case R.id.image_pre:
                    if (currentClick - lastClick1 > 1000) {
                        TCAgent.onEvent(getContext(), "用户使用生存预测的次数", "用户使用生存预测的次数");
                        bundle.putString("url", "hcc_PredictionSurvival.html");
                        lastClick1 = currentClick;
                    }
                    break;
//                case R.id.image_que:
//                    if (currentClick - lastClick2 > 1000) {
//                        TCAgent.onEvent(getContext(), "用户使用一问一答的次数 ", "用户使用一问一答的次数 ");
////                    bundle.putString("url", "");
//                        Toast.getInstance(getContext()).show("功能尚未开放！", 500);
//                        lastClick2 = currentClick;
//                    }
//                    break;
                case R.id.image_model:
                    if (currentClick - lastClick3 > 1000) {
                        TCAgent.onEvent(getContext(), "用户使用随访模板的次数", "用户使用随访模板的次数");
                        bundle.putString("url", "followUp_ModuleList.html");
                        lastClick3 = currentClick;
                    }
                    break;
                case R.id.image_cou:
                    if (currentClick - lastClick4 > 1000) {
                        TCAgent.onEvent(getContext(), "用户使用咨询设置的次数 ", "用户使用咨询设置的次数 ");
                        bundle.putString("url", "consultation.html");
                        lastClick4 = currentClick;
                    }
                    break;
            }
            if (bundle.size() != 0) {
                intent.putExtras(bundle);
                startActivity(intent);
            }
        }
    };

    public View.OnClickListener toQue = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            if (v.getId() == R.id.image_que) {
                SharedPreferenciesUtil.putData("showNotice", false);
                if (MulityClickUtils.isFastClick()) {
                    if (msgNoticeQue.getVisibility() == View.VISIBLE) {
                        msgNoticeQue.setVisibility(View.GONE);

//                        SharedPreferenciesUtil.putData("showNotice", false);
                    }
                    Intent intent = new Intent(getContext(), QuestionListActivity.class);
                    startActivity(intent);
                }
            }
        }
    };

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        context = getActivity();
        EventBus.getDefault().register(this);
    }

    @Override
    public void onResume() {
        super.onResume();
        getBanner();
        getAllSysMessage();
    }

    /*
     * 点击事件
     *
     * 搜索    *
     *
     * */
    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.image_search:
                if (MulityClickUtils.isFastClick()) {
//                    Intent intent = new Intent(getActivity(), SearchActivity.class);
//                    Intent intent = new Intent(getActivity(), SearchActivityNew.class);
                    Intent intent = new Intent(getActivity(), HomeSearchActivity.class);
                    startActivity(intent);
                }
                break;
        }
    }

    @Subscribe(threadMode = ThreadMode.MAIN)
    public void onEvent(EventBusMessage message) {
        Log.e("收到消息—Main", message.message);
        if (message.message.equals("show_icon")) {
            msgNoticeQue.setVisibility(View.VISIBLE);
            showNotice = true;
            SharedPreferenciesUtil.putData("showNotice", true);
        }
    }


    @Override
    public void onDestroy() {
        super.onDestroy();
        EventBus.getDefault().unregister(this);
    }

    @Override
    protected View setContentView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_message, container, false);
        return view;
    }


    /*
     *列表 ViewPager  系统消息 图文咨询
     */
    private class ListFragmentAdapter extends FragmentPagerAdapter {

        List<Fragment> fragments;

        public ListFragmentAdapter(FragmentManager fm, List<Fragment> fragments) {
            super(fm);
            this.fragments = fragments;
        }

        @Override
        public Fragment getItem(int i) {
            return fragments.get(i);
        }

        @Override
        public int getCount() {
            return fragments.size();
        }

        @Nullable
        @Override
        public CharSequence getPageTitle(int position) {
            return titles.get(position);
        }
    }


    /*
     * 0  图文开启查询成功的时候
     * 1  图文开启查询失败的时候
     * 图文咨询是否开启查询失败默认未开启
     *
     *
     * 2  banner加载成功
     *
     * 3 banner加载Shibai
     *
     * */
    private Handler handler = new Handler() {
        @Override
        public void handleMessage(Message msg) {
            super.handleMessage(msg);
            switch (msg.what) {

                case 2:
                    initViewPager();
                    break;

                case 3:
                    initViewPager1();
                    break;
            }
        }
    };


    //    获取banner
    public void getBanner() {
        ThreadPoolManager.getInstance().execute(new Runnable() {
            @Override
            public void run() {
                String path = BuildConfig.baseUrl + "patient/HomePage/getDoctorHomePagePng?position=1";
                String result = PostAndGet.doGetHttp(path);

                if (result.equals("网络异常")) {
                    handler.sendEmptyMessage(3);
                } else {
                    bannerModel = gson.fromJson(result, BannerModel.class);
                    if (bannerModel.getStatus() == 0) {
                        bannerSource = bannerModel.getRetValue();
                        handler.sendEmptyMessage(2);
                    } else {
                        handler.sendEmptyMessage(3);
                    }
                }
            }
        });
    }

    //页面不可见时保存当前显示Fragment index 下次打开还是显示当前Fragment
    @Override
    public void onStop() {
        super.onStop();
        if (timer != null) {
            timer.cancel();
        }
        SharedPreferenciesUtil.putData("currentFragment", currentFragmentPosition);

    }

    public void getAllSysMessage() {

        ThreadPoolManager.getInstance().execute(new Runnable() {
            @Override
            public void run() {
                List<NewMessageModel> allMessageList = LitePal.findAll(NewMessageModel.class);

                for (int i = 0; i < allMessageList.size(); i++) {
                    if (allMessageList.get(i).getType().equals("AskAnswersPlaceOrder") && allMessageList.get(i).isSaved() == false) {
                        msgNoticeQue.post(new Runnable() {
                            @Override
                            public void run() {
                                msgNoticeQue.setVisibility(View.VISIBLE);
                            }
                        });
                        break;
                    }
                }
            }
        });


    }

}
