package com.huidr.HuiDrDoctor.fragment;

import android.content.Intent;
import android.os.Bundle;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.RadioGroup;

import com.huidr.HuiDrDoctor.SearchResult.HomeSearchActivity;
import com.huidr.HuiDrDoctor.contact_fragment.ApplyFragment;
import com.huidr.HuiDrDoctor.contact_fragment.CoopFragment;
import com.huidr.HuiDrDoctor.contact_fragment.NewConversionFragment;
import com.huidr.HuiDrDoctor.contact_fragment.NewCotractFragment;
import com.huidr.HuiDrDoctor.debug.R;
import com.huidr.HuiDrDoctor.util.LogUtil;
import com.huidr.HuiDrDoctor.util.ModifyDrawable;
import com.huidr.HuiDrDoctor.util.MulityClickUtils;
import com.huidr.lib.commom.base.BaseFragment;
import com.tendcloud.tenddata.TCAgent;

import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;
import jiguang.chat.utils.oss.SharedPreferenciesUtil;


//    ConversationListFragment   最近查看    会话列表
//    ContactsFragment           全部联系人   好友列表
//    ApplyFragment             申请/添加
//    CoopFragment               协同医生
//  personal.html?id=140839医生信息页
public class DoctorFragment extends BaseFragment implements View.OnClickListener {





    private RadioGroup radioGroup;
    private RadioButton radio1, radio2, radio3, radio4;

    private ImageView imgSearch;

    private FragmentManager fragmentManager;
    private FragmentTransaction fragmentTransaction;

    int currentPage = 0;

    @Override
    protected void initData() {

    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

    }

    @Override
    protected View setContentView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_doctor, container, false);
        return view;
    }

    @Override
    public void onStop() {
        super.onStop();
        LogUtil.e("联系人页", currentPage + "");
        SharedPreferenciesUtil.putData("friendIndex", currentPage);
    }

    @Override
    protected void findView(View parent) {


        if (getArguments().getInt("key") >= 4) {
            currentPage = (int) SharedPreferenciesUtil.getData("friendIndex", 0);
        } else {
            currentPage = getArguments().getInt("key");
        }
        LogUtil.e("医生", getArguments().getInt("key") + "  " + currentPage);

        imgSearch = parent.findViewById(R.id.image_search);
        imgSearch.setOnClickListener(this);

        initListSelect(parent); //显示列表刷新


        switch (currentPage) {
            case 0:
                radio1.setChecked(true);
                break;
            case 1:
                radio2.setChecked(true);
                break;
            case 2:
                radio3.setChecked(true);
                break;
            case 3:
                radio4.setChecked(true);
                break;
        }

        switchPage(currentPage);

    }


    //  列表选择
    public void initListSelect(View parent) {

        radioGroup = parent.findViewById(R.id.radio_group);
        radio1 = parent.findViewById(R.id.radio1);
        radio2 = parent.findViewById(R.id.radio2);
        radio3 = parent.findViewById(R.id.radio3);
        radio4 = parent.findViewById(R.id.radio4);
        ModifyDrawable.reSize(radio1, 90);
        ModifyDrawable.reSize(radio2, 90);
        ModifyDrawable.reSize(radio3, 90);
        ModifyDrawable.reSize(radio4, 90);

        radioGroup.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {
                switch (checkedId) {
                    case R.id.radio1:
                        currentPage = 0;
                        break;
                    case R.id.radio2:
                        currentPage = 1;
                        break;
                    case R.id.radio3:
                        currentPage = 2;
                        break;
                    case R.id.radio4:
                        currentPage = 3;
                        break;
                }
                switchPage(currentPage);
            }
        });

    }


    public void switchPage(int index) {
        fragmentManager = getChildFragmentManager();
        fragmentTransaction = fragmentManager.beginTransaction();
        switch (index) {
            case 0:

                TCAgent.onEvent(getContext(), "联系人全部医生的按钮点击次数", "联系人全部医生的按钮点击次数");
                fragmentTransaction.replace(R.id.fl_content, new NewCotractFragment());
                break;
            case 1:

                TCAgent.onEvent(getContext(), "联系人协同医生的按钮点击次数", "联系人协同医生的按钮点击次数");
                fragmentTransaction.replace(R.id.fl_content, new CoopFragment());
                break;
            case 2:
                TCAgent.onEvent(getContext(), "联系人最近查看的按钮点击次数 ", "联系人最近查看的按钮点击次数 ");
                fragmentTransaction.replace(R.id.fl_content, new NewConversionFragment());
                break;
            case 3:
                TCAgent.onEvent(getContext(), "联系人申请/添加的按钮点击次数", "联系人申请/添加的按钮点击次数");
                fragmentTransaction.replace(R.id.fl_content, new ApplyFragment());
                break;
        }
        fragmentTransaction.commit();
    }

    //    显示列表
// recentContact
// withContact
// applyContact
// allContact
    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.image_search:
                if (MulityClickUtils.isFastClick()) {
//                    Intent intent = new Intent(getContext(), ContractSearchActivity.class);
                    Intent intent = new Intent(getContext(), HomeSearchActivity.class);
                    startActivity(intent);
                }
                break;
        }
    }
}
