package com.huidr.HuiDrDoctor.module.home;

import java.util.List;

/**
 * @author: Administrator
 * @date: 2019-11-22
 */
public class VisitModel {


    /**
     * status : 0
     * page : 1
     * totalPage : 61
     * retValue : [{"id":1542,"hospitalId":8177,"deptId":71,"disease":"肝切除","doctorId":100137,"patientId":52366,"patientName":"付丹","solutionId":230,"solutionName":"肝切除模板","currentTimes":8,"stage":2,"lastVisitingDate":"2019-06-03 00:00:00","recentSuccessVisitingDate":"2019-04-11 00:00:00","recentSuccessNextVisitingDate":"2019-12-03 00:00:00","recentVisitingDate":"2019-12-03 00:00:00","ignore":false,"isFollow":false,"admitNo":"992499"},{"id":48,"hospitalId":8177,"deptId":71,"disease":"肝切除","doctorId":100137,"patientId":51748,"patientName":"杨正平","solutionId":230,"solutionName":"肝切除模板","currentTimes":8,"stage":2,"lastVisitingDate":"2019-06-01 00:00:00","recentSuccessVisitingDate":"2019-04-04 00:00:00","recentSuccessNextVisitingDate":"2019-12-01 00:00:00","recentVisitingDate":"2019-12-01 00:00:00","ignore":false,"isFollow":false,"admitNo":"1007446"},{"id":3777,"hospitalId":8177,"deptId":71,"disease":"肝切除","doctorId":100137,"patientId":51311,"patientName":"杨伟海","solutionId":230,"solutionName":"肝切除模板","currentTimes":8,"stage":2,"lastVisitingDate":"2019-05-31 00:00:00","recentSuccessVisitingDate":"2019-04-01 00:00:00","recentSuccessNextVisitingDate":"2019-11-30 00:00:00","recentVisitingDate":"2019-11-30 00:00:00","ignore":false,"isFollow":true,"admitNo":"918626"},{"id":1850,"hospitalId":8177,"deptId":71,"disease":"肝切除","doctorId":100137,"patientId":52504,"patientName":"王晓阳","solutionId":230,"solutionName":"肝切除模板","currentTimes":8,"stage":2,"lastVisitingDate":"2019-05-18 00:00:00","recentSuccessVisitingDate":"2019-03-06 00:00:00","recentSuccessNextVisitingDate":"2019-11-17 00:00:00","recentVisitingDate":"2019-11-17 00:00:00","ignore":false,"isFollow":false,"admitNo":"1003855"},{"id":1617,"hospitalId":8177,"deptId":71,"disease":"肝切除","doctorId":100137,"patientId":52400,"patientName":"黄三见","solutionId":230,"solutionName":"肝切除模板","currentTimes":8,"stage":2,"lastVisitingDate":"2019-05-18 00:00:00","recentSuccessVisitingDate":"2019-04-17 00:00:00","recentSuccessNextVisitingDate":"2019-11-17 00:00:00","recentVisitingDate":"2019-11-17 00:00:00","ignore":false,"isFollow":false,"admitNo":"1004244"},{"id":228,"hospitalId":8177,"deptId":71,"disease":"肝切除","doctorId":100137,"patientId":51849,"patientName":"叶永琴","solutionId":230,"solutionName":"肝切除模板","currentTimes":8,"stage":2,"lastVisitingDate":"2019-05-03 00:00:00","recentSuccessVisitingDate":"2019-03-04 00:00:00","recentSuccessNextVisitingDate":"2019-11-02 00:00:00","recentVisitingDate":"2019-11-02 00:00:00","ignore":false,"isFollow":true,"admitNo":"990430"},{"id":4559,"hospitalId":8177,"deptId":71,"disease":"肝切除","doctorId":100137,"patientId":51493,"patientName":"路振喜","solutionId":231,"solutionName":"肝切除模板","currentTimes":0,"stage":3,"lastVisitingDate":"2019-04-24 00:00:00","recentSuccessVisitingDate":"2019-03-13 00:00:00","recentSuccessNextVisitingDate":"2019-10-24 00:00:00","recentVisitingDate":"2019-10-24 00:00:00","ignore":false,"isFollow":true,"admitNo":"963695"},{"id":3460,"hospitalId":8177,"deptId":71,"disease":"肝切除","doctorId":100137,"patientId":51235,"patientName":"李杏宝","solutionId":230,"solutionName":"肝切除模板","currentTimes":5,"stage":2,"lastVisitingDate":"2019-06-25 00:00:00","recentSuccessVisitingDate":"2019-04-12 00:00:00","recentSuccessNextVisitingDate":"2019-09-26 00:00:00","recentVisitingDate":"2019-09-26 00:00:00","ignore":false,"isFollow":false,"admitNo":"1061485"},{"id":5091,"hospitalId":8177,"deptId":71,"disease":"肝切除","doctorId":100137,"patientId":51597,"patientName":"潘秀芬","solutionId":231,"solutionName":"肝切除模板","currentTimes":1,"stage":3,"lastVisitingDate":"2019-03-27 00:00:00","recentSuccessVisitingDate":"2019-03-27 00:00:00","recentSuccessNextVisitingDate":"2019-09-26 00:00:00","recentVisitingDate":"2019-09-26 00:00:00","ignore":false,"isFollow":true,"admitNo":"927017"},{"id":3960,"hospitalId":8177,"deptId":71,"disease":"肝切除","doctorId":100137,"patientId":51357,"patientName":"黄荣亮","solutionId":230,"solutionName":"肝切除模板","currentTimes":7,"stage":2,"lastVisitingDate":"2019-06-21 00:00:00","recentSuccessVisitingDate":"2019-04-02 00:00:00","recentSuccessNextVisitingDate":"2019-09-22 00:00:00","recentVisitingDate":"2019-09-22 00:00:00","ignore":false,"isFollow":false,"admitNo":"1026595"},{"id":5251,"hospitalId":8177,"deptId":71,"disease":"肝切除","doctorId":100137,"patientId":51627,"patientName":"万月兰","solutionId":230,"solutionName":"肝切除模板","currentTimes":4,"stage":2,"lastVisitingDate":"2019-06-17 00:00:00","recentSuccessVisitingDate":"2019-04-22 00:00:00","recentSuccessNextVisitingDate":"2019-09-18 00:00:00","recentVisitingDate":"2019-09-18 00:00:00","ignore":false,"isFollow":false,"admitNo":"1089508"},{"id":1026,"hospitalId":8177,"deptId":71,"disease":"肝切除","doctorId":100137,"patientId":52186,"patientName":"杨佩江","solutionId":230,"solutionName":"肝切除模板","currentTimes":6,"stage":2,"lastVisitingDate":"2019-06-13 00:00:00","recentSuccessVisitingDate":"2019-04-15 00:00:00","recentSuccessNextVisitingDate":"2019-09-14 00:00:00","recentVisitingDate":"2019-09-14 00:00:00","ignore":false,"isFollow":false,"admitNo":"1047327"},{"id":1422,"hospitalId":8177,"deptId":71,"disease":"肝切除","doctorId":100137,"patientId":52313,"patientName":"乔惠明","solutionId":231,"solutionName":"肝切除模板","currentTimes":1,"stage":3,"lastVisitingDate":"2019-03-14 00:00:00","recentSuccessVisitingDate":"2019-01-07 00:00:00","recentSuccessNextVisitingDate":"2019-09-13 00:00:00","recentVisitingDate":"2019-09-13 00:00:00","ignore":false,"isFollow":false,"admitNo":"925351"},{"id":185,"hospitalId":8177,"deptId":71,"disease":"肝切除","doctorId":100137,"patientId":51837,"patientName":"姚建林","solutionId":230,"solutionName":"肝切除模板","currentTimes":6,"stage":2,"lastVisitingDate":"2019-06-06 00:00:00","recentSuccessVisitingDate":"2019-03-11 00:00:00","recentSuccessNextVisitingDate":"2019-09-07 00:00:00","recentVisitingDate":"2019-09-07 00:00:00","ignore":false,"isFollow":false,"admitNo":"1044539"},{"id":3580,"hospitalId":8177,"deptId":71,"disease":"肝切除","doctorId":100137,"patientId":51266,"patientName":"孙阳","solutionId":230,"solutionName":"肝切除模板","currentTimes":1,"stage":2,"lastVisitingDate":"2019-06-06 00:00:00","recentSuccessVisitingDate":"2019-04-04 00:00:00","recentSuccessNextVisitingDate":"2019-09-07 00:00:00","recentVisitingDate":"2019-09-07 00:00:00","ignore":false,"isFollow":false,"admitNo":"1138373"},{"id":3625,"hospitalId":8177,"deptId":71,"disease":"肝切除","doctorId":100137,"patientId":51277,"patientName":"陈福民","solutionId":230,"solutionName":"肝切除模板","currentTimes":7,"stage":2,"lastVisitingDate":"2019-06-05 00:00:00","recentSuccessVisitingDate":"2019-03-18 00:00:00","recentSuccessNextVisitingDate":"2019-09-06 00:00:00","recentVisitingDate":"2019-09-06 00:00:00","ignore":false,"isFollow":false,"admitNo":"1025120"},{"id":288,"hospitalId":8177,"deptId":71,"disease":"肝切除","doctorId":100137,"patientId":51879,"patientName":"郑建淼","solutionId":231,"solutionName":"肝切除模板","currentTimes":0,"stage":3,"lastVisitingDate":"2019-02-26 00:00:00","recentSuccessVisitingDate":"2018-11-26 00:00:00","recentSuccessNextVisitingDate":"2019-08-28 00:00:00","recentVisitingDate":"2019-08-28 00:00:00","ignore":false,"isFollow":false,"admitNo":"952625"},{"id":1185,"hospitalId":8177,"deptId":71,"disease":"肝切除","doctorId":100137,"patientId":52233,"patientName":"蔡华海","solutionId":230,"solutionName":"肝切除模板","currentTimes":5,"stage":2,"lastVisitingDate":"2019-05-25 00:00:00","recentSuccessVisitingDate":"2019-03-13 00:00:00","recentSuccessNextVisitingDate":"2019-08-26 00:00:00","recentVisitingDate":"2019-08-26 00:00:00","ignore":false,"isFollow":false,"admitNo":"1058950"},{"id":251,"hospitalId":8177,"deptId":71,"disease":"肝切除","doctorId":100137,"patientId":51863,"patientName":"吴金云","solutionId":230,"solutionName":"肝切除模板","currentTimes":2,"stage":2,"lastVisitingDate":"2019-05-22 00:00:00","recentSuccessVisitingDate":"2019-03-22 00:00:00","recentSuccessNextVisitingDate":"2019-08-23 00:00:00","recentVisitingDate":"2019-08-23 00:00:00","ignore":false,"isFollow":false,"admitNo":"1123628"},{"id":4031,"hospitalId":8177,"deptId":71,"disease":"肝切除","doctorId":100137,"patientId":51372,"patientName":"张启龙","solutionId":230,"solutionName":"肝切除模板","currentTimes":0,"stage":2,"lastVisitingDate":"2019-05-15 00:00:00","recentSuccessVisitingDate":"2019-02-24 00:00:00","recentSuccessNextVisitingDate":"2019-08-16 00:00:00","recentVisitingDate":"2019-08-16 00:00:00","ignore":false,"isFollow":false,"admitNo":"1159252"}]
     */

    private int status;
    private int page;
    private int totalPage;
    private List<RetValueBean> retValue;

    public int getStatus() {
        return status;
    }

    public void setStatus(int status) {
        this.status = status;
    }

    public int getPage() {
        return page;
    }

    public void setPage(int page) {
        this.page = page;
    }

    public int getTotalPage() {
        return totalPage;
    }

    public void setTotalPage(int totalPage) {
        this.totalPage = totalPage;
    }

    public List<RetValueBean> getRetValue() {
        return retValue;
    }

    public void setRetValue(List<RetValueBean> retValue) {
        this.retValue = retValue;
    }

    public static class RetValueBean {
        /**
         * id : 1542
         * hospitalId : 8177
         * deptId : 71
         * disease : 肝切除
         * doctorId : 100137
         * patientId : 52366
         * patientName : 付丹
         * solutionId : 230
         * solutionName : 肝切除模板
         * currentTimes : 8
         * stage : 2
         * lastVisitingDate : 2019-06-03 00:00:00
         * recentSuccessVisitingDate : 2019-04-11 00:00:00
         * recentSuccessNextVisitingDate : 2019-12-03 00:00:00
         * recentVisitingDate : 2019-12-03 00:00:00
         * ignore : false
         * isFollow : false
         * admitNo : 992499
         */

        private int id;
        private int hospitalId;
        private int deptId;
        private String disease;
        private int doctorId;
        private int patientId;
        private String patientName;
        private int solutionId;
        private String solutionName;
        private int currentTimes;
        private int stage;
        private String lastVisitingDate;
        private String recentSuccessVisitingDate;
        private String recentSuccessNextVisitingDate;
        private String recentVisitingDate;
        private boolean ignore;
        private boolean isFollow;
        private String admitNo;

        //
        private int groupId;
        private String groupImage;
        private String groupName;
        private String patientNum;

        public int getGroupId() {
            return groupId;
        }

        public void setGroupId(int groupId) {
            this.groupId = groupId;
        }

        public String getGroupImage() {
            return groupImage;
        }

        public void setGroupImage(String groupImage) {
            this.groupImage = groupImage;
        }

        public String getGroupName() {
            return groupName;
        }

        public void setGroupName(String groupName) {
            this.groupName = groupName;
        }

        public String getPatientNum() {
            return patientNum;
        }

        public void setPatientNum(String patientNum) {
            this.patientNum = patientNum;
        }

        public String getCreateTime() {
            return createTime;
        }

        public void setCreateTime(String createTime) {
            this.createTime = createTime;
        }

        private String createTime;


        public int getId() {
            return id;
        }

        public void setId(int id) {
            this.id = id;
        }

        public int getHospitalId() {
            return hospitalId;
        }

        public void setHospitalId(int hospitalId) {
            this.hospitalId = hospitalId;
        }

        public int getDeptId() {
            return deptId;
        }

        public void setDeptId(int deptId) {
            this.deptId = deptId;
        }

        public String getDisease() {
            return disease;
        }

        public void setDisease(String disease) {
            this.disease = disease;
        }

        public int getDoctorId() {
            return doctorId;
        }

        public void setDoctorId(int doctorId) {
            this.doctorId = doctorId;
        }

        public int getPatientId() {
            return patientId;
        }

        public void setPatientId(int patientId) {
            this.patientId = patientId;
        }

        public String getPatientName() {
            return patientName;
        }

        public void setPatientName(String patientName) {
            this.patientName = patientName;
        }

        public int getSolutionId() {
            return solutionId;
        }

        public void setSolutionId(int solutionId) {
            this.solutionId = solutionId;
        }

        public String getSolutionName() {
            return solutionName;
        }

        public void setSolutionName(String solutionName) {
            this.solutionName = solutionName;
        }

        public int getCurrentTimes() {
            return currentTimes;
        }

        public void setCurrentTimes(int currentTimes) {
            this.currentTimes = currentTimes;
        }

        public int getStage() {
            return stage;
        }

        public void setStage(int stage) {
            this.stage = stage;
        }

        public String getLastVisitingDate() {
            return lastVisitingDate;
        }

        public void setLastVisitingDate(String lastVisitingDate) {
            this.lastVisitingDate = lastVisitingDate;
        }

        public String getRecentSuccessVisitingDate() {
            return recentSuccessVisitingDate;
        }

        public void setRecentSuccessVisitingDate(String recentSuccessVisitingDate) {
            this.recentSuccessVisitingDate = recentSuccessVisitingDate;
        }

        public String getRecentSuccessNextVisitingDate() {
            return recentSuccessNextVisitingDate;
        }

        public void setRecentSuccessNextVisitingDate(String recentSuccessNextVisitingDate) {
            this.recentSuccessNextVisitingDate = recentSuccessNextVisitingDate;
        }

        public String getRecentVisitingDate() {
            return recentVisitingDate;
        }

        public void setRecentVisitingDate(String recentVisitingDate) {
            this.recentVisitingDate = recentVisitingDate;
        }

        public boolean isIgnore() {
            return ignore;
        }

        public void setIgnore(boolean ignore) {
            this.ignore = ignore;
        }

        public boolean isIsFollow() {
            return isFollow;
        }

        public void setIsFollow(boolean isFollow) {
            this.isFollow = isFollow;
        }

        public String getAdmitNo() {
            return admitNo;
        }

        public void setAdmitNo(String admitNo) {
            this.admitNo = admitNo;
        }
    }
}
