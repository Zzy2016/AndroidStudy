package com.huidr.HuiDrDoctor.activity.main.Consult.fragment;

import android.content.Context;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import androidx.annotation.NonNull;
;
import android.text.Editable;
import android.text.Html;
import android.text.TextWatcher;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.ajguan.library.EasyRefreshLayout;
import com.alibaba.fastjson.JSONObject;
import com.chad.library.adapter.base.BaseQuickAdapter;
import com.chad.library.adapter.base.BaseViewHolder;
import com.google.gson.Gson;
import com.huidr.HuiDrDoctor.activity.main.Consult.Model.AdviceList;
import com.huidr.HuiDrDoctor.activity.main.Consult.utils.PostAndGet;
import com.huidr.HuiDrDoctor.debug.BuildConfig;
import com.huidr.HuiDrDoctor.debug.R;
import com.huidr.HuiDrDoctor.util.LogUtil;
import com.huidr.HuiDrDoctor.util.ThreadPoolManager;
import com.scwang.smartrefresh.layout.SmartRefreshLayout;
import com.scwang.smartrefresh.layout.api.RefreshLayout;
import com.scwang.smartrefresh.layout.listener.OnLoadMoreListener;
import com.scwang.smartrefresh.layout.listener.OnRefreshListener;

import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.List;

import androidx.annotation.Nullable;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import jiguang.chat.activity.fragment.BaseFragment;
import jiguang.chat.utils.oss.SharedPreferenciesUtil;

/**
 * 已结束 咨询记录
 * <p>
 * 显示已经结束的咨询
 * <p>
 * <p>
 * 患者姓名搜索
 */
public class CompleteFragment extends BaseFragment implements View.OnClickListener, EasyRefreshLayout.EasyEvent {

    private Button btnSearch;
    private EditText etInput;
    private SmartRefreshLayout erl;
    private RecyclerView rcList3;

    private int currentPage = 1;
    private int totalPage;
    private List<AdviceList.RetValueBean> allList;//所有建议
    private List<AdviceList.RetValueBean> pageList;//分页建议

    private AdviceAdapter adviceAdapter;

    private RelativeLayout rlEmpty, rlError;
    String doctorId;
    TextView tvEmpty;
    boolean showSearch = false;//显示搜索

    /*
     * 1  加载更多
     * 0  刷新
     * 3  页面第一次打开
     * 4  搜索
     *
     * 100  空态页
     * */
    private Handler handler = new Handler() {
        @Override
        public void handleMessage(Message msg) {
            super.handleMessage(msg);
            switch (msg.what) {
                case 0:
                    adviceAdapter.getData().clear();
                    adviceAdapter.getData().addAll(pageList);
                    adviceAdapter.notifyDataSetChanged();
                    if (pageList.size() == 0) {
                        erl.setVisibility(View.GONE);
                        rlEmpty.setVisibility(View.VISIBLE);
                        tvEmpty.setText("暂无咨询记录哦");
                    } else {
                        erl.setVisibility(View.VISIBLE);
                        rlEmpty.setVisibility(View.GONE);
                    }
                    erl.finishRefresh();
                    break;
                case 1:
                    int position = adviceAdapter.getData().size();
                    adviceAdapter.getData().addAll(pageList);
                    adviceAdapter.notifyItemRangeChanged(position + 1, adviceAdapter.getData().size() - 1);
                    erl.finishLoadMore();
                    if ((adviceAdapter.getData().size() - (position - 1)) > 2) {
                        rcList3.scrollToPosition(position + 1);
                    } else {
                        rcList3.scrollToPosition(adviceAdapter.getData().size() - 1);
                    }

                    break;
                case 3:
                    adviceAdapter.getData().clear();
                    adviceAdapter.getData().addAll(pageList);
                    adviceAdapter.notifyDataSetChanged();
                    if (pageList.size() == 0) {
                        erl.setVisibility(View.GONE);
                        rlEmpty.setVisibility(View.VISIBLE);
                        tvEmpty.setText("暂无咨询记录哦");
                    } else {
                        erl.setVisibility(View.VISIBLE);
                        rlEmpty.setVisibility(View.GONE);
                    }
                    break;

                case 4:  //显示搜索
                    adviceAdapter.getData().clear();
                    adviceAdapter.getData().addAll(pageList);
                    adviceAdapter.notifyDataSetChanged();

                    if (pageList.size() == 0) {
                        erl.setVisibility(View.GONE);
                        rlEmpty.setVisibility(View.VISIBLE);
                        if (showSearch) {
                            tvEmpty.setText("搜索为空");
                        }
                    } else {
                        erl.setVisibility(View.VISIBLE);
                        rlEmpty.setVisibility(View.GONE);
                    }

                    break;

                case 100:  //空
                    erl.setVisibility(View.GONE);
                    rlEmpty.setVisibility(View.VISIBLE);
                    if (showSearch) {
                        tvEmpty.setText("搜索为空");
                    } else {
                        tvEmpty.setText("暂无咨询记录哦");
                    }

                    break;
                case 101:  //服务器内部错误
                    erl.setVisibility(View.GONE);
                    rlError.setVisibility(View.VISIBLE);
                    break;
            }
        }
    };

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_complete, container, false);
        initDate();
        initView(view);
        return view;
    }

    public void initView(View view) {
        doctorId = (String) SharedPreferenciesUtil.getData("id", "");
        btnSearch = (Button) view.findViewById(R.id.btn_search);
        etInput = (EditText) view.findViewById(R.id.et_input);
        erl = (SmartRefreshLayout) view.findViewById(R.id.erl3);
        rcList3 = (RecyclerView) view.findViewById(R.id.rv_list3);
        rlEmpty = (RelativeLayout) view.findViewById(R.id.rl_empty);
        rlError = (RelativeLayout) view.findViewById(R.id.rl_error);
        tvEmpty = (TextView) view.findViewById(R.id.tv_empty);
        btnSearch.setOnClickListener(this);
//        erl.addEasyEvent(this);


        erl.setOnRefreshListener(new OnRefreshListener() {
            @Override
            public void onRefresh(@NonNull RefreshLayout refreshLayout) {
                currentPage = 1;
                getAdviceByPage(1, 0);
            }
        });

        erl.setOnLoadMoreListener(new OnLoadMoreListener() {
            @Override
            public void onLoadMore(@NonNull RefreshLayout refreshLayout) {
                if (pageList.size() == 10 && currentPage <= totalPage - 1) {
                    currentPage += 1;
                    new Thread(new Runnable() {
                        @Override
                        public void run() {
                            getAdviceByPage(currentPage, 1);
                        }
                    }).start();
                } else {
                    erl.finishLoadMore();
                    Toast.makeText(getActivity(), "加载全部", Toast.LENGTH_SHORT).show();
                }
            }
        });

        rcList3.setAdapter(adviceAdapter);
        rcList3.setLayoutManager(new LinearLayoutManager(getContext()));
//        rcList3.setItemAnimator(null);


        etInput.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {
                LogUtil.e("是否搜索", showSearch + "");
                if (showSearch && (s.toString().length() == 0)) {
                    showSearch = false;
                    getAdviceByPage(1, 3);  //结束搜索
                }
            }
        });

        etInput.setOnEditorActionListener(new TextView.OnEditorActionListener() {
            @Override
            public boolean onEditorAction(TextView v, int actionId, KeyEvent event) {
                boolean resultBoolean = false;
                if (actionId == EditorInfo.IME_ACTION_SEARCH) {
                    if (etInput.getText().toString().length() == 0) {
                        Toast.makeText(getActivity(), "请输入患者姓名", Toast.LENGTH_SHORT).show();
                        resultBoolean = true;
//                        hideEk();
                    } else {
                        onClick(btnSearch);
//                        hideEk();
                        resultBoolean = false;
                    }

                }
                return resultBoolean;
            }
        });


    }

    public void initDate() {

        getAdviceByPage(1, 3);
        adviceAdapter = new AdviceAdapter(R.layout.item_consult_layout, null);
        allList = new ArrayList<>();
        pageList = new ArrayList<>();
        adviceAdapter.setNewData(allList);
//        adviceAdapter.setHasStableIds(true);
    }


    /*
     * 加载更多
     * */
    @Override
    public void onLoadMore() {
        LogUtil.e("当前", pageList.size() + "");

    }

    /*加载第一页
     * */
    @Override
    public void onRefreshing() {

    }


    /*
     * 搜索
     * */


    /*
    隐藏软件盘
    * */
    public void hideEk() {
        InputMethodManager imm = (InputMethodManager) getActivity().getSystemService(Context.INPUT_METHOD_SERVICE);
        imm.toggleSoftInput(0, InputMethodManager.HIDE_NOT_ALWAYS);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.btn_search:
                if (etInput.getText().toString().length() > 0) {
                    hideEk();
//                    Toast.makeText(getContext(), "开始搜索", Toast.LENGTH_SHORT).show();

                    ThreadPoolManager.getInstance().execute(new Runnable() {
                        @Override
                        public void run() {
                            JSONObject jsonObject = new JSONObject();
                            jsonObject.put("patientName", etInput.getText().toString());
                            jsonObject.put("doctorUid", doctorId);
                            jsonObject.put("pageSize", 1);
                            String result = PostAndGet.doHttpPost(BuildConfig.baseUrl + "consult/consult/getDoctorConsultSuggest", jsonObject);
                            Gson gson = new Gson();
                            AdviceList adviceList = gson.fromJson(result, AdviceList.class);
                            totalPage = adviceList.getTotalPage();
                            pageList.clear();
                            pageList = adviceList.getRetValue();
                            LogUtil.e("查询单个i建议", result);
                            Message message = new Message();
                            message.what = 4;
                            handler.sendMessage(message);
                            showSearch = true;
                        }
                    });

                } else {
                    Toast.makeText(getContext(), "请输入搜索", Toast.LENGTH_SHORT).show();
                }
                break;
//            case R.id.erl3:
//                hideEk();
//                break;
        }
    }

    /*
    page 页码、、
    indi 标示 0加载更多 1获取最新

    * getAdviceList
    *  "doctorUid":"100143",  医生Id
       "pageSize":""        页码

       http://192.168.1.183:86/consult/getDoctorConsultSuggest
    * */
    public void getAdviceByPage(final int page, final int indi) {
        new Thread(new Runnable() {
            @Override
            public void run() {
                JSONObject jsonObject = new JSONObject();
                String doctorId = (String) SharedPreferenciesUtil.getData("id", "");
                jsonObject.put("doctorUid", doctorId);
                jsonObject.put("pageSize", page);

                String result = PostAndGet.doHttpPost(BuildConfig.baseUrl + "consult/consult/getDoctorConsultSuggest", jsonObject);



                if (result.equals("")) {
                    Message message = new Message();
                    message.what = 100;
                    handler.sendMessage(message);
                } else if (result.contains("服务器内部错误")) {
                    Message message = new Message();
                    message.what = 101;
                    handler.sendMessage(message);
                } else {
                    Gson gson = new Gson();
                    AdviceList adviceList = gson.fromJson(result, AdviceList.class);
                    totalPage = adviceList.getTotalPage();
                    pageList.clear();
                    pageList = adviceList.getRetValue();
                    if (pageList.size() != 0) {
                        Message message = new Message();
                        message.what = indi;
                        handler.sendMessage(message);
                    } else {
                        Message message = new Message();
                        message.what = 100;
                        handler.sendMessage(message);
                    }
                }

            }
        }).start();
    }


    /*
     * 建议列表适配
     * */
    public class AdviceAdapter extends BaseQuickAdapter<AdviceList.RetValueBean, BaseViewHolder> {

        public AdviceAdapter(int layoutResId, @Nullable List<AdviceList.RetValueBean> data) {
            super(layoutResId, data);
        }

        @Override
        protected void convert(BaseViewHolder helper, AdviceList.RetValueBean item) {
            TextView tvName = helper.getView(R.id.tv_name);
            TextView tvRight = helper.getView(R.id.tv_right);
            TextView tvDesc = helper.getView(R.id.tv_desc);
            TextView tvPrice = helper.getView(R.id.tv_price);//咨询费用
            TextView tvTime = helper.getView(R.id.tv_time);//结束时间
            LogUtil.e("咨询价格", item.getMoney() + "");
            DecimalFormat df = new DecimalFormat("0.00");
            String priceStr = "咨询收入：<font color='#248cfa'>¥" + df.format((float) item.getMoney() / 100) + "</font>";
            tvRight.setText("已结束");
            tvName.setText(item.getPatientName());
            tvRight.setTextColor(getResources().getColor(R.color.font_dark));
            tvDesc.setText(item.getSuggest());
            tvPrice.setText(Html.fromHtml(priceStr));
            tvTime.setText("结束时间：" + item.getFinishTime());
            tvTime.setTextColor(getResources().getColor(R.color.endtime_color));
        }
    }

}
