package com.huidr.HuiDrDoctor.activity.main.Consult.Model;

import java.util.List;

public class OrderDetail {

    /**
     * doctorHeadImg : system/doctor/8177-71-13134.jpg
     * doctorHospital : 复旦大学附属中山医院
     * doctorId : 100143
     * doctorName : 测试肝肿瘤外科8
     * hospitalDepartment : 肝肿瘤外科
     * needHelp : 1测试肝肿瘤测试肝肿瘤测试肝肿瘤测试
     * patientHospital : 复旦大学附属中山医院
     * patientId : 45828
     * patientName : 周玉梅
     * pics : []
     * position : 住院医师
     */

    private String doctorHeadImg;
    private String doctorHospital;
    private int doctorId;
    private String doctorName;
    private String hospitalDepartment;
    private String needHelp;
    private String patientHospital;
    private int patientId;
    private String patientName;
    private String position;
    private List<?> pics;

    public String getDoctorHeadImg() {
        return doctorHeadImg;
    }

    public void setDoctorHeadImg(String doctorHeadImg) {
        this.doctorHeadImg = doctorHeadImg;
    }

    public String getDoctorHospital() {
        return doctorHospital;
    }

    public void setDoctorHospital(String doctorHospital) {
        this.doctorHospital = doctorHospital;
    }

    public int getDoctorId() {
        return doctorId;
    }

    public void setDoctorId(int doctorId) {
        this.doctorId = doctorId;
    }

    public String getDoctorName() {
        return doctorName;
    }

    public void setDoctorName(String doctorName) {
        this.doctorName = doctorName;
    }

    public String getHospitalDepartment() {
        return hospitalDepartment;
    }

    public void setHospitalDepartment(String hospitalDepartment) {
        this.hospitalDepartment = hospitalDepartment;
    }

    public String getNeedHelp() {
        return needHelp;
    }

    public void setNeedHelp(String needHelp) {
        this.needHelp = needHelp;
    }

    public String getPatientHospital() {
        return patientHospital;
    }

    public void setPatientHospital(String patientHospital) {
        this.patientHospital = patientHospital;
    }

    public int getPatientId() {
        return patientId;
    }

    public void setPatientId(int patientId) {
        this.patientId = patientId;
    }

    public String getPatientName() {
        return patientName;
    }

    public void setPatientName(String patientName) {
        this.patientName = patientName;
    }

    public String getPosition() {
        return position;
    }

    public void setPosition(String position) {
        this.position = position;
    }

    public List<?> getPics() {
        return pics;
    }

    public void setPics(List<?> pics) {
        this.pics = pics;
    }
}
