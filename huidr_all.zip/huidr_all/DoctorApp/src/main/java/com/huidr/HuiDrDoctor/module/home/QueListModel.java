package com.huidr.HuiDrDoctor.module.home;

import java.util.List;

/**
 * @author: Administrator
 * @date: 2020-04-15
 */
public class QueListModel {

    /**
     * status : 0
     * page : 1
     * totalPage : 1
     * retValue : [{"id":3375,"uid":100137,"chaseId":3346,"problemTitle":null,"problemContent":"傅大撒发啊书法大赛发大水发大水发撒发撒发射点","isHandle":null,"summitTime":1586853865000,"answerType":null,"userName":"周玉梅","userHospitalId":null,"userHospitalName":"复旦大学附属中山医院","userDepartmentId":null,"userDepartmentName":"肝肿瘤外科","userWardName":"原肝外科十七病区","userPrimaryPhysicianCode":null,"userPrimaryPhysicianName":null,"userAdmitNo":null,"hospitalId":null,"hospitalName":null,"departmentId":null,"departmentName":null,"doctorId":null,"doctorIcon":null,"doctorName":null,"doctorTitle":null,"replyTime":null,"isShow":null,"isFee":null,"diseasePicturePaths":null,"diseaseLabel":null,"otherLabel":null,"consultationDisease":null,"isOpenImage":null,"supplementInformation":null,"isAllowAppObtain":null,"answer":null},{"id":3367,"uid":100225,"chaseId":0,"problemTitle":null,"problemContent":"我有点肚子疼，哦多k？","isHandle":null,"summitTime":1578363831000,"answerType":null,"userName":"段玉梅","userHospitalId":null,"userHospitalName":"复旦大学附属中山医院","userDepartmentId":null,"userDepartmentName":"肝肿瘤外科","userWardName":"四十七病区","userPrimaryPhysicianCode":null,"userPrimaryPhysicianName":null,"userAdmitNo":null,"hospitalId":null,"hospitalName":null,"departmentId":null,"departmentName":null,"doctorId":null,"doctorIcon":null,"doctorName":null,"doctorTitle":null,"replyTime":null,"isShow":null,"isFee":null,"diseasePicturePaths":null,"diseaseLabel":null,"otherLabel":null,"consultationDisease":null,"isOpenImage":null,"supplementInformation":null,"isAllowAppObtain":null,"answer":null},{"id":3366,"uid":100225,"chaseId":0,"problemTitle":null,"problemContent":"哈哈哈哈哈哈哈哈哈哈哈哈哈哈","isHandle":null,"summitTime":1576722770000,"answerType":null,"userName":"段玉梅","userHospitalId":null,"userHospitalName":"复旦大学附属中山医院","userDepartmentId":null,"userDepartmentName":"肝肿瘤外科","userWardName":"四十七病区","userPrimaryPhysicianCode":null,"userPrimaryPhysicianName":null,"userAdmitNo":null,"hospitalId":null,"hospitalName":null,"departmentId":null,"departmentName":null,"doctorId":null,"doctorIcon":null,"doctorName":null,"doctorTitle":null,"replyTime":null,"isShow":null,"isFee":null,"diseasePicturePaths":null,"diseaseLabel":null,"otherLabel":null,"consultationDisease":null,"isOpenImage":null,"supplementInformation":null,"isAllowAppObtain":null,"answer":null},{"id":3365,"uid":100225,"chaseId":0,"problemTitle":null,"problemContent":"天啦啦啦啦啦啦啦啦啦啦","isHandle":null,"summitTime":1576722478000,"answerType":null,"userName":"段玉梅","userHospitalId":null,"userHospitalName":"复旦大学附属中山医院","userDepartmentId":null,"userDepartmentName":"肝肿瘤外科","userWardName":"四十七病区","userPrimaryPhysicianCode":null,"userPrimaryPhysicianName":null,"userAdmitNo":null,"hospitalId":null,"hospitalName":null,"departmentId":null,"departmentName":null,"doctorId":null,"doctorIcon":null,"doctorName":null,"doctorTitle":null,"replyTime":null,"isShow":null,"isFee":null,"diseasePicturePaths":null,"diseaseLabel":null,"otherLabel":null,"consultationDisease":null,"isOpenImage":null,"supplementInformation":null,"isAllowAppObtain":null,"answer":null},{"id":3364,"uid":100225,"chaseId":0,"problemTitle":null,"problemContent":"啦啦啦啦啦啦啦啦啦啦啦啦","isHandle":null,"summitTime":1576721640000,"answerType":null,"userName":"段玉梅","userHospitalId":null,"userHospitalName":"复旦大学附属中山医院","userDepartmentId":null,"userDepartmentName":"肝肿瘤外科","userWardName":"四十七病区","userPrimaryPhysicianCode":null,"userPrimaryPhysicianName":null,"userAdmitNo":null,"hospitalId":null,"hospitalName":null,"departmentId":null,"departmentName":null,"doctorId":null,"doctorIcon":null,"doctorName":null,"doctorTitle":null,"replyTime":null,"isShow":null,"isFee":null,"diseasePicturePaths":null,"diseaseLabel":null,"otherLabel":null,"consultationDisease":null,"isOpenImage":null,"supplementInformation":null,"isAllowAppObtain":null,"answer":null},{"id":3363,"uid":100225,"chaseId":0,"problemTitle":null,"problemContent":"啦啦啦啦啦啦啦啦啦啦","isHandle":null,"summitTime":1576719994000,"answerType":null,"userName":"段玉梅","userHospitalId":null,"userHospitalName":"复旦大学附属中山医院","userDepartmentId":null,"userDepartmentName":"肝肿瘤外科","userWardName":"四十七病区","userPrimaryPhysicianCode":null,"userPrimaryPhysicianName":null,"userAdmitNo":null,"hospitalId":null,"hospitalName":null,"departmentId":null,"departmentName":null,"doctorId":null,"doctorIcon":null,"doctorName":null,"doctorTitle":null,"replyTime":null,"isShow":null,"isFee":null,"diseasePicturePaths":null,"diseaseLabel":null,"otherLabel":null,"consultationDisease":null,"isOpenImage":null,"supplementInformation":null,"isAllowAppObtain":null,"answer":null},{"id":3360,"uid":100295,"chaseId":0,"problemTitle":null,"problemContent":"，在一起就好了！你是怎么回事！你是怎么回事！你是怎么回事！你是什么意思！你是怎么回的路上我还是有多爱你爱他就要你说了什么🤔！你是谁呀？我的手机📱？我也不知道怎么样才能让自己变成自己讨厌别人说别人坏话时间不够用就行哦！你","isHandle":null,"summitTime":1575886290000,"answerType":null,"userName":"徐炳荣","userHospitalId":null,"userHospitalName":"复旦大学附属中山医院","userDepartmentId":null,"userDepartmentName":"肝肿瘤外科","userWardName":"四十七病区","userPrimaryPhysicianCode":null,"userPrimaryPhysicianName":null,"userAdmitNo":null,"hospitalId":null,"hospitalName":null,"departmentId":null,"departmentName":null,"doctorId":null,"doctorIcon":null,"doctorName":null,"doctorTitle":null,"replyTime":null,"isShow":null,"isFee":null,"diseasePicturePaths":null,"diseaseLabel":null,"otherLabel":null,"consultationDisease":null,"isOpenImage":null,"supplementInformation":null,"isAllowAppObtain":null,"answer":null},{"id":3358,"uid":100295,"chaseId":0,"problemTitle":null,"problemContent":"哦的劳动阿拉斯加犬神奇宝贝宝贝","isHandle":null,"summitTime":1575600679000,"answerType":null,"userName":"徐炳荣","userHospitalId":null,"userHospitalName":"复旦大学附属中山医院","userDepartmentId":null,"userDepartmentName":"肝肿瘤外科","userWardName":"四十七病区","userPrimaryPhysicianCode":null,"userPrimaryPhysicianName":null,"userAdmitNo":null,"hospitalId":null,"hospitalName":null,"departmentId":null,"departmentName":null,"doctorId":null,"doctorIcon":null,"doctorName":null,"doctorTitle":null,"replyTime":null,"isShow":null,"isFee":null,"diseasePicturePaths":null,"diseaseLabel":null,"otherLabel":null,"consultationDisease":null,"isOpenImage":null,"supplementInformation":null,"isAllowAppObtain":null,"answer":null},{"id":3355,"uid":100296,"chaseId":0,"problemTitle":null,"problemContent":"还大喊大叫的继续吃西瓜就会发现","isHandle":null,"summitTime":1575538912000,"answerType":null,"userName":"迟日柱","userHospitalId":null,"userHospitalName":"复旦大学附属中山医院","userDepartmentId":null,"userDepartmentName":"肝肿瘤外科","userWardName":"四十七病区","userPrimaryPhysicianCode":null,"userPrimaryPhysicianName":null,"userAdmitNo":null,"hospitalId":null,"hospitalName":null,"departmentId":null,"departmentName":null,"doctorId":null,"doctorIcon":null,"doctorName":null,"doctorTitle":null,"replyTime":null,"isShow":null,"isFee":null,"diseasePicturePaths":null,"diseaseLabel":null,"otherLabel":null,"consultationDisease":null,"isOpenImage":null,"supplementInformation":null,"isAllowAppObtain":null,"answer":null},{"id":3354,"uid":100296,"chaseId":0,"problemTitle":null,"problemContent":"鸡蛋鸡蛋鸡蛋鸡蛋鸡蛋卷","isHandle":null,"summitTime":1575538845000,"answerType":null,"userName":"迟日柱","userHospitalId":null,"userHospitalName":"复旦大学附属中山医院","userDepartmentId":null,"userDepartmentName":"肝肿瘤外科","userWardName":"四十七病区","userPrimaryPhysicianCode":null,"userPrimaryPhysicianName":null,"userAdmitNo":null,"hospitalId":null,"hospitalName":null,"departmentId":null,"departmentName":null,"doctorId":null,"doctorIcon":null,"doctorName":null,"doctorTitle":null,"replyTime":null,"isShow":null,"isFee":null,"diseasePicturePaths":null,"diseaseLabel":null,"otherLabel":null,"consultationDisease":null,"isOpenImage":null,"supplementInformation":null,"isAllowAppObtain":null,"answer":null},{"id":3340,"uid":100137,"chaseId":0,"problemTitle":null,"problemContent":"体重魔攻魔龙龙JJ明末红","isHandle":null,"summitTime":1570768849000,"answerType":null,"userName":"周玉梅","userHospitalId":null,"userHospitalName":"复旦大学附属中山医院","userDepartmentId":null,"userDepartmentName":"肝肿瘤外科","userWardName":"原肝外科十七病区","userPrimaryPhysicianCode":null,"userPrimaryPhysicianName":null,"userAdmitNo":null,"hospitalId":null,"hospitalName":null,"departmentId":null,"departmentName":null,"doctorId":null,"doctorIcon":null,"doctorName":null,"doctorTitle":null,"replyTime":null,"isShow":null,"isFee":null,"diseasePicturePaths":null,"diseaseLabel":null,"otherLabel":null,"consultationDisease":null,"isOpenImage":null,"supplementInformation":null,"isAllowAppObtain":null,"answer":null},{"id":3336,"uid":100137,"chaseId":0,"problemTitle":null,"problemContent":"Aaaaaaaaaaa","isHandle":null,"summitTime":1568190617000,"answerType":null,"userName":"周玉梅","userHospitalId":null,"userHospitalName":"复旦大学附属中山医院","userDepartmentId":null,"userDepartmentName":"肝肿瘤外科","userWardName":"原肝外科十七病区","userPrimaryPhysicianCode":null,"userPrimaryPhysicianName":null,"userAdmitNo":null,"hospitalId":null,"hospitalName":null,"departmentId":null,"departmentName":null,"doctorId":null,"doctorIcon":null,"doctorName":null,"doctorTitle":null,"replyTime":null,"isShow":null,"isFee":null,"diseasePicturePaths":null,"diseaseLabel":null,"otherLabel":null,"consultationDisease":null,"isOpenImage":null,"supplementInformation":null,"isAllowAppObtain":null,"answer":null},{"id":3335,"uid":100137,"chaseId":0,"problemTitle":null,"problemContent":"egegggegege","isHandle":null,"summitTime":1568190549000,"answerType":null,"userName":"周玉梅","userHospitalId":null,"userHospitalName":"复旦大学附属中山医院","userDepartmentId":null,"userDepartmentName":"肝肿瘤外科","userWardName":"原肝外科十七病区","userPrimaryPhysicianCode":null,"userPrimaryPhysicianName":null,"userAdmitNo":null,"hospitalId":null,"hospitalName":null,"departmentId":null,"departmentName":null,"doctorId":null,"doctorIcon":null,"doctorName":null,"doctorTitle":null,"replyTime":null,"isShow":null,"isFee":null,"diseasePicturePaths":null,"diseaseLabel":null,"otherLabel":null,"consultationDisease":null,"isOpenImage":null,"supplementInformation":null,"isAllowAppObtain":null,"answer":null}]
     */

    private int status;
    private int page;
    private int totalPage;
    private List<RetValueBean> retValue;

    public int getStatus() {
        return status;
    }

    public void setStatus(int status) {
        this.status = status;
    }

    public int getPage() {
        return page;
    }

    public void setPage(int page) {
        this.page = page;
    }

    public int getTotalPage() {
        return totalPage;
    }

    public void setTotalPage(int totalPage) {
        this.totalPage = totalPage;
    }

    public List<RetValueBean> getRetValue() {
        return retValue;
    }

    public void setRetValue(List<RetValueBean> retValue) {
        this.retValue = retValue;
    }

    public static class RetValueBean {
        /**
         * id : 3375
         * uid : 100137
         * chaseId : 3346
         * problemTitle : null
         * problemContent : 傅大撒发啊书法大赛发大水发大水发撒发撒发射点
         * isHandle : null
         * summitTime : 1586853865000
         * answerType : null
         * userName : 周玉梅
         * userHospitalId : null
         * userHospitalName : 复旦大学附属中山医院
         * userDepartmentId : null
         * userDepartmentName : 肝肿瘤外科
         * userWardName : 原肝外科十七病区
         * userPrimaryPhysicianCode : null
         * userPrimaryPhysicianName : null
         * userAdmitNo : null
         * hospitalId : null
         * hospitalName : null
         * departmentId : null
         * departmentName : null
         * doctorId : null
         * doctorIcon : null
         * doctorName : null
         * doctorTitle : null
         * replyTime : null
         * isShow : null
         * isFee : null
         * diseasePicturePaths : null
         * diseaseLabel : null
         * otherLabel : null
         * consultationDisease : null
         * isOpenImage : null
         * supplementInformation : null
         * isAllowAppObtain : null
         * answer : null
         */

        private int id;
        private int uid;
        private int chaseId;
        private Object problemTitle;
        private String problemContent;
        private Object isHandle;
        private long summitTime;
        private Object answerType;
        private String userName;
        private Object userHospitalId;
        private String userHospitalName;
        private Object userDepartmentId;
        private String userDepartmentName;
        private String userWardName;
        private Object userPrimaryPhysicianCode;
        private Object userPrimaryPhysicianName;
        private Object userAdmitNo;
        private Object hospitalId;
        private Object hospitalName;
        private Object departmentId;
        private Object departmentName;
        private Object doctorId;
        private Object doctorIcon;
        private Object doctorName;
        private Object doctorTitle;
        private Object replyTime;
        private Object isShow;
        private Object isFee;
        private Object diseasePicturePaths;
        private Object diseaseLabel;
        private Object otherLabel;
        private Object consultationDisease;
        private Object isOpenImage;
        private Object supplementInformation;
        private Object isAllowAppObtain;
        private Object answer;

        public int getId() {
            return id;
        }

        public void setId(int id) {
            this.id = id;
        }

        public int getUid() {
            return uid;
        }

        public void setUid(int uid) {
            this.uid = uid;
        }

        public int getChaseId() {
            return chaseId;
        }

        public void setChaseId(int chaseId) {
            this.chaseId = chaseId;
        }

        public Object getProblemTitle() {
            return problemTitle;
        }

        public void setProblemTitle(Object problemTitle) {
            this.problemTitle = problemTitle;
        }

        public String getProblemContent() {
            return problemContent;
        }

        public void setProblemContent(String problemContent) {
            this.problemContent = problemContent;
        }

        public Object getIsHandle() {
            return isHandle;
        }

        public void setIsHandle(Object isHandle) {
            this.isHandle = isHandle;
        }

        public long getSummitTime() {
            return summitTime;
        }

        public void setSummitTime(long summitTime) {
            this.summitTime = summitTime;
        }

        public Object getAnswerType() {
            return answerType;
        }

        public void setAnswerType(Object answerType) {
            this.answerType = answerType;
        }

        public String getUserName() {
            return userName;
        }

        public void setUserName(String userName) {
            this.userName = userName;
        }

        public Object getUserHospitalId() {
            return userHospitalId;
        }

        public void setUserHospitalId(Object userHospitalId) {
            this.userHospitalId = userHospitalId;
        }

        public String getUserHospitalName() {
            return userHospitalName;
        }

        public void setUserHospitalName(String userHospitalName) {
            this.userHospitalName = userHospitalName;
        }

        public Object getUserDepartmentId() {
            return userDepartmentId;
        }

        public void setUserDepartmentId(Object userDepartmentId) {
            this.userDepartmentId = userDepartmentId;
        }

        public String getUserDepartmentName() {
            return userDepartmentName;
        }

        public void setUserDepartmentName(String userDepartmentName) {
            this.userDepartmentName = userDepartmentName;
        }

        public String getUserWardName() {
            return userWardName;
        }

        public void setUserWardName(String userWardName) {
            this.userWardName = userWardName;
        }

        public Object getUserPrimaryPhysicianCode() {
            return userPrimaryPhysicianCode;
        }

        public void setUserPrimaryPhysicianCode(Object userPrimaryPhysicianCode) {
            this.userPrimaryPhysicianCode = userPrimaryPhysicianCode;
        }

        public Object getUserPrimaryPhysicianName() {
            return userPrimaryPhysicianName;
        }

        public void setUserPrimaryPhysicianName(Object userPrimaryPhysicianName) {
            this.userPrimaryPhysicianName = userPrimaryPhysicianName;
        }

        public Object getUserAdmitNo() {
            return userAdmitNo;
        }

        public void setUserAdmitNo(Object userAdmitNo) {
            this.userAdmitNo = userAdmitNo;
        }

        public Object getHospitalId() {
            return hospitalId;
        }

        public void setHospitalId(Object hospitalId) {
            this.hospitalId = hospitalId;
        }

        public Object getHospitalName() {
            return hospitalName;
        }

        public void setHospitalName(Object hospitalName) {
            this.hospitalName = hospitalName;
        }

        public Object getDepartmentId() {
            return departmentId;
        }

        public void setDepartmentId(Object departmentId) {
            this.departmentId = departmentId;
        }

        public Object getDepartmentName() {
            return departmentName;
        }

        public void setDepartmentName(Object departmentName) {
            this.departmentName = departmentName;
        }

        public Object getDoctorId() {
            return doctorId;
        }

        public void setDoctorId(Object doctorId) {
            this.doctorId = doctorId;
        }

        public Object getDoctorIcon() {
            return doctorIcon;
        }

        public void setDoctorIcon(Object doctorIcon) {
            this.doctorIcon = doctorIcon;
        }

        public Object getDoctorName() {
            return doctorName;
        }

        public void setDoctorName(Object doctorName) {
            this.doctorName = doctorName;
        }

        public Object getDoctorTitle() {
            return doctorTitle;
        }

        public void setDoctorTitle(Object doctorTitle) {
            this.doctorTitle = doctorTitle;
        }

        public Object getReplyTime() {
            return replyTime;
        }

        public void setReplyTime(Object replyTime) {
            this.replyTime = replyTime;
        }

        public Object getIsShow() {
            return isShow;
        }

        public void setIsShow(Object isShow) {
            this.isShow = isShow;
        }

        public Object getIsFee() {
            return isFee;
        }

        public void setIsFee(Object isFee) {
            this.isFee = isFee;
        }

        public Object getDiseasePicturePaths() {
            return diseasePicturePaths;
        }

        public void setDiseasePicturePaths(Object diseasePicturePaths) {
            this.diseasePicturePaths = diseasePicturePaths;
        }

        public Object getDiseaseLabel() {
            return diseaseLabel;
        }

        public void setDiseaseLabel(Object diseaseLabel) {
            this.diseaseLabel = diseaseLabel;
        }

        public Object getOtherLabel() {
            return otherLabel;
        }

        public void setOtherLabel(Object otherLabel) {
            this.otherLabel = otherLabel;
        }

        public Object getConsultationDisease() {
            return consultationDisease;
        }

        public void setConsultationDisease(Object consultationDisease) {
            this.consultationDisease = consultationDisease;
        }

        public Object getIsOpenImage() {
            return isOpenImage;
        }

        public void setIsOpenImage(Object isOpenImage) {
            this.isOpenImage = isOpenImage;
        }

        public Object getSupplementInformation() {
            return supplementInformation;
        }

        public void setSupplementInformation(Object supplementInformation) {
            this.supplementInformation = supplementInformation;
        }

        public Object getIsAllowAppObtain() {
            return isAllowAppObtain;
        }

        public void setIsAllowAppObtain(Object isAllowAppObtain) {
            this.isAllowAppObtain = isAllowAppObtain;
        }

        public Object getAnswer() {
            return answer;
        }

        public void setAnswer(Object answer) {
            this.answer = answer;
        }
    }
}
