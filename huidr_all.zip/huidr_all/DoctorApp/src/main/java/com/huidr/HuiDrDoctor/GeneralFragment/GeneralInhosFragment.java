package com.huidr.HuiDrDoctor.GeneralFragment;

import android.app.Dialog;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import android.text.Html;
import android.util.Log;
import android.view.Display;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.ImageView;
import android.widget.TextView;

import com.alibaba.fastjson.JSONObject;
import com.chad.library.adapter.base.BaseQuickAdapter;
import com.chad.library.adapter.base.BaseViewHolder;
import com.google.gson.Gson;
import com.huidr.HuiDrDoctor.activity.WebActivity;
import com.huidr.HuiDrDoctor.activity.main.Consult.utils.PostAndGet;
import com.huidr.HuiDrDoctor.customview.CustomRecyclerView;
import com.huidr.HuiDrDoctor.debug.BuildConfig;
import com.huidr.HuiDrDoctor.debug.R;
import com.huidr.HuiDrDoctor.module.home.InhosModel;
import com.huidr.HuiDrDoctor.module.home.PatientsModel;
import com.huidr.HuiDrDoctor.module.home.SimpleResultModel;
import com.huidr.HuiDrDoctor.util.LogUtil;
import com.huidr.HuiDrDoctor.util.ThreadPoolManager;
import com.huidr.lib.commom.base.HuidrActivityManager;
import com.scwang.smartrefresh.layout.SmartRefreshLayout;
import com.scwang.smartrefresh.layout.api.RefreshLayout;
import com.scwang.smartrefresh.layout.listener.OnLoadMoreListener;
import com.scwang.smartrefresh.layout.listener.OnRefreshListener;
import com.zyao89.view.zloading.ZLoadingDialog;
import com.zyao89.view.zloading.Z_TYPE;

import java.util.List;

import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import jiguang.chat.utils.oss.SharedPreferenciesUtil;

/**
 * 这里是住院患者动态生成列表的Fragment
 */
public class GeneralInhosFragment extends Fragment {

    String tip;//标签
    int tipType;

    SmartRefreshLayout smartRefreshLayout;
    CustomRecyclerView customRecyclerView;
    long lastClick = 0;

    ConstraintLayout clEmpty;
    ImageView imageEmpty;
    TextView tvEmpty1;
    TextView tvEmpty2;

    String urlAll = BuildConfig.baseUrl + "";
    String yrlTag = BuildConfig.baseUrl + "";

    private List<InhosModel.RetValueBean> allInhos; //所有列表
    private InhosModel tempInhos;//缓存列表

    int currentPage = 1;
    int totalPage = 0;
    Gson gson;

    PatientsModel patientsModel;

    String urlGetPatient = BuildConfig.baseUrl + "patient/doctorPatientMedical/getPatients";
    String urlTags = BuildConfig.baseUrl + "patient/doctorPatientMedical/getPatientPoolByTags";

    int[] patients;

    ZLoadingDialog zLoadingDialog;

    int refreshCount = 0;


    public void getDataPatients() {
        ThreadPoolManager.getInstance().execute(new Runnable() {
            @Override
            public void run() {
                patientsModel = new PatientsModel();
                gson = new Gson();
                JSONObject jsonObject = new JSONObject();
                jsonObject.put("patientType", 2);
                String result = PostAndGet.doHttpPost(urlGetPatient, jsonObject);
                if (result == null | result.equals("网络异常")) {

                } else {

                    patientsModel = gson.fromJson(result, PatientsModel.class);
                    patients = new int[patientsModel.getRetValue().size()];
                    for (int i = 0; i < patientsModel.getRetValue().size(); i++) {
                        patients[i] = patientsModel.getRetValue().get(i);
                    }
                    handler.sendEmptyMessage(6);
                }
            }
        });
    }


    public void initView(View view) {
        smartRefreshLayout = view.findViewById(R.id.srl_layout);
        customRecyclerView = view.findViewById(R.id.rv_list_recent);
        clEmpty = view.findViewById(R.id.cl_empty);
        imageEmpty = view.findViewById(R.id.img_empty);
        tvEmpty1 = view.findViewById(R.id.tv_empty1);
        tvEmpty2 = view.findViewById(R.id.tv_empty2);

        smartRefreshLayout.setEnableRefresh(true);
        smartRefreshLayout.setEnableLoadMore(true);

        smartRefreshLayout.setOnLoadMoreListener(new OnLoadMoreListener() {
            @Override
            public void onLoadMore(@NonNull RefreshLayout refreshLayout) {


                if (tempInhos.getRetValue().size() == 20 && currentPage < totalPage) {
                    currentPage += 1;
                    if (tip.equals("全部")) {
                        getNoTagDataByPage();
                    } else {
                        getTagDataByPage();
                    }
                } else {
                    com.huidr.lib.commom.util.Toast.getInstance(getActivity()).show("数据加载全部", 500);
                    smartRefreshLayout.finishLoadMore();
                }


            }
        });

        smartRefreshLayout.setOnRefreshListener(new OnRefreshListener() {
            @Override
            public void onRefresh(@NonNull RefreshLayout refreshLayout) {
                currentPage = 1;
                if (tip.equals("全部")) {
                    getNoTagDataByPage();
                } else {
                    getTagDataByPage();
                }
            }
        });

        customRecyclerView.setAdapter(generalAdapter);
        customRecyclerView.setLayoutManager(new LinearLayoutManager(getContext()));

        tvEmpty2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (tvEmpty2.getText().toString().equals("点击刷新")) {
                    refreshCount += 1;
                }
                if (tip.equals("全部")) {
                    getNoTagDataByPage();
                } else {
                    getDataPatients();
                }
                zLoadingDialog = new ZLoadingDialog(HuidrActivityManager.getInstance().getCurrentActivity());
                zLoadingDialog.setLoadingBuilder(Z_TYPE.STAR_LOADING)//设置类型
                        .setLoadingColor(Color.BLUE)//颜色
                        .setHintText("正在加载,请稍候...").setHintTextSize(16) // 设置字体大小 dp
                        .setHintTextColor(Color.GRAY)  // 设置字体颜色
                        .setDurationTime(0.5) // 设置动画时间百分比 - 0.5倍
                        .setCanceledOnTouchOutside(false).setCancelable(false).show();

            }
        });
    }


    public static GeneralInhosFragment newInstance_Fragment(String tip) {
        GeneralInhosFragment generalInhosFragment = new GeneralInhosFragment();
        Bundle bundle = new Bundle();
        bundle.putString("tip", tip);
        generalInhosFragment.setArguments(bundle);
        return generalInhosFragment;
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_general_inhos, container, false);
        gson = new Gson();
        initView(view);
        return view;
    }


    @Override
    public void setUserVisibleHint(boolean isVisibleToUser) {
        super.setUserVisibleHint(isVisibleToUser);

        if (isVisibleToUser) {
            Bundle bundle = getArguments();
            tip = bundle.getString("tip");
            tipType = bundle.getInt("tipType");
            zLoadingDialog = new ZLoadingDialog(HuidrActivityManager.getInstance().getCurrentActivity());
            zLoadingDialog.setLoadingBuilder(Z_TYPE.STAR_LOADING)//设置类型
                    .setLoadingColor(Color.BLUE)//颜色
                    .setHintText("正在加载,请稍候...").setHintTextSize(16) // 设置字体大小 dp
                    .setHintTextColor(Color.GRAY)  // 设置字体颜色
                    .setDurationTime(0.5) // 设置动画时间百分比 - 0.5倍
                    .setCanceledOnTouchOutside(false).setCancelable(false).show();

            if (tip.equals("全部")) {
                getNoTagDataByPage();
            } else {
                getDataPatients();
            }
        }
    }

    /*
     * 获取默认数据列表
     * */
    public void getNoTagDataByPage() {
        ThreadPoolManager.getInstance().execute(new Runnable() {
            @Override
            public void run() {
//                String path = BuildConfig.baseUrl + "patient/doctorPatientMedical/getFollowUpPoolList?pageIndex=" + currentPage + "&hospitalActionStatus=1&pageSize=20";
                String path = BuildConfig.baseUrl + "patient/doctorPatientMedical/getFollowUpPoolList?pageIndex=" + currentPage + "&hospitalActionStatus=1&pageSize=20";
                String result = PostAndGet.doGetHttp(path);
                tempInhos = new InhosModel();

                LogUtil.e("患者池 住院患者", result);
                if (result == null || result.equals("网络异常")) {
                    handler.sendEmptyMessage(3);
                } else {
                    tempInhos = gson.fromJson(result, InhosModel.class);
                    if (tempInhos == null) {
                        handler.sendEmptyMessage(3);
                    } else if (tempInhos.getStatus() == 0) {
                        totalPage = tempInhos.getTotalPage();
                        if (currentPage == 1) {
                            handler.sendEmptyMessage(currentPage);
                        } else {
                            handler.sendEmptyMessage(2);
                        }
                    } else {
                        handler.sendEmptyMessage(3);
                    }
                }
            }
        });
    }

    /*
     * 根据标签获取数据列表
     * */
    public void getTagDataByPage() {
        ThreadPoolManager.getInstance().execute(new Runnable() {
            @Override
            public void run() {
                JSONObject jsonObject = new JSONObject();
                jsonObject.put("tagName", tip);
                jsonObject.put("tagType", tipType);
                jsonObject.put("patients", patients);
                jsonObject.put("pageIndex", currentPage);
                jsonObject.put("pageSize", 20);
                String result = PostAndGet.doHttpPost(urlTags, jsonObject);

                Log.e("住院患者获取标签数据", result);
                if (result == null || result.equals("网络异常")) {
                    handler.sendEmptyMessage(3);
                } else {
                    tempInhos = gson.fromJson(result, InhosModel.class);
                    if (tempInhos == null) {
                        handler.sendEmptyMessage(3);
                    } else if (tempInhos.getStatus() == 0) {
                        totalPage = tempInhos.getTotalPage();
                        if (currentPage == 1) {
                            handler.sendEmptyMessage(currentPage);
                        } else {
                            handler.sendEmptyMessage(2);
                        }
                    } else {
                        handler.sendEmptyMessage(3);
                    }
                }

                Log.e("根据标签获取最近查看", result);
            }
        });
    }

    Handler handler = new Handler() {
        @Override
        public void handleMessage(Message msg) {
            super.handleMessage(msg);
            switch (msg.what) {
                case 1:
                    if (zLoadingDialog != null) {
                        new Handler().postDelayed(new Runnable() {
                            @Override
                            public void run() {
                                zLoadingDialog.dismiss();
                                zLoadingDialog = null;
                            }
                        }, 500);
                    }
                    generalAdapter.getData().clear();
                    if (tempInhos == null || tempInhos.getRetValue() == null || tempInhos.getRetValue().size() == 0) {
                        clEmpty.setVisibility(View.VISIBLE);
                        smartRefreshLayout.setVisibility(View.GONE);
                        String tip1 = "暂无患者";
                        String tip2 = "<font color='#248cfa'><u>点击刷新<u></font>";
                        tvEmpty1.setText(tip1);
                        tvEmpty2.setText(Html.fromHtml(tip2));
                        if (currentPage == 3) {
                            tvEmpty2.setVisibility(View.GONE);
                            refreshCount = 0;
                        } else {
                            if (tvEmpty2.getVisibility() == View.GONE) {
                                tvEmpty2.setVisibility(View.VISIBLE);
                            }
                        }
                    } else {
                        clEmpty.setVisibility(View.GONE);
                        smartRefreshLayout.setVisibility(View.VISIBLE);
                        generalAdapter.getData().addAll(tempInhos.getRetValue());
                        generalAdapter.notifyDataSetChanged();
                    }
                    smartRefreshLayout.finishRefresh();
                    break;
                case 2:
                    if (zLoadingDialog != null) {
                        new Handler().postDelayed(new Runnable() {
                            @Override
                            public void run() {
                                zLoadingDialog.dismiss();
                                zLoadingDialog = null;
                            }
                        }, 500);
                    }
                    generalAdapter.getData().addAll(tempInhos.getRetValue());
                    generalAdapter.notifyDataSetChanged();
                    smartRefreshLayout.finishLoadMore();
                    break;
                case 3:
                    if (zLoadingDialog != null) {
                        new Handler().postDelayed(new Runnable() {
                            @Override
                            public void run() {
                                zLoadingDialog.dismiss();
                                zLoadingDialog = null;
                            }
                        }, 500);
                    }
                    clEmpty.setVisibility(View.VISIBLE);
                    smartRefreshLayout.setVisibility(View.GONE);
                    String tip1 = "网络错误~";
                    String tip2 = "<font color='#248cfa'><u>立即刷新<u></font>";
                    tvEmpty1.setText(tip1);
                    tvEmpty2.setText(Html.fromHtml(tip2));
                    smartRefreshLayout.finishRefresh();
                    smartRefreshLayout.finishLoadMore();
                    break;
                case 4://取消关注 关注患者 成功
                    String tip = "";
                    Boolean atten = (Boolean) msg.obj;
                    if (atten) {
                        tip = "关注患者成功";
                        generalAdapter.getData().get(msg.arg1).setIsFollow(true);
                    } else {
                        tip = "取消成功";
                        generalAdapter.getData().get(msg.arg1).setIsFollow(false);
                    }
                    com.huidr.lib.commom.util.Toast.getInstance(getActivity()).show(tip, 500);
                    generalAdapter.notifyDataSetChanged();
                    break;
                case 5://取消关注 关注患者 失败
                    String str = "";
                    Boolean atten1 = (Boolean) msg.obj;
                    if (atten1) {
                        str = "关注患者失败";
                    } else {
                        str = "取消失败";
                    }
                    com.huidr.lib.commom.util.Toast.getInstance(getActivity()).show(str, 500);
                    generalAdapter.notifyDataSetChanged();
                    break;

                case 6:
                    getTagDataByPage();
                    break;
            }
        }
    };


    BaseQuickAdapter<InhosModel.RetValueBean, BaseViewHolder> generalAdapter = new BaseQuickAdapter<InhosModel.RetValueBean, BaseViewHolder>(R.layout.item_patient_scroll_layout) {
        @Override
        protected void convert(final BaseViewHolder helper, final InhosModel.RetValueBean item) {
            ImageView imgItemHead = helper.getView(R.id.img_item_head);
            setPatientImage(imgItemHead, item.getBindUserRelationship(), item.getUserSex());
//            提醒
            ImageView imgNotice = helper.getView(R.id.img_notice);
            imgNotice.setVisibility(View.GONE);
//            姓名
            TextView tvItemName = helper.getView(R.id.tv_item_name);
            tvItemName.setText(item.getUserName());
//            住院号
            TextView tvPatientNum = helper.getView(R.id.tv_patient_num);
            tvPatientNum.setText(item.getLatelyAdmitNo());
//            日期
            TextView tvItemDate = helper.getView(R.id.tv_item_date);
            tvItemDate.setText(item.getLatelyVisitingDate());
//            状态
            TextView tvItemMsg = helper.getView(R.id.tv_item_msg);
            tvItemMsg.setText(item.getLatelyAdmissionDiagnosis());
//            模板
            TextView tvModel = helper.getView(R.id.tv_model);
            tvModel.setText(item.getFollowupName());


            final TextView tvRight = helper.getView(R.id.tv_scroll_right);

            if (item.isIsFollow()) {
                String str = "<font>已<br>关注</font>";
                tvRight.setText(Html.fromHtml(str));
                tvRight.setBackgroundResource(R.drawable.shape_atten_gray);
            } else {
                String str = "<font>关注<br>患者</font>";
                tvRight.setText(Html.fromHtml(str));
                tvRight.setBackgroundResource(R.drawable.shape_attent_blue);
            }

            tvRight.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (item.isIsFollow()) {
//                        取消关注
//                        modifyAttent(false, helper.getAdapterPosition(), item.getId());
                        generalAdapter.notifyItemChanged(helper.getAdapterPosition());
                        com.huidr.lib.commom.util.Toast.getInstance(getContext()).show("该患者已关注", 500);
                    } else {
//                        关注患者
//                        modifyAttent(true, helper.getAdapterPosition(), item.getId());
                        showCoopDialog(true, helper.getAdapterPosition(), item.getId());

                    }
                }
            });

            ConstraintLayout clItem = helper.getView(R.id.cl_item);
//            点击跳转 患者详情  patientData_inHos.html?id=52366
            clItem.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {

                    if (System.currentTimeMillis() - lastClick > 1000) {
                        JSONObject jsonObject = new JSONObject();
                        jsonObject.put("id", item.getId());
                        SharedPreferenciesUtil.putData("psearchID", jsonObject.toJSONString());
                        SharedPreferenciesUtil.putData("followDoctorId", item.getDoctorId());

                        Intent intent1 = new Intent(getActivity(), WebActivity.class);
                        Bundle bundle = new Bundle();
                        bundle.putString("url", "patientData_inHos.html");
                        intent1.putExtras(bundle);
                        startActivity(intent1);
                        lastClick = System.currentTimeMillis();
                    }
                }
            });
        }
    };


    public void setPatientImage(ImageView image, String ship, int sex) {
        if (ship == null) {
            image.setBackgroundResource(R.drawable.head_patient);
            return;
        }
        switch (ship) {
            case "本人":
                if (sex == 1) {
                    image.setBackgroundResource(R.drawable.my_him);
                } else {
                    image.setBackgroundResource(R.drawable.my_her);
                }
                break;
            case "丈夫":
                image.setBackgroundResource(R.drawable.husband);
                break;
            case "妻子":
                image.setBackgroundResource(R.drawable.wife);
                break;
            case "爸爸":
                image.setBackgroundResource(R.drawable.papa);
                break;
            case "妈妈":
                image.setBackgroundResource(R.drawable.mama);
                break;
            case "儿子":
                image.setBackgroundResource(R.drawable.son);
                break;
            case "女儿":
                image.setBackgroundResource(R.drawable.daughter);
                break;
            case "其他":
                image.setBackgroundResource(R.drawable.head_patient);
                break;
            default:
                image.setBackgroundResource(R.drawable.head_patient);
                break;
        }
    }

    //    取消添加协同对话框
    public void showCoopDialog(final boolean atten, final int position, final int patientId) {

        final Dialog builder = new Dialog(getContext(), R.style.jmui_default_dialog_style);
        //final Dialog builder = new Dialog(this, R.style.jmui_default_dialog_style);
        View view = LayoutInflater.from(getContext()).inflate(R.layout.dialog_content, null);

        TextView tvTitle = view.findViewById(R.id.tv_title);
        TextView tvFooter1 = view.findViewById(R.id.tv_footer1);
        TextView tvFooter2 = view.findViewById(R.id.tv_footer2);

        tvTitle.setText("是否关注该患者！");


//        取消
        tvFooter1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                builder.cancel();
                generalAdapter.notifyItemChanged(position);

            }
        });
//确定
        tvFooter2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                builder.cancel();
                modifyAttent(atten, position, patientId);
                generalAdapter.notifyItemChanged(position);
            }
        });

        builder.setContentView(view);
        //builder.setCanceledOnTouchOutside(true);
        builder.show();
        Window window = builder.getWindow();
        WindowManager.LayoutParams lp = window.getAttributes();
        WindowManager windowManager = getActivity().getWindowManager();
        Display display = windowManager.getDefaultDisplay();
        lp.width = (int) (display.getWidth() * 0.7);
//        lp.height = (int) (display.getHeight() * 0.1);
        window.setAttributes(lp);
    }

    public void modifyAttent(final boolean atten, final int position, final int patientId) {
        ThreadPoolManager.getInstance().execute(new Runnable() {
            @Override
            public void run() {
                String id = (String) SharedPreferenciesUtil.getData("id", "0");
                String path = BuildConfig.baseUrl + "patient/doctorPatientMedical/addRemarksAndFollow?doctorId=" + id + "&patientId=" + patientId + "&isFollow=" + atten;
                String result = PostAndGet.doGetHttp(path);

                LogUtil.e("关注", result);
                if (result.equals("网络异常")) {

                } else {
                    SimpleResultModel simpleResultModel = gson.fromJson(result, SimpleResultModel.class);
                    Message message = new Message();
                    message.obj = atten;
                    if (simpleResultModel.getStatus() == 0) {
                        message.what = 4;
                        message.arg1 = position;
                        handler.sendMessage(message);
                    } else {
                        message.what = 5;
                        handler.sendMessage(message);
                    }
                }
            }
        });
    }
}
