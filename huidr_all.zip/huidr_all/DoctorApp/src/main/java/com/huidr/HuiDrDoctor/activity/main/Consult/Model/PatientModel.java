package com.huidr.HuiDrDoctor.activity.main.Consult.Model;

public class PatientModel {


    /**
     * status : 0
     * retValue : {"id":45828,"userName":"周玉梅","userInitials":null,"userBirth":-383126400000,"userSex":2,"userIcon":null,"cardType":1,"card":"310104195711110860","allergyDesc":null,"bindUid":100137,"bindUserRelationship":"其他","relationshipIcon":"","latelyAdmitNo":"890313","latelyBed":"108","latelyAdmissionDiagnosis":"肝囊肿,胆囊结石","latelyDischargeDiagnosis":"肝囊肿,胆囊结石","latelyAdmissionTime":1422928860000,"latelyDischargeTime":1423443660000,"latelyVisitingDate":1550814221000,"patientMobile1":"13600000000","patientMobile2":"13600000001","patientMobile3":"13600000000","patientProvince":"北京市","patientCity":"北京市","patientArea":"东城区","patientAddress":"123","callAdmitNo":null,"encryptCard":null}
     */

    private int status;
    private RetValueBean retValue;

    public int getStatus() {
        return status;
    }

    public void setStatus(int status) {
        this.status = status;
    }

    public RetValueBean getRetValue() {
        return retValue;
    }

    public void setRetValue(RetValueBean retValue) {
        this.retValue = retValue;
    }

    public static class RetValueBean {
        /**
         * id : 45828
         * userName : 周玉梅
         * userInitials : null
         * userBirth : -383126400000
         * userSex : 2
         * userIcon : null
         * cardType : 1
         * card : 310104195711110860
         * allergyDesc : null
         * bindUid : 100137
         * bindUserRelationship : 其他
         * relationshipIcon :
         * latelyAdmitNo : 890313
         * latelyBed : 108
         * latelyAdmissionDiagnosis : 肝囊肿,胆囊结石
         * latelyDischargeDiagnosis : 肝囊肿,胆囊结石
         * latelyAdmissionTime : 1422928860000
         * latelyDischargeTime : 1423443660000
         * latelyVisitingDate : 1550814221000
         * patientMobile1 : 13600000000
         * patientMobile2 : 13600000001
         * patientMobile3 : 13600000000
         * patientProvince : 北京市
         * patientCity : 北京市
         * patientArea : 东城区
         * patientAddress : 123
         * callAdmitNo : null
         * encryptCard : null
         */

        private int id;
        private String userName;
        private Object userInitials;
        private long userBirth;
        private int userSex;
        private Object userIcon;
        private int cardType;
        private String card;
        private Object allergyDesc;
        private int bindUid;
        private String bindUserRelationship;
        private String relationshipIcon;
        private String latelyAdmitNo;
        private String latelyBed;
        private String latelyAdmissionDiagnosis;
        private String latelyDischargeDiagnosis;
        private long latelyAdmissionTime;
        private long latelyDischargeTime;
        private long latelyVisitingDate;
        private String patientMobile1;
        private String patientMobile2;
        private String patientMobile3;
        private String patientProvince;
        private String patientCity;
        private String patientArea;
        private String patientAddress;
        private Object callAdmitNo;
        private Object encryptCard;

        public int getId() {
            return id;
        }

        public void setId(int id) {
            this.id = id;
        }

        public String getUserName() {
            return userName;
        }

        public void setUserName(String userName) {
            this.userName = userName;
        }

        public Object getUserInitials() {
            return userInitials;
        }

        public void setUserInitials(Object userInitials) {
            this.userInitials = userInitials;
        }

        public long getUserBirth() {
            return userBirth;
        }

        public void setUserBirth(long userBirth) {
            this.userBirth = userBirth;
        }

        public int getUserSex() {
            return userSex;
        }

        public void setUserSex(int userSex) {
            this.userSex = userSex;
        }

        public Object getUserIcon() {
            return userIcon;
        }

        public void setUserIcon(Object userIcon) {
            this.userIcon = userIcon;
        }

        public int getCardType() {
            return cardType;
        }

        public void setCardType(int cardType) {
            this.cardType = cardType;
        }

        public String getCard() {
            return card;
        }

        public void setCard(String card) {
            this.card = card;
        }

        public Object getAllergyDesc() {
            return allergyDesc;
        }

        public void setAllergyDesc(Object allergyDesc) {
            this.allergyDesc = allergyDesc;
        }

        public int getBindUid() {
            return bindUid;
        }

        public void setBindUid(int bindUid) {
            this.bindUid = bindUid;
        }

        public String getBindUserRelationship() {
            return bindUserRelationship;
        }

        public void setBindUserRelationship(String bindUserRelationship) {
            this.bindUserRelationship = bindUserRelationship;
        }

        public String getRelationshipIcon() {
            return relationshipIcon;
        }

        public void setRelationshipIcon(String relationshipIcon) {
            this.relationshipIcon = relationshipIcon;
        }

        public String getLatelyAdmitNo() {
            return latelyAdmitNo;
        }

        public void setLatelyAdmitNo(String latelyAdmitNo) {
            this.latelyAdmitNo = latelyAdmitNo;
        }

        public String getLatelyBed() {
            return latelyBed;
        }

        public void setLatelyBed(String latelyBed) {
            this.latelyBed = latelyBed;
        }

        public String getLatelyAdmissionDiagnosis() {
            return latelyAdmissionDiagnosis;
        }

        public void setLatelyAdmissionDiagnosis(String latelyAdmissionDiagnosis) {
            this.latelyAdmissionDiagnosis = latelyAdmissionDiagnosis;
        }

        public String getLatelyDischargeDiagnosis() {
            return latelyDischargeDiagnosis;
        }

        public void setLatelyDischargeDiagnosis(String latelyDischargeDiagnosis) {
            this.latelyDischargeDiagnosis = latelyDischargeDiagnosis;
        }

        public long getLatelyAdmissionTime() {
            return latelyAdmissionTime;
        }

        public void setLatelyAdmissionTime(long latelyAdmissionTime) {
            this.latelyAdmissionTime = latelyAdmissionTime;
        }

        public long getLatelyDischargeTime() {
            return latelyDischargeTime;
        }

        public void setLatelyDischargeTime(long latelyDischargeTime) {
            this.latelyDischargeTime = latelyDischargeTime;
        }

        public long getLatelyVisitingDate() {
            return latelyVisitingDate;
        }

        public void setLatelyVisitingDate(long latelyVisitingDate) {
            this.latelyVisitingDate = latelyVisitingDate;
        }

        public String getPatientMobile1() {
            return patientMobile1;
        }

        public void setPatientMobile1(String patientMobile1) {
            this.patientMobile1 = patientMobile1;
        }

        public String getPatientMobile2() {
            return patientMobile2;
        }

        public void setPatientMobile2(String patientMobile2) {
            this.patientMobile2 = patientMobile2;
        }

        public String getPatientMobile3() {
            return patientMobile3;
        }

        public void setPatientMobile3(String patientMobile3) {
            this.patientMobile3 = patientMobile3;
        }

        public String getPatientProvince() {
            return patientProvince;
        }

        public void setPatientProvince(String patientProvince) {
            this.patientProvince = patientProvince;
        }

        public String getPatientCity() {
            return patientCity;
        }

        public void setPatientCity(String patientCity) {
            this.patientCity = patientCity;
        }

        public String getPatientArea() {
            return patientArea;
        }

        public void setPatientArea(String patientArea) {
            this.patientArea = patientArea;
        }

        public String getPatientAddress() {
            return patientAddress;
        }

        public void setPatientAddress(String patientAddress) {
            this.patientAddress = patientAddress;
        }

        public Object getCallAdmitNo() {
            return callAdmitNo;
        }

        public void setCallAdmitNo(Object callAdmitNo) {
            this.callAdmitNo = callAdmitNo;
        }

        public Object getEncryptCard() {
            return encryptCard;
        }

        public void setEncryptCard(Object encryptCard) {
            this.encryptCard = encryptCard;
        }
    }
}
