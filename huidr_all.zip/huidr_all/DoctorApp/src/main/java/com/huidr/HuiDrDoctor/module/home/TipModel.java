package com.huidr.HuiDrDoctor.module.home;

import java.util.List;
/*
* 标签数据获取结果
* */
public class TipModel {


    /**
     * status : 0
     * page : 1
     * totalPage : 1
     * retValue : [{"tagName":"(甲)(优思弗)熊去氧胆酸胶囊","tagType":2},{"tagName":"(甲)(日夜百服宁)氨酚伪麻美芬片(日片)/氨麻美敏片Ⅱ(夜片)","tagType":2},{"tagName":"[少](乙20%)(顺尔宁)孟鲁司特钠片","tagType":2},{"tagName":"(甲)(来立信)乳酸左氧氟沙星片","tagType":2},{"tagName":"(甲)(思密达)蒙脱石散","tagType":2},{"tagName":"瑞戈非尼","tagType":2},{"tagName":"(乙10%)稳心颗粒(无蔗糖)","tagType":2},{"tagName":"肝切除","tagType":3},{"tagName":"胃病","tagType":3},{"tagName":"脊柱恶性肿瘤","tagType":3},{"tagName":"骨关节损伤","tagType":3},{"tagName":"骨肿瘤","tagType":3},{"tagName":"强直性脊柱炎","tagType":3},{"tagName":"测试","tagType":3},{"tagName":"结核","tagType":3},{"tagName":"(@葡萄糖粉82.5克)葡萄糖粉82.5克(含结晶水）","tagType":2},{"tagName":"(乐友)盐酸帕罗西汀片","tagType":2},{"tagName":"(乐松)洛索洛芬钠贴剂","tagType":2},{"tagName":"(乐沙定)注射用奥沙利铂","tagType":2},{"tagName":"(乐瑞卡)普瑞巴林胶囊","tagType":2},{"tagName":"(乙10%)(Tc-MAA)锝[99mTc]聚合白蛋白注射液","tagType":2},{"tagName":"(乙10%)(万生力克)拉米夫定胶囊","tagType":2},{"tagName":"(乙10%)(东泰)华蟾素胶囊","tagType":2},{"tagName":"(乙10%)(中畅)福多司坦片","tagType":2},{"tagName":"(乙10%)(为快乐)瑞巴派特片","tagType":2},{"tagName":"(乙10%)(乐友)盐酸帕罗西汀片","tagType":2},{"tagName":"(乙10%)(乐松)洛索洛芬钠片","tagType":2},{"tagName":"(乙10%)(乙己苏)注射用生长抑素","tagType":2},{"tagName":"(乙10%)(九唯他)注射用水溶性维生素","tagType":2}]
     */

    private int status;
    private int page;
    private int totalPage;
    private List<RetValueBean> retValue;

    public int getStatus() {
        return status;
    }

    public void setStatus(int status) {
        this.status = status;
    }

    public int getPage() {
        return page;
    }

    public void setPage(int page) {
        this.page = page;
    }

    public int getTotalPage() {
        return totalPage;
    }

    public void setTotalPage(int totalPage) {
        this.totalPage = totalPage;
    }

    public List<RetValueBean> getRetValue() {
        return retValue;
    }

    public void setRetValue(List<RetValueBean> retValue) {
        this.retValue = retValue;
    }

    public static class RetValueBean {
        /**
         * tagName : (甲)(优思弗)熊去氧胆酸胶囊
         * tagType : 2
         */

        private String tagName;
        private int tagType;

        public String getTagName() {
            return tagName;
        }

        public void setTagName(String tagName) {
            this.tagName = tagName;
        }

        public int getTagType() {
            return tagType;
        }

        public void setTagType(int tagType) {
            this.tagType = tagType;
        }
    }
}
