package com.huidr.HuiDrDoctor.module.model;

import com.google.gson.annotations.SerializedName;

import java.util.List;

/**
 * 作者：jlyoua on 2018/12/11 14:40
 * <p>
 * 邮箱：914531679@qq.com
 */

public class UserDInfo {


    /**
     * key : loginKey
     * value : {"id":100062,"mobile":"13600000000","userName":"测试医生2","userIcon":"{{userIcon}}","userSex":1,"userTitle":"主任医生","userJobNumber":"12421","hospitalId":8177,"hospitalName":"复旦大学附属中山医院","departmentId":71,"hospitalDepartment":"肝肿瘤外科","expertise":"{{expertise}}","honor":"嗯嗯计算机三级","fcount":0,"academicActivities":"嗯嗯嗯很喜欢点解点解你妈妈v刚刚好","outpatientTimeList":"[{\"1\":{\"sel\":false},\"2\":{\"sel\":true},\"3\":{\"sel\":true},\"4\":{\"sel\":false},\"5\":{\"sel\":true},\"6\":{\"sel\":false},\"7\":{\"sel\":false}},{\"1\":{\"sel\":true},\"2\":{\"sel\":false},\"3\":{\"sel\":true},\"4\":{\"sel\":false},\"5\":{\"sel\":false},\"6\":{\"sel\":true},\"7\":{\"sel\":true}}]","imPassword":"M7d686215P","jwt":"eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiIxMDAwNjIiLCJleHAiOjE1NDUxMTQyMTcsImlhdCI6MTU0NDUwOTQxNywiQWNjb3VudEluZm8iOnsiaWQiOjEwMDA2MiwibW9iaWxlIjoiMTM2MDAwMDAwMDAiLCJ1c2VySWNvbiI6Int7dXNlckljb259fSIsInVzZXJTZXgiOjEsInVzZXJUeXBlIjoyLCJ1c2VyTmFtZSI6Iua1i-ivleWMu-eUnzIiLCJpbVBhc3N3b3JkIjoiTTdkNjg2MjE1UCIsIm9zTmFtZSI6IkFuZHJvaWQiLCJ2ZXJzaW9uIjoiMS4wIiwidXNlclJvbGUiOlsiUk9MRV9ET0NUT1IiLCJST0xFX1BBVElFTlQiXX19.nZgS-a6KHL_TzxMdiAEAqY_NUSj9NMfinmgXzBydDrc","doctorSearchDate":"2018-12-11 08:00:48","osName":"Android"}
     */

    private String key;
    private ValueBean value;

    public String getKey() {
        return key;
    }

    public void setKey(String key) {
        this.key = key;
    }

    public ValueBean getValue() {
        return value;
    }

    public void setValue(ValueBean value) {
        this.value = value;
    }



    public static class ValueBean {

        private int id;
        private String mobile;
        private String userName;
        private String userIcon;
        private int userSex;
        private String userTitle;
        private String userJobNumber;
        private int hospitalId;
        private String hospitalName;
        private int departmentId;
        private String hospitalDepartment;
        private String expertise;
        private String honor;
        private int fcount;
        private String academicActivities;
        private List<Noon> outpatientTimeList;
        private String imPassword;
        private String jwt;
        private String doctorSearchDate;
        private String osName;

        public int getId() {
            return id;
        }

        public void setId(int id) {
            this.id = id;
        }

        public String getMobile() {
            return mobile;
        }

        public void setMobile(String mobile) {
            this.mobile = mobile;
        }

        public String getUserName() {
            return userName;
        }

        public void setUserName(String userName) {
            this.userName = userName;
        }

        public String getUserIcon() {
            return userIcon;
        }

        public void setUserIcon(String userIcon) {
            this.userIcon = userIcon;
        }

        public List<Noon> getOutpatientTimeList() {
            return outpatientTimeList;
        }

        public void setOutpatientTimeList(List<Noon> outpatientTimeList) {
            this.outpatientTimeList = outpatientTimeList;
        }

        public int getUserSex() {
            return userSex;
        }

        public void setUserSex(int userSex) {
            this.userSex = userSex;
        }

        public String getUserTitle() {
            return userTitle;
        }

        public void setUserTitle(String userTitle) {
            this.userTitle = userTitle;
        }

        public String getUserJobNumber() {
            return userJobNumber;
        }

        public void setUserJobNumber(String userJobNumber) {
            this.userJobNumber = userJobNumber;
        }

        public int getHospitalId() {
            return hospitalId;
        }

        public void setHospitalId(int hospitalId) {
            this.hospitalId = hospitalId;
        }

        public String getHospitalName() {
            return hospitalName;
        }

        public void setHospitalName(String hospitalName) {
            this.hospitalName = hospitalName;
        }

        public int getDepartmentId() {
            return departmentId;
        }

        public void setDepartmentId(int departmentId) {
            this.departmentId = departmentId;
        }

        public String getHospitalDepartment() {
            return hospitalDepartment;
        }

        public void setHospitalDepartment(String hospitalDepartment) {
            this.hospitalDepartment = hospitalDepartment;
        }

        public String getExpertise() {
            return expertise;
        }

        public void setExpertise(String expertise) {
            this.expertise = expertise;
        }

        public String getHonor() {
            return honor;
        }

        public void setHonor(String honor) {
            this.honor = honor;
        }

        public int getFcount() {
            return fcount;
        }

        public void setFcount(int fcount) {
            this.fcount = fcount;
        }

        public String getAcademicActivities() {
            return academicActivities;
        }

        public void setAcademicActivities(String academicActivities) {
            this.academicActivities = academicActivities;
        }



        public String getImPassword() {
            return imPassword;
        }

        public void setImPassword(String imPassword) {
            this.imPassword = imPassword;
        }

        public String getJwt() {
            return jwt;
        }

        public void setJwt(String jwt) {
            this.jwt = jwt;
        }

        public String getDoctorSearchDate() {
            return doctorSearchDate;
        }

        public void setDoctorSearchDate(String doctorSearchDate) {
            this.doctorSearchDate = doctorSearchDate;
        }

        public String getOsName() {
            return osName;
        }

        public void setOsName(String osName) {
            this.osName = osName;
        }
    }
}


class Noon {
    @SerializedName("1")
    private MonDay _$1;
    @SerializedName("2")
    private TuesDay _$2;
    @SerializedName("3")
    private ThirdDay _$3;
    @SerializedName("4")
    private ThursDay _$4;
    @SerializedName("5")
    private FriDay _$5;
    @SerializedName("6")
    private SaturDay _$6;
    @SerializedName("7")
    private SunDay _$7;

    public MonDay get_$1() {
        return _$1;
    }

    public void set_$1(MonDay _$1) {
        this._$1 = _$1;
    }

    public TuesDay get_$2() {
        return _$2;
    }

    public void set_$2(TuesDay _$2) {
        this._$2 = _$2;
    }

    public ThirdDay get_$3() {
        return _$3;
    }

    public void set_$3(ThirdDay _$3) {
        this._$3 = _$3;
    }

    public ThursDay get_$4() {
        return _$4;
    }

    public void set_$4(ThursDay _$4) {
        this._$4 = _$4;
    }

    public FriDay get_$5() {
        return _$5;
    }

    public void set_$5(FriDay _$5) {
        this._$5 = _$5;
    }

    public SaturDay get_$6() {
        return _$6;
    }

    public void set_$6(SaturDay _$6) {
        this._$6 = _$6;
    }

    public SunDay get_$7() {
        return _$7;
    }

    public void set_$7(SunDay _$7) {
        this._$7 = _$7;
    }

    public static class MonDay {
        /**
         * sel : false
         */

        private boolean sel;

        public boolean isSel() {
            return sel;
        }

        public void setSel(boolean sel) {
            this.sel = sel;
        }
    }

    public static class TuesDay {
        /**
         * sel : true
         */

        private boolean sel;

        public boolean isSel() {
            return sel;
        }

        public void setSel(boolean sel) {
            this.sel = sel;
        }
    }

    public static class ThirdDay {
        /**
         * sel : true
         */

        private boolean sel;

        public boolean isSel() {
            return sel;
        }

        public void setSel(boolean sel) {
            this.sel = sel;
        }
    }

    public static class ThursDay {
        /**
         * sel : false
         */

        private boolean sel;

        public boolean isSel() {
            return sel;
        }

        public void setSel(boolean sel) {
            this.sel = sel;
        }
    }

    public static class FriDay {
        /**
         * sel : true
         */

        private boolean sel;

        public boolean isSel() {
            return sel;
        }

        public void setSel(boolean sel) {
            this.sel = sel;
        }
    }

    public static class SaturDay {
        /**
         * sel : false
         */

        private boolean sel;

        public boolean isSel() {
            return sel;
        }

        public void setSel(boolean sel) {
            this.sel = sel;
        }
    }

    public static class SunDay {
        /**
         * sel : false
         */

        private boolean sel;

        public boolean isSel() {
            return sel;
        }

        public void setSel(boolean sel) {
            this.sel = sel;
        }
    }
    // outpatientTimeList : [{"1":{"sel":false},"2":{"sel":true},"3":{"sel":true},"4":{"sel":false},"5":{"sel":true},"6":{"sel":false},"7":{"sel":false}},{"1":{"sel":true},"2":{"sel":false},"3":{"sel":true},"4":{"sel":false},"5":{"sel":false},"6":{"sel":true},"7":{"sel":true}}]

}