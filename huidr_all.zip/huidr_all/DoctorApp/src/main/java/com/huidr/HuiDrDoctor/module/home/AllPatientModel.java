package com.huidr.HuiDrDoctor.module.home;

import java.util.List;

/**
 * @author: Administrator
 * @date: 2019-11-22
 */
public class AllPatientModel {


    /**
     * status : 0
     * page : 1
     * totalPage : 301
     * retValue : [{"id":62444,"userName":"沈凤贞","userSex":2,"latelyAdmitNo":"1190998","latelyBed":"119","latelyAdmissionDiagnosis":"肝恶性肿瘤(综合治疗)","latelyDischargeTime":"2019-04-16","latelyVisitingDate":"2019-04-15","doctorId":100166,"followupName":"肝切除模板","isFollow":true},{"id":68541,"userName":"董莲","userSex":2,"doctorId":100166,"isFollow":true},{"id":49037,"userName":"安明开","userSex":1,"latelyAdmitNo":"467442","latelyBed":"8","latelyAdmissionDiagnosis":"肝占位性病变","latelyDischargeDiagnosis":"胃癌肝转移","latelyDischargeTime":"2015-12-30","latelyVisitingDate":"2018-01-02","doctorId":100136,"followupName":"肝切除模板","isFollow":true},{"id":48031,"userName":"安建华","userSex":1,"latelyAdmitNo":"958991","latelyBed":"40","latelyAdmissionDiagnosis":"肝继发恶性肿瘤","latelyDischargeDiagnosis":"直肠癌肝转移","latelyDischargeTime":"2016-04-11","latelyVisitingDate":"2016-05-19","doctorId":100136,"followupName":"肝切除模板","isFollow":true},{"id":48639,"userName":"安正非","userSex":1,"latelyAdmitNo":"891202","latelyBed":"23","latelyAdmissionDiagnosis":"肝占位性病变","latelyDischargeDiagnosis":"原发性肝癌","latelyDischargeTime":"2015-02-18","latelyVisitingDate":"2015-02-10","doctorId":100136,"followupName":"肝切除模板","isFollow":false},{"id":51024,"userName":"阿斯木古力·吐尔孙","userSex":2,"latelyAdmitNo":"1166876","latelyBed":"122","latelyAdmissionDiagnosis":"肝肿瘤切除术后","latelyDischargeDiagnosis":"肝肿瘤切除术后","latelyDischargeTime":"2018-12-14","latelyVisitingDate":"2018-12-05","doctorId":100136,"followupName":"肝切除模板","isFollow":false},{"id":52527,"userName":"敖福寿","userSex":1,"latelyAdmitNo":"1006040","latelyBed":"57","latelyAdmissionDiagnosis":"肝恶性肿瘤,梗阻性黄疸,睡眠障碍","latelyDischargeDiagnosis":"肝恶性肿瘤,梗阻性黄疸,睡眠障碍","latelyDischargeTime":"2018-12-03","latelyVisitingDate":"2018-11-19","doctorId":100137,"followupName":"肝切除模板","isFollow":false},{"id":58573,"userName":"艾可可","userSex":2,"latelyAdmitNo":"1024852","latelyBed":"36","latelyAdmissionDiagnosis":"腮腺肿瘤术后感染","latelyDischargeDiagnosis":"腮腺肿瘤术后感染","latelyDischargeTime":"2017-03-20","latelyVisitingDate":"2017-11-07","doctorId":100157,"isFollow":false},{"id":48936,"userName":"白强","userSex":1,"latelyAdmitNo":"1153553","latelyBed":"105","latelyAdmissionDiagnosis":"乙肝后肝硬化","latelyDischargeDiagnosis":"乙肝后肝硬化","latelyDischargeTime":"2018-10-17","latelyVisitingDate":"2018-10-12","doctorId":100136,"isFollow":false},{"id":48999,"userName":"包兆明","userSex":1,"latelyAdmitNo":"963637","latelyBed":"12","latelyAdmissionDiagnosis":"肝占位性病变","latelyDischargeDiagnosis":"肝占位性病变","latelyDischargeTime":"2016-05-05","latelyVisitingDate":"2016-08-27","doctorId":100136,"followupName":"肝切除模板","isFollow":true},{"id":49507,"userName":"布云比丽格","userSex":2,"latelyAdmitNo":"916980","latelyBed":"22","latelyAdmissionDiagnosis":"肝占位性病变","latelyDischargeDiagnosis":"肝脏恶性肿瘤（继发性）","latelyDischargeTime":"2015-08-10","latelyVisitingDate":"2015-08-12","doctorId":100136,"followupName":"肝切除模板","isFollow":true},{"id":49606,"userName":"卞亮明","userSex":1,"latelyAdmitNo":"993614","latelyBed":"3","latelyAdmissionDiagnosis":"肝占位性病变,肝占位性病变","latelyDischargeDiagnosis":"肝恶性肿瘤","latelyDischargeTime":"2016-10-06","latelyVisitingDate":"2017-12-07","doctorId":100136,"followupName":"肝切除模板","isFollow":true},{"id":49735,"userName":"鲍洪立","userSex":1,"latelyAdmitNo":"1145062","latelyBed":"105","latelyAdmissionDiagnosis":"胃MT术后多发MET","latelyDischargeTime":"2019-04-19","latelyVisitingDate":"2019-04-19","doctorId":100136,"isFollow":true},{"id":49869,"userName":"柏晓丹","userSex":2,"latelyAdmitNo":"1016511","latelyBed":"10","latelyAdmissionDiagnosis":"肝囊肿,胆囊结石","latelyDischargeDiagnosis":"肝囊肿，胆囊结石","latelyDischargeTime":"2017-01-22","latelyVisitingDate":"2017-01-16","doctorId":100136,"isFollow":false},{"id":50152,"userName":"鲍文秀","userSex":2,"latelyAdmitNo":"1106445","latelyBed":"21","latelyAdmissionDiagnosis":"肝恶性肿瘤,双下肢乏力待查,高血压","latelyDischargeDiagnosis":"肝恶性肿瘤术后","latelyDischargeTime":"2018-04-08","latelyVisitingDate":"2019-02-20","doctorId":100136,"followupName":"肝切除模板","isFollow":false},{"id":50160,"userName":"卞有成","userSex":1,"latelyAdmitNo":"1010559","latelyBed":"19","latelyAdmissionDiagnosis":"肝占位性病变","latelyDischargeDiagnosis":"肠癌肝转移","latelyDischargeTime":"2016-12-30","latelyVisitingDate":"2017-09-07","doctorId":100136,"followupName":"肝切除模板","isFollow":false},{"id":50259,"userName":"白淑兰","userSex":2,"latelyAdmitNo":"982567","latelyBed":"23","latelyAdmissionDiagnosis":"肝占位性病变","latelyDischargeDiagnosis":"肝右叶MT","latelyDischargeTime":"2016-08-12","latelyVisitingDate":"2016-09-01","doctorId":100136,"followupName":"肝切除模板","isFollow":false},{"id":50450,"userName":"包福根","userSex":1,"latelyAdmitNo":"1007076","latelyBed":"21","latelyAdmissionDiagnosis":"肝恶性肿瘤(综合治疗),2型糖尿病,高血压病,冠状动脉粥样硬化性心脏病","latelyDischargeDiagnosis":"肝恶性肿瘤(综合治疗),2型糖尿病,高血压病,冠状动脉粥样硬化性心脏病","latelyDischargeTime":"2017-03-21","latelyVisitingDate":"2017-02-04","doctorId":100136,"followupName":"肝切除模板","isFollow":false},{"id":50541,"userName":"鲍林英","userSex":2,"latelyAdmitNo":"1102709","latelyBed":"106","latelyAdmissionDiagnosis":"胆管恶性肿瘤","latelyDischargeDiagnosis":"胆管恶性肿瘤,肝恶性肿瘤,梗阻性黄疸,胆囊切除术后状态","latelyDischargeTime":"2018-04-16","latelyVisitingDate":"2019-01-30","doctorId":100136,"followupName":"肝切除模板","isFollow":false},{"id":50706,"userName":"包长林","userSex":1,"latelyAdmitNo":"769673","latelyBed":"122","latelyAdmissionDiagnosis":"肝占位性病变,肝占位性病变,肝占位性病变","latelyDischargeDiagnosis":"原发性肝癌","latelyDischargeTime":"2015-07-05","latelyVisitingDate":"2018-12-28","doctorId":100136,"followupName":"肝切除模板","isFollow":false}]
     */

    private int status;
    private int page;
    private int totalPage;
    private List<RetValueBean> retValue;

    public int getStatus() {
        return status;
    }

    public void setStatus(int status) {
        this.status = status;
    }

    public int getPage() {
        return page;
    }

    public void setPage(int page) {
        this.page = page;
    }

    public int getTotalPage() {
        return totalPage;
    }

    public void setTotalPage(int totalPage) {
        this.totalPage = totalPage;
    }

    public List<RetValueBean> getRetValue() {
        return retValue;
    }

    public void setRetValue(List<RetValueBean> retValue) {
        this.retValue = retValue;
    }



    public static class RetValueBean {
        /**
         * id : 62444
         * userName : 沈凤贞
         * userSex : 2
         * latelyAdmitNo : 1190998
         * latelyBed : 119
         * latelyAdmissionDiagnosis : 肝恶性肿瘤(综合治疗)
         * latelyDischargeTime : 2019-04-16
         * latelyVisitingDate : 2019-04-15
         * doctorId : 100166
         * followupName : 肝切除模板
         * isFollow : true
         * latelyDischargeDiagnosis : 胃癌肝转移
         */

        private int id;
        private String userName;
        private int userSex;
        private String latelyAdmitNo;
        private String latelyBed;
        private String latelyAdmissionDiagnosis;
        private String latelyDischargeTime;
        private String latelyVisitingDate;
        private int doctorId;
        private String followupName;
        private boolean isFollow;
        private String latelyDischargeDiagnosis;

        public boolean isFollow() {
            return isFollow;
        }

        public void setFollow(boolean follow) {
            isFollow = follow;
        }

        public String getBindUserRelationship() {
            return bindUserRelationship;
        }

        public void setBindUserRelationship(String bindUserRelationship) {
            this.bindUserRelationship = bindUserRelationship;
        }

        private String bindUserRelationship;


        public int getId() {
            return id;
        }

        public void setId(int id) {
            this.id = id;
        }

        public String getUserName() {
            return userName;
        }

        public void setUserName(String userName) {
            this.userName = userName;
        }

        public int getUserSex() {
            return userSex;
        }

        public void setUserSex(int userSex) {
            this.userSex = userSex;
        }

        public String getLatelyAdmitNo() {
            return latelyAdmitNo;
        }

        public void setLatelyAdmitNo(String latelyAdmitNo) {
            this.latelyAdmitNo = latelyAdmitNo;
        }

        public String getLatelyBed() {
            return latelyBed;
        }

        public void setLatelyBed(String latelyBed) {
            this.latelyBed = latelyBed;
        }

        public String getLatelyAdmissionDiagnosis() {
            return latelyAdmissionDiagnosis;
        }

        public void setLatelyAdmissionDiagnosis(String latelyAdmissionDiagnosis) {
            this.latelyAdmissionDiagnosis = latelyAdmissionDiagnosis;
        }

        public String getLatelyDischargeTime() {
            return latelyDischargeTime;
        }

        public void setLatelyDischargeTime(String latelyDischargeTime) {
            this.latelyDischargeTime = latelyDischargeTime;
        }

        public String getLatelyVisitingDate() {
            return latelyVisitingDate;
        }

        public void setLatelyVisitingDate(String latelyVisitingDate) {
            this.latelyVisitingDate = latelyVisitingDate;
        }

        public int getDoctorId() {
            return doctorId;
        }

        public void setDoctorId(int doctorId) {
            this.doctorId = doctorId;
        }

        public String getFollowupName() {
            return followupName;
        }

        public void setFollowupName(String followupName) {
            this.followupName = followupName;
        }

        public boolean isIsFollow() {
            return isFollow;
        }

        public void setIsFollow(boolean isFollow) {
            this.isFollow = isFollow;
        }

        public String getLatelyDischargeDiagnosis() {
            return latelyDischargeDiagnosis;
        }

        public void setLatelyDischargeDiagnosis(String latelyDischargeDiagnosis) {
            this.latelyDischargeDiagnosis = latelyDischargeDiagnosis;
        }
    }
}
