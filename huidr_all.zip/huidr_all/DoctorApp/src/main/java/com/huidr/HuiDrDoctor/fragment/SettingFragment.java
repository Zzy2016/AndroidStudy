package com.huidr.HuiDrDoctor.fragment;

import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Matrix;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Message;
import android.provider.MediaStore;
import androidx.core.content.FileProvider;
import android.util.Log;
import android.view.Display;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.CompoundButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.PopupWindow;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.google.gson.Gson;
import com.huidr.Feedback.HuiyiAssistantActivity;
import com.huidr.HuiDrDoctor.activity.FastReplyActivity;
import com.huidr.HuiDrDoctor.activity.ShowCodeActivity;
import com.huidr.HuiDrDoctor.activity.WebActivity;
import com.huidr.HuiDrDoctor.activity.main.Consult.utils.PostAndGet;
import com.huidr.HuiDrDoctor.debug.BuildConfig;
import com.huidr.HuiDrDoctor.debug.R;
import com.huidr.HuiDrDoctor.module.H5UserInfo;
import com.huidr.HuiDrDoctor.module.home.FastLoginModel;
import com.huidr.HuiDrDoctor.module.home.SimpleResultModel;
import com.huidr.HuiDrDoctor.module.model.LoginResult;
import com.huidr.HuiDrDoctor.util.CircleImageView;
import com.huidr.HuiDrDoctor.util.LogUtil;
import com.huidr.HuiDrDoctor.util.ThreadPoolManager;
import com.huidr.lib.commom.base.BaseFragment;
import com.tendcloud.tenddata.TCAgent;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;

import jiguang.chat.utils.oss.Constants;
import jiguang.chat.utils.oss.OssService;
import jiguang.chat.utils.oss.SharedPreferenciesUtil;

import static android.app.Activity.RESULT_OK;


/**
 * onCreate
 * onCreateView
 * <p>
 * onStart
 * onResume
 * <p>
 * 我的设置页面
 * 头像  二维码
 * 医生信息展示
 * 点击跳转
 * <p>
 * 13636388572  100137/doctor/1575943546901.png
 * 此电脑\HUAWEI nova 3e\内部存储\com.huidr.HuiDrDoctor.debug\img\head\system\doctor\81777-455-45.jpg
 * 此电脑\vivo X21A\内部存储设备\com.huidr.HuiDrDoctor.debug\img\head\system\doctor
 */
public class SettingFragment extends BaseFragment implements View.OnClickListener {

    private Context context;
    private TextView tvDoctorName;
    private TextView tvDoctorTitle;
    private TextView tvDoctorHos;
    private CircleImageView imageDoctorHead;
    private ImageView imageViewCode;
    private LinearLayout llAccount, llReceive, llCollect, llHelp, llSetting;

    private TextView tvState;
    private Switch swOpenFollowup;
    private ImageView imgVisit;

    private TextView tvPage;

    private String access_token;
    private H5UserInfo loginResult;//登录保存信息
    private Gson gson;
    private String userInfoStr;
    boolean visitIsOpen;//随访开关
    private PopupWindow popupWindow;
    private TextView btnPopupAlbum;
    private TextView btnPopupCamera;
    private TextView btnPopupCancel;

    //相册请求码
    private static final int ALBUM_REQUEST_CODE = 1;
    //相机请求码
    private static final int CAMERA_REQUEST_CODE = 2;
    //剪裁请求码
    private static final int CROP_SMALL_PICTURE = 3;
    //调用照相机返回图片文件
    private File tempFile;
    //最后显示的图片文件
    private String mFile;
    //头像文件夹
    private String headPath;   //截图保存地址的前一部分
    //    存储地址   截图保存
    private String upLoadPath;
    private String doctorId;
    //上传地址
    private String userIconPath;  //上传oss 的文件夹
    private ByteArrayOutputStream byteArrayOutputStream;
    private Matrix matrix;
    private long lastClick = 0;
    private Bitmap bitmap;
    private File file;
    private FastLoginModel fastLoginModel;

    /*
     *
     * 更换医生头像
     *
     * 更换成功之后会返回 新的医生信息
     * */
    public void upLoadImg() {
        ThreadPoolManager.getInstance().execute(new Runnable() {
            @Override
            public void run() {
                String path = BuildConfig.baseUrl + "hospital/doctorSetting/updateUserIcon";
                JSONObject jsonObject = new JSONObject();


                String path1 = (String) SharedPreferenciesUtil.getData("userIcon", "0");
                LogUtil.e("更换头像", path1);
                jsonObject.put("uid", doctorId);
                jsonObject.put("userIcon", path1);
                String result = PostAndGet.doHttpPost(path, jsonObject);

                LogUtil.e("用户头像", result);
                if (result.equals("网络异常")) {
                    SharedPreferenciesUtil.putData("userIcon", "0");
                } else {
                    LoginResult loginResult1 = gson.fromJson(result, LoginResult.class);
                    if (loginResult1.getStatus() == 0) {
                        SharedPreferenciesUtil.putData("userIcon", loginResult1.getRetValue().getUserIcon());

                    } else {
                        SharedPreferenciesUtil.putData("userIcon", "0");
                    }
                }
            }
        });
    }

    //裁剪后的地址
    public String getPath() {
        //resize image to thumb
        if (mFile == null) {
            mFile = headPath + doctorId + "/doctor/" + System.currentTimeMillis() + ".png";
            upLoadPath = mFile.substring(headPath.length());
            SharedPreferenciesUtil.putData("userIcon", upLoadPath);
            LogUtil.e("头像路径1  sh", upLoadPath);
        }
        return mFile;
    }


    /*
     * 读取  解析 医生登录之后保存的信息
     *
     * */
    @Override
    protected void initData() {
        Log.e("setting----->", "initData");
        getFollowInfo();
        byteArrayOutputStream = new ByteArrayOutputStream();
        gson = new Gson();
        fastLoginModel = new FastLoginModel();
        userInfoStr = (String) SharedPreferenciesUtil.getData(Constants.SharedAccountConfig.USER_DOCTOR_INFO, "1");
        Log.e("医生信息", userInfoStr);
        loginResult = new H5UserInfo();
        loginResult = gson.fromJson(userInfoStr, H5UserInfo.class);
        doctorId = loginResult.getValue().getId() + "";
        headPath = Environment.getExternalStorageDirectory() + "/" + context.getPackageName() + "/img/head/";
    }

    @Override
    public void onResume() {
        super.onResume();
        Log.e("setting----->", "onResume");

        userIconPath = (String) SharedPreferenciesUtil.getData("userIcon", "0");


        Log.e("head1",userIconPath);
        if (userIconPath.equals("0")) {
            userIconPath = loginResult.getValue().getUserIcon();
        } else {
            
        }
        Log.e("head2",userIconPath);

        if (userIconPath.equals("")) {
            imageDoctorHead.setBackgroundResource(R.drawable.nantou);
        } else {


            file = new File(headPath + userIconPath);
            if (file.exists()) {
                bitmap = BitmapFactory.decodeFile(file.getAbsolutePath());
                if (bitmap != null) {
                    imageDoctorHead.setImageBitmap(bitmap);
                } else {
                    imageDoctorHead.setBackgroundResource(R.drawable.nantou);
                }
            } else {
                ThreadPoolManager.getInstance().execute(new Runnable() {
                    @Override
                    public void run() {
                        OssService ossService = new OssService(getActivity());
                        bitmap = ossService.downHeadImageSyc(userIconPath);

                        if (bitmap != null) {

                            if (!file.getParentFile().exists()) {
                                file.getParentFile().mkdirs();
                            }
                            handler.sendEmptyMessage(1);
                            try {
                                file.createNewFile();
                                FileOutputStream fileOutputStream = new FileOutputStream(file);
                                bitmap.compress(Bitmap.CompressFormat.PNG, 100, fileOutputStream);
                                fileOutputStream.flush();

                            } catch (Exception e) {

                            }
                        } else {
                            handler.sendEmptyMessage(0);
                        }
                    }
                });
            }
        }
    }


    Handler handler = new Handler() {
        @Override
        public void handleMessage(Message msg) {
            super.handleMessage(msg);
            switch (msg.what) {
                case 0://没有头像 或者头像加载失败
                    imageDoctorHead.setBackgroundResource(R.drawable.nantou);
                    break;
                case 1://头像加载成功
                    imageDoctorHead.setImageBitmap(bitmap);
                    break;

                case 2://开启
                    imgVisit.setBackgroundResource(R.drawable.visit_open);
                    swOpenFollowup.setChecked(true);
                    tvState.setText("(已开启)");
                    break;

                case 3://关闭

                    showCoopDialog();

                    break;
                case 4:
                    if (visitIsOpen) {
                        imgVisit.setBackgroundResource(R.drawable.visit_open);
                        swOpenFollowup.setChecked(true);
                        tvState.setText("(已开启)");
                    } else {
                        imgVisit.setBackgroundResource(R.drawable.visit_close);
                        swOpenFollowup.setChecked(false);
                        tvState.setText("(已关闭)");
                    }
                    break;
            }
        }
    };


    /**
     * 显示删除协同对话框
     */
    public void showCoopDialog() {

        final Dialog builder = new Dialog(getContext(), R.style.jmui_default_dialog_style);
        //final Dialog builder = new Dialog(this, R.style.jmui_default_dialog_style);
        View view = LayoutInflater.from(getContext()).inflate(R.layout.dialog_content, null);

        TextView tvTitle = view.findViewById(R.id.tv_title);
        TextView tvFooter1 = view.findViewById(R.id.tv_footer1);
        TextView tvFooter2 = view.findViewById(R.id.tv_footer2);

        tvTitle.setText("是否关闭患者随访报到，关闭后将无法收到患者的报到");


//        取消
        tvFooter1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                builder.cancel();
                swOpenFollowup.setChecked(true);
            }
        });
//确定  关闭随访报到
        tvFooter2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                builder.cancel();
                imgVisit.setBackgroundResource(R.drawable.visit_close);
                swOpenFollowup.setChecked(false);
                tvState.setText("(已关闭)");
            }
        });

        builder.setContentView(view);
        //builder.setCanceledOnTouchOutside(true);
        builder.show();
        Window window = builder.getWindow();
        WindowManager.LayoutParams lp = window.getAttributes();
        WindowManager windowManager = getActivity().getWindowManager();
        Display display = windowManager.getDefaultDisplay();
        lp.width = (int) (display.getWidth() * 0.7);
//        lp.height = (int) (display.getHeight() * 0.1);
        window.setAttributes(lp);
    }

    /*获取医生随访信息*/
    public void getFollowInfo() {

        ThreadPoolManager.getInstance().execute(new Runnable() {
            @Override
            public void run() {
                String path = BuildConfig.baseUrl + "hospital/doctorUser/fastLogin";
                SharedPreferences sPreferences = context.getSharedPreferences("updateDownload", 0);
                String nowVersion = sPreferences.getString("version", "0");
                JSONObject jsonObject = new JSONObject();
                jsonObject.put("osName", "Android");
                jsonObject.put("version", nowVersion);
                String result = PostAndGet.doHttpPost(path, jsonObject);
                Log.e("医生信息--", result);
                if (result.equals("")) {

                } else if(result.equals("网络异常")){

                }else {
                    fastLoginModel = gson.fromJson(result, FastLoginModel.class);

                    if(fastLoginModel.getStatus()==0){
                        visitIsOpen = fastLoginModel.getRetValue().isIsFollowup();
                        handler.sendEmptyMessage(4);
                    }

                }
            }
        });
    }


    @Override
    protected View setContentView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_setting, container, false);
        return view;
    }


    @Override
    protected void findView(View parent) {
        initView(parent);


//        头像选择popwindow  控件绑定设置监听
        View view = LayoutInflater.from(getContext()).inflate(R.layout.pop_layout, null);
        popupWindow = new PopupWindow(view, ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT, true);
        popupWindow.setOutsideTouchable(true);
        btnPopupAlbum = view.findViewById(R.id.btn_album);
        btnPopupCamera = view.findViewById(R.id.btn_camera);
        btnPopupCancel = view.findViewById(R.id.btn_cancel);

        btnPopupAlbum.setOnClickListener(popClick);
        btnPopupCamera.setOnClickListener(popClick);
        btnPopupCancel.setOnClickListener(popClick);
    }


    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        context = getActivity();
        matrix = new Matrix();
        matrix.setRotate(90);
        getAccessToken();
    }


    /*
     * 初始化控件 绑定监听  页面内直接显示  /100167/doctor/1575339573210.png
     * */
    public void initView(View view) {

        tvDoctorName = view.findViewById(R.id.tv_doctor_name);
        tvDoctorTitle = view.findViewById(R.id.tv_doctor_title);
        tvDoctorHos = view.findViewById(R.id.tv_doctor_hos);
        imageDoctorHead = view.findViewById(R.id.image_doctor_head);
        imageViewCode = view.findViewById(R.id.image_code);
        llAccount = view.findViewById(R.id.ll_account);
        llReceive = view.findViewById(R.id.ll_receive);
        llCollect = view.findViewById(R.id.ll_collect);
        llHelp = view.findViewById(R.id.ll_help);
        llSetting = view.findViewById(R.id.ll_setting);

        tvState = view.findViewById(R.id.tv_state);
        swOpenFollowup = view.findViewById(R.id.sw_open_followup);
        imgVisit = view.findViewById(R.id.img_visit);

        tvPage = view.findViewById(R.id.tv_page);

        tvPage.setOnClickListener(this);

        llAccount.setOnClickListener(this);
        llReceive.setOnClickListener(this);
        llCollect.setOnClickListener(this);
        llHelp.setOnClickListener(this);
        llSetting.setOnClickListener(this);

        imageViewCode.setOnClickListener(this);

        tvDoctorName.setOnClickListener(this);
        tvDoctorHos.setOnClickListener(this);
        tvDoctorTitle.setOnClickListener(this);

        tvDoctorName.setText(loginResult.getValue().getUserName());
        tvDoctorTitle.setText(loginResult.getValue().getUserTitle());
        tvDoctorHos.setText(loginResult.getValue().getHospitalName() + "/" + loginResult.getValue().getHospitalDepartment());
        imageDoctorHead.setOnClickListener(imageClick);

        swOpenFollowup.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                modifyFollowUp(isChecked);
            }
        });

    }


    /*
     * 开启 关闭随访报到
     * */
    public void modifyFollowUp(final boolean isOpen) {
        ThreadPoolManager.getInstance().execute(new Runnable() {
            @Override
            public void run() {
                String path = BuildConfig.baseUrl + "hospital/doctorUser/operationFollowup?isFollowup=" + isOpen;
                String result = PostAndGet.doGetHttp(path);

                Log.e("随访报到", result);
                if (result.equals("网络异常")) {

                } else {
                    SimpleResultModel simpleResultModel = gson.fromJson(result, SimpleResultModel.class);
                    if (simpleResultModel.getStatus() == 0) {
                        if (isOpen) {
                            handler.sendEmptyMessage(2);//开启
                        } else {
                            handler.sendEmptyMessage(3);//关闭
                        }

                    }
                }
            }
        });
    }

    /*
     * 点击头像  选择头像选择框
     * */
    public View.OnClickListener imageClick = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            TCAgent.onEvent(getContext(), "头像的点击次数 ", "头像的点击次数 ");
            popupWindow.showAsDropDown(imageDoctorHead);
        }
    };


    /*
     * popupwindow 点击事件
     */
    private View.OnClickListener popClick = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            switch (v.getId()) {
                case R.id.btn_album:
                    Intent photoPickerIntent = new Intent(Intent.ACTION_PICK);
                    photoPickerIntent.setType("image/*");
                    getActivity().startActivityForResult(photoPickerIntent, ALBUM_REQUEST_CODE);
                    popupWindow.dismiss();
                    break;
                case R.id.btn_camera:
                    tempFile = new File(context.getExternalFilesDir("").getAbsoluteFile() + "/img/" + System.currentTimeMillis() + ".png");
                    if (!tempFile.getParentFile().exists()) {
                        tempFile.getParentFile().mkdirs();
                    }
                    if (!tempFile.exists()) {
                        try {
                            tempFile.createNewFile();
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                    }
                    //跳转到调用系统相机
                    Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
                    //判断版本
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {   //如果在Android7.0以上,使用FileProvider获取Uri
                        intent.setFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
                        Uri contentUri = FileProvider.getUriForFile(getContext(), context.getPackageName() + ".fileprovider", tempFile);
                        intent.putExtra(MediaStore.EXTRA_OUTPUT, contentUri);
                    } else {    //否则使用Uri.fromFile(file)方法获取Uri
                        intent.putExtra(MediaStore.EXTRA_OUTPUT, Uri.fromFile(tempFile));
                    }
                    getActivity().startActivityForResult(intent, CAMERA_REQUEST_CODE);
                    popupWindow.dismiss();
                    break;
                case R.id.btn_cancel:
                    popupWindow.dismiss();
                    break;
            }
        }
    };


    /*
     * 拍照、相册、裁剪回调事件
     *
     * */
    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        switch (requestCode) {
            case 1:  //相册
                if (resultCode == RESULT_OK) {
                    Uri uri = data.getData();
                    startPhotoZoom(uri); // 开始对图片进行裁剪处理
                }
                break;
            case 2://拍照
                if (resultCode == RESULT_OK) {
                    //用相机返回的照片去调用剪裁也需要对Uri进行处理
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                        Uri contentUri = FileProvider.getUriForFile(getContext(), context.getPackageName() + ".fileprovider", tempFile);
                        startPhotoZoom(contentUri);//开始对图片进行裁剪处理
                    } else {
                        startPhotoZoom(Uri.fromFile(tempFile));//开始对图片进行裁剪处理
                    }
                }
                break;
            case 3://剪切
                LogUtil.e("onResume", "剪切" + userIconPath);
                Log.e("上传",userIconPath);
                upLoadImg();
                OssService ossService = new OssService(getActivity());

                ossService.asyncPutImage(userIconPath, headPath + userIconPath);
                break;
        }

    }


    /**
     * 裁剪图片方法实现
     *
     * @param uri
     */
    protected void startPhotoZoom(Uri uri) {
        if (uri == null) {
            Log.i("tag", "The uri is not exist.");
        }
//        tempUri = uri;
        Intent intent = new Intent("com.android.camera.action.CROP");
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        intent.addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
        intent.setDataAndType(uri, "image/*");
        // 设置裁剪
        intent.putExtra("crop", "true");
        // aspectX aspectY 是宽高的比例content://com.example.selectimage.FileProvider/images/test/1574305213918.png
        intent.putExtra("aspectX", 1);
        intent.putExtra("aspectY", 1);
        // outputX outputY 是裁剪图片宽高
        intent.putExtra("outputX", 100);
        intent.putExtra("outputY", 100);
        intent.putExtra("return-data", false);
        File out = new File(getPath());
        if (!out.getParentFile().exists()) {
            out.getParentFile().mkdirs();
        }

        if (!out.exists()) {
            try {
                out.createNewFile();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        intent.putExtra(MediaStore.EXTRA_OUTPUT, Uri.fromFile(out));
        getActivity().startActivityForResult(intent, CROP_SMALL_PICTURE);
    }


    /*
     * 点击事件
     *
     * 账户
     * 快捷回复
     * 收藏
     * 会议助手
     * 设置
     * */
    @Override
    public void onClick(View v) {
        Intent intent = new Intent();
        Bundle bundle = null;
        switch (v.getId()) {
            case R.id.ll_account:
                TCAgent.onEvent(getContext(), "我的账户按钮点击情况 ", "我的账户按钮点击情况 ");
                intent.setClass(context, WebActivity.class);
                bundle = new Bundle();
                bundle.putString("url", "myAccount.html");
                intent.putExtras(bundle);
                break;
            case R.id.ll_receive:
                TCAgent.onEvent(getContext(), "快捷回复按钮点击情况 ", "快捷回复按钮点击情况 ");
                intent.setClass(context, FastReplyActivity.class);
                break;
            case R.id.ll_collect:
                TCAgent.onEvent(getContext(), "我的收藏按钮点击情况 ", "我的收藏按钮点击情况 ");

                intent.setClass(context, WebActivity.class);
                bundle = new Bundle();
                bundle.putString("url", "MyCollection.html");
                intent.putExtras(bundle);
                break;
            case R.id.ll_help:
                TCAgent.onEvent(getContext(), "荟医助手按钮点击情况 ", "荟医助手按钮点击情况 ");

                intent.setClass(context, HuiyiAssistantActivity.class);
                break;
            case R.id.ll_setting:
                TCAgent.onEvent(getContext(), "设置按钮点击情况 ", "设置按钮点击情况 ");

                intent.setClass(context, WebActivity.class);
                bundle = new Bundle();
                bundle.putString("url", "MySetting.html");
                intent.putExtras(bundle);
                break;
            case R.id.image_code:

                if (access_token == null || byteArrayOutputStream.toByteArray() == null) {
                    Toast.makeText(getActivity(), "网络错误,请稍候重试~", Toast.LENGTH_SHORT).show();
                } else {
                    intent.setClass(context, ShowCodeActivity.class);
                    bundle = new Bundle();
                    bundle.putString("token", access_token);
                    bundle.putByteArray("image", byteArrayOutputStream.toByteArray());
                    intent.putExtras(bundle);
                }


                break;


            case R.id.tv_page:
                intent.setClass(context, WebActivity.class);
                TCAgent.onEvent(getContext(), "进入医生个人信息资料的次数 ", "进入医生个人信息资料的次数 ");

                bundle = new Bundle();
                bundle.putString("url", "personal.html?id=" + loginResult.getValue().getId());
                intent.putExtras(bundle);
                break;

            case R.id.tv_doctor_name:
//                intent.setClass(context, WebActivity.class);
//                TCAgent.onEvent(getContext(), "进入医生个人信息资料的次数 ", "进入医生个人信息资料的次数 ");
//
//                bundle = new Bundle();
//                bundle.putString("url", "personal.html?id=" + loginResult.getValue().getId());
//                intent.putExtras(bundle);
                break;
            case R.id.tv_doctor_title:
//                intent.setClass(context, WebActivity.class);
//                TCAgent.onEvent(getContext(), "进入医生个人信息资料的次数 ", "进入医生个人信息资料的次数 ");
//                bundle = new Bundle();
//                bundle.putString("url", "personal.html?id=" + loginResult.getValue().getId());
//                intent.putExtras(bundle);
                break;
            case R.id.tv_doctor_hos:
//                intent.setClass(context, WebActivity.class);
//                TCAgent.onEvent(getContext(), "进入医生个人信息资料的次数 ", "进入医生个人信息资料的次数 ");
//                bundle = new Bundle();
//                bundle.putString("url", "personal.html?id=" + loginResult.getValue().getId());
//                intent.putExtras(bundle);
                break;
        }

        if (System.currentTimeMillis() - lastClick > 1000) {
            if (!(intent.getComponent() == null)) {
                startActivity(intent);
            }
            lastClick = System.currentTimeMillis();
        }

    }

    /*
     * 获取二维码access_token
     * */
    public void getAccessToken() {

        ThreadPoolManager.getInstance().execute(new Runnable() {
            @Override
            public void run() {
                String path = "https://api.weixin.qq.com/cgi-bin/token?grant_type=client_credential&appid=wxdd068eab2feb60af&secret=f4e97614b0f37fe3b87e1d91ff246660";

                String result = PostAndGet.doGetHttp(path);
                LogUtil.e("token", result);
                if (result.equals("网络异常")) {

                } else {
                    JSONObject jsonObject = JSON.parseObject(result);
                    LogUtil.e("获取二维码code", result);
                    if (jsonObject.containsKey("access_token")) {
                        access_token = jsonObject.getString("access_token");
                        getCode(access_token);
                    } else {
                        access_token = "";
                    }
                }

            }
        });
    }


    /*
     * 获取二维码图片
     * */
    public void getCode(String token) {
        String path = "https://api.weixin.qq.com/wxa/getwxacodeunlimit?access_token=" + token;
        try {
            URL url = new URL(path);
            HttpURLConnection connection = (HttpURLConnection) url.openConnection();

            JSONObject jsonObject = new JSONObject();
            jsonObject.put("scene", "10086");
            jsonObject.put("page", "pages/login/login");
            connection.setRequestMethod("POST");
            connection.setRequestProperty("Content-Type", "application/json");
            connection.setDoOutput(true);
            connection.setDoInput(true);
            connection.connect();
            OutputStream outputStream = connection.getOutputStream();
            outputStream.write(jsonObject.toString().getBytes());
            outputStream.flush();
            outputStream.close();

            if (connection.getResponseCode() == 200) {
//                FileOutputStream fileOutputStream = new FileOutputStream(file);
                InputStream inputStream = connection.getInputStream();
                try {
                    byte[] buffer = new byte[1024];
                    int len = 0;
                    while ((len = inputStream.read(buffer)) != -1) {
                        byteArrayOutputStream.write(buffer, 0, len);
//                        fileOutputStream.write(buffer);
                    }
                } catch (IOException e) {
                    // TODO Auto-generated catch block
                    e.printStackTrace();
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
            Log.e("we",e.toString());
        }

    }


}

//            File file = new File(headPath + userIconPath);
//            if (file.exists()) {
//                Bitmap bitmap = BitmapFactory.decodeFile(file.getAbsolutePath());
//                if (bitmap != null) {
//                    bitmap = getCirleBitmap(bitmap);
//                    imageDoctorHead.setImageBitmap(bitmap);
//                }
//            } else {
//
//                ThreadPoolManager.getInstance().execute(new Runnable() {
//                    @Override
//                    public void run() {
//
//                    }
//                });
//
//                OssService ossService = new OssService(getActivity());
//                Bitmap bitmap1 = ossService.downImageSyc(userIconPath);
//
//                if (bitmap1 != null) {
//                    if (userIconPath.endsWith("img")) {
//                        bitmap1 = Bitmap.createBitmap(bitmap1, 0, 0, bitmap1.getWidth(), bitmap1.getHeight(), matrix, true);
//                    }
//                    imageDoctorHead.setImageBitmap(bitmap1);
//                    if (!file.getParentFile().exists()) {
//                        file.getParentFile().mkdirs();
//                    }
//                    try {
//                        file.createNewFile();
//                        FileOutputStream fileOutputStream = new FileOutputStream(file);
//                        bitmap1.compress(Bitmap.CompressFormat.PNG, 100, fileOutputStream);
//                        fileOutputStream.flush();
//                    } catch (Exception e) {
//
//                    }
//
//                } else {
//                    LogUtil.e("头像--->", "空");
//                    imageDoctorHead.setBackgroundResource(R.drawable.nantou);
//                }
//            }
