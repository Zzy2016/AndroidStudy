package com.huidr.HuiDrDoctor.module.model;

/**
 * @author: Administrator
 * @date: 2019-11-08
 */
public class LoginResultForH5 {

    /**
     * key : loginKey
     * value : {"id":100137,"mobile":"13600000003","userName":"吴亦凡","userIcon":"system/doctor/8177-71-12310.jpg","userSex":1,"userTitle":"副主任医师","userJobNumber":"12310","hospitalId":8177,"hospitalName":"复旦大学附属中山医院","departmentId":71,"hospitalDepartment":"肝肿瘤外科","expertise":"吃喝完了哦五天","honor":"微积分微博控红包口令卡的好像我也不想吃东西的感觉。我的手机没电啦？我在外面等你们来吃饭吗？我在外面玩的开心的是一天了、一个人的生活方式就是这样一种","fabulousCount":5,"isFabulous":false,"academicActivities":"后送柠檬公告拟命名为全国省级重点文物保护工作人员的重要组成部分？我们的生活方式是什么意思，的一一一一解答，饿了就去医院了您也不能这样了。Dior is the day you get to the gym and get to the gym and and get then to to go get to some the point kids of are the being，我们的生活方式是什么意思，，我们的生活方式是什么意思，，我们的生活方式是什么意思，，我们的生活方式是什么意思，我们的生活方式uu\u2006u","outpatientTimeList":"[{\"1\":{\"sel\":true},\"2\":{\"sel\":true},\"3\":{\"sel\":true},\"4\":{\"sel\":true},\"5\":{\"sel\":true},\"6\":{\"sel\":true},\"7\":{\"sel\":true}},{\"1\":{\"sel\":true},\"2\":{\"sel\":true},\"3\":{\"sel\":false},\"4\":{\"sel\":true},\"5\":{\"sel\":false},\"6\":{\"sel\":false},\"7\":{\"sel\":false}}]","imPassword":"1Pc783982J","isSetLoginPassword":false,"jwt":"eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiIxMDAxMzciLCJleHAiOjE1NzM4MDg2NjgsImlhdCI6MTU3MzIwMzg2OCwiQWNjb3VudEluZm8iOnsiaWQiOjEwMDEzNywibW9iaWxlIjoiMTM2MDAwMDAwMDMiLCJsb2dpbk5hbWUiOiI4MTc3XzEyMzEwIiwidXNlckljb24iOiJzeXN0ZW0vZG9jdG9yLzgxNzctNzEtMTIzMTAuanBnIiwidXNlclNleCI6MSwidXNlclR5cGUiOjIsInVzZXJOYW1lIjoi5ZC05Lqm5YehIiwiaW1QYXNzd29yZCI6IjFQYzc4Mzk4MkoiLCJpc1NldExvZ2luUGFzc3dvcmQiOmZhbHNlLCJvc05hbWUiOiJBbmRyb2lkIiwibGFzdExvZ2luVGltZSI6IjIwMTktMTEtMDggMTc6MDQ6MjgiLCJ2ZXJzaW9uIjoiMi4wLjciLCJ1c2VyUm9sZSI6WyJST0xFX0RPQ1RPUiIsIlJPTEVfUEFUSUVOVCIsIlJPTEVfTUVOVEFMIl0sImlzRW5hYmxlIjpmYWxzZSwiYWRkVGltZSI6IjIwMTktMDgtMjkgMTE6MjY6NDkifX0.lIzbJoeIEPSPQVKSqGoCWaLdflSyF8n30KhRRUI3jJc","doctorSearchDate":"2019-04-25 00:00:18","osName":"Android","enable":true,"isFollowup":true}
     */

    private String key;
    private ValueBean value;

    public String getKey() {
        return key;
    }

    public void setKey(String key) {
        this.key = key;
    }

    public ValueBean getValue() {
        return value;
    }

    public void setValue(ValueBean value) {
        this.value = value;
    }

    public static class ValueBean {
        /**
         * id : 100137
         * mobile : 13600000003
         * userName : 吴亦凡
         * userIcon : system/doctor/8177-71-12310.jpg
         * userSex : 1
         * userTitle : 副主任医师
         * userJobNumber : 12310
         * hospitalId : 8177
         * hospitalName : 复旦大学附属中山医院
         * departmentId : 71
         * hospitalDepartment : 肝肿瘤外科
         * expertise : 吃喝完了哦五天
         * honor : 微积分微博控红包口令卡的好像我也不想吃东西的感觉。我的手机没电啦？我在外面等你们来吃饭吗？我在外面玩的开心的是一天了、一个人的生活方式就是这样一种
         * fabulousCount : 5
         * isFabulous : false
         * academicActivities : 后送柠檬公告拟命名为全国省级重点文物保护工作人员的重要组成部分？我们的生活方式是什么意思，的一一一一解答，饿了就去医院了您也不能这样了。Dior is the day you get to the gym and get to the gym and and get then to to go get to some the point kids of are the being，我们的生活方式是什么意思，，我们的生活方式是什么意思，，我们的生活方式是什么意思，，我们的生活方式是什么意思，我们的生活方式uu u
         * outpatientTimeList : [{"1":{"sel":true},"2":{"sel":true},"3":{"sel":true},"4":{"sel":true},"5":{"sel":true},"6":{"sel":true},"7":{"sel":true}},{"1":{"sel":true},"2":{"sel":true},"3":{"sel":false},"4":{"sel":true},"5":{"sel":false},"6":{"sel":false},"7":{"sel":false}}]
         * imPassword : 1Pc783982J
         * isSetLoginPassword : false
         * jwt : eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiIxMDAxMzciLCJleHAiOjE1NzM4MDg2NjgsImlhdCI6MTU3MzIwMzg2OCwiQWNjb3VudEluZm8iOnsiaWQiOjEwMDEzNywibW9iaWxlIjoiMTM2MDAwMDAwMDMiLCJsb2dpbk5hbWUiOiI4MTc3XzEyMzEwIiwidXNlckljb24iOiJzeXN0ZW0vZG9jdG9yLzgxNzctNzEtMTIzMTAuanBnIiwidXNlclNleCI6MSwidXNlclR5cGUiOjIsInVzZXJOYW1lIjoi5ZC05Lqm5YehIiwiaW1QYXNzd29yZCI6IjFQYzc4Mzk4MkoiLCJpc1NldExvZ2luUGFzc3dvcmQiOmZhbHNlLCJvc05hbWUiOiJBbmRyb2lkIiwibGFzdExvZ2luVGltZSI6IjIwMTktMTEtMDggMTc6MDQ6MjgiLCJ2ZXJzaW9uIjoiMi4wLjciLCJ1c2VyUm9sZSI6WyJST0xFX0RPQ1RPUiIsIlJPTEVfUEFUSUVOVCIsIlJPTEVfTUVOVEFMIl0sImlzRW5hYmxlIjpmYWxzZSwiYWRkVGltZSI6IjIwMTktMDgtMjkgMTE6MjY6NDkifX0.lIzbJoeIEPSPQVKSqGoCWaLdflSyF8n30KhRRUI3jJc
         * doctorSearchDate : 2019-04-25 00:00:18
         * osName : Android
         * enable : true
         * isFollowup : true
         */

        private int id;
        private String mobile;
        private String userName;
        private String userIcon;
        private int userSex;
        private String userTitle;
        private String userJobNumber;
        private int hospitalId;
        private String hospitalName;
        private int departmentId;
        private String hospitalDepartment;
        private String expertise;
        private String honor;
        private int fabulousCount;
        private boolean isFabulous;
        private String academicActivities;
        private String outpatientTimeList;
        private String imPassword;
        private boolean isSetLoginPassword;
        private String jwt;
        private String doctorSearchDate;
        private String osName;
        private boolean enable;
        private boolean isFollowup;

        public int getId() {
            return id;
        }

        public void setId(int id) {
            this.id = id;
        }

        public String getMobile() {
            return mobile;
        }

        public void setMobile(String mobile) {
            this.mobile = mobile;
        }

        public String getUserName() {
            return userName;
        }

        public void setUserName(String userName) {
            this.userName = userName;
        }

        public String getUserIcon() {
            return userIcon;
        }

        public void setUserIcon(String userIcon) {
            this.userIcon = userIcon;
        }

        public int getUserSex() {
            return userSex;
        }

        public void setUserSex(int userSex) {
            this.userSex = userSex;
        }

        public String getUserTitle() {
            return userTitle;
        }

        public void setUserTitle(String userTitle) {
            this.userTitle = userTitle;
        }

        public String getUserJobNumber() {
            return userJobNumber;
        }

        public void setUserJobNumber(String userJobNumber) {
            this.userJobNumber = userJobNumber;
        }

        public int getHospitalId() {
            return hospitalId;
        }

        public void setHospitalId(int hospitalId) {
            this.hospitalId = hospitalId;
        }

        public String getHospitalName() {
            return hospitalName;
        }

        public void setHospitalName(String hospitalName) {
            this.hospitalName = hospitalName;
        }

        public int getDepartmentId() {
            return departmentId;
        }

        public void setDepartmentId(int departmentId) {
            this.departmentId = departmentId;
        }

        public String getHospitalDepartment() {
            return hospitalDepartment;
        }

        public void setHospitalDepartment(String hospitalDepartment) {
            this.hospitalDepartment = hospitalDepartment;
        }

        public String getExpertise() {
            return expertise;
        }

        public void setExpertise(String expertise) {
            this.expertise = expertise;
        }

        public String getHonor() {
            return honor;
        }

        public void setHonor(String honor) {
            this.honor = honor;
        }

        public int getFabulousCount() {
            return fabulousCount;
        }

        public void setFabulousCount(int fabulousCount) {
            this.fabulousCount = fabulousCount;
        }

        public boolean isIsFabulous() {
            return isFabulous;
        }

        public void setIsFabulous(boolean isFabulous) {
            this.isFabulous = isFabulous;
        }

        public String getAcademicActivities() {
            return academicActivities;
        }

        public void setAcademicActivities(String academicActivities) {
            this.academicActivities = academicActivities;
        }

        public String getOutpatientTimeList() {
            return outpatientTimeList;
        }

        public void setOutpatientTimeList(String outpatientTimeList) {
            this.outpatientTimeList = outpatientTimeList;
        }

        public String getImPassword() {
            return imPassword;
        }

        public void setImPassword(String imPassword) {
            this.imPassword = imPassword;
        }

        public boolean isIsSetLoginPassword() {
            return isSetLoginPassword;
        }

        public void setIsSetLoginPassword(boolean isSetLoginPassword) {
            this.isSetLoginPassword = isSetLoginPassword;
        }

        public String getJwt() {
            return jwt;
        }

        public void setJwt(String jwt) {
            this.jwt = jwt;
        }

        public String getDoctorSearchDate() {
            return doctorSearchDate;
        }

        public void setDoctorSearchDate(String doctorSearchDate) {
            this.doctorSearchDate = doctorSearchDate;
        }

        public String getOsName() {
            return osName;
        }

        public void setOsName(String osName) {
            this.osName = osName;
        }

        public boolean isEnable() {
            return enable;
        }

        public void setEnable(boolean enable) {
            this.enable = enable;
        }

        public boolean isIsFollowup() {
            return isFollowup;
        }

        public void setIsFollowup(boolean isFollowup) {
            this.isFollowup = isFollowup;
        }
    }
}
