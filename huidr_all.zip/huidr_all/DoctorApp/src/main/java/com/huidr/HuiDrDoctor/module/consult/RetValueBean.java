package com.huidr.HuiDrDoctor.module.consult;

import java.util.List;

public class RetValueBean {

    /**
     * orderId : 2019081914252341351769
     * orderStatusAction : 1
     * orderStatus : 1
     * orderTopic : 图文咨询
     * orderDetails : {"patientId":45839,"patientName":"钱进军","patientHospital":"复旦大学附属中山医院","needHelp":"哈哈哈看看啦啦啦啦，就健健康康我拒绝","pics":["100162/patient/156619592300044.png","100162/patient/156619592300064.png"],"doctorId":100137,"doctorName":"测试肝肿瘤外科4","position":"副主任医师","doctorHospital":"复旦大学附属中山医院","hospitalDepartment":"肝肿瘤外科","doctorHeadImg":"system/doctor/8177-71-12310.jpg"}
     * orderKind : 2
     * payOrderId : 2019081914252341351769
     * payPlatformKind : 3
     * createTime : 2019-08-19 14:25:24
     * buyerId : 100162
     * sellerId : 100137
     * buyerRelationId : 45839
     * addressInfo : {}
     * orderPrice : 1000
     * couponPrice : 0
     * integralPrice : 0
     * goodsDetails : [{"id":22,"goodsName":"测试肝肿瘤外科4的图文咨询服务","goodsNumber":1,"goodsBalance":1000,"merchantId":100137,"goodsGroup":2,"isOnShelf":true,"enableInfiniteStock":true,"stock":50,"mainPicture":"/article/uploadImg/1.jpg","enableDayLimitSale":true,"dayLimitMaxSale":2,"enableDayLimitTime":true,"dayLimitTimeStart":0,"dayLimitTimeEnd":82800,"isMathCoupon":true}]
     * payTime : 2019-08-19 14:25:29
     */

    private String orderId;
    private int orderStatusAction;
    private int orderStatus;
    private String orderTopic;
    private OrderDetailsBean orderDetails;
    private int orderKind;
    private String payOrderId;
    private int payPlatformKind;
    private String createTime;
    private int buyerId;
    private int sellerId;
    private int buyerRelationId;
    private AddressInfoBean addressInfo;
    private int orderPrice;
    private int couponPrice;
    private int integralPrice;
    private String payTime;
    private List<GoodsDetailsBean> goodsDetails;

    public String getOrderId() {
        return orderId;
    }

    public void setOrderId(String orderId) {
        this.orderId = orderId;
    }

    public int getOrderStatusAction() {
        return orderStatusAction;
    }

    public void setOrderStatusAction(int orderStatusAction) {
        this.orderStatusAction = orderStatusAction;
    }

    public int getOrderStatus() {
        return orderStatus;
    }

    public void setOrderStatus(int orderStatus) {
        this.orderStatus = orderStatus;
    }

    public String getOrderTopic() {
        return orderTopic;
    }

    public void setOrderTopic(String orderTopic) {
        this.orderTopic = orderTopic;
    }

    public OrderDetailsBean getOrderDetails() {
        return orderDetails;
    }

    public void setOrderDetails(OrderDetailsBean orderDetails) {
        this.orderDetails = orderDetails;
    }

    public int getOrderKind() {
        return orderKind;
    }

    public void setOrderKind(int orderKind) {
        this.orderKind = orderKind;
    }

    public String getPayOrderId() {
        return payOrderId;
    }

    public void setPayOrderId(String payOrderId) {
        this.payOrderId = payOrderId;
    }

    public int getPayPlatformKind() {
        return payPlatformKind;
    }

    public void setPayPlatformKind(int payPlatformKind) {
        this.payPlatformKind = payPlatformKind;
    }

    public String getCreateTime() {
        return createTime;
    }

    public void setCreateTime(String createTime) {
        this.createTime = createTime;
    }

    public int getBuyerId() {
        return buyerId;
    }

    public void setBuyerId(int buyerId) {
        this.buyerId = buyerId;
    }

    public int getSellerId() {
        return sellerId;
    }

    public void setSellerId(int sellerId) {
        this.sellerId = sellerId;
    }

    public int getBuyerRelationId() {
        return buyerRelationId;
    }

    public void setBuyerRelationId(int buyerRelationId) {
        this.buyerRelationId = buyerRelationId;
    }

    public AddressInfoBean getAddressInfo() {
        return addressInfo;
    }

    public void setAddressInfo(AddressInfoBean addressInfo) {
        this.addressInfo = addressInfo;
    }

    public int getOrderPrice() {
        return orderPrice;
    }

    public void setOrderPrice(int orderPrice) {
        this.orderPrice = orderPrice;
    }

    public int getCouponPrice() {
        return couponPrice;
    }

    public void setCouponPrice(int couponPrice) {
        this.couponPrice = couponPrice;
    }

    public int getIntegralPrice() {
        return integralPrice;
    }

    public void setIntegralPrice(int integralPrice) {
        this.integralPrice = integralPrice;
    }

    public String getPayTime() {
        return payTime;
    }

    public void setPayTime(String payTime) {
        this.payTime = payTime;
    }

    public List<GoodsDetailsBean> getGoodsDetails() {
        return goodsDetails;
    }

    public void setGoodsDetails(List<GoodsDetailsBean> goodsDetails) {
        this.goodsDetails = goodsDetails;
    }

    public static class OrderDetailsBean {
        /**
         * patientId : 45839
         * patientName : 钱进军
         * patientHospital : 复旦大学附属中山医院
         * needHelp : 哈哈哈看看啦啦啦啦，就健健康康我拒绝
         * pics : ["100162/patient/156619592300044.png","100162/patient/156619592300064.png"]
         * doctorId : 100137
         * doctorName : 测试肝肿瘤外科4
         * position : 副主任医师
         * doctorHospital : 复旦大学附属中山医院
         * hospitalDepartment : 肝肿瘤外科
         * doctorHeadImg : system/doctor/8177-71-12310.jpg
         */

        private int patientId;
        private String patientName;
        private String patientHospital;
        private String needHelp;
        private int doctorId;
        private String doctorName;
        private String position;
        private String doctorHospital;
        private String hospitalDepartment;
        private String doctorHeadImg;
        private List<String> pics;

        public int getPatientId() {
            return patientId;
        }

        public void setPatientId(int patientId) {
            this.patientId = patientId;
        }

        public String getPatientName() {
            return patientName;
        }

        public void setPatientName(String patientName) {
            this.patientName = patientName;
        }

        public String getPatientHospital() {
            return patientHospital;
        }

        public void setPatientHospital(String patientHospital) {
            this.patientHospital = patientHospital;
        }

        public String getNeedHelp() {
            return needHelp;
        }

        public void setNeedHelp(String needHelp) {
            this.needHelp = needHelp;
        }

        public int getDoctorId() {
            return doctorId;
        }

        public void setDoctorId(int doctorId) {
            this.doctorId = doctorId;
        }

        public String getDoctorName() {
            return doctorName;
        }

        public void setDoctorName(String doctorName) {
            this.doctorName = doctorName;
        }

        public String getPosition() {
            return position;
        }

        public void setPosition(String position) {
            this.position = position;
        }

        public String getDoctorHospital() {
            return doctorHospital;
        }

        public void setDoctorHospital(String doctorHospital) {
            this.doctorHospital = doctorHospital;
        }

        public String getHospitalDepartment() {
            return hospitalDepartment;
        }

        public void setHospitalDepartment(String hospitalDepartment) {
            this.hospitalDepartment = hospitalDepartment;
        }

        public String getDoctorHeadImg() {
            return doctorHeadImg;
        }

        public void setDoctorHeadImg(String doctorHeadImg) {
            this.doctorHeadImg = doctorHeadImg;
        }

        public List<String> getPics() {
            return pics;
        }

        public void setPics(List<String> pics) {
            this.pics = pics;
        }
    }

    public static class AddressInfoBean {
    }

    public static class GoodsDetailsBean {
        /**
         * id : 22
         * goodsName : 测试肝肿瘤外科4的图文咨询服务
         * goodsNumber : 1
         * goodsBalance : 1000
         * merchantId : 100137
         * goodsGroup : 2
         * isOnShelf : true
         * enableInfiniteStock : true
         * stock : 50
         * mainPicture : /article/uploadImg/1.jpg
         * enableDayLimitSale : true
         * dayLimitMaxSale : 2
         * enableDayLimitTime : true
         * dayLimitTimeStart : 0
         * dayLimitTimeEnd : 82800
         * isMathCoupon : true
         */

        private int id;
        private String goodsName;
        private int goodsNumber;
        private int goodsBalance;
        private int merchantId;
        private int goodsGroup;
        private boolean isOnShelf;
        private boolean enableInfiniteStock;
        private int stock;
        private String mainPicture;
        private boolean enableDayLimitSale;
        private int dayLimitMaxSale;
        private boolean enableDayLimitTime;
        private int dayLimitTimeStart;
        private int dayLimitTimeEnd;
        private boolean isMathCoupon;

        public int getId() {
            return id;
        }

        public void setId(int id) {
            this.id = id;
        }

        public String getGoodsName() {
            return goodsName;
        }

        public void setGoodsName(String goodsName) {
            this.goodsName = goodsName;
        }

        public int getGoodsNumber() {
            return goodsNumber;
        }

        public void setGoodsNumber(int goodsNumber) {
            this.goodsNumber = goodsNumber;
        }

        public int getGoodsBalance() {
            return goodsBalance;
        }

        public void setGoodsBalance(int goodsBalance) {
            this.goodsBalance = goodsBalance;
        }

        public int getMerchantId() {
            return merchantId;
        }

        public void setMerchantId(int merchantId) {
            this.merchantId = merchantId;
        }

        public int getGoodsGroup() {
            return goodsGroup;
        }

        public void setGoodsGroup(int goodsGroup) {
            this.goodsGroup = goodsGroup;
        }

        public boolean isIsOnShelf() {
            return isOnShelf;
        }

        public void setIsOnShelf(boolean isOnShelf) {
            this.isOnShelf = isOnShelf;
        }

        public boolean isEnableInfiniteStock() {
            return enableInfiniteStock;
        }

        public void setEnableInfiniteStock(boolean enableInfiniteStock) {
            this.enableInfiniteStock = enableInfiniteStock;
        }

        public int getStock() {
            return stock;
        }

        public void setStock(int stock) {
            this.stock = stock;
        }

        public String getMainPicture() {
            return mainPicture;
        }

        public void setMainPicture(String mainPicture) {
            this.mainPicture = mainPicture;
        }

        public boolean isEnableDayLimitSale() {
            return enableDayLimitSale;
        }

        public void setEnableDayLimitSale(boolean enableDayLimitSale) {
            this.enableDayLimitSale = enableDayLimitSale;
        }

        public int getDayLimitMaxSale() {
            return dayLimitMaxSale;
        }

        public void setDayLimitMaxSale(int dayLimitMaxSale) {
            this.dayLimitMaxSale = dayLimitMaxSale;
        }

        public boolean isEnableDayLimitTime() {
            return enableDayLimitTime;
        }

        public void setEnableDayLimitTime(boolean enableDayLimitTime) {
            this.enableDayLimitTime = enableDayLimitTime;
        }

        public int getDayLimitTimeStart() {
            return dayLimitTimeStart;
        }

        public void setDayLimitTimeStart(int dayLimitTimeStart) {
            this.dayLimitTimeStart = dayLimitTimeStart;
        }

        public int getDayLimitTimeEnd() {
            return dayLimitTimeEnd;
        }

        public void setDayLimitTimeEnd(int dayLimitTimeEnd) {
            this.dayLimitTimeEnd = dayLimitTimeEnd;
        }

        public boolean isIsMathCoupon() {
            return isMathCoupon;
        }

        public void setIsMathCoupon(boolean isMathCoupon) {
            this.isMathCoupon = isMathCoupon;
        }
    }
}
