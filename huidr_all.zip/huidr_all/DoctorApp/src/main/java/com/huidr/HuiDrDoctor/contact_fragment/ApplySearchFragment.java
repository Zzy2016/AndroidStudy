package com.huidr.HuiDrDoctor.contact_fragment;

import android.app.Dialog;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.drawable.BitmapDrawable;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;

import android.text.Html;
import android.view.Display;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import com.alibaba.fastjson.JSONObject;
import com.chad.library.adapter.base.BaseQuickAdapter;
import com.chad.library.adapter.base.BaseViewHolder;
import com.google.gson.Gson;
import com.guanaj.easyswipemenulibrary.EasySwipeMenuLayout;
import com.huidr.HuiDrDoctor.activity.WebActivity;
import com.huidr.HuiDrDoctor.activity.main.Consult.utils.PostAndGet;
import com.huidr.HuiDrDoctor.debug.BuildConfig;
import com.huidr.HuiDrDoctor.debug.R;
import com.huidr.HuiDrDoctor.module.home.SearchContractModel;
import com.huidr.HuiDrDoctor.module.home.SimpleResultModel;
import com.huidr.HuiDrDoctor.util.CircleImageView;
import com.huidr.HuiDrDoctor.util.DownLoadImg;
import com.huidr.HuiDrDoctor.util.LogUtil;
import com.huidr.HuiDrDoctor.util.ThreadPoolManager;
import com.huidr.lib.commom.base.BaseFragment;
import com.huidr.lib.commom.base.HuidrActivityManager;
import com.huidr.lib.commom.util.Toast;
import com.scwang.smartrefresh.layout.SmartRefreshLayout;
import com.zyao89.view.zloading.ZLoadingDialog;
import com.zyao89.view.zloading.Z_TYPE;

import java.io.File;

import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import cn.jpush.im.android.api.ContactManager;
import cn.jpush.im.android.api.JMessageClient;
import cn.jpush.im.android.api.content.TextContent;
import cn.jpush.im.android.api.model.Conversation;
import cn.jpush.im.api.BasicCallback;
import jiguang.chat.activity.ChatActivity;
import jiguang.chat.application.JGApplication;
import jiguang.chat.utils.oss.OssService;
import jiguang.chat.utils.oss.SharedPreferenciesUtil;

import static com.huidr.HuiDrDoctor.util.DownLoadImg.getCirleBitmap;


public class ApplySearchFragment extends BaseFragment {

    SmartRefreshLayout srlSearchList;
    RecyclerView rvSearchList;
    ConstraintLayout clEmptyApply;
    String key;
    private String doctorId = (String) SharedPreferenciesUtil.getData("id", "0");
    SearchContractModel searchContractModel;
    String path = BuildConfig.baseUrl + "hospital/doctorGroup/getDoctorList";//医生搜索
    String pathAdd = BuildConfig.baseUrl + "hospital/doctorGroup/addAssistDoctor";//添加协同
    String pathDelete = BuildConfig.baseUrl + "hospital/doctorGroup/removeAssistDoctor";//删除协同
    int currentPage = 1;
    int totalPage = 1;
    OssService ossService;
    ZLoadingDialog dialog, dialog1;
    Gson gson;
    TextView tvEmptyApply1;

    long lastClick = 0;
    private String imgPath;

    Bitmap bitmap;

    @Override
    protected void initData() {
        key = getArguments().getString("search_key");
        imgPath = getContext().getExternalFilesDir("").getAbsolutePath() + "/img/head/";

        gson = new Gson();
        ossService = new OssService(getContext());
        dialog = new ZLoadingDialog(getContext());
        dialog.setLoadingBuilder(Z_TYPE.STAR_LOADING)//设置类型
                .setLoadingColor(Color.BLUE)//颜色
                .setHintText("处理中,请稍候...").setHintTextSize(16) // 设置字体大小 dp
                .setHintTextColor(Color.GRAY)  // 设置字体颜色
                .setDurationTime(0.5) // 设置动画时间百分比 - 0.5倍
                .setCanceledOnTouchOutside(false).setCancelable(false);

        dialog1 = new ZLoadingDialog(getContext());
        dialog1.setLoadingBuilder(Z_TYPE.STAR_LOADING)//设置类型
                .setLoadingColor(Color.BLUE)//颜色
                .setHintText("正在加载,请稍候...").setHintTextSize(16) // 设置字体大小 dp
                .setHintTextColor(Color.GRAY)  // 设置字体颜色
                .setDurationTime(0.5) // 设置动画时间百分比 - 0.5倍
                .setCanceledOnTouchOutside(false).setCancelable(false).show();
        getResultByPage();
    }

    @Override
    protected View setContentView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_apply_search, container, false);
        return view;
    }

    @Override
    protected void findView(View parent) {
        srlSearchList = parent.findViewById(R.id.srl_search_list);
        rvSearchList = parent.findViewById(R.id.rv_search_list);
        clEmptyApply = parent.findViewById(R.id.cl_empty_apply);

        tvEmptyApply1 = parent.findViewById(R.id.tv_empty_apply1);

        rvSearchList.setAdapter(searchAdapter);
        rvSearchList.setLayoutManager(new LinearLayoutManager(getContext()));
    }


    public void getResultByPage() {
        ThreadPoolManager.getInstance().execute(new Runnable() {
            @Override
            public void run() {
                JSONObject jsonObject = new JSONObject();
                jsonObject.put("pageIndex", currentPage);
                jsonObject.put("pageSize", 20);
                jsonObject.put("search", key);
                String result = PostAndGet.doHttpPost(path, jsonObject);
                searchContractModel = new SearchContractModel();

                LogUtil.e("搜索结果", result);
                if (result.equals("网络异常")) {
                    handler.sendEmptyMessage(3);
                } else {
                    searchContractModel = gson.fromJson(result, SearchContractModel.class);
                    if (searchContractModel.getStatus() == 0) {
                        totalPage = searchContractModel.getTotalPage();
                        if (currentPage == 1) {
                            handler.sendEmptyMessage(1);
                        } else {
                            handler.sendEmptyMessage(2);
                        }
                    } else {
                        handler.sendEmptyMessage(3);
                    }
                }

            }
        });
    }



    private Handler handler = new Handler() {
        @Override
        public void handleMessage(Message msg) {
            super.handleMessage(msg);

            switch (msg.what) {
                case 1:
                    searchAdapter.getData().clear();

                    if (searchContractModel.getRetValue().size() == 0) {
                        clEmptyApply.setVisibility(View.VISIBLE);
                        srlSearchList.setVisibility(View.GONE);
                        tvEmptyApply1.setText("暂未搜索到该医生~");
                    } else {
                        clEmptyApply.setVisibility(View.GONE);
                        srlSearchList.setVisibility(View.VISIBLE);
                        searchAdapter.getData().addAll(searchContractModel.getRetValue());
                        searchAdapter.notifyDataSetChanged();
                    }
                    srlSearchList.finishRefresh();

                    if (dialog1 != null) {
                        new Handler().postDelayed(new Runnable() {
                            @Override
                            public void run() {
                                dialog1.dismiss();
                            }
                        }, 500);
                    }
                    break;
                case 2:
                    searchAdapter.getData().addAll(searchContractModel.getRetValue());
                    searchAdapter.notifyDataSetChanged();
                    srlSearchList.finishLoadMore();
                    break;
                case 3:
                    clEmptyApply.setVisibility(View.VISIBLE);
                    srlSearchList.setVisibility(View.GONE);
                    tvEmptyApply1.setText("网络错误~");
                    break;

//                    获取历史搜索成功

//                    邀请发送成功
                case 8:
                    dialog.dismiss();
                    searchAdapter.getData().get(msg.arg1).setIsApply(true);
//                    searchAdapter.notifyDataSetChanged();
                    searchAdapter.notifyItemChanged(msg.arg1);
                    Toast.getInstance(getContext()).show("邀请发送成功", 500);
                    break;
//                    不要重复发送邀请
                case 9:
                    dialog.dismiss();
                    Toast.getInstance(getContext()).show("您已发送邀请，请不要重复发送", 500);
                    break;
//                    邀请发送失败 
                case 10:
                    dialog.dismiss();
                    Toast.getInstance(getContext()).show("邀请发送失败", 500);
                    break;
//                    添加协同成功
                case 11:
                    searchAdapter.getData().get(msg.arg1).setIsAssist(true);
                    searchAdapter.notifyItemChanged(msg.arg1);
                    dialog.dismiss();
                    Toast.getInstance(getContext()).show("添加协同医生成功", 500);
                    break;
//                    添加协同失败
                case 12:
                    dialog.dismiss();
                    Toast.getInstance(getContext()).show("添加协同医生失败", 500);
                    break;
                //                    删除协同成功
                case 13:
                    searchAdapter.getData().get(msg.arg1).setIsAssist(false);
                    searchAdapter.notifyItemChanged(msg.arg1);
                    dialog.dismiss();
                    Toast.getInstance(getContext()).show("取消协同医生成功", 500);
                    break;
                //                    删除协同失败
                case 14:
                    dialog.dismiss();
                    Toast.getInstance(getContext()).show("取消协同医生失败", 500);
                    break;

            }
        }
    };

    /*
     * 搜索结果  适配
     *
     * */
    private BaseQuickAdapter<SearchContractModel.RetValueBean, BaseViewHolder> searchAdapter = new BaseQuickAdapter<SearchContractModel.RetValueBean, BaseViewHolder>(R.layout.item_scroll_layout) {

        @Override
        protected void convert(final BaseViewHolder helper, final SearchContractModel.RetValueBean item) {

//            helper.setIsRecyclable(false);
            final CircleImageView imgItemHead = helper.getView(R.id.img_item_head);
//            imgItemHead.setBackgroundResource(R.drawable.nantou);

            EasySwipeMenuLayout esml_item = helper.getView(R.id.esml_item);

            ConstraintLayout clItem = helper.getView(R.id.cl_item);
            clItem.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (System.currentTimeMillis() - lastClick > 1000) {
                        if (item.isIsContacts()) {
                            if (JMessageClient.getMyInfo() == null) {
                                return;
                            }
                            Intent intent = new Intent(getContext(), ChatActivity.class);
                            Bundle bundle = new Bundle();
                            bundle.putString("targetId", item.getId() + "");
                            bundle.putString(JGApplication.CONV_TITLE, item.getUserName());
                            bundle.putString(JGApplication.TARGET_APP_KEY, BuildConfig.appkey);
                            intent.putExtras(bundle);
                            startActivity(intent);
                        } else {
                            Intent intent1 = new Intent(getContext(), WebActivity.class);
                            Bundle bundle = new Bundle();
                            bundle.putString("url", "personal.html?id=" + item.getId());
                            intent1.putExtras(bundle);
                            startActivity(intent1);
                        }
                        lastClick = System.currentTimeMillis();
                    }
                }
            });


            TextView textView = helper.getView(R.id.tv_scroll_right);
            String st = "<font>添加<br />协同</font>";
            textView.setText(Html.fromHtml(st));

            TextView tvItemName = helper.getView(R.id.tv_item_name);
            tvItemName.setText(item.getUserName());
            TextView tvItemMsg = helper.getView(R.id.tv_item_msg);

            Bitmap bitmapDoctor = BitmapFactory.decodeResource(getResources(), R.drawable.default_doctor);
            BitmapDrawable bitmapDrawable = new BitmapDrawable(getContext().getResources(), bitmapDoctor);
            imgItemHead.setBackgroundDrawable(bitmapDrawable);

            if (item.getUserIcon() != null) {


                imgItemHead.setTag(item.getUserIcon());


                final File file = new File(imgPath + item.getUserIcon());
                if (file.exists()) {

                    bitmap = BitmapFactory.decodeFile(file.getAbsolutePath());
                    if (bitmap != null) {
                        bitmap = getCirleBitmap(bitmap);
                        BitmapDrawable bitmapDrawable1 = new BitmapDrawable(getContext().getResources(), bitmap);
                        if (imgItemHead.getTag().equals(item.getUserIcon())) {
                            imgItemHead.setBackgroundDrawable(bitmapDrawable1);
//                            tvItemMsg.setText("本地 TAg  " + imgItemHead.getTag() + "   url" + item.getUserIcon());
                        }
                    } else {
//                        imgItemHead.setBackgroundResource(R.drawable.nantou);
                    }
                } else {
                    DownLoadImg.BitmapWorkerTask bitmapWorkerTask = new DownLoadImg.BitmapWorkerTask(imgItemHead, file, ossService);
                    bitmapWorkerTask.execute(item.getUserIcon());
                }
            } else {
                imgItemHead.setBackgroundResource(R.drawable.nantou);
                tvItemMsg.setText("没有头像 TAg  " + imgItemHead.getTag() + "   url" + item.getUserIcon());
            }


            ImageView imgNotice = helper.getView(R.id.img_notice);
            imgNotice.setVisibility(View.GONE);
            ImageView imageItemGender = helper.getView(R.id.image_item_gender);
            TextView tvItemAge = helper.getView(R.id.tv_item_age);
            tvItemAge.setText(item.getHospitalDepartment() + "(" + item.getUserTitle() + ")");
            TextView tvItemState = helper.getView(R.id.tv_item_state);
            TextView tvItemDate = helper.getView(R.id.tv_item_date);
            tvItemDate.setVisibility(View.GONE);

//            tvItemMsg.setText(item.getLatelyAdmissionDiagnosis());
            TextView tvItemModel = helper.getView(R.id.tv_item_model);
            tvItemModel.setVisibility(View.GONE);
            TextView tvScrollRight = helper.getView(R.id.tv_scroll_right);
            Conversation conversation = JMessageClient.getSingleConversation(item.getId() + "");
//            if (conversation == null) {
//                imgNotice.setVisibility(View.GONE);
//            } else {
//                if (conversation.getUnReadMsgCnt() > 0) {
//                    imgNotice.setVisibility(View.VISIBLE);
//                } else {
//                    imgNotice.setVisibility(View.GONE);
//                }
//            }
            final Button btnApply = helper.getView(R.id.btn_apply);
            if (item.isIsContacts()) {
                btnApply.setBackgroundResource(R.drawable.btn_apply_gray);
                btnApply.setText("已申请");
            } else {
                if (item.isIsApply()) {
                    btnApply.setBackgroundResource(R.drawable.btn_apply_gray);
                    btnApply.setText("已申请");
                } else {
                    btnApply.setBackgroundResource(R.drawable.btn_grad_empty);
                    btnApply.setText("申请");
                }
            }


//            已经是好友
            if (item.isIsContacts()) {
                esml_item.setCanLeftSwipe(true);
                if (conversation == null) {
                    tvItemMsg.setText("暂无聊天消息");
                } else {
                    cn.jpush.im.android.api.model.Message message = conversation.getLatestMessage();
                    if (message != null) {
                        switch (message.getContentType()) {
                            case text:
                                tvItemMsg.setText(((TextContent) message.getContent()).getText());
                                break;
                            case voice:
                                tvItemMsg.setText("[语音消息]");
                                break;
                            case image:
                                tvItemMsg.setText("[图片]");
                                break;
                            case file:
                                tvItemMsg.setText("[文件]");
                                break;
                            case location:
                                tvItemMsg.setText("[位置]");
                                break;
                            default:
                                break;
                        }
                    }
                }
            } else {
                esml_item.setCanLeftSwipe(false);
                tvItemMsg.setText("该医生还不是您的联系人");
            }
            btnApply.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (btnApply.getText().toString().equals("已申请")) {
                    } else {
                        dialog.show();
                        ContactManager.sendInvitationRequest(item.getId() + "", "", "", new BasicCallback() {
                            @Override
                            public void gotResult(int responseCode, String responseMessage) {
                                if (0 == responseCode) {
                                    LogUtil.e("极光发送邀请成功", "极光发送邀请成功");
                                    addContact(item.getId() + "", helper.getAdapterPosition());
                                } else {
                                    LogUtil.e("极光发送邀请失败", "极光发送邀请失败" + responseMessage);
                                    dialog.dismiss();
                                    if (responseMessage.equals("Target user cannot be yourself.")) {
                                        Toast.getInstance(getContext()).show("不能发送邀请给自己", 500);
                                    } else {
                                        Toast.getInstance(getContext()).show("邀请发送失败", 500);
                                    }
                                }
                            }
                        });
                    }

                }
            });
            String tip = "";
            if (item.isIsAssist()) {
                tip = "<font>取消<br>协同<font>";
                tvScrollRight.setBackgroundResource(R.drawable.shape_atten_gray);
            } else {
                tip = "<font>添加<br>协同<font>";
                tvScrollRight.setBackgroundResource(R.drawable.btn_grad_empty);
            }
            tvScrollRight.setText(Html.fromHtml(tip));
            tvScrollRight.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    showCoopDialog(item.getId() + "", helper.getAdapterPosition(), item.isIsAssist());
                }
            });
        }
    };

    public void showCoopDialog(final String id, final int position, final boolean isCoop) {

        final Dialog builder = new Dialog(getContext(), R.style.jmui_default_dialog_style);
        //final Dialog builder = new Dialog(this, R.style.jmui_default_dialog_style);
        View view = LayoutInflater.from(getContext()).inflate(R.layout.dialog_content, null);

        TextView tvTitle = view.findViewById(R.id.tv_title);
        TextView tvFooter1 = view.findViewById(R.id.tv_footer1);
        TextView tvFooter2 = view.findViewById(R.id.tv_footer2);

        if (isCoop) {
            tvTitle.setText("是否删除协同医生!");
        } else {
            tvTitle.setText("是否添加协同医生!");
        }


//        取消
        tvFooter1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                builder.cancel();
                searchAdapter.notifyItemChanged(position);
            }
        });
//确定
        tvFooter2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                builder.cancel();
                if (isCoop) {
                    deleteCooperDoctor(id, position);
                } else {
                    addAssistDoctor(id, position);
                }
            }
        });

        builder.setContentView(view);
        //builder.setCanceledOnTouchOutside(true);
        builder.show();
        Window window = builder.getWindow();
        WindowManager.LayoutParams lp = window.getAttributes();
        WindowManager windowManager = HuidrActivityManager.getInstance().getCurrentActivity().getWindowManager();
        Display display = windowManager.getDefaultDisplay();
        lp.width = (int) (display.getWidth() * 0.7);
//        lp.height = (int) (display.getHeight() * 0.1);
        window.setAttributes(lp);
    }

    public void addAssistDoctor(final String id, final int position) {
        ThreadPoolManager.getInstance().execute(new Runnable() {
            @Override
            public void run() {
                JSONObject jsonObject = new JSONObject();
                int uid = Integer.valueOf(id);
                int[] a = new int[]{uid};
                jsonObject.put("assistUids", a);

                String result = PostAndGet.doHttpPost(pathAdd, jsonObject);
                LogUtil.e("添加协同医生", result);
                if (result.equals("网络异常")) {
                    handler.sendEmptyMessage(12);
                } else {
                    SimpleResultModel simpleResultModel = gson.fromJson(result, SimpleResultModel.class);
                    if (simpleResultModel.getStatus() == 0) {
                        if (simpleResultModel.getRetValue() == 0) {
//
                            Message msg = new Message();
                            msg.what = 11;
                            msg.arg1 = position;
                            handler.sendMessage(msg);

                        } else {
                            handler.sendEmptyMessage(12);
                        }
                    } else {
                        handler.sendEmptyMessage(12);
                    }
                }
            }
        });
    }


    //    删除协同医生
    public void deleteCooperDoctor(final String deleteId, final int position) {
        ThreadPoolManager.getInstance().execute(new Runnable() {
            @Override
            public void run() {
                JSONObject jsonObject = new JSONObject();
                jsonObject.put("assistUid", deleteId);
                String result = PostAndGet.doHttpPost(pathDelete, jsonObject);
                if (result.equals("网络异常")) {
                    handler.sendEmptyMessage(14);
                } else {
                    SimpleResultModel simpleResultModel = gson.fromJson(result, SimpleResultModel.class);
                    if (simpleResultModel.getStatus() == 0) {
                        if (simpleResultModel.getRetValue() == 0) {
                            Message message = new Message();
                            message.arg1 = position;
                            message.what = 13;
                            handler.sendMessage(message);
                        }

                    } else {
                        handler.sendEmptyMessage(14);
                    }
                }
            }
        });
    }

    //    添加联系人  访问接口
    public void addContact(final String targetId, final int position) {
        ThreadPoolManager.getInstance().execute(new Runnable() {
            @Override
            public void run() {
                String path = BuildConfig.baseUrl + "hospital/doctorGroup/addContacts";
                JSONObject jsonObject = new JSONObject();
                String id = (String) SharedPreferenciesUtil.getData("id", "0");
//                申请人ID  applicantId
                jsonObject.put("applicantId", id);
                //                本申请人ID applicantId
                jsonObject.put("respondentId", targetId);

                String result = PostAndGet.doHttpPost(path, jsonObject);
                LogUtil.e("添加联系人", result);
                if (result.equals("网络异常")) {
                    handler.sendEmptyMessage(10);
                } else {
                    SimpleResultModel simpleResultModel = gson.fromJson(result, SimpleResultModel.class);
                    if (simpleResultModel.getStatus() == 0) {
//                        1发送成功 0 24小时内不能重复发送
                        if (simpleResultModel.getRetValue() == 1) {
//                            handler.sendEmptyMessage(8);
                            Message message = new Message();
                            message.what = 8;
                            message.arg1 = position;
                            handler.sendMessage(message);
                        } else if (simpleResultModel.getRetValue() == -1) {
                            handler.sendEmptyMessage(9);
                        } else {
                            handler.sendEmptyMessage(10);
                        }
                    } else {
                        handler.sendEmptyMessage(10);
                    }
                }
            }
        });
    }

}
