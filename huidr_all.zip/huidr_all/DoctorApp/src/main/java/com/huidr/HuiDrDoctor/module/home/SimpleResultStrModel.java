package com.huidr.HuiDrDoctor.module.home;

/**
 * @author: Administrator
 * @date: 2020-04-15
 */
public class SimpleResultStrModel {

    /**
     * status : 0
     * retValue : SUCCESS
     */

    private int status;
    private String retValue;

    public int getStatus() {
        return status;
    }

    public void setStatus(int status) {
        this.status = status;
    }

    public String getRetValue() {
        return retValue;
    }

    public void setRetValue(String retValue) {
        this.retValue = retValue;
    }
}
