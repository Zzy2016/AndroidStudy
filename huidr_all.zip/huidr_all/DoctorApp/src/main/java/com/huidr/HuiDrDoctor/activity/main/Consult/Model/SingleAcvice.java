package com.huidr.HuiDrDoctor.activity.main.Consult.Model;

import java.util.List;

public class SingleAcvice {

    /**
     * status : 0
     * page : 1
     * totalPage : 1
     * retValue : [{"id":2577,"userType":1,"contentType":4,"consultContent":"医生已经接受您的咨询申请，赶快向医生咨询吧","commitTime":"2019-09-28 11:11:59","isSuggest":false,"suggest":"回来咯急急如律令可口可乐了了"}]
     */

    private int status;
    private int page;
    private int totalPage;
    private List<RetValueBean> retValue;

    public int getStatus() {
        return status;
    }

    public void setStatus(int status) {
        this.status = status;
    }

    public int getPage() {
        return page;
    }

    public void setPage(int page) {
        this.page = page;
    }

    public int getTotalPage() {
        return totalPage;
    }

    public void setTotalPage(int totalPage) {
        this.totalPage = totalPage;
    }

    public List<RetValueBean> getRetValue() {
        return retValue;
    }

    public void setRetValue(List<RetValueBean> retValue) {
        this.retValue = retValue;
    }

    public static class RetValueBean {
        /**
         * id : 2577
         * userType : 1
         * contentType : 4
         * consultContent : 医生已经接受您的咨询申请，赶快向医生咨询吧
         * commitTime : 2019-09-28 11:11:59
         * isSuggest : false
         * suggest : 回来咯急急如律令可口可乐了了
         */

        private int id;
        private int userType;
        private int contentType;
        private String consultContent;
        private String commitTime;
        private boolean isSuggest;
        private String suggest;

        public int getId() {
            return id;
        }

        public void setId(int id) {
            this.id = id;
        }

        public int getUserType() {
            return userType;
        }

        public void setUserType(int userType) {
            this.userType = userType;
        }

        public int getContentType() {
            return contentType;
        }

        public void setContentType(int contentType) {
            this.contentType = contentType;
        }

        public String getConsultContent() {
            return consultContent;
        }

        public void setConsultContent(String consultContent) {
            this.consultContent = consultContent;
        }

        public String getCommitTime() {
            return commitTime;
        }

        public void setCommitTime(String commitTime) {
            this.commitTime = commitTime;
        }

        public boolean isIsSuggest() {
            return isSuggest;
        }

        public void setIsSuggest(boolean isSuggest) {
            this.isSuggest = isSuggest;
        }

        public String getSuggest() {
            return suggest;
        }

        public void setSuggest(String suggest) {
            this.suggest = suggest;
        }
    }
}
