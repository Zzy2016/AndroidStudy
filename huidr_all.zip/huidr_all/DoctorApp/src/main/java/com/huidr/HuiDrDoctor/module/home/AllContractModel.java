package com.huidr.HuiDrDoctor.module.home;

import java.util.List;

/**
 * @author: Administrator
 * @date: 2019-12-06
 */
public class AllContractModel {
    /**
     * status : 0
     * page : 1
     * totalPage : 1
     * retValue : [{"id":14,"contactsId":140870,"contactsName":"胡金晶","contactsIcon":"article/uploadImg/timg.jpg","contactsDepartment":"骨科","contactsTitle":"主任医师","contactsInitials":"h","bindId":100161,"createTime":"2019-12-06","updateTime":"2019-12-06","isAssist":false},{"id":10,"contactsId":141197,"contactsName":"剑晨4","contactsIcon":"article/uploadImg/anquan.png","contactsDepartment":"精神科","contactsTitle":"主治医师","contactsInitials":"j","bindId":100161,"createTime":"2019-12-06","updateTime":"2019-12-06","isAssist":true},{"id":12,"contactsId":141196,"contactsName":"剑晨3","contactsIcon":"article/uploadImg/anquan.png","contactsDepartment":"精神科","contactsTitle":"主任医师","contactsInitials":"j","bindId":100161,"createTime":"2019-12-06","updateTime":"2019-12-06","isAssist":false}]
     */

    private int status;
    private int page;
    private int totalPage;
    private List<RetValueBean> retValue;

    public int getStatus() {
        return status;
    }

    public void setStatus(int status) {
        this.status = status;
    }

    public int getPage() {
        return page;
    }

    public void setPage(int page) {
        this.page = page;
    }

    public int getTotalPage() {
        return totalPage;
    }

    public void setTotalPage(int totalPage) {
        this.totalPage = totalPage;
    }

    public List<RetValueBean> getRetValue() {
        return retValue;
    }

    public void setRetValue(List<RetValueBean> retValue) {
        this.retValue = retValue;
    }

    public static class RetValueBean {
        /**
         * id : 14
         * contactsId : 140870
         * contactsName : 胡金晶
         * contactsIcon : article/uploadImg/timg.jpg
         * contactsDepartment : 骨科
         * contactsTitle : 主任医师
         * contactsInitials : h
         * bindId : 100161
         * createTime : 2019-12-06
         * updateTime : 2019-12-06
         * isAssist : false
         */

        private int id;
        private int contactsId;
        private String contactsName;
        private String contactsIcon;
        private String contactsDepartment;
        private String contactsTitle;
        private String contactsInitials;
        private int bindId;
        private String createTime;
        private String updateTime;
        private boolean isAssist;

        public int getId() {
            return id;
        }

        public void setId(int id) {
            this.id = id;
        }

        public int getContactsId() {
            return contactsId;
        }

        public void setContactsId(int contactsId) {
            this.contactsId = contactsId;
        }

        public String getContactsName() {
            return contactsName;
        }

        public void setContactsName(String contactsName) {
            this.contactsName = contactsName;
        }

        public String getContactsIcon() {
            return contactsIcon;
        }

        public void setContactsIcon(String contactsIcon) {
            this.contactsIcon = contactsIcon;
        }

        public String getContactsDepartment() {
            return contactsDepartment;
        }

        public void setContactsDepartment(String contactsDepartment) {
            this.contactsDepartment = contactsDepartment;
        }

        public String getContactsTitle() {
            return contactsTitle;
        }

        public void setContactsTitle(String contactsTitle) {
            this.contactsTitle = contactsTitle;
        }

        public String getContactsInitials() {
            return contactsInitials;
        }

        public void setContactsInitials(String contactsInitials) {
            this.contactsInitials = contactsInitials;
        }

        public int getBindId() {
            return bindId;
        }

        public void setBindId(int bindId) {
            this.bindId = bindId;
        }

        public String getCreateTime() {
            return createTime;
        }

        public void setCreateTime(String createTime) {
            this.createTime = createTime;
        }

        public String getUpdateTime() {
            return updateTime;
        }

        public void setUpdateTime(String updateTime) {
            this.updateTime = updateTime;
        }

        public boolean isIsAssist() {
            return isAssist;
        }

        public void setIsAssist(boolean isAssist) {
            this.isAssist = isAssist;
        }
    }
}
