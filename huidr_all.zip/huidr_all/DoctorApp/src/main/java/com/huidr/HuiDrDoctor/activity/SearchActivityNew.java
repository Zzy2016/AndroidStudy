package com.huidr.HuiDrDoctor.activity;

import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.Matrix;
import android.graphics.drawable.BitmapDrawable;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import androidx.annotation.NonNull;

import androidx.appcompat.app.AppCompatActivity;

import android.text.Editable;
import android.text.Html;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.util.Log;
import android.view.Display;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.alibaba.fastjson.JSONObject;
import com.chad.library.adapter.base.BaseQuickAdapter;
import com.chad.library.adapter.base.BaseViewHolder;
import com.google.android.flexbox.FlexDirection;
import com.google.android.flexbox.FlexWrap;
import com.google.android.flexbox.FlexboxLayoutManager;
import com.google.android.material.tabs.TabLayout;
import com.google.gson.Gson;
import com.guanaj.easyswipemenulibrary.EasySwipeMenuLayout;
import com.huidr.HuiDrDoctor.activity.main.Consult.utils.PostAndGet;
import com.huidr.HuiDrDoctor.debug.BuildConfig;
import com.huidr.HuiDrDoctor.debug.R;
import com.huidr.HuiDrDoctor.module.home.DeleteHisModel;
import com.huidr.HuiDrDoctor.module.home.HisSearchModel;
import com.huidr.HuiDrDoctor.module.home.MessageSearchModel;
import com.huidr.HuiDrDoctor.module.home.PatientSearchModel;
import com.huidr.HuiDrDoctor.module.home.SearchContractModel;
import com.huidr.HuiDrDoctor.module.home.SimpleResultModel;
import com.huidr.HuiDrDoctor.util.CircleImageView;
import com.huidr.HuiDrDoctor.util.DownLoadImg;
import com.huidr.HuiDrDoctor.util.FormatTime;
import com.huidr.HuiDrDoctor.util.LogUtil;
import com.huidr.HuiDrDoctor.util.ThreadPoolManager;
import com.scwang.smartrefresh.layout.SmartRefreshLayout;
import com.scwang.smartrefresh.layout.api.RefreshLayout;
import com.scwang.smartrefresh.layout.listener.OnLoadMoreListener;
import com.scwang.smartrefresh.layout.listener.OnRefreshListener;
import com.tendcloud.tenddata.TCAgent;
import com.zyao89.view.zloading.ZLoadingDialog;
import com.zyao89.view.zloading.Z_TYPE;

import java.io.File;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.regex.Pattern;

import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import cn.jpush.im.android.api.JMessageClient;
import cn.jpush.im.android.api.content.TextContent;
import cn.jpush.im.android.api.model.Conversation;
import jiguang.chat.activity.ChatActivity;
import jiguang.chat.application.JGApplication;
import jiguang.chat.utils.oss.OssService;
import jiguang.chat.utils.oss.SharedPreferenciesUtil;

import static com.huidr.HuiDrDoctor.util.DownLoadImg.getCirleBitmap;

public class SearchActivityNew extends AppCompatActivity implements View.OnClickListener {


    private ImageView imgSearch, imgClear;
    private EditText etSearch;
    private TextView tvCancel;
    private ConstraintLayout clHis;
    private RecyclerView rvHisSearch;
    private InputMethodManager imm;
    //    空态
    private ConstraintLayout clEmpty;
    private TextView tvEmpty;
    private TextView tvEmpty1;
    private Button btnLink;
    //    历史搜索空态
    private ConstraintLayout cl_empty_his;
    private TextView tv_empty_his1, tv_empty_his2;
    private boolean showSearch;//显示搜索 true
    private HisSearchModel hisSearchModel;
    private List<HisSearchModel.RetValueBean> hisSearchList;
    private MessageSearchModel messageSearchModel;
    private List<MessageSearchModel.RetValueBean.DoctorBean> doctorList;
    private List<MessageSearchModel.RetValueBean.PatientBean> patientList;
    private Gson gson;
    private String pathHis = BuildConfig.baseUrl + "hospital/search/searchHis";//历史搜索

    private OssService ossService;
    private String doctorId = (String) SharedPreferenciesUtil.getData("id", "0");
    private long lastClick = 0;
    private long lastClick2 = 0;
    private String path;
    private Matrix matrix;
    private TabLayout tabTitle;
    private ConstraintLayout clSearch;
    private RecyclerView rvDoctor, rvPatient;
    private int searchIndex = 0; //0  患者 1 医生
    //    private TextView tvPatientLink, tvDoctorLink;
    private ImageView imgDeleteHis;

    private SmartRefreshLayout srlPatient, srlDoctor;

    private int totalPagePatient = 1;
    private int totalPageDoctor = 1;
    private int currentPatient = 1;
    private int currentDoctor = 1;

    String patientSearchPath = BuildConfig.baseUrl + "patient/doctorPatientMedical/getFollowUpPoolList"; //患者搜索
    String doctorSearchPath = BuildConfig.baseUrl + "hospital/doctorGroup/getDoctorList";//医生搜索
    SearchContractModel searchContractModel;
    PatientSearchModel patientSearchModel;
    Bitmap bitmap;

    String imgPath;

    ZLoadingDialog dialog;
    String pathAdd = BuildConfig.baseUrl + "hospital/doctorGroup/addAssistDoctor";//添加协同
    String pathDelete = BuildConfig.baseUrl + "hospital/doctorGroup/removeAssistDoctor";//删除协同

    View viewFooterPatient, viewFooterDoctor;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_search_new);

        matrix = new Matrix();
        matrix.setRotate(90);
        TCAgent.onEvent(this, "医生进入搜索页面的次数", "医生进入搜索页面的次数");
        imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
        path = getExternalFilesDir("").getAbsolutePath() + "/img/head/";
        ossService = new OssService(SearchActivityNew.this);
        imgPath = getExternalFilesDir("").getAbsolutePath() + "/img/head/";

        dialog = new ZLoadingDialog(SearchActivityNew.this);
        dialog.setLoadingBuilder(Z_TYPE.STAR_LOADING)//设置类型
                .setLoadingColor(Color.BLUE)//颜色
                .setHintText("处理中,请稍候...").setHintTextSize(16) // 设置字体大小 dp
                .setHintTextColor(Color.GRAY)  // 设置字体颜色
                .setDurationTime(0.5) // 设置动画时间百分比 - 0.5倍
                .setCanceledOnTouchOutside(false).setCancelable(false);


        initDate();
        initEmptyView();
        initSearchResultView();
        initHisSearch();
        initView();
    }

    //    隐藏软键盘
    public void hideImm(EditText editText) {
        if (imm != null) {
            imm.hideSoftInputFromWindow(editText.getWindowToken(), 0);
        }
    }

    public void initDate() {

        gson = new Gson();
        hisSearchModel = new HisSearchModel();
        hisSearchList = new ArrayList<>();
        messageSearchModel = new MessageSearchModel();
        doctorList = new ArrayList<>();
        patientList = new ArrayList<>();
        hisAdapter.setNewData(hisSearchList);
        searchContractModel = new SearchContractModel();
        patientSearchModel = new PatientSearchModel();

        getHisAdapter();
    }


    /*
     * 获取历史搜索记录
     * */
    public void getHisAdapter() {
        ThreadPoolManager.getInstance().execute(new Runnable() {
            @Override
            public void run() {
                JSONObject jsonObject = new JSONObject();
                jsonObject.put("searchType", 1);
                String result = PostAndGet.doHttpPost(pathHis, jsonObject);
                LogUtil.e("搜索历史", result);
                if (result.equals("网络异常")) {
                    handler.sendEmptyMessage(7);
                } else {
                    hisSearchModel = gson.fromJson(result, HisSearchModel.class);
                    if (hisSearchModel.getStatus() == 0) {
                        handler.sendEmptyMessage(6);
                    } else {
                        handler.sendEmptyMessage(7);
                    }
                }
            }
        });
    }

    /*删除历史记录   hospital/search/delSearchHis  uid*/
    public void deleteHisSearch() {

        ThreadPoolManager.getInstance().execute(new Runnable() {
            @Override
            public void run() {
                String deleteUrl = BuildConfig.baseUrl + "hospital/search/delSearchHis";
                JSONObject jsonObject = new JSONObject();
                jsonObject.put("uid", (String) SharedPreferenciesUtil.getData("id", "0"));
                jsonObject.put("searchType", 1);
                String result = PostAndGet.doHttpPost(deleteUrl, jsonObject);
                Log.e("123456", result);
                if (result.equals("网络异常")) {//删除历史记录失败
                    handler.sendEmptyMessage(13);
                } else {//删除历史记录成功
                    DeleteHisModel simpleResultModel = gson.fromJson(result, DeleteHisModel.class);
                    if (simpleResultModel.getStatus() == 0) {
                        handler.sendEmptyMessage(12);
                    } else {
                        handler.sendEmptyMessage(13);
                    }
                }
            }
        });

    }

    class Result {
        int status;
        String retValue;

        public int getStatus() {
            return status;
        }

        public void setStatus(int status) {
            this.status = status;
        }

        public String getRetValue() {
            return retValue;
        }

        public void setRetValue(String retValue) {
            this.retValue = retValue;
        }
    }

    //    空态页
    public void initEmptyView() {
        clEmpty = (ConstraintLayout) findViewById(R.id.cl_empty);
        tvEmpty = (TextView) findViewById(R.id.tv_empty);
        tvEmpty1 = (TextView) findViewById(R.id.tv_empty1);

        tvEmpty1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                doKeySearch();
            }
        });

        cl_empty_his = (ConstraintLayout) findViewById(R.id.cl_empty_his);
        tv_empty_his1 = (TextView) findViewById(R.id.tv_empty_his1);
        tv_empty_his2 = (TextView) findViewById(R.id.tv_empty_his2);

        tv_empty_his2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                getHisAdapter();
            }
        });
    }


    //    搜索结果
    public void initSearchResultView() {

        rvPatient = (RecyclerView) findViewById(R.id.rv_search_patient);
        rvDoctor = (RecyclerView) findViewById(R.id.rv_search_doctor);
        rvPatient.setAdapter(searchAdapter);
        rvPatient.setLayoutManager(new LinearLayoutManager(this));
        rvDoctor.setAdapter(doctorAdapter);
        rvDoctor.setLayoutManager(new LinearLayoutManager(this));


        viewFooterDoctor = LayoutInflater.from(this).inflate(R.layout.footer_doctor, rvDoctor, false);
        viewFooterPatient = LayoutInflater.from(this).inflate(R.layout.footer_patient, rvPatient, false);


        viewFooterPatient.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                SharedPreferenciesUtil.putData("currentId", 1);
                finish();
            }
        });

        viewFooterDoctor.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                SharedPreferenciesUtil.putData("currentId", 2);
                finish();
            }
        });


    }

    //    历史搜索
    public void initHisSearch() {
        clHis = (ConstraintLayout) findViewById(R.id.cl_his);
        rvHisSearch = (RecyclerView) findViewById(R.id.rv_his_search);

        rvHisSearch.setAdapter(hisAdapter);
        FlexboxLayoutManager manager = new FlexboxLayoutManager(this, FlexDirection.ROW, FlexWrap.WRAP) {
            @Override
            public boolean canScrollVertically() {
                return false;
            }
        };
        rvHisSearch.setLayoutManager(manager);
    }


    private void switchSearchResult() {
        clEmpty.setVisibility(View.GONE);
        if (searchIndex == 0) {
            srlDoctor.setVisibility(View.GONE);
            if (searchAdapter.getData().size() > 0) {
                srlPatient.setVisibility(View.VISIBLE);
            } else {
                clEmpty.setVisibility(View.VISIBLE);
                showPatientEmpty();
            }
        } else {
            srlPatient.setVisibility(View.GONE);
            if (doctorAdapter.getData().size() > 0) {
                srlDoctor.setVisibility(View.VISIBLE);
            } else {
                clEmpty.setVisibility(View.VISIBLE);
                showDoctorEmpty();
            }
        }
    }

    public void initView() {

        imgSearch = (ImageView) findViewById(R.id.image_search);
        imgClear = (ImageView) findViewById(R.id.image_clear);
        etSearch = (EditText) findViewById(R.id.et_search);
        tvCancel = (TextView) findViewById(R.id.tv_cancel);

        tvEmpty = (TextView) findViewById(R.id.tv_empty);
        tvEmpty1 = (TextView) findViewById(R.id.tv_empty1);
        btnLink = (Button) findViewById(R.id.btn_link);


        clSearch = (ConstraintLayout) findViewById(R.id.cl_search);

        tabTitle = (TabLayout) findViewById(R.id.tab_title);
        tabTitle.addTab(tabTitle.newTab().setText("患者"));
        tabTitle.addTab(tabTitle.newTab().setText("医生"));


        tabTitle.setOnTabSelectedListener(new TabLayout.OnTabSelectedListener() {
            @Override
            public void onTabSelected(TabLayout.Tab tab) {
                if (tab.getText().toString().equals("患者")) {
                    searchIndex = 0;
                } else {
                    searchIndex = 1;
                }
                switchSearchResult();
            }

            @Override
            public void onTabUnselected(TabLayout.Tab tab) {

            }

            @Override
            public void onTabReselected(TabLayout.Tab tab) {

            }
        });

//        tvPatientLink = (TextView) findViewById(R.id.tv_patient_link);
//        tvDoctorLink = (TextView) findViewById(R.id.tv_doctor_link);
//        tvPatientLink.setOnClickListener(this);
//        tvDoctorLink.setOnClickListener(this);

        imgSearch.setOnClickListener(this);
        imgClear.setOnClickListener(this);
        tvCancel.setOnClickListener(this);

        btnLink.setOnClickListener(this);

        etSearch.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {
                if (etSearch.getText().toString().length() > 0) {
                    imgClear.setVisibility(View.VISIBLE);
                } else {
                    imgClear.setVisibility(View.GONE);
                }
            }
        });

        /*
         * doKeySearch();  键盘监听
         * */
        etSearch.setOnEditorActionListener(new TextView.OnEditorActionListener() {
            @Override
            public boolean onEditorAction(TextView v, int actionId, KeyEvent event) {
                if (actionId == 3) {//
                    if (etSearch.getText().toString().length() > 0) {
                        Pattern pattern = Pattern.compile("^\\s*$");
                        if (pattern.matcher(etSearch.getText().toString()).matches()) {
                            Toast.makeText(SearchActivityNew.this, "请重新输入", Toast.LENGTH_LONG).show();
                            etSearch.setText("");
                        } else {
                            doKeySearch();
                        }
                    }
                    return true;
                } else {
                    return false;
                }
            }
        });

        imgDeleteHis = (ImageView) findViewById(R.id.img_delete_his);

        imgDeleteHis.setOnClickListener(this);

        srlPatient = (SmartRefreshLayout) findViewById(R.id.srl_patient);
        srlDoctor = (SmartRefreshLayout) findViewById(R.id.srl_doctor);


        srlPatient.setOnRefreshListener(new OnRefreshListener() {
            @Override
            public void onRefresh(@NonNull RefreshLayout refreshLayout) {
                currentPatient = 1;
                searchPatient();
            }
        });

        srlPatient.setOnLoadMoreListener(new OnLoadMoreListener() {
            @Override
            public void onLoadMore(@NonNull RefreshLayout refreshLayout) {
                if (patientSearchModel.getRetValue().size() == 20 && currentPatient < totalPagePatient) {
                    currentPatient += 1;
                    searchPatient();
                } else {
                    srlPatient.finishLoadMore();
                }
            }
        });

        srlDoctor.setOnRefreshListener(new OnRefreshListener() {
            @Override
            public void onRefresh(@NonNull RefreshLayout refreshLayout) {
                currentDoctor = 1;
                searchDoctor();
            }
        });

        srlDoctor.setOnLoadMoreListener(new OnLoadMoreListener() {
            @Override
            public void onLoadMore(@NonNull RefreshLayout refreshLayout) {
                if (doctorAdapter.getData().size() == 20 && currentDoctor < totalPageDoctor) {
                    currentDoctor += 1;
                    searchDoctor();
                } else {
                    srlDoctor.finishLoadMore();
                }
            }
        });


    }


    /*显示患者搜索为空*/
    public void showPatientEmpty() {
        tvEmpty.setText("暂未搜索到该患者，您可以去");
        String test = "开启患者<font color='#248cfa'>随访报到</font>";
        tvEmpty1.setText(Html.fromHtml(test));
        btnLink.setText("随访报到");
    }

    /*显示医生搜索为空*/
    public void showDoctorEmpty() {
        tvEmpty.setText("暂未搜索到该医生");
        String test = "请<font color='#248cfa'>添加医生联系人</font>";
        tvEmpty1.setText(Html.fromHtml(test));
        btnLink.setText("添加联系人");
    }

    private Handler handler = new Handler() {
        @Override
        public void handleMessage(Message msg) {
            super.handleMessage(msg);

            switch (msg.what) {

                case 1:
//                    searchAdapter.getData().clear();
//                    doctorAdapter.getData().clear();
//
//                    if (messageSearchModel.getRetValue().getPatient().size() == 0) {
//                        clEmpty.setVisibility(View.VISIBLE);
//                        tvPatientLink.setVisibility(View.GONE);
//                        showPatientEmpty();
//                    } else {
//                        searchAdapter.setNewData(messageSearchModel.getRetValue().getPatient());
//                        clEmpty.setVisibility(View.GONE);
//                    }
//
//                    if (messageSearchModel.getRetValue().getDoctor().size() == 0) {
//                        clEmpty.setVisibility(View.VISIBLE);
//                        tvDoctorLink.setVisibility(View.GONE);
//                    } else {
//                        clSearch.setVisibility(View.VISIBLE);
//                        doctorAdapter.setNewData(messageSearchModel.getRetValue().getDoctor());
//                        clEmpty.setVisibility(View.GONE);
//                    }
//
//                    tabTitle.getTabAt(0).select();
//                    switchSearchResult();

                    break;

                case 3:
                    clSearch.setVisibility(View.GONE);
                    clEmpty.setVisibility(View.VISIBLE);
                    tvEmpty.setText("网络错误~");
                    tvEmpty1.setText(Html.fromHtml("<font color='#248cfa'><u>立即刷新<u><font>"));
                    break;

                //关注患者成功
                case 4:
                    String tip = "";
                    Boolean atten = (Boolean) msg.obj;
//                    if (atten) {
//                        tip = "关注患者成功";
//                        searchAdapter.getData().get(msg.arg1).setIsFollow(true);
//                    } else {
//                        tip = "取消成功";
//                        searchAdapter.getData().get(msg.arg1).setIsFollow(false);
//                    }
                    com.huidr.lib.commom.util.Toast.getInstance(SearchActivityNew.this).show(tip, 500);
                    searchAdapter.notifyDataSetChanged();
                    break;
//                    关注患者失败
                case 5:
                    String str = "";
                    Boolean atten1 = (Boolean) msg.obj;
                    if (atten1) {
                        str = "关注患者失败";
                    } else {
                        str = "取消失败";
                    }
                    com.huidr.lib.commom.util.Toast.getInstance(SearchActivityNew.this).show(str, 500);
                    break;

                case 6://获取搜索记录成功
                    hisAdapter.getData().clear();
                    if (hisSearchModel.getRetValue().size() == 0) {
                        rvHisSearch.setVisibility(View.GONE);
                        cl_empty_his.setVisibility(View.VISIBLE);
                        tv_empty_his1.setText("暂无搜索记录~");
                        tv_empty_his2.setText("");
                        imgDeleteHis.setVisibility(View.GONE);
                    } else {
                        rvHisSearch.setVisibility(View.VISIBLE);
                        cl_empty_his.setVisibility(View.GONE);
                        clEmpty.setVisibility(View.GONE);
                        hisAdapter.getData().addAll(hisSearchModel.getRetValue());
                        hisAdapter.notifyDataSetChanged();
                        imgDeleteHis.setVisibility(View.VISIBLE);
                    }
                    break;
                case 7://获取搜索记录失败
                    rvHisSearch.setVisibility(View.GONE);
                    cl_empty_his.setVisibility(View.VISIBLE);
                    tv_empty_his1.setText("网络错误~");
                    String tip1 = "<font color='#248cfa'><u>立即刷新<u><font>";
                    tv_empty_his2.setText(Html.fromHtml(tip1));
                    break;
//                搜索患者成功 第一页
                case 8:
                    searchAdapter.getData().clear();
                    searchAdapter.notifyDataSetChanged();

                    if (patientSearchModel.getRetValue().size() == 0) {
                        srlPatient.setVisibility(View.VISIBLE);
                        clEmpty.setVisibility(View.VISIBLE);
                        showPatientEmpty();
                    } else {
                        searchAdapter.getData().addAll(patientSearchModel.getRetValue());
                        searchAdapter.notifyDataSetChanged();

                        if (searchAdapter.getFooterLayoutCount() == 0) {
                            searchAdapter.addFooterView(viewFooterPatient);
                        }
                    }

                    srlPatient.finishRefresh();

                    break;
//                    搜索患者 加载更多
                case 9:
                    searchAdapter.getData().addAll(patientSearchModel.getRetValue());
                    searchAdapter.notifyDataSetChanged();
                    srlPatient.finishLoadMore();
                    break;
//                    搜索医生 第一页
                case 10:
                    doctorAdapter.getData().clear();
                    doctorAdapter.notifyDataSetChanged();
                    if (searchContractModel.getRetValue().size() == 0) {
                        srlDoctor.setVisibility(View.VISIBLE);
                        clEmpty.setVisibility(View.VISIBLE);
                        showDoctorEmpty();
                    } else {
                        doctorAdapter.getData().addAll(searchContractModel.getRetValue());
                        doctorAdapter.notifyDataSetChanged();
                        if (doctorAdapter.getFooterLayoutCount() == 0) {
                            doctorAdapter.addFooterView(viewFooterDoctor);
                        }
                    }
                    srlDoctor.finishRefresh();
                    break;
//                    搜索医生 加载更多
                case 11:
                    doctorAdapter.getData().addAll(searchContractModel.getRetValue());
                    doctorAdapter.notifyDataSetChanged();
                    srlDoctor.finishLoadMore();
                    break;

                /*删除历史记录成功*/
                case 12:
//                    显示 搜索历史空态页
                    rvHisSearch.setVisibility(View.GONE);
                    cl_empty_his.setVisibility(View.VISIBLE);
                    tv_empty_his1.setText("暂无搜索记录~");
                    tv_empty_his2.setText("");
                    break;
                /*删除历史记录失败*/
                case 13:
                    Toast.makeText(SearchActivityNew.this, "删除失败,请稍后重试", Toast.LENGTH_SHORT).show();
                    break;
            }
        }
    };

    private BaseQuickAdapter<PatientSearchModel.RetValueBean, BaseViewHolder> searchAdapter = new BaseQuickAdapter<PatientSearchModel.RetValueBean, BaseViewHolder>(R.layout.item_scroll_layout) {
        @Override
        protected void convert(final BaseViewHolder helper, final PatientSearchModel.RetValueBean item) {

            EasySwipeMenuLayout esml_item = helper.getView(R.id.esml_item);
            esml_item.setCanLeftSwipe(false);

            ConstraintLayout clItem = helper.getView(R.id.cl_item);

            ImageView imgItemHead = helper.getView(R.id.img_item_head);
//            setPatientImage(imgItemHead, item.getBindUserRelationship(), item.getUserSex());
            ImageView imgNotice = helper.getView(R.id.img_notice);
            imgNotice.setVisibility(View.GONE);
            ImageView imageItemGender = helper.getView(R.id.image_item_gender);
            imageItemGender.setVisibility(View.VISIBLE);
            if (item.getUserSex() == 1) {
                imageItemGender.setBackgroundResource(R.drawable.gender_man);
            } else if (item.getUserSex() == 2) {
                imageItemGender.setBackgroundResource(R.drawable.gender_w);
            } else {

            }

            TextView tvItemName = helper.getView(R.id.tv_item_name);
            tvItemName.setText(item.getUserName());
            TextView tvItemAge = helper.getView(R.id.tv_item_age);
            tvItemAge.setText(item.getLatelyAdmitNo());
            TextView tvItemState = helper.getView(R.id.tv_item_state);
            TextView tvItemDate = helper.getView(R.id.tv_item_date);
            tvItemDate.setText(item.getLatelyVisitingDate());
            TextView tvItemMsg = helper.getView(R.id.tv_item_msg);

            tvItemMsg.setText(item.getLatelyAdmissionDiagnosis());

            TextView tvItemMode = helper.getView(R.id.tv_item_model);
            tvItemMode.setText(item.getFollowupName());

            TextView tvScrollRight = helper.getView(R.id.tv_scroll_right);

            Button btnApply = helper.getView(R.id.btn_apply);
            btnApply.setVisibility(View.GONE);

            String tip = "";
            if (item.isIsFollow()) {
                tip = "<font>已<br>关注<font>";
                tvScrollRight.setBackgroundResource(R.drawable.shape_atten_gray);
            } else {
                tip = "<font>关注<br>患者<font>";
            }
            tvScrollRight.setText(Html.fromHtml(tip));
            tvScrollRight.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (item.isIsFollow()) { //已经关注 取消关注
//                        modifyAttent(false, helper.getAdapterPosition(), item.getId());
                        searchAdapter.notifyDataSetChanged();
                        Toast.makeText(SearchActivityNew.this, "该患者已关注", Toast.LENGTH_SHORT).show();
                    } else {  //未关注 添加关注
//                        modifyAttent(true, helper.getAdapterPosition(), item.getId());
                        showCoopDialog(true, helper.getAdapterPosition(), item.getId());
                    }
                }
            });


            clItem.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (System.currentTimeMillis() - lastClick > 1000) {
                        JSONObject jsonObject = new JSONObject();
                        jsonObject.put("id", item.getId());
                        SharedPreferenciesUtil.putData("psearchID", jsonObject.toJSONString());
                        SharedPreferenciesUtil.putData("followDoctorId", item.getDoctorId());

                        Intent intent1 = new Intent(SearchActivityNew.this, WebActivity.class);
                        Bundle bundle = new Bundle();
                        bundle.putString("url", "patientData.html");
                        intent1.putExtras(bundle);
                        startActivity(intent1);
                        lastClick = System.currentTimeMillis();
                    }
                }
            });

        }
    };


    //    取消添加协同对话框
    public void showCoopDialog(final String id, final int position, final boolean isCoop) {

        final Dialog builder = new Dialog(SearchActivityNew.this, R.style.jmui_default_dialog_style);
        //final Dialog builder = new Dialog(this, R.style.jmui_default_dialog_style);
        View view = LayoutInflater.from(SearchActivityNew.this).inflate(R.layout.dialog_content, null);

        TextView tvTitle = view.findViewById(R.id.tv_title);
        TextView tvFooter1 = view.findViewById(R.id.tv_footer1);
        TextView tvFooter2 = view.findViewById(R.id.tv_footer2);

        if (isCoop) {
            tvTitle.setText("是否删除协同医生!");
        } else {
            tvTitle.setText("是否添加协同医生!");
        }


//        取消
        tvFooter1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                builder.cancel();
                searchAdapter.notifyItemChanged(position);
            }
        });
//确定
        tvFooter2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                builder.cancel();
                if (isCoop) {
                    deleteCooperDoctor(id, position);
                } else {
                    addAssistDoctor(id, position);
                }
            }
        });

        builder.setContentView(view);
        //builder.setCanceledOnTouchOutside(true);
        builder.show();
        Window window = builder.getWindow();
        WindowManager.LayoutParams lp = window.getAttributes();
        WindowManager windowManager = getWindowManager();
        Display display = windowManager.getDefaultDisplay();
        lp.width = (int) (display.getWidth() * 0.7);
//        lp.height = (int) (display.getHeight() * 0.1);
        window.setAttributes(lp);
    }

    public void addAssistDoctor(final String id, final int position) {
        ThreadPoolManager.getInstance().execute(new Runnable() {
            @Override
            public void run() {
                JSONObject jsonObject = new JSONObject();
                int uid = Integer.valueOf(id);
                int[] a = new int[]{uid};
                jsonObject.put("assistUids", a);

                String result = PostAndGet.doHttpPost(pathAdd, jsonObject);
                LogUtil.e("添加协同医生", result);
                if (result.equals("网络异常")) {
                    handler.sendEmptyMessage(12);
                } else {
                    SimpleResultModel simpleResultModel = gson.fromJson(result, SimpleResultModel.class);
                    if (simpleResultModel.getStatus() == 0) {
                        if (simpleResultModel.getRetValue() == 0) {
//
                            Message msg = new Message();
                            msg.what = 11;
                            msg.arg1 = position;
                            handler.sendMessage(msg);

                        } else {
                            handler.sendEmptyMessage(12);
                        }
                    } else {
                        handler.sendEmptyMessage(12);
                    }
                }
            }
        });
    }

    //    删除协同医生
    public void deleteCooperDoctor(final String deleteId, final int position) {
        ThreadPoolManager.getInstance().execute(new Runnable() {
            @Override
            public void run() {
                JSONObject jsonObject = new JSONObject();
                jsonObject.put("assistUid", deleteId);
                String result = PostAndGet.doHttpPost(pathDelete, jsonObject);
                if (result.equals("网络异常")) {
                    handler.sendEmptyMessage(14);
                } else {
                    SimpleResultModel simpleResultModel = gson.fromJson(result, SimpleResultModel.class);
                    if (simpleResultModel.getStatus() == 0) {
                        if (simpleResultModel.getRetValue() == 0) {
                            Message message = new Message();
                            message.arg1 = position;
                            message.what = 13;
                            handler.sendMessage(message);
                        }

                    } else {
                        handler.sendEmptyMessage(14);
                    }
                }
            }
        });
    }

    public void addContact(final String targetId, final int position) {
        ThreadPoolManager.getInstance().execute(new Runnable() {
            @Override
            public void run() {
                String path = BuildConfig.baseUrl + "hospital/doctorGroup/addContacts";
                JSONObject jsonObject = new JSONObject();
                String id = (String) SharedPreferenciesUtil.getData("id", "0");
//                申请人ID  applicantId
                jsonObject.put("applicantId", id);
                //                本申请人ID applicantId
                jsonObject.put("respondentId", targetId);

                String result = PostAndGet.doHttpPost(path, jsonObject);
                LogUtil.e("添加联系人", result);
                if (result.equals("网络异常")) {
                    handler.sendEmptyMessage(10);
                } else {
                    SimpleResultModel simpleResultModel = gson.fromJson(result, SimpleResultModel.class);
                    if (simpleResultModel.getStatus() == 0) {
//                        1发送成功 0 24小时内不能重复发送
                        if (simpleResultModel.getRetValue() == 1) {
//                            handler.sendEmptyMessage(8);
                            Message message = new Message();
                            message.what = 8;
                            message.arg1 = position;
                            handler.sendMessage(message);
                        } else if (simpleResultModel.getRetValue() == -1) {
                            handler.sendEmptyMessage(9);
                        } else {
                            handler.sendEmptyMessage(10);
                        }
                    } else {
                        handler.sendEmptyMessage(10);
                    }
                }
            }
        });
    }

    /*
    * 搜索
    * 清除
      取消
    *
    * */
    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.image_search:
                if (etSearch.getText().toString().length() > 0) {
                    Pattern pattern = Pattern.compile("^\\s*$");
                    if (pattern.matcher(etSearch.getText().toString()).matches()) {
                        Toast.makeText(SearchActivityNew.this, "请重新输入", Toast.LENGTH_LONG).show();
                        etSearch.setText("");
                    } else {
                        doKeySearch();
                    }
                } else {
                    Toast.makeText(SearchActivityNew.this, "请重新输入", Toast.LENGTH_LONG).show();
                }

                break;
            case R.id.image_clear:
                searchAdapter.getData().clear();
                searchAdapter.notifyDataSetChanged();
                doctorAdapter.getData().clear();
                doctorAdapter.notifyDataSetChanged();
                showSearch = false;
                etSearch.setText("");
                refreshPage();
                getHisAdapter();
                break;
            case R.id.tv_cancel:
                finish();
                break;

//            case R.id.tv_patient_link:
////                跳转患者池 全部患者
//                SharedPreferenciesUtil.putData("currentId", 1);
//                finish();
//                break;
//            case R.id.tv_doctor_link:
////联系人 全部联系人
//                SharedPreferenciesUtil.putData("currentId", 2);
//                finish();
//                break;

            case R.id.btn_link:
                if (btnLink.getText().toString().equals("随访报到")) {
                    SharedPreferenciesUtil.putData("currentId", 3);
                } else {//联系人 申请添加
                    SharedPreferenciesUtil.putData("currentId", 2);
                    SharedPreferenciesUtil.putData("friendIndex", 3);
                }
                finish();
                break;
            case R.id.img_delete_his:
                /*删除历史记录*/
                deleteHisSearch();
                break;


        }
    }

    /*
     * 关键字搜索
     * */
    public void doKeySearch() {
        TCAgent.onEvent(this, "医生搜索的次数", "医生搜索的次数");
        showSearch = true;
        hideImm(etSearch);
        refreshPage();
        searchPatient();

    }

    /*患者搜索*/
    public void searchPatient() {
        ThreadPoolManager.getInstance().execute(new Runnable() {
            @Override
            public void run() {
                String result = PostAndGet.doGetHttp(patientSearchPath + "?pageSize=20&pageIndex=" + currentPatient + "&userName=" + etSearch.getText().toString());
                LogUtil.e("搜索结果--患者", result);
                searchDoctor();
                if (result.equals("网络异常")) {
//                    handler.sendEmptyMessage(3);
                } else {
                    patientSearchModel = gson.fromJson(result, PatientSearchModel.class);
                    if (patientSearchModel.getStatus() == 0) {
                        totalPagePatient = patientSearchModel.getTotalPage();

                        if (currentPatient == 1) {
                            handler.sendEmptyMessage(8);
                        } else {
                            handler.sendEmptyMessage(9);
                        }
                    } else {
                        handler.sendEmptyMessage(3);
                    }
                }
            }
        });
    }

    /*医生搜索*/
    public void searchDoctor() {
        ThreadPoolManager.getInstance().execute(new Runnable() {
            @Override
            public void run() {
                JSONObject jsonObject = new JSONObject();
                jsonObject.put("pageIndex", currentDoctor);
                jsonObject.put("pageSize", 20);
                jsonObject.put("search", etSearch.getText().toString());
                String result = PostAndGet.doHttpPost(doctorSearchPath, jsonObject);
                searchContractModel = new SearchContractModel();

                LogUtil.e("搜索结果--医生", result);
                if (result.equals("网络异常")) {
                    handler.sendEmptyMessage(3);
                } else {
                    searchContractModel = gson.fromJson(result, SearchContractModel.class);
                    if (searchContractModel.getStatus() == 0) {
                        totalPageDoctor = searchContractModel.getTotalPage();
                        if (currentDoctor == 1) {
                            handler.sendEmptyMessage(10);
                        } else {
                            handler.sendEmptyMessage(11);
                        }
                    } else {
                        handler.sendEmptyMessage(3);
                    }
                }

            }
        });
    }

    /*
     * 刷新显示
     * true  显示搜索结果 搜索结果为空 显示空态页
     * false 隐藏搜搜结果页 显示搜索历史
     *
     */
    public void refreshPage() {
        if (showSearch) {
            clHis.setVisibility(View.GONE);
            clSearch.setVisibility(View.VISIBLE);
            Log.e("显示设置", "搜索结果");
        } else {
            clHis.setVisibility(View.VISIBLE);
            clSearch.setVisibility(View.GONE);
            Log.e("显示设置", "搜索历史");
            clEmpty.setVisibility(View.GONE);
            getHisAdapter();
        }
    }


    /*
     * 历史搜索 适配
     * */
    private BaseQuickAdapter<HisSearchModel.RetValueBean, BaseViewHolder> hisAdapter = new BaseQuickAdapter<HisSearchModel.RetValueBean, BaseViewHolder>(R.layout.item_tip) {
        @Override
        protected void convert(BaseViewHolder helper, final HisSearchModel.RetValueBean item) {
            TextView tvTip = helper.getView(R.id.tv_tip);
            tvTip.setText(item.getSearchContent());

            tvTip.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    etSearch.setText(item.getSearchContent());
//                    showSearch = true;
                    doKeySearch();
                    TCAgent.onEvent(SearchActivityNew.this, "历史搜索的点击次数", "历史搜索的点击次数");
                }
            });
        }
    };


    //    取消添加协同对话框
    public void showCoopDialog(final boolean atten, final int position, final int patientId) {

        final Dialog builder = new Dialog(this, R.style.jmui_default_dialog_style);
        //final Dialog builder = new Dialog(this, R.style.jmui_default_dialog_style);
        View view = LayoutInflater.from(this).inflate(R.layout.dialog_content, null);

        TextView tvTitle = view.findViewById(R.id.tv_title);
        TextView tvFooter1 = view.findViewById(R.id.tv_footer1);
        TextView tvFooter2 = view.findViewById(R.id.tv_footer2);

        tvTitle.setText("是否关注该患者！");


//        取消
        tvFooter1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                builder.cancel();
                searchAdapter.notifyDataSetChanged();
            }
        });
//确定
        tvFooter2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                builder.cancel();
                modifyAttent(atten, position, patientId);
                searchAdapter.notifyDataSetChanged();
            }
        });

        builder.setContentView(view);
        //builder.setCanceledOnTouchOutside(true);
        builder.show();
        Window window = builder.getWindow();
        WindowManager.LayoutParams lp = window.getAttributes();
        WindowManager windowManager = getWindowManager();
        Display display = windowManager.getDefaultDisplay();
        lp.width = (int) (display.getWidth() * 0.7);
//        lp.height = (int) (display.getHeight() * 0.1);
        window.setAttributes(lp);
    }


    //    关注患者  取消关注
    public void modifyAttent(final boolean atten, final int position, final int patientId) {
        ThreadPoolManager.getInstance().execute(new Runnable() {
            @Override
            public void run() {
                String id = (String) SharedPreferenciesUtil.getData("id", "0");

                String path = BuildConfig.baseUrl + "patient/doctorPatientMedical/addRemarksAndFollow?doctorId=" + id + "&patientId=" + patientId + "&isFollow=" + atten;
                String result = PostAndGet.doGetHttp(path);

//                LogUtil.e("关注", result);
                if (result.equals("网络异常")) {

                } else {
                    SimpleResultModel simpleResultModel = gson.fromJson(result, SimpleResultModel.class);
                    Message message = new Message();
                    message.obj = atten;
                    if (simpleResultModel.getStatus() == 0) {
                        message.what = 4;
                        message.arg1 = position;
                        handler.sendMessage(message);
                    } else {
                        message.what = 5;
                        handler.sendMessage(message);
                    }
                }

            }
        });
    }


    /*
     * 搜索结果  适配
     *
     * */
    private BaseQuickAdapter<SearchContractModel.RetValueBean, BaseViewHolder> doctorAdapter = new BaseQuickAdapter<SearchContractModel.RetValueBean, BaseViewHolder>(R.layout.item_scroll_layout) {

        @Override
        protected void convert(final BaseViewHolder helper, final SearchContractModel.RetValueBean item) {

//            helper.setIsRecyclable(false);
            final CircleImageView imgItemHead = helper.getView(R.id.img_item_head);
//            imgItemHead.setBackgroundResource(R.drawable.nantou);

            EasySwipeMenuLayout esml_item = helper.getView(R.id.esml_item);
            esml_item.setCanLeftSwipe(false);

            ConstraintLayout clItem = helper.getView(R.id.cl_item);
            clItem.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (System.currentTimeMillis() - lastClick > 1000) {
                        if (item.isIsContacts()) {
                            if (JMessageClient.getMyInfo() == null) {
                                return;
                            }
                            Intent intent = new Intent(SearchActivityNew.this, ChatActivity.class);
                            Bundle bundle = new Bundle();
                            bundle.putString("targetId", item.getId() + "");
                            bundle.putString(JGApplication.CONV_TITLE, item.getUserName());
                            bundle.putString(JGApplication.TARGET_APP_KEY, BuildConfig.appkey);
                            intent.putExtras(bundle);
                            startActivity(intent);
                        } else {
                            Intent intent1 = new Intent(SearchActivityNew.this, WebActivity.class);
                            Bundle bundle = new Bundle();
                            bundle.putString("url", "personal.html?id=" + item.getId());
                            intent1.putExtras(bundle);
                            startActivity(intent1);
                        }
                        lastClick = System.currentTimeMillis();
                    }
                }
            });


            TextView textView = helper.getView(R.id.tv_scroll_right);
            String st = "<font>添加<br />协同</font>";
            textView.setText(Html.fromHtml(st));

            TextView tvItemName = helper.getView(R.id.tv_item_name);
            tvItemName.setText(item.getUserName());
            TextView tvItemMsg = helper.getView(R.id.tv_item_msg);

            Bitmap bitmapDoctor = BitmapFactory.decodeResource(getResources(), R.drawable.default_doctor);
            BitmapDrawable bitmapDrawable = new BitmapDrawable(getResources(), bitmapDoctor);
            imgItemHead.setBackgroundDrawable(bitmapDrawable);

            if (item.getUserIcon() != null) {


                imgItemHead.setTag(item.getUserIcon());


                final File file = new File(imgPath + item.getUserIcon());
                if (file.exists()) {

                    bitmap = BitmapFactory.decodeFile(file.getAbsolutePath());
                    if (bitmap != null) {
                        bitmap = getCirleBitmap(bitmap);
                        BitmapDrawable bitmapDrawable1 = new BitmapDrawable(getResources(), bitmap);
                        if (imgItemHead.getTag().equals(item.getUserIcon())) {
                            imgItemHead.setBackgroundDrawable(bitmapDrawable1);
//                            tvItemMsg.setText("本地 TAg  " + imgItemHead.getTag() + "   url" + item.getUserIcon());
                        }
                    } else {
//                        imgItemHead.setBackgroundResource(R.drawable.nantou);
                    }
                } else {
                    DownLoadImg.BitmapWorkerTask bitmapWorkerTask = new DownLoadImg.BitmapWorkerTask(imgItemHead, file, ossService);
                    bitmapWorkerTask.execute(item.getUserIcon());
                }
            } else {
                imgItemHead.setBackgroundResource(R.drawable.nantou);
                tvItemMsg.setText("没有头像 TAg  " + imgItemHead.getTag() + "   url" + item.getUserIcon());
            }


            ImageView imgNotice = helper.getView(R.id.img_notice);
            imgNotice.setVisibility(View.GONE);
            ImageView imageItemGender = helper.getView(R.id.image_item_gender);
            TextView tvItemAge = helper.getView(R.id.tv_item_age);
            tvItemAge.setText(item.getHospitalDepartment() + "(" + item.getUserTitle() + ")");
            TextView tvItemState = helper.getView(R.id.tv_item_state);
            TextView tvItemDate = helper.getView(R.id.tv_item_date);
//            tvItemDate.setVisibility(View.GONE);
//            tvItemDate.setText(item.getDoctorSearchDate());


            if (!TextUtils.isEmpty(item.getDoctorSearchDate())) {
                SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
                try {
                    Date date = simpleDateFormat.parse(item.getDoctorSearchDate());
                    tvItemDate.setText(FormatTime.getTime(date.getTime()));
                } catch (ParseException e) {
                    e.printStackTrace();
                }
            } else {
                tvItemDate.setText("");
            }


//            tvItemMsg.setText(item.getLatelyAdmissionDiagnosis());
            TextView tvItemModel = helper.getView(R.id.tv_item_model);
            tvItemModel.setVisibility(View.GONE);
            TextView tvScrollRight = helper.getView(R.id.tv_scroll_right);
            Conversation conversation = JMessageClient.getSingleConversation(item.getId() + "");
//            if (conversation == null) {
//                imgNotice.setVisibility(View.GONE);
//            } else {
//                if (conversation.getUnReadMsgCnt() > 0) {
//                    imgNotice.setVisibility(View.VISIBLE);
//                } else {
//                    imgNotice.setVisibility(View.GONE);
//                }
//            }
            final Button btnApply = helper.getView(R.id.btn_apply);
            if (item.isIsContacts()) {
                btnApply.setBackgroundResource(R.drawable.btn_apply_gray);
                btnApply.setText("已申请");
            } else {
                if (item.isIsApply()) {
                    btnApply.setBackgroundResource(R.drawable.btn_apply_gray);
                    btnApply.setText("已申请");
                } else {
                    btnApply.setBackgroundResource(R.drawable.btn_grad_empty);
                    btnApply.setText("申请");
                }
            }


//            已经是好友
            if (item.isIsContacts()) {
//                esml_item.setCanLeftSwipe(true);
                if (conversation == null) {
                    tvItemMsg.setText("暂无聊天消息");
                } else {
                    cn.jpush.im.android.api.model.Message message = conversation.getLatestMessage();
                    if (message != null) {
                        switch (message.getContentType()) {
                            case text:
                                tvItemMsg.setText(((TextContent) message.getContent()).getText());
                                break;
                            case voice:
                                tvItemMsg.setText("[语音消息]");
                                break;
                            case image:
                                tvItemMsg.setText("[图片]");
                                break;
                            case file:
                                tvItemMsg.setText("[文件]");
                                break;
                            case location:
                                tvItemMsg.setText("[位置]");
                                break;
                            default:
                                break;
                        }
                    }

                    tvItemDate.setText(FormatTime.getTime(message.getCreateTime()));
                }
            } else {
//                esml_item.setCanLeftSwipe(false);
                tvItemMsg.setText("该医生还不是您的联系人");
            }
//            btnApply.setOnClickListener(new View.OnClickListener() {
//                @Override
//                public void onClick(View v) {
//                    if (btnApply.getText().toString().equals("已申请")) {
//                    } else {
//                        dialog.show();
//                        ContactManager.sendInvitationRequest(item.getId() + "", "", "", new BasicCallback() {
//                            @Override
//                            public void gotResult(int responseCode, String responseMessage) {
//                                if (0 == responseCode) {
//                                    LogUtil.e("极光发送邀请成功", "极光发送邀请成功");
//                                    addContact(item.getId() + "", helper.getAdapterPosition());
//                                } else {
//                                    LogUtil.e("极光发送邀请失败", "极光发送邀请失败" + responseMessage);
//                                    dialog.dismiss();
//                                    if (responseMessage.equals("Target user cannot be yourself.")) {
//                                        com.huidr.lib.commom.util.Toast.getInstance(SearchActivityNew.this).show("不能发送邀请给自己", 500);
//                                    } else {
//                                        com.huidr.lib.commom.util.Toast.getInstance(SearchActivityNew.this).show("邀请发送失败", 500);
//                                    }
//                                }
//                            }
//                        });
//                    }
//                }
//            });

            btnApply.setVisibility(View.GONE);

//            String tip = "";
//            if (item.isIsAssist()) {
//                tip = "<font>取消<br>协同<font>";
//                tvScrollRight.setBackgroundResource(R.drawable.shape_atten_gray);
//            } else {
//                tip = "<font>添加<br>协同<font>";
//                tvScrollRight.setBackgroundResource(R.drawable.btn_grad_empty);
//            }
//            tvScrollRight.setText(Html.fromHtml(tip));
//            tvScrollRight.setOnClickListener(new View.OnClickListener() {
//                @Override
//                public void onClick(View v) {
//                    showCoopDialog(item.getId() + "", helper.getAdapterPosition(), item.isIsAssist());
//                }
//            });
        }
    };


}
