package com.huidr.HuiDrDoctor.module.home;

import java.util.List;

/**
 * @author: Administrator
 * @date: 2020-04-15
 */
public class RelationQueListModel {


    /**
     * status : 0
     * page : 1
     * totalPage : 1
     * retValue : [{"id":3492,"chaseId":3460,"problemContent":"5565485624666845158533545","diseasePicturePaths":"","answerType":2,"answer":"100138/sounds/caeb07da-5d4e-439b-a692-c214a19576ee.mp3","speechDuration":"6 \" ","patientId":45832,"userName":"徐炳荣","userSex":1,"userAge":65,"userHospitalName":"复旦大学附属中山医院","userDepartmentName":"肝肿瘤外科","userWardName":"四十七病区","userAdmitNo":"830627","hospitalName":"复旦大学附属中山医院","departmentName":"肝肿瘤外科","doctorId":100138,"doctorName":"测试肝肿瘤外科","doctorTitle":"主任医师","summitTime":"2020-04-24 16:57:08","replyTime":"2020-04-24 16:58:17","otherLabel":"追问","consultationDisease":"啦啦啦啦"}]
     */

    private int status;
    private int page;
    private int totalPage;
    private List<RetValueBean> retValue;

    public int getStatus() {
        return status;
    }

    public void setStatus(int status) {
        this.status = status;
    }

    public int getPage() {
        return page;
    }

    public void setPage(int page) {
        this.page = page;
    }

    public int getTotalPage() {
        return totalPage;
    }

    public void setTotalPage(int totalPage) {
        this.totalPage = totalPage;
    }

    public List<RetValueBean> getRetValue() {
        return retValue;
    }

    public void setRetValue(List<RetValueBean> retValue) {
        this.retValue = retValue;
    }

    public static class RetValueBean {
        /**
         * id : 3492
         * chaseId : 3460
         * problemContent : 5565485624666845158533545
         * diseasePicturePaths :
         * answerType : 2
         * answer : 100138/sounds/caeb07da-5d4e-439b-a692-c214a19576ee.mp3
         * speechDuration : 6 "
         * patientId : 45832
         * userName : 徐炳荣
         * userSex : 1
         * userAge : 65
         * userHospitalName : 复旦大学附属中山医院
         * userDepartmentName : 肝肿瘤外科
         * userWardName : 四十七病区
         * userAdmitNo : 830627
         * hospitalName : 复旦大学附属中山医院
         * departmentName : 肝肿瘤外科
         * doctorId : 100138
         * doctorName : 测试肝肿瘤外科
         * doctorTitle : 主任医师
         * summitTime : 2020-04-24 16:57:08
         * replyTime : 2020-04-24 16:58:17
         * otherLabel : 追问
         * consultationDisease : 啦啦啦啦
         */

        private int id;
        private int chaseId;
        private String problemContent;
        private String diseasePicturePaths;
        private int answerType;
        private String answer;
        private String speechDuration;
        private int patientId;
        private String userName;
        private int userSex;
        private int userAge;
        private String userHospitalName;
        private String userDepartmentName;
        private String userWardName;
        private String userAdmitNo;
        private String hospitalName;
        private String departmentName;
        private int doctorId;
        private String doctorName;
        private String doctorTitle;
        private String summitTime;
        private String replyTime;
        private String otherLabel;
        private String consultationDisease;

        public int getId() {
            return id;
        }

        public void setId(int id) {
            this.id = id;
        }

        public int getChaseId() {
            return chaseId;
        }

        public void setChaseId(int chaseId) {
            this.chaseId = chaseId;
        }

        public String getProblemContent() {
            return problemContent;
        }

        public void setProblemContent(String problemContent) {
            this.problemContent = problemContent;
        }

        public String getDiseasePicturePaths() {
            return diseasePicturePaths;
        }

        public void setDiseasePicturePaths(String diseasePicturePaths) {
            this.diseasePicturePaths = diseasePicturePaths;
        }

        public int getAnswerType() {
            return answerType;
        }

        public void setAnswerType(int answerType) {
            this.answerType = answerType;
        }

        public String getAnswer() {
            return answer;
        }

        public void setAnswer(String answer) {
            this.answer = answer;
        }

        public String getSpeechDuration() {
            return speechDuration;
        }

        public void setSpeechDuration(String speechDuration) {
            this.speechDuration = speechDuration;
        }

        public int getPatientId() {
            return patientId;
        }

        public void setPatientId(int patientId) {
            this.patientId = patientId;
        }

        public String getUserName() {
            return userName;
        }

        public void setUserName(String userName) {
            this.userName = userName;
        }

        public int getUserSex() {
            return userSex;
        }

        public void setUserSex(int userSex) {
            this.userSex = userSex;
        }

        public int getUserAge() {
            return userAge;
        }

        public void setUserAge(int userAge) {
            this.userAge = userAge;
        }

        public String getUserHospitalName() {
            return userHospitalName;
        }

        public void setUserHospitalName(String userHospitalName) {
            this.userHospitalName = userHospitalName;
        }

        public String getUserDepartmentName() {
            return userDepartmentName;
        }

        public void setUserDepartmentName(String userDepartmentName) {
            this.userDepartmentName = userDepartmentName;
        }

        public String getUserWardName() {
            return userWardName;
        }

        public void setUserWardName(String userWardName) {
            this.userWardName = userWardName;
        }

        public String getUserAdmitNo() {
            return userAdmitNo;
        }

        public void setUserAdmitNo(String userAdmitNo) {
            this.userAdmitNo = userAdmitNo;
        }

        public String getHospitalName() {
            return hospitalName;
        }

        public void setHospitalName(String hospitalName) {
            this.hospitalName = hospitalName;
        }

        public String getDepartmentName() {
            return departmentName;
        }

        public void setDepartmentName(String departmentName) {
            this.departmentName = departmentName;
        }

        public int getDoctorId() {
            return doctorId;
        }

        public void setDoctorId(int doctorId) {
            this.doctorId = doctorId;
        }

        public String getDoctorName() {
            return doctorName;
        }

        public void setDoctorName(String doctorName) {
            this.doctorName = doctorName;
        }

        public String getDoctorTitle() {
            return doctorTitle;
        }

        public void setDoctorTitle(String doctorTitle) {
            this.doctorTitle = doctorTitle;
        }

        public String getSummitTime() {
            return summitTime;
        }

        public void setSummitTime(String summitTime) {
            this.summitTime = summitTime;
        }

        public String getReplyTime() {
            return replyTime;
        }

        public void setReplyTime(String replyTime) {
            this.replyTime = replyTime;
        }

        public String getOtherLabel() {
            return otherLabel;
        }

        public void setOtherLabel(String otherLabel) {
            this.otherLabel = otherLabel;
        }

        public String getConsultationDisease() {
            return consultationDisease;
        }

        public void setConsultationDisease(String consultationDisease) {
            this.consultationDisease = consultationDisease;
        }
    }
}
