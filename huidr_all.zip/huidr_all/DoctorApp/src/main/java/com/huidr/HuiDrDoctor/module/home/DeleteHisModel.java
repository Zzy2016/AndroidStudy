package com.huidr.HuiDrDoctor.module.home;

/**
 * @author: Administrator
 * @date: 2020-04-02
 */
public class DeleteHisModel {

    /**
     * status : 0
     * retValue : 成功
     */

    private int status;
    private String retValue;

    public int getStatus() {
        return status;
    }

    public void setStatus(int status) {
        this.status = status;
    }

    public String getRetValue() {
        return retValue;
    }

    public void setRetValue(String retValue) {
        this.retValue = retValue;
    }
}
