package com.huidr.HuiDrDoctor.module.home;

import java.util.List;

/**
 * @author: Administrator
 * @date: 2020-04-16
 */
public class ReplyListModel {


    /**
     * status : 0
     * page : 1
     * totalPage : 1
     * retValue : [{"id":3426,"uid":100295,"chaseId":0,"problemTitle":null,"problemContent":"going你明明你明明吱吱吱why","isHandle":null,"summitTime":1587093162000,"answerType":null,"speechDuration":null,"userName":"徐炳荣","patientId":null,"userSex":null,"userAge":null,"userHospitalId":null,"userHospitalName":"复旦大学附属中山医院","userDepartmentId":null,"userDepartmentName":"肝肿瘤外科","userWardName":"四十七病区","userPrimaryPhysicianCode":null,"userPrimaryPhysicianName":"沈英皓","userAdmitNo":null,"hospitalId":null,"hospitalName":null,"departmentId":null,"departmentName":null,"doctorId":null,"doctorIcon":null,"doctorName":null,"doctorTitle":null,"replyTime":null,"isShow":null,"isFee":null,"diseasePicturePaths":null,"diseaseLabel":null,"otherLabel":null,"consultationDisease":null,"isOpenImage":null,"supplementInformation":null,"isAllowAppObtain":null,"answer":null},{"id":3427,"uid":100295,"chaseId":0,"problemTitle":null,"problemContent":"耳鸣胡明明滴滴滴滴定明灭","isHandle":null,"summitTime":1587093428000,"answerType":null,"speechDuration":null,"userName":"徐炳荣","patientId":null,"userSex":null,"userAge":null,"userHospitalId":null,"userHospitalName":"复旦大学附属中山医院","userDepartmentId":null,"userDepartmentName":"肝肿瘤外科","userWardName":"四十七病区","userPrimaryPhysicianCode":null,"userPrimaryPhysicianName":"沈英皓","userAdmitNo":null,"hospitalId":null,"hospitalName":null,"departmentId":null,"departmentName":null,"doctorId":null,"doctorIcon":null,"doctorName":null,"doctorTitle":null,"replyTime":null,"isShow":null,"isFee":null,"diseasePicturePaths":null,"diseaseLabel":null,"otherLabel":null,"consultationDisease":null,"isOpenImage":null,"supplementInformation":null,"isAllowAppObtain":null,"answer":null},{"id":3428,"uid":100295,"chaseId":0,"problemTitle":null,"problemContent":"KKK里是KKK里hill哦dollKKK","isHandle":null,"summitTime":1587093971000,"answerType":null,"speechDuration":null,"userName":"徐炳荣","patientId":null,"userSex":null,"userAge":null,"userHospitalId":null,"userHospitalName":"复旦大学附属中山医院","userDepartmentId":null,"userDepartmentName":"肝肿瘤外科","userWardName":"四十七病区","userPrimaryPhysicianCode":null,"userPrimaryPhysicianName":"沈英皓","userAdmitNo":null,"hospitalId":null,"hospitalName":null,"departmentId":null,"departmentName":null,"doctorId":null,"doctorIcon":null,"doctorName":null,"doctorTitle":null,"replyTime":null,"isShow":null,"isFee":null,"diseasePicturePaths":null,"diseaseLabel":null,"otherLabel":null,"consultationDisease":null,"isOpenImage":null,"supplementInformation":null,"isAllowAppObtain":null,"answer":null},{"id":3429,"uid":100295,"chaseId":0,"problemTitle":null,"problemContent":"的人1URL金秘籍记录估计手机膜1了","isHandle":null,"summitTime":1587094985000,"answerType":null,"speechDuration":null,"userName":"徐炳荣","patientId":null,"userSex":null,"userAge":null,"userHospitalId":null,"userHospitalName":"复旦大学附属中山医院","userDepartmentId":null,"userDepartmentName":"肝肿瘤外科","userWardName":"四十七病区","userPrimaryPhysicianCode":null,"userPrimaryPhysicianName":"沈英皓","userAdmitNo":null,"hospitalId":null,"hospitalName":null,"departmentId":null,"departmentName":null,"doctorId":null,"doctorIcon":null,"doctorName":null,"doctorTitle":null,"replyTime":null,"isShow":null,"isFee":null,"diseasePicturePaths":null,"diseaseLabel":null,"otherLabel":null,"consultationDisease":null,"isOpenImage":null,"supplementInformation":null,"isAllowAppObtain":null,"answer":null},{"id":3435,"uid":100137,"chaseId":0,"problemTitle":null,"problemContent":"阿里啦咯啦咯啦咯嘛？！？！。","isHandle":null,"summitTime":1587102354000,"answerType":null,"speechDuration":null,"userName":"丁和荣","patientId":null,"userSex":null,"userAge":null,"userHospitalId":null,"userHospitalName":"复旦大学附属中山医院","userDepartmentId":null,"userDepartmentName":"肝肿瘤外科","userWardName":"四十四病区","userPrimaryPhysicianCode":null,"userPrimaryPhysicianName":"孙惠川","userAdmitNo":null,"hospitalId":null,"hospitalName":null,"departmentId":null,"departmentName":null,"doctorId":null,"doctorIcon":null,"doctorName":null,"doctorTitle":null,"replyTime":null,"isShow":null,"isFee":null,"diseasePicturePaths":null,"diseaseLabel":null,"otherLabel":null,"consultationDisease":null,"isOpenImage":null,"supplementInformation":null,"isAllowAppObtain":null,"answer":null},{"id":3437,"uid":100137,"chaseId":0,"problemTitle":null,"problemContent":"你跟你明明明明明明明","isHandle":null,"summitTime":1587102826000,"answerType":null,"speechDuration":null,"userName":"丁和荣","patientId":null,"userSex":null,"userAge":null,"userHospitalId":null,"userHospitalName":"复旦大学附属中山医院","userDepartmentId":null,"userDepartmentName":"肝肿瘤外科","userWardName":"四十四病区","userPrimaryPhysicianCode":null,"userPrimaryPhysicianName":"孙惠川","userAdmitNo":null,"hospitalId":null,"hospitalName":null,"departmentId":null,"departmentName":null,"doctorId":null,"doctorIcon":null,"doctorName":null,"doctorTitle":null,"replyTime":null,"isShow":null,"isFee":null,"diseasePicturePaths":null,"diseaseLabel":null,"otherLabel":null,"consultationDisease":null,"isOpenImage":null,"supplementInformation":null,"isAllowAppObtain":null,"answer":null},{"id":3451,"uid":100136,"chaseId":0,"problemTitle":null,"problemContent":"您poorYY婆婆哦送哦咯海豚隔壁偷摸skr","isHandle":null,"summitTime":1587105473000,"answerType":null,"speechDuration":null,"userName":"朱兴杭","patientId":null,"userSex":null,"userAge":null,"userHospitalId":null,"userHospitalName":"复旦大学附属中山医院","userDepartmentId":null,"userDepartmentName":"肝肿瘤外科","userWardName":"四十八病区","userPrimaryPhysicianCode":null,"userPrimaryPhysicianName":"周俭","userAdmitNo":null,"hospitalId":null,"hospitalName":null,"departmentId":null,"departmentName":null,"doctorId":null,"doctorIcon":null,"doctorName":null,"doctorTitle":null,"replyTime":null,"isShow":null,"isFee":null,"diseasePicturePaths":null,"diseaseLabel":null,"otherLabel":null,"consultationDisease":null,"isOpenImage":null,"supplementInformation":null,"isAllowAppObtain":null,"answer":null},{"id":3452,"uid":100136,"chaseId":0,"problemTitle":null,"problemContent":"hi卡恩摸鸡鸡去他我打1胡咯哦那","isHandle":null,"summitTime":1587105632000,"answerType":null,"speechDuration":null,"userName":"朱兴杭","patientId":null,"userSex":null,"userAge":null,"userHospitalId":null,"userHospitalName":"复旦大学附属中山医院","userDepartmentId":null,"userDepartmentName":"肝肿瘤外科","userWardName":"四十八病区","userPrimaryPhysicianCode":null,"userPrimaryPhysicianName":"周俭","userAdmitNo":null,"hospitalId":null,"hospitalName":null,"departmentId":null,"departmentName":null,"doctorId":null,"doctorIcon":null,"doctorName":null,"doctorTitle":null,"replyTime":null,"isShow":null,"isFee":null,"diseasePicturePaths":null,"diseaseLabel":null,"otherLabel":null,"consultationDisease":null,"isOpenImage":null,"supplementInformation":null,"isAllowAppObtain":null,"answer":null}]
     * totalCount : 8
     */

    private int status;
    private int page;
    private int totalPage;
    private int totalCount;
    private List<RetValueBean> retValue;

    public int getStatus() {
        return status;
    }

    public void setStatus(int status) {
        this.status = status;
    }

    public int getPage() {
        return page;
    }

    public void setPage(int page) {
        this.page = page;
    }

    public int getTotalPage() {
        return totalPage;
    }

    public void setTotalPage(int totalPage) {
        this.totalPage = totalPage;
    }

    public int getTotalCount() {
        return totalCount;
    }

    public void setTotalCount(int totalCount) {
        this.totalCount = totalCount;
    }

    public List<RetValueBean> getRetValue() {
        return retValue;
    }

    public void setRetValue(List<RetValueBean> retValue) {
        this.retValue = retValue;
    }

    public static class RetValueBean {
        /**
         * id : 3426
         * uid : 100295
         * chaseId : 0
         * problemTitle : null
         * problemContent : going你明明你明明吱吱吱why
         * isHandle : null
         * summitTime : 1587093162000
         * answerType : null
         * speechDuration : null
         * userName : 徐炳荣
         * patientId : null
         * userSex : null
         * userAge : null
         * userHospitalId : null
         * userHospitalName : 复旦大学附属中山医院
         * userDepartmentId : null
         * userDepartmentName : 肝肿瘤外科
         * userWardName : 四十七病区
         * userPrimaryPhysicianCode : null
         * userPrimaryPhysicianName : 沈英皓
         * userAdmitNo : null
         * hospitalId : null
         * hospitalName : null
         * departmentId : null
         * departmentName : null
         * doctorId : null
         * doctorIcon : null
         * doctorName : null
         * doctorTitle : null
         * replyTime : null
         * isShow : null
         * isFee : null
         * diseasePicturePaths : null
         * diseaseLabel : null
         * otherLabel : null
         * consultationDisease : null
         * isOpenImage : null
         * supplementInformation : null
         * isAllowAppObtain : null
         * answer : null
         */

        private int id;
        private int uid;
        private int chaseId;
        private Object problemTitle;
        private String problemContent;
        private Object isHandle;
        private long summitTime;
        private Object answerType;
        private Object speechDuration;
        private String userName;
        private Object patientId;
        private Object userSex;
        private Object userAge;
        private Object userHospitalId;
        private String userHospitalName;
        private Object userDepartmentId;
        private String userDepartmentName;
        private String userWardName;
        private Object userPrimaryPhysicianCode;
        private String userPrimaryPhysicianName;
        private Object userAdmitNo;
        private Object hospitalId;
        private Object hospitalName;
        private Object departmentId;
        private Object departmentName;
        private Object doctorId;
        private Object doctorIcon;
        private Object doctorName;
        private Object doctorTitle;
        private Object replyTime;
        private Object isShow;
        private Object isFee;
        private Object diseasePicturePaths;
        private Object diseaseLabel;
        private Object otherLabel;
        private Object consultationDisease;
        private Object isOpenImage;
        private Object supplementInformation;
        private Object isAllowAppObtain;
        private Object answer;

        public int getId() {
            return id;
        }

        public void setId(int id) {
            this.id = id;
        }

        public int getUid() {
            return uid;
        }

        public void setUid(int uid) {
            this.uid = uid;
        }

        public int getChaseId() {
            return chaseId;
        }

        public void setChaseId(int chaseId) {
            this.chaseId = chaseId;
        }

        public Object getProblemTitle() {
            return problemTitle;
        }

        public void setProblemTitle(Object problemTitle) {
            this.problemTitle = problemTitle;
        }

        public String getProblemContent() {
            return problemContent;
        }

        public void setProblemContent(String problemContent) {
            this.problemContent = problemContent;
        }

        public Object getIsHandle() {
            return isHandle;
        }

        public void setIsHandle(Object isHandle) {
            this.isHandle = isHandle;
        }

        public long getSummitTime() {
            return summitTime;
        }

        public void setSummitTime(long summitTime) {
            this.summitTime = summitTime;
        }

        public Object getAnswerType() {
            return answerType;
        }

        public void setAnswerType(Object answerType) {
            this.answerType = answerType;
        }

        public Object getSpeechDuration() {
            return speechDuration;
        }

        public void setSpeechDuration(Object speechDuration) {
            this.speechDuration = speechDuration;
        }

        public String getUserName() {
            return userName;
        }

        public void setUserName(String userName) {
            this.userName = userName;
        }

        public Object getPatientId() {
            return patientId;
        }

        public void setPatientId(Object patientId) {
            this.patientId = patientId;
        }

        public Object getUserSex() {
            return userSex;
        }

        public void setUserSex(Object userSex) {
            this.userSex = userSex;
        }

        public Object getUserAge() {
            return userAge;
        }

        public void setUserAge(Object userAge) {
            this.userAge = userAge;
        }

        public Object getUserHospitalId() {
            return userHospitalId;
        }

        public void setUserHospitalId(Object userHospitalId) {
            this.userHospitalId = userHospitalId;
        }

        public String getUserHospitalName() {
            return userHospitalName;
        }

        public void setUserHospitalName(String userHospitalName) {
            this.userHospitalName = userHospitalName;
        }

        public Object getUserDepartmentId() {
            return userDepartmentId;
        }

        public void setUserDepartmentId(Object userDepartmentId) {
            this.userDepartmentId = userDepartmentId;
        }

        public String getUserDepartmentName() {
            return userDepartmentName;
        }

        public void setUserDepartmentName(String userDepartmentName) {
            this.userDepartmentName = userDepartmentName;
        }

        public String getUserWardName() {
            return userWardName;
        }

        public void setUserWardName(String userWardName) {
            this.userWardName = userWardName;
        }

        public Object getUserPrimaryPhysicianCode() {
            return userPrimaryPhysicianCode;
        }

        public void setUserPrimaryPhysicianCode(Object userPrimaryPhysicianCode) {
            this.userPrimaryPhysicianCode = userPrimaryPhysicianCode;
        }

        public String getUserPrimaryPhysicianName() {
            return userPrimaryPhysicianName;
        }

        public void setUserPrimaryPhysicianName(String userPrimaryPhysicianName) {
            this.userPrimaryPhysicianName = userPrimaryPhysicianName;
        }

        public Object getUserAdmitNo() {
            return userAdmitNo;
        }

        public void setUserAdmitNo(Object userAdmitNo) {
            this.userAdmitNo = userAdmitNo;
        }

        public Object getHospitalId() {
            return hospitalId;
        }

        public void setHospitalId(Object hospitalId) {
            this.hospitalId = hospitalId;
        }

        public Object getHospitalName() {
            return hospitalName;
        }

        public void setHospitalName(Object hospitalName) {
            this.hospitalName = hospitalName;
        }

        public Object getDepartmentId() {
            return departmentId;
        }

        public void setDepartmentId(Object departmentId) {
            this.departmentId = departmentId;
        }

        public Object getDepartmentName() {
            return departmentName;
        }

        public void setDepartmentName(Object departmentName) {
            this.departmentName = departmentName;
        }

        public Object getDoctorId() {
            return doctorId;
        }

        public void setDoctorId(Object doctorId) {
            this.doctorId = doctorId;
        }

        public Object getDoctorIcon() {
            return doctorIcon;
        }

        public void setDoctorIcon(Object doctorIcon) {
            this.doctorIcon = doctorIcon;
        }

        public Object getDoctorName() {
            return doctorName;
        }

        public void setDoctorName(Object doctorName) {
            this.doctorName = doctorName;
        }

        public Object getDoctorTitle() {
            return doctorTitle;
        }

        public void setDoctorTitle(Object doctorTitle) {
            this.doctorTitle = doctorTitle;
        }

        public Object getReplyTime() {
            return replyTime;
        }

        public void setReplyTime(Object replyTime) {
            this.replyTime = replyTime;
        }

        public Object getIsShow() {
            return isShow;
        }

        public void setIsShow(Object isShow) {
            this.isShow = isShow;
        }

        public Object getIsFee() {
            return isFee;
        }

        public void setIsFee(Object isFee) {
            this.isFee = isFee;
        }

        public Object getDiseasePicturePaths() {
            return diseasePicturePaths;
        }

        public void setDiseasePicturePaths(Object diseasePicturePaths) {
            this.diseasePicturePaths = diseasePicturePaths;
        }

        public Object getDiseaseLabel() {
            return diseaseLabel;
        }

        public void setDiseaseLabel(Object diseaseLabel) {
            this.diseaseLabel = diseaseLabel;
        }

        public Object getOtherLabel() {
            return otherLabel;
        }

        public void setOtherLabel(Object otherLabel) {
            this.otherLabel = otherLabel;
        }

        public Object getConsultationDisease() {
            return consultationDisease;
        }

        public void setConsultationDisease(Object consultationDisease) {
            this.consultationDisease = consultationDisease;
        }

        public Object getIsOpenImage() {
            return isOpenImage;
        }

        public void setIsOpenImage(Object isOpenImage) {
            this.isOpenImage = isOpenImage;
        }

        public Object getSupplementInformation() {
            return supplementInformation;
        }

        public void setSupplementInformation(Object supplementInformation) {
            this.supplementInformation = supplementInformation;
        }

        public Object getIsAllowAppObtain() {
            return isAllowAppObtain;
        }

        public void setIsAllowAppObtain(Object isAllowAppObtain) {
            this.isAllowAppObtain = isAllowAppObtain;
        }

        public Object getAnswer() {
            return answer;
        }

        public void setAnswer(Object answer) {
            this.answer = answer;
        }
    }
}
