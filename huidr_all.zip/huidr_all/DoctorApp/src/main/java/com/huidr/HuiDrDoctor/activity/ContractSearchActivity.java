package com.huidr.HuiDrDoctor.activity;

import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.Matrix;
import android.graphics.drawable.BitmapDrawable;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;


import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.text.Editable;
import android.text.Html;
import android.text.TextWatcher;
import android.util.Log;
import android.view.Display;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

import com.alibaba.fastjson.JSONObject;
import com.chad.library.adapter.base.BaseQuickAdapter;
import com.chad.library.adapter.base.BaseViewHolder;
import com.google.android.flexbox.FlexDirection;
import com.google.android.flexbox.FlexWrap;
import com.google.android.flexbox.FlexboxLayoutManager;
import com.google.gson.Gson;
import com.guanaj.easyswipemenulibrary.EasySwipeMenuLayout;
import com.huidr.HuiDrDoctor.activity.main.Consult.utils.PostAndGet;
import com.huidr.HuiDrDoctor.debug.BuildConfig;
import com.huidr.HuiDrDoctor.debug.R;
import com.huidr.HuiDrDoctor.module.home.DeleteHisModel;
import com.huidr.HuiDrDoctor.module.home.HisSearchModel;
import com.huidr.HuiDrDoctor.module.home.SearchContractModel;
import com.huidr.HuiDrDoctor.module.home.SimpleResultModel;
import com.huidr.HuiDrDoctor.util.CircleImageView;
import com.huidr.HuiDrDoctor.util.DownLoadImg;
import com.huidr.HuiDrDoctor.util.LogUtil;
import com.huidr.HuiDrDoctor.util.ThreadPoolManager;
import com.huidr.lib.commom.util.Toast;
import com.scwang.smartrefresh.layout.SmartRefreshLayout;
import com.scwang.smartrefresh.layout.api.RefreshLayout;
import com.scwang.smartrefresh.layout.listener.OnLoadMoreListener;
import com.scwang.smartrefresh.layout.listener.OnRefreshListener;
import com.zyao89.view.zloading.ZLoadingDialog;
import com.zyao89.view.zloading.Z_TYPE;

import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Pattern;

import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import cn.jpush.im.android.api.ContactManager;
import cn.jpush.im.android.api.JMessageClient;
import cn.jpush.im.android.api.content.TextContent;
import cn.jpush.im.android.api.model.Conversation;
import cn.jpush.im.api.BasicCallback;
import jiguang.chat.activity.ChatActivity;
import jiguang.chat.application.JGApplication;
import jiguang.chat.utils.oss.OssService;
import jiguang.chat.utils.oss.SharedPreferenciesUtil;

import static com.alibaba.mtl.log.a.getContext;
import static com.huidr.HuiDrDoctor.util.DownLoadImg.getCirleBitmap;

/*
 * 联系人搜索
 *
 * */
public class ContractSearchActivity extends AppCompatActivity implements View.OnClickListener {

    ImageView imgSearch, imgClear;
    EditText etSearch;
    TextView tvCancel;

    SmartRefreshLayout srlLayout;
    RecyclerView rvSearch;

    ConstraintLayout clHis;
    RecyclerView rvHisSearch;

    //    历史搜索 空态
    ConstraintLayout clEmptyHis;
    TextView tvEmptyHis1;

    //  搜索结果  空态
    ConstraintLayout clEmpty;
    TextView tvEmpty;

    InputMethodManager imm;


    boolean showSearch;//显示搜索 true

    List<HisSearchModel.RetValueBean> allHisSeach;//搜索历史
    HisSearchModel hisSearchModel;

    int currentPage = 1;
    int totalPage = 1;

    SearchContractModel searchContractModel;
    List<SearchContractModel.RetValueBean> allSearchList;
    Gson gson;

    OssService ossService;

    String path = BuildConfig.baseUrl + "hospital/doctorGroup/getDoctorList";//医生搜索
    String pathHis = BuildConfig.baseUrl + "hospital/search/searchHis";//历史搜索
    String pathAdd = BuildConfig.baseUrl + "hospital/doctorGroup/addAssistDoctor";//添加协同
    String pathDelete = BuildConfig.baseUrl + "hospital/doctorGroup/removeAssistDoctor";//删除协同


    String imgPath;

    ZLoadingDialog dialog;

    long lastClick = 0;

    Matrix matrix;

//    File file;

    Bitmap bitmap;

    Pattern pattern;
    String searchStr;

    ImageView imgDeleteHis;//img_delete_his

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_contract_search);


        pattern = Pattern.compile("^\\s*$");

        matrix = new Matrix();
        matrix.setRotate(90);

        imgPath = getExternalFilesDir("").getAbsolutePath() + "/img/head/";

        imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
        dialog = new ZLoadingDialog(ContractSearchActivity.this);
        dialog.setLoadingBuilder(Z_TYPE.STAR_LOADING)//设置类型
                .setLoadingColor(Color.BLUE)//颜色
                .setHintText("处理中,请稍候...").setHintTextSize(16) // 设置字体大小 dp
                .setHintTextColor(Color.GRAY)  // 设置字体颜色
                .setDurationTime(0.5) // 设置动画时间百分比 - 0.5倍
                .setCanceledOnTouchOutside(false).setCancelable(false);

        initDate();
        initEmptyView();
        initSearchResultView();
        initHisSearchView();
        initView();
    }

    //    隐藏软键盘
    public void hideImm(EditText editText) {
        if (imm != null) {
            imm.hideSoftInputFromWindow(editText.getWindowToken(), 0);
        }
    }

    public void initDate() {
        searchContractModel = new SearchContractModel();
        allSearchList = new ArrayList<>();
        gson = new Gson();
        ossService = new OssService(ContractSearchActivity.this);
        allHisSeach = new ArrayList<>();
        hisSearchModel = new HisSearchModel();
        hisAdapter.setNewData(allHisSeach);
        searchAdapter.setNewData(allSearchList);
        getHisSearch();
    }

    //    空态页
    public void initEmptyView() {
        clEmpty = (ConstraintLayout) findViewById(R.id.cl_empty);
    }


    //    搜索结果
    public void initSearchResultView() {
        srlLayout = (SmartRefreshLayout) findViewById(R.id.srl_layout);
        srlLayout.setEnableRefresh(true);
        srlLayout.setEnableLoadMore(true);

        srlLayout.setOnRefreshListener(new OnRefreshListener() {
            @Override
            public void onRefresh(@NonNull RefreshLayout refreshLayout) {
                currentPage = 1;
                getResultByPage();
            }
        });

        srlLayout.setOnLoadMoreListener(new OnLoadMoreListener() {
            @Override
            public void onLoadMore(@NonNull RefreshLayout refreshLayout) {

                if (searchContractModel.getRetValue().size() == 20 && currentPage < totalPage) {
                    currentPage += 1;
                    getResultByPage();
                } else {
                    Toast.getInstance(ContractSearchActivity.this).show("数据加载全部", 500);
                    srlLayout.finishLoadMore();
                }
            }
        });

        rvSearch = (RecyclerView) findViewById(R.id.rv_search);
        rvSearch.setAdapter(searchAdapter);
        rvSearch.setLayoutManager(new LinearLayoutManager(this));

    }

    //    历史搜索
    public void initHisSearchView() {
        clHis = (ConstraintLayout) findViewById(R.id.cl_his);
        rvHisSearch = (RecyclerView) findViewById(R.id.rv_his_search);

        rvHisSearch.setAdapter(hisAdapter);
//        rvHisSearch.setLayoutManager(new GridLayoutManager(this, 4));

        FlexboxLayoutManager manager = new FlexboxLayoutManager(this, FlexDirection.ROW, FlexWrap.WRAP) {
            @Override
            public boolean canScrollVertically() {
                return false;
            }
        };
        rvHisSearch.setLayoutManager(manager);

        clEmptyHis = (ConstraintLayout) findViewById(R.id.cl_empty_his);
        tvEmptyHis1 = (TextView) findViewById(R.id.tv_empty_his1);
    }

    public void initView() {

        imgSearch = (ImageView) findViewById(R.id.image_search);
        imgClear = (ImageView) findViewById(R.id.image_clear);
        etSearch = (EditText) findViewById(R.id.et_search);
        tvCancel = (TextView) findViewById(R.id.tv_cancel);

        tvEmpty = (TextView) findViewById(R.id.tv_empty);


        imgSearch.setOnClickListener(this);
        imgClear.setOnClickListener(this);
        tvCancel.setOnClickListener(this);


        etSearch.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {
                if (etSearch.getText().toString().length() > 0) {
                    imgClear.setVisibility(View.VISIBLE);
                } else {
                    imgClear.setVisibility(View.GONE);
                }
            }
        });

        /*
         * doKeySearch();  键盘监听
         * */
        etSearch.setOnEditorActionListener(new TextView.OnEditorActionListener() {
            @Override
            public boolean onEditorAction(TextView v, int actionId, KeyEvent event) {
                if (actionId == 3) {//
                    searchStr = etSearch.getText().toString();
                    if (searchStr.length() > 0) {

                        if (pattern.matcher(searchStr).matches()) {
                            android.widget.Toast.makeText(ContractSearchActivity.this, "请重新输入", android.widget.Toast.LENGTH_SHORT).show();
                            etSearch.setText("");
                        } else {
                            doKeySearch();
                        }
                    }
                    return true;
                } else {
                    return false;
                }
            }
        });


        imgDeleteHis = (ImageView) findViewById(R.id.img_delete_his);
        imgDeleteHis.setOnClickListener(this);


    }

    private Handler handler = new Handler() {
        @Override
        public void handleMessage(Message msg) {
            super.handleMessage(msg);

            switch (msg.what) {
                case 1:
                    searchAdapter.getData().clear();

                    if (searchContractModel.getRetValue().size() == 0) {
                        clEmpty.setVisibility(View.VISIBLE);
                        srlLayout.setVisibility(View.GONE);
                        tvEmpty.setText("暂未搜索到该医生~");
                    } else {
                        clEmpty.setVisibility(View.GONE);
                        srlLayout.setVisibility(View.VISIBLE);
                        searchAdapter.getData().addAll(searchContractModel.getRetValue());
                        searchAdapter.notifyDataSetChanged();
                    }
                    srlLayout.finishRefresh();
                    break;
                case 2:
                    searchAdapter.getData().addAll(searchContractModel.getRetValue());
                    searchAdapter.notifyDataSetChanged();
                    srlLayout.finishLoadMore();
                    break;
                case 3:
                    clEmpty.setVisibility(View.VISIBLE);
                    srlLayout.setVisibility(View.GONE);
                    tvEmpty.setText("网络错误~");
                    break;

//                    获取历史搜索成功
                case 6:
                    hisAdapter.getData().clear();
                    if (hisSearchModel.getRetValue().size() == 0) {
                        rvHisSearch.setVisibility(View.GONE);
                        clEmptyHis.setVisibility(View.VISIBLE);
                        tvEmptyHis1.setText("暂无搜索历史~");
                        imgDeleteHis.setVisibility(View.GONE);
                    } else {
                        rvHisSearch.setVisibility(View.VISIBLE);
                        clEmptyHis.setVisibility(View.GONE);
                        hisAdapter.getData().addAll(hisSearchModel.getRetValue());
                        hisAdapter.notifyDataSetChanged();
                        imgDeleteHis.setVisibility(View.VISIBLE);
                    }
                    break;
//                    获取历史搜索失败
                case 7:
                    rvHisSearch.setVisibility(View.GONE);
                    clEmptyHis.setVisibility(View.VISIBLE);
                    tvEmptyHis1.setText("网络错误~");
                    imgDeleteHis.setVisibility(View.GONE);
                    break;

//                    邀请发送成功
                case 8:
                    dialog.dismiss();
                    searchAdapter.getData().get(msg.arg1).setIsApply(true);
//                    searchAdapter.notifyDataSetChanged();
                    searchAdapter.notifyItemChanged(msg.arg1);
                    Toast.getInstance(ContractSearchActivity.this).show("邀请发送成功", 500);
                    break;
//                    不要重复发送邀请
                case 9:
                    dialog.dismiss();
                    Toast.getInstance(ContractSearchActivity.this).show("您已发送邀请，请不要重复发送", 500);
                    break;
//                    邀请发送失败 
                case 10:
                    dialog.dismiss();
                    Toast.getInstance(ContractSearchActivity.this).show("邀请发送失败", 500);
                    break;
//                    添加协同成功
                case 11:
                    searchAdapter.getData().get(msg.arg1).setIsAssist(true);
                    searchAdapter.notifyItemChanged(msg.arg1);
                    dialog.dismiss();
                    Toast.getInstance(ContractSearchActivity.this).show("添加协同医生成功", 500);
                    break;
//                    添加协同失败
                case 12:
                    dialog.dismiss();
                    Toast.getInstance(ContractSearchActivity.this).show("添加协同医生失败", 500);
                    break;
                //                    删除协同成功
                case 13:
                    searchAdapter.getData().get(msg.arg1).setIsAssist(false);
                    searchAdapter.notifyItemChanged(msg.arg1);
                    dialog.dismiss();
                    Toast.getInstance(ContractSearchActivity.this).show("取消协同医生成功", 500);
                    break;
                //                    删除协同失败
                case 14:
                    dialog.dismiss();
                    Toast.getInstance(ContractSearchActivity.this).show("取消协同医生失败", 500);
                    break;


                /*删除历史记录成功*/
                case 15:
                    getHisSearch();
                    break;
                /*删除历史记录失败*/
                case 16:
                    Toast.getInstance(ContractSearchActivity.this).show("删除失败，请稍后重试", 500);
                    break;

            }
        }
    };

    /*
    * 搜索
    * 清除
      取消
    *
    * */
    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.image_search:
                if (etSearch.getText().toString().length() > 0) {
                    Pattern pattern = Pattern.compile("^\\s*$");
                    if (pattern.matcher(etSearch.getText().toString()).matches()) {
                        android.widget.Toast.makeText(ContractSearchActivity.this, "请重新输入", android.widget.Toast.LENGTH_SHORT).show();
                        etSearch.setText("");
                    } else {
                        doKeySearch();
                    }
                } else {
                    android.widget.Toast.makeText(ContractSearchActivity.this, "请重新输入", android.widget.Toast.LENGTH_SHORT).show();
                }
                break;
            case R.id.image_clear:
                searchAdapter.getData().clear();
                searchAdapter.notifyDataSetChanged();
                etSearch.setText("");
                showSearch = false;
                refreshPage();
                currentPage = 1;
                getHisSearch();
                break;
            case R.id.tv_cancel:
//                searchAdapter.notifyDataSetChanged();
//                showSearch = false;
//                etSearch.setText("");
//                refreshPage();
                finish();
                break;

            case R.id.img_delete_his:
                deleteHis();
                break;
        }
    }

    /*
     * 关键字搜索
     * */
    public void doKeySearch() {
        showSearch = true;
        hideImm(etSearch);
        refreshPage();
        getResultByPage();
    }

    // 分页获取搜索结果
    public void getResultByPage() {
        ThreadPoolManager.getInstance().execute(new Runnable() {
            @Override
            public void run() {
                JSONObject jsonObject = new JSONObject();
                jsonObject.put("pageIndex", currentPage);
                jsonObject.put("pageSize", 20);
                jsonObject.put("search", etSearch.getText().toString());
                String result = PostAndGet.doHttpPost(path, jsonObject);
                searchContractModel = new SearchContractModel();

                LogUtil.e("搜索结果", result);
                if (result.equals("网络异常")) {
                    handler.sendEmptyMessage(3);
                } else {
                    searchContractModel = gson.fromJson(result, SearchContractModel.class);
                    if (searchContractModel.getStatus() == 0) {
                        totalPage = searchContractModel.getTotalPage();
                        if (currentPage == 1) {
                            handler.sendEmptyMessage(1);
                        } else {
                            handler.sendEmptyMessage(2);
                        }
                    } else {
                        handler.sendEmptyMessage(3);
                    }
                }

            }
        });
    }


    //    获取搜索历史
    public void getHisSearch() {
        ThreadPoolManager.getInstance().execute(new Runnable() {
            @Override
            public void run() {
                JSONObject jsonObject = new JSONObject();
                jsonObject.put("searchType", 8);
                String result = PostAndGet.doHttpPost(pathHis, jsonObject);
                if (result.equals("网络异常")) {
                    handler.sendEmptyMessage(7);
                } else {
                    hisSearchModel = gson.fromJson(result, HisSearchModel.class);
                    if (hisSearchModel.getStatus() == 0) {
                        handler.sendEmptyMessage(6);
                    } else {
                        handler.sendEmptyMessage(7);
                    }
                }
            }
        });
    }

    /*删除搜索历史记录*/
    public void deleteHis() {
        ThreadPoolManager.getInstance().execute(new Runnable() {
            @Override
            public void run() {
                String deleteUrl = BuildConfig.baseUrl + "hospital/search/delSearchHis";
                JSONObject jsonObject = new JSONObject();
                jsonObject.put("uid", (String) SharedPreferenciesUtil.getData("id", "0"));
                jsonObject.put("searchType", 8);
                String result = PostAndGet.doHttpPost(deleteUrl, jsonObject);
                Log.e("123456", result);
                if (result.equals("网络异常")) {//删除历史记录失败
                    handler.sendEmptyMessage(16);
                } else {//删除历史记录成功
                    DeleteHisModel simpleResultModel = gson.fromJson(result, DeleteHisModel.class);
                    if (simpleResultModel.getStatus() == 0) {
                        handler.sendEmptyMessage(15);
                    } else {
                        handler.sendEmptyMessage(16);
                    }
                }
            }
        });
    }


    /*
     * 刷新显示
     * true  显示搜索结果 搜索结果为空 显示空态页
     * false 隐藏搜搜结果页 显示搜索历史
     *
     */
    public void refreshPage() {
        if (showSearch) {
            clHis.setVisibility(View.GONE);
            srlLayout.setVisibility(View.VISIBLE);
            clEmpty.setVisibility(View.GONE);
        } else {
            clHis.setVisibility(View.VISIBLE);
            srlLayout.setVisibility(View.GONE);
            clEmpty.setVisibility(View.GONE);
            clEmptyHis.setVisibility(View.GONE);
        }
    }


    @Override
    protected void onStop() {
        super.onStop();
        if (dialog != null) {
            dialog.dismiss();
        }
    }

    /*
     * 历史搜索 适配
     * */
    private BaseQuickAdapter<HisSearchModel.RetValueBean, BaseViewHolder> hisAdapter = new BaseQuickAdapter<HisSearchModel.RetValueBean, BaseViewHolder>(R.layout.item_tip) {
        @Override
        protected void convert(BaseViewHolder helper, final HisSearchModel.RetValueBean item) {
            TextView tvTip = helper.getView(R.id.tv_tip);
            tvTip.setText(item.getSearchContent());

            tvTip.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    etSearch.setText(item.getSearchContent());
//                    showSearch = true;
                    doKeySearch();
                }
            });
        }
    };


    /*
     * 搜索结果  适配
     *
     * */
    private BaseQuickAdapter<SearchContractModel.RetValueBean, BaseViewHolder> searchAdapter = new BaseQuickAdapter<SearchContractModel.RetValueBean, BaseViewHolder>(R.layout.item_scroll_layout) {

        @Override
        protected void convert(final BaseViewHolder helper, final SearchContractModel.RetValueBean item) {

//            helper.setIsRecyclable(false);
            final CircleImageView imgItemHead = helper.getView(R.id.img_item_head);
//            imgItemHead.setBackgroundResource(R.drawable.nantou);

            EasySwipeMenuLayout esml_item = helper.getView(R.id.esml_item);

            ConstraintLayout clItem = helper.getView(R.id.cl_item);
            clItem.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (System.currentTimeMillis() - lastClick > 1000) {
                        if (item.isIsContacts()) {
                            if (JMessageClient.getMyInfo() == null) {
                                return;
                            }
                            Intent intent = new Intent(ContractSearchActivity.this, ChatActivity.class);
                            Bundle bundle = new Bundle();
                            bundle.putString("targetId", item.getId() + "");
                            bundle.putString(JGApplication.CONV_TITLE, item.getUserName());
                            bundle.putString(JGApplication.TARGET_APP_KEY, BuildConfig.appkey);
                            intent.putExtras(bundle);
                            startActivity(intent);
                        } else {
                            Intent intent1 = new Intent(ContractSearchActivity.this, WebActivity.class);
                            Bundle bundle = new Bundle();
                            bundle.putString("url", "personal.html?id=" + item.getId());
                            intent1.putExtras(bundle);
                            startActivity(intent1);
                        }
                        lastClick = System.currentTimeMillis();
                    }
                }
            });


            TextView textView = helper.getView(R.id.tv_scroll_right);
            String st = "<font>添加<br />协同</font>";
            textView.setText(Html.fromHtml(st));

            TextView tvItemName = helper.getView(R.id.tv_item_name);
            tvItemName.setText(item.getUserName());
            TextView tvItemMsg = helper.getView(R.id.tv_item_msg);

            Bitmap bitmapDoctor = BitmapFactory.decodeResource(getResources(), R.drawable.default_doctor);
            BitmapDrawable bitmapDrawable = new BitmapDrawable(getContext().getResources(), bitmapDoctor);
            imgItemHead.setBackgroundDrawable(bitmapDrawable);

            if (item.getUserIcon() != null) {


                imgItemHead.setTag(item.getUserIcon());


                final File file = new File(imgPath + item.getUserIcon());
                if (file.exists()) {

                    bitmap = BitmapFactory.decodeFile(file.getAbsolutePath());
                    if (bitmap != null) {
                        bitmap = getCirleBitmap(bitmap);
                        BitmapDrawable bitmapDrawable1 = new BitmapDrawable(getContext().getResources(), bitmap);
                        if (imgItemHead.getTag().equals(item.getUserIcon())) {
                            imgItemHead.setBackgroundDrawable(bitmapDrawable1);
//                            tvItemMsg.setText("本地 TAg  " + imgItemHead.getTag() + "   url" + item.getUserIcon());
                        }
                    } else {
//                        imgItemHead.setBackgroundResource(R.drawable.nantou);
                    }
                } else {
                    DownLoadImg.BitmapWorkerTask bitmapWorkerTask = new DownLoadImg.BitmapWorkerTask(imgItemHead, file, ossService);
                    bitmapWorkerTask.execute(item.getUserIcon());
                }
            } else {
                imgItemHead.setBackgroundResource(R.drawable.nantou);
                tvItemMsg.setText("没有头像 TAg  " + imgItemHead.getTag() + "   url" + item.getUserIcon());
            }


            ImageView imgNotice = helper.getView(R.id.img_notice);
            imgNotice.setVisibility(View.GONE);
            ImageView imageItemGender = helper.getView(R.id.image_item_gender);
            TextView tvItemAge = helper.getView(R.id.tv_item_age);
            tvItemAge.setText(item.getHospitalDepartment() + "(" + item.getUserTitle() + ")");
            TextView tvItemState = helper.getView(R.id.tv_item_state);
            TextView tvItemDate = helper.getView(R.id.tv_item_date);
            tvItemDate.setVisibility(View.GONE);

//            tvItemMsg.setText(item.getLatelyAdmissionDiagnosis());
            TextView tvItemModel = helper.getView(R.id.tv_item_model);
            tvItemModel.setVisibility(View.GONE);
            TextView tvScrollRight = helper.getView(R.id.tv_scroll_right);
            Conversation conversation = JMessageClient.getSingleConversation(item.getId() + "");
//            if (conversation == null) {
//                imgNotice.setVisibility(View.GONE);
//            } else {
//                if (conversation.getUnReadMsgCnt() > 0) {
//                    imgNotice.setVisibility(View.VISIBLE);
//                } else {
//                    imgNotice.setVisibility(View.GONE);
//                }
//            }
            final Button btnApply = helper.getView(R.id.btn_apply);
            if (item.isIsContacts()) {
                btnApply.setBackgroundResource(R.drawable.btn_apply_gray);
                btnApply.setText("已申请");
            } else {
                if (item.isIsApply()) {
                    btnApply.setBackgroundResource(R.drawable.btn_apply_gray);
                    btnApply.setText("已申请");
                } else {
                    btnApply.setBackgroundResource(R.drawable.btn_grad_empty);
                    btnApply.setText("申请");
                }
            }


//            已经是好友
            if (item.isIsContacts()) {
                esml_item.setCanLeftSwipe(true);
                if (conversation == null) {
                    tvItemMsg.setText("暂无聊天消息");
                } else {
                    cn.jpush.im.android.api.model.Message message = conversation.getLatestMessage();
                    if (message != null) {
                        switch (message.getContentType()) {
                            case text:
                                tvItemMsg.setText(((TextContent) message.getContent()).getText());
                                break;
                            case voice:
                                tvItemMsg.setText("[语音消息]");
                                break;
                            case image:
                                tvItemMsg.setText("[图片]");
                                break;
                            case file:
                                tvItemMsg.setText("[文件]");
                                break;
                            case location:
                                tvItemMsg.setText("[位置]");
                                break;
                            default:
                                break;
                        }
                    }
                }
            } else {
                esml_item.setCanLeftSwipe(false);
                tvItemMsg.setText("该医生还不是您的联系人");
            }
            btnApply.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (btnApply.getText().toString().equals("已申请")) {
                    } else {
                        dialog.show();
                        ContactManager.sendInvitationRequest(item.getId() + "", "", "", new BasicCallback() {
                            @Override
                            public void gotResult(int responseCode, String responseMessage) {
                                if (0 == responseCode) {
                                    LogUtil.e("极光发送邀请成功", "极光发送邀请成功");
                                    addContact(item.getId() + "", helper.getAdapterPosition());
                                } else {
                                    LogUtil.e("极光发送邀请失败", "极光发送邀请失败" + responseMessage);
                                    dialog.dismiss();
                                    if (responseMessage.equals("Target user cannot be yourself.")) {
                                        Toast.getInstance(ContractSearchActivity.this).show("不能发送邀请给自己", 500);
                                    } else {
                                        Toast.getInstance(ContractSearchActivity.this).show("邀请发送失败", 500);
                                    }
                                }
                            }
                        });
                    }
                }
            });
            String tip = "";
            if (item.isIsAssist()) {
                tip = "<font>取消<br>协同<font>";
                tvScrollRight.setBackgroundResource(R.drawable.shape_atten_gray);
            } else {
                tip = "<font>添加<br>协同<font>";
                tvScrollRight.setBackgroundResource(R.drawable.btn_grad_empty);
            }
            tvScrollRight.setText(Html.fromHtml(tip));
            tvScrollRight.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    showCoopDialog(item.getId() + "", helper.getAdapterPosition(), item.isIsAssist());
                }
            });
        }
    };

    //    添加联系人  访问接口
    public void addContact(final String targetId, final int position) {
        ThreadPoolManager.getInstance().execute(new Runnable() {
            @Override
            public void run() {
                String path = BuildConfig.baseUrl + "hospital/doctorGroup/addContacts";
                JSONObject jsonObject = new JSONObject();
                String id = (String) SharedPreferenciesUtil.getData("id", "0");
//                申请人ID  applicantId
                jsonObject.put("applicantId", id);
                //                本申请人ID applicantId
                jsonObject.put("respondentId", targetId);

                String result = PostAndGet.doHttpPost(path, jsonObject);
                LogUtil.e("添加联系人", result);
                if (result.equals("网络异常")) {
                    handler.sendEmptyMessage(10);
                } else {
                    SimpleResultModel simpleResultModel = gson.fromJson(result, SimpleResultModel.class);
                    if (simpleResultModel.getStatus() == 0) {
//                        1发送成功 0 24小时内不能重复发送
                        if (simpleResultModel.getRetValue() == 1) {
//                            handler.sendEmptyMessage(8);
                            Message message = new Message();
                            message.what = 8;
                            message.arg1 = position;
                            handler.sendMessage(message);
                        } else if (simpleResultModel.getRetValue() == -1) {
                            handler.sendEmptyMessage(9);
                        } else {
                            handler.sendEmptyMessage(10);
                        }
                    } else {
                        handler.sendEmptyMessage(10);
                    }
                }
            }
        });
    }

    //    添加协同  String path = "http://192.168.1.180:1189/doctorGroup/addAssistDoctor";
    public void addAssistDoctor(final String id, final int position) {
        ThreadPoolManager.getInstance().execute(new Runnable() {
            @Override
            public void run() {
                JSONObject jsonObject = new JSONObject();
                int uid = Integer.valueOf(id);
                int[] a = new int[]{uid};
                jsonObject.put("assistUids", a);

                String result = PostAndGet.doHttpPost(pathAdd, jsonObject);
                LogUtil.e("添加协同医生", result);
                if (result.equals("网络异常")) {
                    handler.sendEmptyMessage(12);
                } else {
                    SimpleResultModel simpleResultModel = gson.fromJson(result, SimpleResultModel.class);
                    if (simpleResultModel.getStatus() == 0) {
                        if (simpleResultModel.getRetValue() == 0) {
//
                            Message msg = new Message();
                            msg.what = 11;
                            msg.arg1 = position;
                            handler.sendMessage(msg);

                        } else {
                            handler.sendEmptyMessage(12);
                        }
                    } else {
                        handler.sendEmptyMessage(12);
                    }
                }
            }
        });
    }


    //    删除协同医生
    public void deleteCooperDoctor(final String deleteId, final int position) {
        ThreadPoolManager.getInstance().execute(new Runnable() {
            @Override
            public void run() {
                JSONObject jsonObject = new JSONObject();
                jsonObject.put("assistUid", deleteId);
                String result = PostAndGet.doHttpPost(pathDelete, jsonObject);
                if (result.equals("网络异常")) {
                    handler.sendEmptyMessage(14);
                } else {
                    SimpleResultModel simpleResultModel = gson.fromJson(result, SimpleResultModel.class);
                    if (simpleResultModel.getStatus() == 0) {
                        if (simpleResultModel.getRetValue() == 0) {
                            Message message = new Message();
                            message.arg1 = position;
                            message.what = 13;
                            handler.sendMessage(message);
                        }

                    } else {
                        handler.sendEmptyMessage(14);
                    }
                }
            }
        });
    }


    //    取消添加协同对话框
    public void showCoopDialog(final String id, final int position, final boolean isCoop) {

        final Dialog builder = new Dialog(ContractSearchActivity.this, R.style.jmui_default_dialog_style);
        //final Dialog builder = new Dialog(this, R.style.jmui_default_dialog_style);
        View view = LayoutInflater.from(ContractSearchActivity.this).inflate(R.layout.dialog_content, null);

        TextView tvTitle = view.findViewById(R.id.tv_title);
        TextView tvFooter1 = view.findViewById(R.id.tv_footer1);
        TextView tvFooter2 = view.findViewById(R.id.tv_footer2);

        if (isCoop) {
            tvTitle.setText("是否删除协同医生!");
        } else {
            tvTitle.setText("是否添加协同医生!");
        }


//        取消
        tvFooter1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                builder.cancel();
                searchAdapter.notifyItemChanged(position);
            }
        });
//确定
        tvFooter2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                builder.cancel();
                if (isCoop) {
                    deleteCooperDoctor(id, position);
                } else {
                    addAssistDoctor(id, position);
                }
            }
        });

        builder.setContentView(view);
        //builder.setCanceledOnTouchOutside(true);
        builder.show();
        Window window = builder.getWindow();
        WindowManager.LayoutParams lp = window.getAttributes();
        WindowManager windowManager = getWindowManager();
        Display display = windowManager.getDefaultDisplay();
        lp.width = (int) (display.getWidth() * 0.7);
//        lp.height = (int) (display.getHeight() * 0.1);
        window.setAttributes(lp);
    }

}