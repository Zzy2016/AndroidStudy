package com.huidr.HuiDrDoctor.module.consult;

public class ReasonModel {


    /**
     * patientName : 患者段
     * patientIcon :
     * patientSex : 1
     * needHelp : 测试肝肿瘤214586655777556
     * createTime : 2019-09-06 14:22:07
     * orderId : 20190906142206109058940
     * price : 200
     * patientBrith : 2010-10-20
     */

    private String patientName;
    private String patientIcon;
    private int patientSex;
    private String needHelp;
    private String createTime;
    private String orderId;
    private int price;
    private String patientBrith;

    public String getPatientName() {
        return patientName;
    }

    public void setPatientName(String patientName) {
        this.patientName = patientName;
    }

    public String getPatientIcon() {
        return patientIcon;
    }

    public void setPatientIcon(String patientIcon) {
        this.patientIcon = patientIcon;
    }

    public int getPatientSex() {
        return patientSex;
    }

    public void setPatientSex(int patientSex) {
        this.patientSex = patientSex;
    }

    public String getNeedHelp() {
        return needHelp;
    }

    public void setNeedHelp(String needHelp) {
        this.needHelp = needHelp;
    }

    public String getCreateTime() {
        return createTime;
    }

    public void setCreateTime(String createTime) {
        this.createTime = createTime;
    }

    public String getOrderId() {
        return orderId;
    }

    public void setOrderId(String orderId) {
        this.orderId = orderId;
    }

    public int getPrice() {
        return price;
    }

    public void setPrice(int price) {
        this.price = price;
    }

    public String getPatientBrith() {
        return patientBrith;
    }

    public void setPatientBrith(String patientBrith) {
        this.patientBrith = patientBrith;
    }
}
