package com.huidr.HuiDrDoctor.services;

import android.app.Dialog;
import android.app.Service;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Handler;
import android.os.IBinder;
import android.os.Message;
import android.util.Log;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.alibaba.sdk.android.oss.common.OSSConstants;
import com.alibaba.sdk.android.oss.common.utils.IOUtils;
import com.huidr.HuiDrDoctor.debug.BuildConfig;
import com.huidr.HuiDrDoctor.util.LogUtil;
import com.huidr.lib.commom.util.HbuildUtil;
import com.huidr.lib.commom.util.ZipUtils;
import com.taobao.sophix.SophixManager;

import java.io.BufferedInputStream;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.RandomAccessFile;
import java.net.HttpURLConnection;
import java.net.URL;

import jiguang.chat.utils.oss.Constants;
import jiguang.chat.utils.oss.SharedPreferenciesUtil;

/*
 *
 * 医生端app启动时的检查更新
 * */
public class NewUpdateService extends Service {


    private String isLogin;
    Dialog builder;//更新对话框
    private String updateContent;
    private String newVersion;
    TaskInfo info;//任务信息

    String nowVersion; //本地版本号
    private SharedPreferences sPreferences;//  缓存工具
    private String updateUrl;//url
    boolean force;//  强制更新 暂时不用
    int androidCheck;//能否更新  1 不更新  2 允许更新
    boolean silenceUpdate;//是否静默更新  true 静默更新 false 显示弹窗

    public NewUpdateService() {
    }


    @Override
    public IBinder onBind(Intent intent) {
        // TODO: Return the communication channel to the service.
        throw new UnsupportedOperationException("Not yet implemented");
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        sPreferences = getSharedPreferences("updateDownload", 0);
        nowVersion = sPreferences.getString("version", "0");
        updateUrl = BuildConfig.UpdateUrl;
        isLogin = (String) SharedPreferenciesUtil.getData(Constants.SharedAccountConfig.IS_LOGIN, "0");

        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    URL versionUrl = new URL(updateUrl + "/version.json");
                    HttpURLConnection conn = (HttpURLConnection) versionUrl.openConnection();
                    InputStream input = conn.getInputStream();
                    String jsonText = IOUtils.readStreamAsString(input, OSSConstants.DEFAULT_CHARSET_NAME);
                    JSONObject parse = JSON.parseObject(jsonText);
                    LogUtil.e("service--", parse.toString());
                    newVersion = parse.getString("version");
                    force = parse.getBoolean("force");
                    updateContent = parse.getString("desc");//
//                    androidCheck = parse.getIntValue("androidCheck");//  1  不更新 2允许更新
//                    silenceUpdate = parse.getBooleanValue("silenceUpdate");//  true 静默更新  false  显示弹窗
                    silenceUpdate = true;//  true 静默更新  false  显示弹窗
                    LogUtil.e("SilenceUpdate", "silenceUpdate" + silenceUpdate);

                    if (parse.containsKey("androidCheck")) {
                        androidCheck = parse.getIntValue("androidCheck");//  1  不更新 2允许更新
                    } else {
                        androidCheck = 2;
                    }


                    if (compareVersion(newVersion, nowVersion) == 1 && androidCheck == 2) {
                        LogUtil.e("登录加载  SilenceUpdate ", "有新版本");
                        Message msg = new Message();
                        msg.what = 1;
                        handler.sendMessage(msg);
                    } else {
                        LogUtil.e("SilenceUpdate", "无可用的更新");
                        Message message = new Message();
                        message.what = 0;
                        handler.sendMessage(message);
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        }).start();
        return super.onStartCommand(intent, flags, startId);
    }

    /*
     * 0 已经时最新版
     * 1 显示更新内容弹窗  静默更细 不需要显示  直接开始下载
     * 2 更新完毕     不做操作  silenceUpdate false提示更新到最新版，但不会返回首页 true
     * */
    private Handler handler = new Handler() {
        @Override
        public void handleMessage(Message msg) {
            switch (msg.what) {
                case 0:
                    //Toast.makeText(SilenceUpdateService.this, "已经是最新版本", Toast.LENGTH_SHORT).show();
                    stopSelf();
                    break;
                case 1:

                    if (silenceUpdate) {
                        new Thread(new Runnable() {
                            @Override
                            public void run() {
                                downLoad();
                            }
                        }).start();
                    }

                    break;
                case 2:
                    Log.e("登录加载 SilenceUpdate", "下载完毕 UI" + silenceUpdate + "    " + newVersion);
//                    if (!silenceUpdate) {
//                        Toast.makeText(SilenceUpdateService.this, "已更新到" + newVersion, Toast.LENGTH_SHORT).show();
//                    }

//                    //检查更新
                    SophixManager.getInstance().queryAndLoadNewPatch();
//                    //复制文件
                    HbuildUtil.copyApps(getApplicationContext(), newVersion);

                    stopSelf();
                    break;
            }
        }
    };

    /**
     * 版本号比较
     *
     * @param version1
     * @param version2 本地版本
     * @return 0  最新版本 不用更新   1有新的版本 需要更新
     */
    public static int compareVersion(String version1, String version2) {
        version1 = version1.replace("v", "");
        version2 = version2.replace("v", "");

        LogUtil.e("version1", version1);
        LogUtil.e("version2", version2);
        if (version1.equals(version2)) {
            return 0;
        }
        String[] version1Array = version1.split("\\.");
        String[] version2Array = version2.split("\\.");
        int index = 0;
        // 获取最小长度值
        int minLen = Math.min(version1Array.length, version2Array.length);
        int diff = 0;
        // 循环判断每位的大小  执行while的时候是相等的 跳出循环的时候不相等（版本不同 长度不同）
        while (index < minLen && (diff = Integer.parseInt(version1Array[index]) - Integer.parseInt(version2Array[index])) == 0) {
            index++;
        }
        if (diff == 0) {  //长度不同
            // 如果位数不一致，比较多余位数
            for (int i = index; i < version1Array.length; i++) {  //新版本
                if (Integer.parseInt(version1Array[i]) > 0) {
                    return 1;
                }
            }

            for (int i = index; i < version2Array.length; i++) {  //本地版本
                if (Integer.parseInt(version2Array[i]) > 0) {
                    return -1;
                }
            }
            return 0;
        } else {   //version值不同
            return diff > 0 ? 1 : -1;
        }
    }

    /*
     * 下载新的apk
     * */
    private void downLoad() {
        LogUtil.e("service----", "开始下载");
        LogUtil.e("SilenceUpdate", "开始下载");
        try {
            URL versionUrl = new URL(updateUrl + "/version.json");
            HttpURLConnection conn = (HttpURLConnection) versionUrl.openConnection();
            InputStream input = conn.getInputStream();
            String jsonText = IOUtils.readStreamAsString(input, OSSConstants.DEFAULT_CHARSET_NAME);
            JSONObject parse = JSON.parseObject(jsonText);
            newVersion = parse.getString("version");
            force = parse.getBoolean("force");
            updateContent = parse.getString("desc");
        } catch (Exception e) {
            e.printStackTrace();
        }

        //需要更新
        String url = updateUrl + "/" + newVersion + ".zip";
        //实例化任务信息对象
        info = new TaskInfo(newVersion + ".zip", NewUpdateService.this.getFilesDir().getAbsolutePath() + "/Download/", url);
        BufferedInputStream bis;//缓冲输入流，从服务器获取
        RandomAccessFile raf;//随机读写器，用于写入文件，实现断点续传
        int len = 0;//每次读取的数组长度
        byte[] buffer = new byte[1024 * 8];//流读写的缓冲区
        try {
            //通过文件路径和文件名实例化File
            File filePath = new File(info.getPath());
            if (!filePath.exists()) {
                filePath.mkdirs();
            }
            File file = new File(info.getPath() + info.getName());

            LogUtil.e("SilenceUpdate", "下载路径" + info.getPath() + info.getName());
            //实例化RandomAccessFile，rwd模式
            raf = new RandomAccessFile(file, "rwd");
            HttpURLConnection conn = (HttpURLConnection) new URL(info.getUrl()).openConnection();
            conn.setConnectTimeout(120000);//连接超时时间
            conn.setReadTimeout(120000);//读取超时时间
            conn.setRequestMethod("GET");//请求类型为GET
            raf.seek(info.getCompletedLen());//移动RandomAccessFile写入位置，从上次完成的位置开始
            conn.connect();//连接
            bis = new BufferedInputStream(conn.getInputStream());//获取输入流并且包装为缓冲流
            //从流读取字节数组到缓冲区
            while (-1 != (len = bis.read(buffer))) {
                //把字节数组写入到文件
                raf.write(buffer, 0, len);
                //更新任务信息中的完成的文件长度属性
                info.setCompletedLen(info.getCompletedLen() + len);
            }
            update();
            //handler.sendEmptyMessage(UPDATEOVER);
        } catch (IOException e) {
            e.printStackTrace();
            //handler.sendEmptyMessage(ERROR);
        }
    }

    /*
     * 更新
     * */
    private void update() {
        LogUtil.e("service---", "update");
        LogUtil.e("SilenceUpdate", "下载完毕");
        if (!newVersion.isEmpty()) {
            try {
                ZipUtils.UnZipFolder(getFilesDir().getAbsolutePath() + "/Download/" + newVersion + ".zip", getFilesDir().getAbsolutePath() + "/" + newVersion + "/apps");
                LogUtil.e("SilenceUpdate", "下载路径  解压" + info.getPath() + info.getName());
                sPreferences.edit().putString("version", newVersion).apply();
                Message message = new Message();
                message.what = 2;
                handler.sendMessage(message);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    class TaskInfo {
        private String name;//文件名
        private String path;//文件路径
        private String url;//链接
        private long contentLen;//文件总长度

        private volatile long completedLen;//已完成长度

        public TaskInfo(String name, String path, String url) {
            this.name = name;
            this.path = path;
            this.url = url;
        }

        public String getName() {
            return name;
        }

        public void setName(String name) {
            this.name = name;
        }

        public String getPath() {
            return path;
        }

        public void setPath(String path) {
            this.path = path;
        }

        public String getUrl() {
            return url;
        }

        public void setUrl(String url) {
            this.url = url;
        }

        public long getContentLen() {
            return contentLen;
        }

        public void setContentLen(long contentLen) {
            this.contentLen = contentLen;
        }

        public long getCompletedLen() {
            return completedLen;
        }

        public void setCompletedLen(long completedLen) {
            this.completedLen = completedLen;
        }
    }


}
