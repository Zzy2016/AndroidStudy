package com.huidr.HuiDrDoctor.module.home;

import org.litepal.crud.LitePalSupport;

/**
 * @author: Administrator
 * @date: 2019-12-18
 * 新的系统消息
 */
public class NewMessageModel extends LitePalSupport {

    /**
     * content : 审核中
     * orderKind : 3
     * orderStatus : 0
     * orderStatusAction : 0
     * type : systemMessage
     */

    private String content;
    private String orderKind;
    private String orderStatus;
    private String orderStatusAction;
    private String type;
    private String url;
    private String info;

    public String getInfo() {
        return info;
    }

    public void setInfo(String info) {
        this.info = info;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public int getIsRead() {
        return isRead;
    }

    public void setIsRead(int isRead) {
        this.isRead = isRead;
    }

    private int isRead; // 0 未读 1已读

    private long date;

    public long getDate() {
        return date;
    }

    public void setDate(long date) {
        this.date = date;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public String getOrderKind() {
        return orderKind;
    }

    public void setOrderKind(String orderKind) {
        this.orderKind = orderKind;
    }

    public String getOrderStatus() {
        return orderStatus;
    }

    public void setOrderStatus(String orderStatus) {
        this.orderStatus = orderStatus;
    }

    public String getOrderStatusAction() {
        return orderStatusAction;
    }

    public void setOrderStatusAction(String orderStatusAction) {
        this.orderStatusAction = orderStatusAction;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }
}


