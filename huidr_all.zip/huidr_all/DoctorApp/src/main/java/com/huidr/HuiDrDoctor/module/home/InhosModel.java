package com.huidr.HuiDrDoctor.module.home;

import java.util.List;

/**
 * @author: Administrator
 * @date: 2019-11-22
 */
public class InhosModel {


    /**
     * status : 0
     * page : 1
     * totalPage : 6
     * retValue : [{"id":69883,"userName":"陈清满","userSex":1,"latelyAdmitNo":"1198094","latelyBed":"103","latelyAdmissionDiagnosis":"结直肠恶性肿瘤伴肝转移","latelyVisitingDate":"2019-04-24","doctorId":100136,"isFollow":false},{"id":64532,"userName":"陈翠兰","userSex":2,"latelyAdmitNo":"1181129","latelyBed":"118","latelyAdmissionDiagnosis":"肝恶性肿瘤术后","latelyVisitingDate":"2019-04-19","doctorId":100137,"isFollow":false},{"id":68186,"userName":"蔡顺才","userSex":1,"latelyAdmitNo":"1194426","latelyBed":"22","latelyAdmissionDiagnosis":"甲状腺恶性肿瘤(疑似)","latelyVisitingDate":"2019-04-10","doctorId":100157,"isFollow":false},{"id":64703,"userName":"陈厚泉","userSex":1,"latelyAdmitNo":"1193761","latelyBed":"28","latelyAdmissionDiagnosis":"右侧甲状腺肿物,右侧声带麻痹","latelyVisitingDate":"2019-04-08","doctorId":100157,"isFollow":false},{"id":62392,"userName":"曹正清","userSex":1,"latelyAdmitNo":"1190279","latelyBed":"23","latelyAdmissionDiagnosis":"喉恶性肿瘤","latelyVisitingDate":"2019-03-22","doctorId":100157,"isFollow":false},{"id":47726,"userName":"陈文宝","userSex":1,"latelyAdmitNo":"1109621","latelyBed":"106","latelyAdmissionDiagnosis":"肝移植状态","latelyVisitingDate":"2019-04-19","doctorId":100137,"followupName":"肝切除模板","isFollow":false},{"id":68638,"userName":"陈洪德","userSex":1,"latelyAdmitNo":"988783","latelyBed":"104","latelyAdmissionDiagnosis":"AFP升高原因待查","latelyVisitingDate":"2019-04-22","doctorId":100136,"isFollow":false},{"id":51753,"userName":"陈玉保","userSex":1,"latelyAdmitNo":"1132723","latelyBed":"31","latelyAdmissionDiagnosis":"结直肠恶性肿瘤术后肝转移","latelyDischargeDiagnosis":"直肠癌术后肝转移","latelyVisitingDate":"2019-04-12","doctorId":100137,"isFollow":true},{"id":68597,"userName":"丁正叨","userSex":1,"latelyAdmitNo":"1196027","latelyBed":"30","latelyAdmissionDiagnosis":"肝占位性病变","latelyDischargeDiagnosis":"肝占位性病变","latelyVisitingDate":"2019-04-17","doctorId":100166,"isFollow":false},{"id":65424,"userName":"董澄","userSex":1,"latelyAdmitNo":"1184290","latelyBed":"26","latelyAdmissionDiagnosis":"原发性胆汁型肝硬化","latelyVisitingDate":"2019-04-16","doctorId":100136,"isFollow":false},{"id":49799,"userName":"方宝安","userSex":1,"latelyAdmitNo":"1167128","latelyBed":"40","latelyAdmissionDiagnosis":"切口疝伴肠梗阻,肝移植状态","latelyDischargeDiagnosis":"切口疝伴肠梗阻,肝移植状态","latelyVisitingDate":"2019-03-25","doctorId":100136,"isFollow":false},{"id":62232,"userName":"冯克祥","userSex":1,"latelyAdmitNo":"1184578","latelyBed":"24","latelyAdmissionDiagnosis":"肝恶性肿瘤","latelyVisitingDate":"2019-04-09","doctorId":100137,"isFollow":false},{"id":68645,"userName":"顾伯群","userSex":1,"latelyAdmitNo":"1197510","latelyBed":"14","latelyAdmissionDiagnosis":"肝占位性病变","latelyVisitingDate":"2019-04-22","doctorId":100166,"isFollow":false},{"id":68566,"userName":"谷芳德","userSex":1,"latelyAdmitNo":"1195846","latelyBed":"35","latelyAdmissionDiagnosis":"肝占位性病变","latelyDischargeDiagnosis":"原发性肝癌","latelyVisitingDate":"2019-04-15","doctorId":100166,"isFollow":false},{"id":68636,"userName":"郭世平","userSex":1,"latelyAdmitNo":"1197518","latelyBed":"6","latelyAdmissionDiagnosis":"肝占位性病变,结肠恶性肿瘤术后","latelyVisitingDate":"2019-04-22","doctorId":100136,"isFollow":false},{"id":64552,"userName":"高学深","userSex":1,"latelyAdmitNo":"1192343","latelyBed":"6","latelyAdmissionDiagnosis":"肝占位性病变","latelyDischargeDiagnosis":"原发性肝癌","latelyVisitingDate":"2019-04-19","doctorId":100136,"isFollow":false},{"id":64706,"userName":"葛成圆","userSex":2,"latelyAdmitNo":"1193852","latelyBed":"31","latelyAdmissionDiagnosis":"甲状腺恶性肿瘤","latelyVisitingDate":"2019-04-08","doctorId":100157,"isFollow":false},{"id":69868,"userName":"顾锋","userSex":1,"latelyAdmitNo":"1197792","latelyBed":"21","latelyAdmissionDiagnosis":"肝恶性肿瘤","latelyVisitingDate":"2019-04-23","doctorId":100166,"isFollow":false},{"id":46118,"userName":"华根林","userSex":1,"latelyAdmitNo":"1058435","latelyBed":"41","bindUserRelationship":"丈夫","latelyAdmissionDiagnosis":"血尿","latelyVisitingDate":"2019-04-22","doctorId":100166,"bindUid":140481,"isFollow":false},{"id":52344,"userName":"黄超群","userSex":1,"latelyAdmitNo":"880680","latelyBed":"27","latelyAdmissionDiagnosis":"肝细胞癌,乙肝后肝硬化","latelyVisitingDate":"2019-03-11","doctorId":100137,"followupName":"肝切除模板","isFollow":true}]
     */

    private int status;
    private int page;
    private int totalPage;
    private List<RetValueBean> retValue;

    public int getStatus() {
        return status;
    }

    public void setStatus(int status) {
        this.status = status;
    }

    public int getPage() {
        return page;
    }

    public void setPage(int page) {
        this.page = page;
    }

    public int getTotalPage() {
        return totalPage;
    }

    public void setTotalPage(int totalPage) {
        this.totalPage = totalPage;
    }

    public List<RetValueBean> getRetValue() {
        return retValue;
    }

    public void setRetValue(List<RetValueBean> retValue) {
        this.retValue = retValue;
    }

    public static class RetValueBean {
        /**
         * id : 69883
         * userName : 陈清满
         * userSex : 1
         * latelyAdmitNo : 1198094
         * latelyBed : 103
         * latelyAdmissionDiagnosis : 结直肠恶性肿瘤伴肝转移
         * latelyVisitingDate : 2019-04-24
         * doctorId : 100136
         * isFollow : false
         * followupName : 肝切除模板
         * latelyDischargeDiagnosis : 直肠癌术后肝转移
         * bindUserRelationship : 丈夫
         * bindUid : 140481
         */

        private int id;
        private String userName;
        private int userSex;
        private String latelyAdmitNo;
        private String latelyBed;
        private String latelyAdmissionDiagnosis;
        private String latelyVisitingDate;
        private int doctorId;
        private boolean isFollow;
        private String followupName;
        private String latelyDischargeDiagnosis;
        private String bindUserRelationship;
        private int bindUid;

        public int getId() {
            return id;
        }

        public void setId(int id) {
            this.id = id;
        }

        public String getUserName() {
            return userName;
        }

        public void setUserName(String userName) {
            this.userName = userName;
        }

        public int getUserSex() {
            return userSex;
        }

        public void setUserSex(int userSex) {
            this.userSex = userSex;
        }

        public String getLatelyAdmitNo() {
            return latelyAdmitNo;
        }

        public void setLatelyAdmitNo(String latelyAdmitNo) {
            this.latelyAdmitNo = latelyAdmitNo;
        }

        public String getLatelyBed() {
            return latelyBed;
        }

        public void setLatelyBed(String latelyBed) {
            this.latelyBed = latelyBed;
        }

        public String getLatelyAdmissionDiagnosis() {
            return latelyAdmissionDiagnosis;
        }

        public void setLatelyAdmissionDiagnosis(String latelyAdmissionDiagnosis) {
            this.latelyAdmissionDiagnosis = latelyAdmissionDiagnosis;
        }

        public String getLatelyVisitingDate() {
            return latelyVisitingDate;
        }

        public void setLatelyVisitingDate(String latelyVisitingDate) {
            this.latelyVisitingDate = latelyVisitingDate;
        }

        public int getDoctorId() {
            return doctorId;
        }

        public void setDoctorId(int doctorId) {
            this.doctorId = doctorId;
        }

        public boolean isIsFollow() {
            return isFollow;
        }

        public void setIsFollow(boolean isFollow) {
            this.isFollow = isFollow;
        }

        public String getFollowupName() {
            return followupName;
        }

        public void setFollowupName(String followupName) {
            this.followupName = followupName;
        }

        public String getLatelyDischargeDiagnosis() {
            return latelyDischargeDiagnosis;
        }

        public void setLatelyDischargeDiagnosis(String latelyDischargeDiagnosis) {
            this.latelyDischargeDiagnosis = latelyDischargeDiagnosis;
        }

        public String getBindUserRelationship() {
            return bindUserRelationship;
        }

        public void setBindUserRelationship(String bindUserRelationship) {
            this.bindUserRelationship = bindUserRelationship;
        }

        public int getBindUid() {
            return bindUid;
        }

        public void setBindUid(int bindUid) {
            this.bindUid = bindUid;
        }
    }
}
