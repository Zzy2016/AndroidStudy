package com.huidr.HuiDrDoctor.activity.fastReply;

import android.content.Context;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import java.util.LinkedList;
import java.util.List;

/**
 * Created by Laiyimin on 2016/7/13.
 */
public class FastReplyPresenter implements FastReplyContract.Presenter {
    private static final String TAG = FastReplyPresenter.class.getName();

    private final FastReplyContract.View mView;
    private final Context mContext;


    public FastReplyPresenter(FastReplyContract.View view) {
        this.mContext = (Context) view;
        this.mView = view;
    }


    @Override
    public void destroy() {

    }

    @Override
    public void getList() {
        List<ReplyModel> list = ReplyModel.getEntryAll();
        mView.showList(list);
    }

    @Override
    public void addItem(final String content) {
        ReplyModel replyModel = new ReplyModel(false, content);
        mView.addSuccess(replyModel);
    }

    @Override
    public void updateItem(ReplyModel model, final int position) {
        mView.updateSuccess(position);
    }

    @Override
    public void adjustIndex(LinkedList<ReplyModel> data) {
        JSONArray array = new JSONArray();
        for (int i = 0; i < data.size(); i++) {
            ReplyModel model = data.get(i);
            JSONObject json = new JSONObject();
            json.put("id", model.getId());
            json.put("seqIndex", i + 1);
            array.add(json);
        }
    }

    @Override
    public void delItem(Long id, final int position) {

        mView.deleteSuccess(position);
   }
}
