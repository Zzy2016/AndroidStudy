package com.huidr.HuiDrDoctor.module.home;

/**
 * @author: Administrator
 * @date: 2020-04-16
 */
public class SumitAnswerModel {

    /**
     * status : 0
     * retValue : {"orderId":"2020041616272127096555","orderStatusAction":3,"orderStatus":2,"orderTopic":"一问医答提问","orderDetails":"{\"userWardName\":\"四十七病区\",\"userPrimaryPhysicianCode\":\"12268\",\"consultationDisease\":\"啦啦啦啦\",\"isOpenImage\":true,\"userDepartmentName\":\"肝肿瘤外科\",\"supplementInformation\":\"墨迹了咯哦哦哦哦哦哦哦哦\",\"userAge\":65,\"uid\":100295,\"userDepartmentId\":71,\"userPrimaryPhysicianName\":\"沈英皓\",\"isHandle\":false,\"userSex\":1,\"diseasePicturePaths\":\"100295/patient/158702564000059.JPG,100295/patient/158702564000029.PNG,100295/patient/15870256400003.PNG,100295/patient/158702564000028.PNG,100295/patient/158702564000083.PNG,100295/patient/158702564000037.PNG,100295/patient/158702564000080.PNG,100295/patient/158702564000013.PNG,100295/patient/158702564000038.PNG\",\"chaseId\":0,\"problemContent\":\"弄哭啊啊啊啊啊啊啊啊啊\",\"userName\":\"徐炳荣\",\"isShow\":false,\"userHospitalId\":8177,\"userHospitalName\":\"复旦大学附属中山医院\",\"userAdmitNo\":\"830627\"}","orderKind":7,"payOrderId":"2020041616272127096555","payPlatformKind":3,"createTime":"2020-04-16 16:27:21","buyerId":100295,"sellerId":10000,"buyerRelationId":3397,"addressInfo":{},"orderPrice":2,"couponPrice":0,"integralPrice":0,"payTime":"2020-04-16 16:27:28","freight":0}
     */

    private int status;
    private RetValueBean retValue;

    public int getStatus() {
        return status;
    }

    public void setStatus(int status) {
        this.status = status;
    }

    public RetValueBean getRetValue() {
        return retValue;
    }

    public void setRetValue(RetValueBean retValue) {
        this.retValue = retValue;
    }

    public static class RetValueBean {
        /**
         * orderId : 2020041616272127096555
         * orderStatusAction : 3
         * orderStatus : 2
         * orderTopic : 一问医答提问
         * orderDetails : {"userWardName":"四十七病区","userPrimaryPhysicianCode":"12268","consultationDisease":"啦啦啦啦","isOpenImage":true,"userDepartmentName":"肝肿瘤外科","supplementInformation":"墨迹了咯哦哦哦哦哦哦哦哦","userAge":65,"uid":100295,"userDepartmentId":71,"userPrimaryPhysicianName":"沈英皓","isHandle":false,"userSex":1,"diseasePicturePaths":"100295/patient/158702564000059.JPG,100295/patient/158702564000029.PNG,100295/patient/15870256400003.PNG,100295/patient/158702564000028.PNG,100295/patient/158702564000083.PNG,100295/patient/158702564000037.PNG,100295/patient/158702564000080.PNG,100295/patient/158702564000013.PNG,100295/patient/158702564000038.PNG","chaseId":0,"problemContent":"弄哭啊啊啊啊啊啊啊啊啊","userName":"徐炳荣","isShow":false,"userHospitalId":8177,"userHospitalName":"复旦大学附属中山医院","userAdmitNo":"830627"}
         * orderKind : 7
         * payOrderId : 2020041616272127096555
         * payPlatformKind : 3
         * createTime : 2020-04-16 16:27:21
         * buyerId : 100295
         * sellerId : 10000
         * buyerRelationId : 3397
         * addressInfo : {}
         * orderPrice : 2
         * couponPrice : 0
         * integralPrice : 0
         * payTime : 2020-04-16 16:27:28
         * freight : 0
         */

        private String orderId;
        private int orderStatusAction;
        private int orderStatus;
        private String orderTopic;
        private String orderDetails;
        private int orderKind;
        private String payOrderId;
        private int payPlatformKind;
        private String createTime;
        private int buyerId;
        private int sellerId;
        private int buyerRelationId;
        private AddressInfoBean addressInfo;
        private int orderPrice;
        private int couponPrice;
        private int integralPrice;
        private String payTime;
        private int freight;

        public String getOrderId() {
            return orderId;
        }

        public void setOrderId(String orderId) {
            this.orderId = orderId;
        }

        public int getOrderStatusAction() {
            return orderStatusAction;
        }

        public void setOrderStatusAction(int orderStatusAction) {
            this.orderStatusAction = orderStatusAction;
        }

        public int getOrderStatus() {
            return orderStatus;
        }

        public void setOrderStatus(int orderStatus) {
            this.orderStatus = orderStatus;
        }

        public String getOrderTopic() {
            return orderTopic;
        }

        public void setOrderTopic(String orderTopic) {
            this.orderTopic = orderTopic;
        }

        public String getOrderDetails() {
            return orderDetails;
        }

        public void setOrderDetails(String orderDetails) {
            this.orderDetails = orderDetails;
        }

        public int getOrderKind() {
            return orderKind;
        }

        public void setOrderKind(int orderKind) {
            this.orderKind = orderKind;
        }

        public String getPayOrderId() {
            return payOrderId;
        }

        public void setPayOrderId(String payOrderId) {
            this.payOrderId = payOrderId;
        }

        public int getPayPlatformKind() {
            return payPlatformKind;
        }

        public void setPayPlatformKind(int payPlatformKind) {
            this.payPlatformKind = payPlatformKind;
        }

        public String getCreateTime() {
            return createTime;
        }

        public void setCreateTime(String createTime) {
            this.createTime = createTime;
        }

        public int getBuyerId() {
            return buyerId;
        }

        public void setBuyerId(int buyerId) {
            this.buyerId = buyerId;
        }

        public int getSellerId() {
            return sellerId;
        }

        public void setSellerId(int sellerId) {
            this.sellerId = sellerId;
        }

        public int getBuyerRelationId() {
            return buyerRelationId;
        }

        public void setBuyerRelationId(int buyerRelationId) {
            this.buyerRelationId = buyerRelationId;
        }

        public AddressInfoBean getAddressInfo() {
            return addressInfo;
        }

        public void setAddressInfo(AddressInfoBean addressInfo) {
            this.addressInfo = addressInfo;
        }

        public int getOrderPrice() {
            return orderPrice;
        }

        public void setOrderPrice(int orderPrice) {
            this.orderPrice = orderPrice;
        }

        public int getCouponPrice() {
            return couponPrice;
        }

        public void setCouponPrice(int couponPrice) {
            this.couponPrice = couponPrice;
        }

        public int getIntegralPrice() {
            return integralPrice;
        }

        public void setIntegralPrice(int integralPrice) {
            this.integralPrice = integralPrice;
        }

        public String getPayTime() {
            return payTime;
        }

        public void setPayTime(String payTime) {
            this.payTime = payTime;
        }

        public int getFreight() {
            return freight;
        }

        public void setFreight(int freight) {
            this.freight = freight;
        }

        public static class AddressInfoBean {
        }
    }
}
