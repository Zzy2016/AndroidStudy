package com.huidr.HuiDrDoctor.activity;

import android.content.Intent;
import android.graphics.Paint;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.text.Html;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;


import com.chad.library.adapter.base.BaseQuickAdapter;
import com.chad.library.adapter.base.BaseViewHolder;
import com.google.gson.Gson;
import com.huidr.HuiDrDoctor.activity.main.Consult.utils.PostAndGet;
import com.huidr.HuiDrDoctor.debug.BuildConfig;
import com.huidr.HuiDrDoctor.debug.R;
import com.huidr.HuiDrDoctor.module.home.QueListModel;
import com.huidr.HuiDrDoctor.module.home.SimpleResultModel;
import com.huidr.HuiDrDoctor.module.home.SimpleResultStrModel;
import com.huidr.HuiDrDoctor.module.model.LoginResultForH5;
import com.huidr.HuiDrDoctor.util.DialogContentUtil;
import com.huidr.HuiDrDoctor.util.DialogDeleteUtil;
import com.huidr.HuiDrDoctor.util.LogUtil;
import com.huidr.HuiDrDoctor.util.MulityClickUtils;
import com.huidr.HuiDrDoctor.util.ThreadPoolManager;
import com.scwang.smartrefresh.layout.SmartRefreshLayout;
import com.scwang.smartrefresh.layout.api.RefreshLayout;
import com.scwang.smartrefresh.layout.listener.OnLoadMoreListener;
import com.scwang.smartrefresh.layout.listener.OnRefreshListener;

import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.Date;

import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import jiguang.chat.utils.oss.Constants;
import jiguang.chat.utils.oss.SharedPreferenciesUtil;

public class QuestionListActivity extends AppCompatActivity {

    private DialogDeleteUtil dialogDeleteUtil;
    private DialogContentUtil dialogContentUtil;


    private ImageView imgBack;
    private TextView tvLink;
    private TextView tvDialog;
    private TextView tvIncomeCount;
    private ImageView imgDialog;
    private SmartRefreshLayout srlQuestion;
    private RecyclerView rvListQuestion;


    private ImageView imgEmpty;
    private TextView tvEmptyHint;

    private int currentPage = 1;
    private int totalPage = 1;


    private Gson gson;
    String doctorJobNum;
    int doctorDepId;
    int hospitalId;

    int pageSize = 20;


    private QueListModel queListModel;


    private SimpleDateFormat sDateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
    private Date date = new Date();


    private String path = BuildConfig.baseUrl + "recommend/askAnswerOptimizationDoctorController/getDoctorMedicalAnswerList";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_question_list);

        queListModel = new QueListModel();
        gson = new Gson();
        initView();
        initData();

        String userInfo = (String) SharedPreferenciesUtil.getData(Constants.SharedAccountConfig.USER_DOCTOR_INFO, "");
        Log.e("user", userInfo);

        LoginResultForH5 loginResult = gson.fromJson(userInfo, LoginResultForH5.class);

        doctorDepId = loginResult.getValue().getDepartmentId();
        doctorJobNum = loginResult.getValue().getUserJobNumber();
        SharedPreferenciesUtil.putData("doctorJobNum", "0");
        hospitalId = loginResult.getValue().getHospitalId();

    }

    @Override
    protected void onStart() {
        super.onStart();

        Log.e("获取列表数据", "huoqu");
        getQuestionList();
        getTotalRevenue();

    }

    /*列表数据*/
    public void getQuestionList() {
        ThreadPoolManager.getInstance().execute(new Runnable() {
            @Override
            public void run() {
                path = BuildConfig.baseUrl + "recommend/askAnswerOptimizationDoctorController/getDoctorMedicalAnswerList?departmentId=" + doctorDepId + "&pageIndex=" + currentPage + "&pageSize=" + pageSize + "&userJobNumber=" + doctorJobNum;

                String result = PostAndGet.doGetHttp(path);
                queListModel = new QueListModel();
                LogUtil.e("问题列表", result);
                if (result.equals("网络异常")) {
                    handler.sendEmptyMessage(2);
                } else {

                    queListModel = gson.fromJson(result, QueListModel.class);
                    totalPage = queListModel.getTotalPage();
                    if (currentPage == 1) {
                        handler.sendEmptyMessage(0);
                    } else {
                        handler.sendEmptyMessage(1);
                    }
                }
            }
        });
    }

    /*获取  收益*/
    public void getTotalRevenue() {
        final String path = BuildConfig.baseUrl + "pay/askAnswersMallController/getDoctorQuestionsTotalRevenue";
        ThreadPoolManager.getInstance().execute(new Runnable() {
            @Override
            public void run() {
                String result = PostAndGet.doGetHttp(path);
                Log.e("收益", result);
                if (result.equals("网络异常")) {

                } else {
                    final SimpleResultModel simpleResultModel = gson.fromJson(result, SimpleResultModel.class);
                    tvIncomeCount.post(new Runnable() {
                        @Override
                        public void run() {


                            double num = new BigDecimal((float) simpleResultModel.getRetValue() / 100).setScale(2, BigDecimal.ROUND_HALF_UP).doubleValue();


                            tvIncomeCount.setText(Html.fromHtml("<u>" + num + "元</u>"));
                        }
                    });
                }
            }
        });
    }


    public void initView() {
        imgBack = (ImageView) findViewById(R.id.img_back);
        tvLink = (TextView) findViewById(R.id.tv_link);
        tvDialog = (TextView) findViewById(R.id.tv_dialog);
        imgDialog = (ImageView) findViewById(R.id.img_dialog);
        tvIncomeCount = (TextView) findViewById(R.id.tv_income_count);
        tvIncomeCount.setText(Html.fromHtml("<u>" + "0元" + "</u>"));

        imgBack.setOnClickListener(clickListener);
        tvLink.setOnClickListener(clickListener);
        tvDialog.setOnClickListener(clickListener);
        imgDialog.setOnClickListener(clickListener);
        tvIncomeCount.setOnClickListener(clickListener);


        srlQuestion = (SmartRefreshLayout) findViewById(R.id.srl_question);
        rvListQuestion = (RecyclerView) findViewById(R.id.rv_list_question);
        rvListQuestion.setAdapter(adapter);
        rvListQuestion.setLayoutManager(new LinearLayoutManager(this));
//        rvListQuestion.addItemDecoration(new DividerItemDecoration(QuestionListActivity.this, DividerItemDecoration.VERTICAL));

        srlQuestion.setEnableLoadMore(true);
        srlQuestion.setEnableRefresh(true);


        srlQuestion.setOnLoadMoreListener(new OnLoadMoreListener() {
            @Override
            public void onLoadMore(@NonNull RefreshLayout refreshLayout) {

                if (currentPage < totalPage && queListModel.getRetValue().size() == 20) {
                    currentPage += 1;
                    getQuestionList();
                } else {

                    com.huidr.lib.commom.util.Toast.getInstance(QuestionListActivity.this).show("数据加载全部", 500);
                    srlQuestion.finishLoadMore();
                }
            }
        });


        srlQuestion.setOnRefreshListener(new OnRefreshListener() {
            @Override
            public void onRefresh(@NonNull RefreshLayout refreshLayout) {
                currentPage = 1;
                getQuestionList();
            }
        });

        imgEmpty = (ImageView) findViewById(R.id.img_empty);
        tvEmptyHint = (TextView) findViewById(R.id.tv_empty_hint);

    }

    Handler handler = new Handler() {
        @Override
        public void handleMessage(Message msg) {
            super.handleMessage(msg);

            switch (msg.what) {
                case 0:
                    adapter.getData().clear();

                    if (queListModel.getRetValue() == null || queListModel.getRetValue().size() == 0) {
                        srlQuestion.setVisibility(View.GONE);
                        imgEmpty.setVisibility(View.VISIBLE);
                        tvEmptyHint.setVisibility(View.VISIBLE);
                    } else {

                        if (srlQuestion.getVisibility() == View.GONE) {
                            srlQuestion.setVisibility(View.VISIBLE);
                            imgEmpty.setVisibility(View.GONE);
                            tvEmptyHint.setVisibility(View.GONE);
                        }

                        adapter.getData().addAll(queListModel.getRetValue());
                        adapter.notifyDataSetChanged();
                    }


                    srlQuestion.finishRefresh();
                    break;
                case 1:
                    adapter.getData().addAll(queListModel.getRetValue());
                    adapter.notifyDataSetChanged();
                    srlQuestion.finishLoadMore();
                    break;
                case 2:
                    srlQuestion.finishRefresh();
                    srlQuestion.finishLoadMore();

                    srlQuestion.setVisibility(View.GONE);
                    imgEmpty.setVisibility(View.VISIBLE);
                    tvEmptyHint.setVisibility(View.VISIBLE);
                    break;

//                    删除失败
                case 3:
//                    adapter.remove();
//                    Toast.makeText(QuestionListActivity.this, "操作失败，请稍后重试", Toast.LENGTH_SHORT).show();
                    com.huidr.lib.commom.util.Toast.getInstance(QuestionListActivity.this).show("操作失败,请稍后重试", 500);

                    break;
//                    删除成功
                case 4:
                    adapter.remove(msg.arg1);
                    break;
            }
        }
    };


    public void initData() {
        dialogContentUtil = new DialogContentUtil(QuestionListActivity.this);


        dialogDeleteUtil = new DialogDeleteUtil(QuestionListActivity.this);

        dialogDeleteUtil.setDialogOperate(new DialogDeleteUtil.DialogOperate() {
            @Override
            public void onClickEnsure(int position) {
                doDelete(adapter.getData().get(position).getId(), position);
            }

            @Override
            public void onClickCancel(int position) {

            }
        });


    }


    //    不感兴趣

    public void doDelete(int id, final int position) {
        final String path = BuildConfig.baseUrl + "recommend/askAnswerOptimizationDoctorController/editIsInterest?id=" + id + "&hospitalId=" + hospitalId + "&departmentId=" + doctorDepId;
        ThreadPoolManager.getInstance().execute(new Runnable() {
            @Override
            public void run() {
                String result = PostAndGet.doGetHttp(path);
                Log.e("不感兴趣", result);
                if (result.equals("网络异常")) {
                    handler.sendEmptyMessage(3);
                } else {
                    SimpleResultStrModel simpleResultStrModel = gson.fromJson(result, SimpleResultStrModel.class);
                    if (simpleResultStrModel.getRetValue().equals("SUCCESS")) {
                        Message message = new Message();
                        message.what = 4;
                        message.arg1 = position;
                        handler.sendMessage(message);
                    } else {
                        handler.sendEmptyMessage(3);
                    }
                }
            }
        });
    }


    BaseQuickAdapter<QueListModel.RetValueBean, BaseViewHolder> adapter = new BaseQuickAdapter<QueListModel.RetValueBean, BaseViewHolder>(R.layout.item_question) {
        @Override
        protected void convert(final BaseViewHolder helper, final QueListModel.RetValueBean item) {

            ImageView imgHead = helper.getView(R.id.img_head);

            imgHead.setBackgroundResource(R.drawable.husband);

            TextView tvName = helper.getView(R.id.tv_name);
            TextView tvIndi = helper.getView(R.id.tv_indi);
            TextView tvIndi1 = helper.getView(R.id.tv_indi1);
            TextView tvDate = helper.getView(R.id.tv_date);
            TextView tvSource = helper.getView(R.id.tv_source);
            TextView tvQuestion = helper.getView(R.id.tv_question);
            TextView tvDep = helper.getView(R.id.tv_depart);
            TextView tvDepart = helper.getView(R.id.tv_depart);
            Button btnDetail = helper.getView(R.id.btn_detail);
            Button btnReply = helper.getView(R.id.btn_reply);
            TextView tvHide = helper.getView(R.id.tv_hide);
            tvHide.getPaint().setFlags(Paint.UNDERLINE_TEXT_FLAG);

            tvName.setText(item.getUserName());

            tvSource.setText(item.getUserHospitalName());
            tvDep.setText(item.getUserDepartmentName());
            tvDepart.setText(item.getUserWardName());


            date.setTime(item.getSummitTime());
            tvDate.setText(sDateFormat.format(date));

            tvQuestion.setText("问题：" + item.getProblemContent());

            LogUtil.e("我的患者", item.getUserPrimaryPhysicianCode() + "    " + doctorJobNum);

            if (item.getUserPrimaryPhysicianCode() != null && item.getUserPrimaryPhysicianCode().equals(doctorJobNum)) {
                tvIndi.setVisibility(View.VISIBLE);
            } else {
                tvIndi.setVisibility(View.GONE);
            }


            if (item.getOtherLabel() != null) {
                tvIndi1.setText("#" + item.getOtherLabel() + "#");
            }

//            问题详情页 打开回答 回答问题
            btnReply.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (MulityClickUtils.isFastClick()) {
                        Intent intent = new Intent(QuestionListActivity.this, QuestionDetailActivity.class);
                        intent.putExtra("showType", 0);
                        intent.putExtra("showImm", 1);
                        intent.putExtra("queId", item.getId());

//                        if (item.getUserPrimaryPhysicianCode()!=null&&item.getUserPrimaryPhysicianCode().equals(doctorJobNum) ) {
//                            intent.putExtra("isMyPatient", true);
//                        } else {
//                            intent.putExtra("isMyPatient", false);
//                        }

                        if (item.getUserPrimaryPhysicianCode() != null && item.getUserPrimaryPhysicianCode().equals(doctorJobNum)) {
                            intent.putExtra("jobnum", item.getUserPrimaryPhysicianCode().toString());
                        } else {
                            intent.putExtra("jobnum", "0");
                        }


                        startActivity(intent);
                    }
                }
            });
//问题详情页  查看详情
            btnDetail.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (MulityClickUtils.isFastClick()) {
                        Intent intent = new Intent(QuestionListActivity.this, QuestionDetailActivity.class);
                        intent.putExtra("showType", 0);
                        intent.putExtra("showImm", 0);
                        intent.putExtra("queId", item.getId());

//                        if (item.getUserPrimaryPhysicianCode() != null && item.getUserPrimaryPhysicianCode().equals(doctorJobNum)) {
//                            intent.putExtra("isMyPatient", true);
//                        } else {
//                            intent.putExtra("isMyPatient", false);
//                        }

                        if (item.getUserPrimaryPhysicianCode() != null && item.getUserPrimaryPhysicianCode().equals(doctorJobNum)) {
                            intent.putExtra("jobnum", item.getUserPrimaryPhysicianCode().toString());
                        } else {
                            intent.putExtra("jobnum", "0");
                        }

                        startActivity(intent);
                    }
                }
            });

            tvQuestion.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (MulityClickUtils.isFastClick()) {
                        Intent intent = new Intent(QuestionListActivity.this, QuestionDetailActivity.class);
                        intent.putExtra("showType", 0);
                        intent.putExtra("showImm", 0);
                        intent.putExtra("queId", item.getId());

                        if (item.getUserPrimaryPhysicianCode() == doctorJobNum) {
                            intent.putExtra("isMyPatient", true);
                        } else {
                            intent.putExtra("isMyPatient", false);
                        }

                        startActivity(intent);
                    }
                }
            });


//            弹出确认弹窗  根据是否是自己的患者  进行弹窗 提示
            tvHide.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {


                    if (item.getUserPrimaryPhysicianCode().equals(doctorJobNum)) {
                        if (MulityClickUtils.isFastClick()) {
                            dialogDeleteUtil.setPosition(helper.getAdapterPosition());
                            dialogDeleteUtil.setTitle(item.getUserName() + "是您的患者,是否删除本条咨询？");
                            dialogDeleteUtil.showDeleteDialog();
                        }
                    } else {
                        doDelete(item.getId(), helper.getAdapterPosition());
                    }
                }
            });

        }

    };


    View.OnClickListener clickListener = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            switch (v.getId()) {
                case R.id.img_back:
                    if(MulityClickUtils.isFastClick()){
                        finish();
                    }
                    break;
                case R.id.tv_link:
                    /*历史问答*/
                    if (MulityClickUtils.isFastClick()) {
                        Intent intent = new Intent(QuestionListActivity.this, ReplyActivity.class);
                        startActivity(intent);
                    }
                    break;

                case R.id.tv_income_count:
                    /*我的账户*/
                    if (MulityClickUtils.isFastClick()) {
                        Intent intent = new Intent(QuestionListActivity.this, WebActivity.class);
                        Bundle bundle = new Bundle();
                        bundle.putString("url", "myAccount.html");
                        intent.putExtras(bundle);
                        startActivity(intent);
                    }
                    break;

                default:
                    if (MulityClickUtils.isFastClick()) {
                        dialogContentUtil.showContentDialog();
                    }
            }
        }
    };


}
