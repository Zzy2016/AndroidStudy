package com.huidr.HuiDrDoctor.module.home;

import java.util.List;

/**
 * @author: Administrator
 * @date: 2019-11-26
 */
public class BannerModel {
    /**
     * status : 0
     * page : 1
     * totalPage : 1
     * retValue : [{"id":50,"showPng":"article/uploadImg/banner.png","jumpUrl":"shoppingMall_detail.html?id=59","description":"首页banner","jumpType":1,"position":1,"isUse":true,"bannerType":2}]
     */

    private int status;
    private int page;
    private int totalPage;
    private List<RetValueBean> retValue;

    public int getStatus() {
        return status;
    }

    public void setStatus(int status) {
        this.status = status;
    }

    public int getPage() {
        return page;
    }

    public void setPage(int page) {
        this.page = page;
    }

    public int getTotalPage() {
        return totalPage;
    }

    public void setTotalPage(int totalPage) {
        this.totalPage = totalPage;
    }

    public List<RetValueBean> getRetValue() {
        return retValue;
    }

    public void setRetValue(List<RetValueBean> retValue) {
        this.retValue = retValue;
    }

    public static class RetValueBean {
        /**
         * id : 50
         * showPng : article/uploadImg/banner.png
         * jumpUrl : shoppingMall_detail.html?id=59
         * description : 首页banner
         * jumpType : 1
         * position : 1
         * isUse : true
         * bannerType : 2
         */

        private int id;
        private String showPng;
        private String jumpUrl;
        private String description;
        private int jumpType;
        private int position;
        private boolean isUse;
        private int bannerType;

        public int getId() {
            return id;
        }

        public void setId(int id) {
            this.id = id;
        }

        public String getShowPng() {
            return showPng;
        }

        public void setShowPng(String showPng) {
            this.showPng = showPng;
        }

        public String getJumpUrl() {
            return jumpUrl;
        }

        public void setJumpUrl(String jumpUrl) {
            this.jumpUrl = jumpUrl;
        }

        public String getDescription() {
            return description;
        }

        public void setDescription(String description) {
            this.description = description;
        }

        public int getJumpType() {
            return jumpType;
        }

        public void setJumpType(int jumpType) {
            this.jumpType = jumpType;
        }

        public int getPosition() {
            return position;
        }

        public void setPosition(int position) {
            this.position = position;
        }

        public boolean isIsUse() {
            return isUse;
        }

        public void setIsUse(boolean isUse) {
            this.isUse = isUse;
        }

        public int getBannerType() {
            return bannerType;
        }

        public void setBannerType(int bannerType) {
            this.bannerType = bannerType;
        }
    }
}
