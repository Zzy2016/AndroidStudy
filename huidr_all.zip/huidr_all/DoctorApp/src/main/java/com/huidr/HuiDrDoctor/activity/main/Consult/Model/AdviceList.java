package com.huidr.HuiDrDoctor.activity.main.Consult.Model;

import java.util.List;

public class AdviceList {
    /**
     * status : 0
     * page : 1
     * totalPage : 10
     * retValue : [{"id":2675,"orderId":"2019101003170743197661","userType":1,"finishTime":"2019-10-10 12:07:37","money":500,"patientName":"测试肝肿瘤外科8","isSuggest":true,"suggest":"12345"},{"id":2674,"orderId":"2019101003170743197661","userType":1,"finishTime":"2019-10-10 12:07:37","money":500,"patientName":"测试肝肿瘤外科8","isSuggest":true,"suggest":"1234"},{"id":2673,"orderId":"2019101003170743197661","userType":1,"finishTime":"2019-10-10 12:07:37","money":500,"patientName":"测试肝肿瘤外科8","isSuggest":true,"suggest":"123"},{"id":2672,"orderId":"2019101003170743197661","userType":1,"finishTime":"2019-10-10 12:07:37","money":500,"patientName":"测试肝肿瘤外科8","isSuggest":true,"suggest":"12"},{"id":2671,"orderId":"2019101003170743197661","userType":1,"finishTime":"2019-10-10 12:07:37","money":500,"patientName":"测试肝肿瘤外科8","isSuggest":true,"suggest":"1"},{"id":2669,"orderId":"2019100910521042001454","userType":1,"money":500,"patientName":"测试肝肿瘤外科8","isSuggest":true,"suggest":"1234567890"},{"id":2668,"orderId":"2019100910521042001454","userType":1,"money":500,"patientName":"测试肝肿瘤外科8","isSuggest":true,"suggest":"123456789"},{"id":2667,"orderId":"2019100910521042001454","userType":1,"money":500,"patientName":"测试肝肿瘤外科8","isSuggest":true,"suggest":"12345678"},{"id":2666,"orderId":"2019100910521042001454","userType":1,"money":500,"patientName":"测试肝肿瘤外科8","isSuggest":true,"suggest":"1234567"},{"id":2665,"orderId":"2019100910521042001454","userType":1,"money":500,"patientName":"测试肝肿瘤外科8","isSuggest":true,"suggest":"123456"}]
     */

    private int status;
    private int page;
    private int totalPage;
    private List<RetValueBean> retValue;

    public int getStatus() {
        return status;
    }

    public void setStatus(int status) {
        this.status = status;
    }

    public int getPage() {
        return page;
    }

    public void setPage(int page) {
        this.page = page;
    }

    public int getTotalPage() {
        return totalPage;
    }

    public void setTotalPage(int totalPage) {
        this.totalPage = totalPage;
    }

    public List<RetValueBean> getRetValue() {
        return retValue;
    }

    public void setRetValue(List<RetValueBean> retValue) {
        this.retValue = retValue;
    }

    public static class RetValueBean {
        /**
         * id : 2675
         * orderId : 2019101003170743197661
         * userType : 1
         * finishTime : 2019-10-10 12:07:37
         * money : 500
         * patientName : 测试肝肿瘤外科8
         * isSuggest : true
         * suggest : 12345
         */

        private int id;
        private String orderId;
        private int userType;
        private String finishTime;
        private int money;
        private String patientName;
        private boolean isSuggest;
        private String suggest;

        public int getId() {
            return id;
        }

        public void setId(int id) {
            this.id = id;
        }

        public String getOrderId() {
            return orderId;
        }

        public void setOrderId(String orderId) {
            this.orderId = orderId;
        }

        public int getUserType() {
            return userType;
        }

        public void setUserType(int userType) {
            this.userType = userType;
        }

        public String getFinishTime() {
            return finishTime;
        }

        public void setFinishTime(String finishTime) {
            this.finishTime = finishTime;
        }

        public int getMoney() {
            return money;
        }

        public void setMoney(int money) {
            this.money = money;
        }

        public String getPatientName() {
            return patientName;
        }

        public void setPatientName(String patientName) {
            this.patientName = patientName;
        }

        public boolean isIsSuggest() {
            return isSuggest;
        }

        public void setIsSuggest(boolean isSuggest) {
            this.isSuggest = isSuggest;
        }

        public String getSuggest() {
            return suggest;
        }

        public void setSuggest(String suggest) {
            this.suggest = suggest;
        }
    }


//    /**
//     * status : 0
//     * page : 1
//     * totalPage : 0
//     * retValue : [{"id":2537,"userType":1,"contentType":4,"consultContent":"医生已经接受您的咨询申请，赶快向医生咨询吧","commitTime":"2019-09-16 16:26:11","isSuggest":false,"suggest":"路我就去"},{"id":2537,"userType":1,"contentType":4,"consultContent":"医生已经接受您的咨询申请，赶快向医生咨询吧","commitTime":"2019-09-16 16:26:11","isSuggest":false,"suggest":"路我就去"},{"id":2537,"userType":1,"contentType":4,"consultContent":"医生已经接受您的咨询申请，赶快向医生咨询吧","commitTime":"2019-09-16 16:26:11","isSuggest":false,"suggest":"路我就去"},{"id":2537,"userType":1,"contentType":4,"consultContent":"医生已经接受您的咨询申请，赶快向医生咨询吧","commitTime":"2019-09-16 16:26:11","isSuggest":false,"suggest":"路我就去"},{"id":2537,"userType":1,"contentType":4,"consultContent":"医生已经接受您的咨询申请，赶快向医生咨询吧","commitTime":"2019-09-16 16:26:11","isSuggest":false,"suggest":"路我就去"},{"id":2537,"userType":1,"contentType":4,"consultContent":"医生已经接受您的咨询申请，赶快向医生咨询吧","commitTime":"2019-09-16 16:26:11","isSuggest":false,"suggest":"路我就去"},{"id":2537,"userType":1,"contentType":4,"consultContent":"医生已经接受您的咨询申请，赶快向医生咨询吧","commitTime":"2019-09-16 16:26:11","isSuggest":false,"suggest":"路我就去"},{"id":2537,"userType":1,"contentType":4,"consultContent":"医生已经接受您的咨询申请，赶快向医生咨询吧","commitTime":"2019-09-16 16:26:11","isSuggest":false,"suggest":"路我就去"},{"id":2537,"userType":1,"contentType":4,"consultContent":"医生已经接受您的咨询申请，赶快向医生咨询吧","commitTime":"2019-09-16 16:26:11","isSuggest":false,"suggest":"路我就去"},{"id":2537,"userType":1,"contentType":4,"consultContent":"医生已经接受您的咨询申请，赶快向医生咨询吧","commitTime":"2019-09-16 16:26:11","isSuggest":false,"suggest":"路我就去"},{"id":2537,"userType":1,"contentType":4,"consultContent":"医生已经接受您的咨询申请，赶快向医生咨询吧","commitTime":"2019-09-16 16:26:11","isSuggest":false,"suggest":"路我就去"},{"id":2537,"userType":1,"contentType":4,"consultContent":"医生已经接受您的咨询申请，赶快向医生咨询吧","commitTime":"2019-09-16 16:26:11","isSuggest":false,"suggest":"路我就去"},{"id":2537,"userType":1,"contentType":4,"consultContent":"医生已经接受您的咨询申请，赶快向医生咨询吧","commitTime":"2019-09-16 16:26:11","isSuggest":false,"suggest":"路我就去"},{"id":2537,"userType":1,"contentType":4,"consultContent":"医生已经接受您的咨询申请，赶快向医生咨询吧","commitTime":"2019-09-16 16:26:11","isSuggest":false,"suggest":"路我就去"},{"id":2537,"userType":1,"contentType":4,"consultContent":"医生已经接受您的咨询申请，赶快向医生咨询吧","commitTime":"2019-09-16 16:26:11","isSuggest":false,"suggest":"路我就去"},{"id":2537,"userType":1,"contentType":4,"consultContent":"医生已经接受您的咨询申请，赶快向医生咨询吧","commitTime":"2019-09-16 16:26:11","isSuggest":false,"suggest":"路我就去"},{"id":2537,"userType":1,"contentType":4,"consultContent":"医生已经接受您的咨询申请，赶快向医生咨询吧","commitTime":"2019-09-16 16:26:11","isSuggest":false,"suggest":"路我就去"},{"id":2537,"userType":1,"contentType":4,"consultContent":"医生已经接受您的咨询申请，赶快向医生咨询吧","commitTime":"2019-09-16 16:26:11","isSuggest":false,"suggest":"路我就去"},{"id":2537,"userType":1,"contentType":4,"consultContent":"医生已经接受您的咨询申请，赶快向医生咨询吧","commitTime":"2019-09-16 16:26:11","isSuggest":false,"suggest":"路我就去"},{"id":2537,"userType":1,"contentType":4,"consultContent":"医生已经接受您的咨询申请，赶快向医生咨询吧","commitTime":"2019-09-16 16:26:11","isSuggest":false,"suggest":"路我就去"},{"id":2537,"userType":1,"contentType":4,"consultContent":"医生已经接受您的咨询申请，赶快向医生咨询吧","commitTime":"2019-09-16 16:26:11","isSuggest":false,"suggest":"路我就去"},{"id":2537,"userType":1,"contentType":4,"consultContent":"医生已经接受您的咨询申请，赶快向医生咨询吧","commitTime":"2019-09-16 16:26:11","isSuggest":false,"suggest":"路我就去"},{"id":2537,"userType":1,"contentType":4,"consultContent":"医生已经接受您的咨询申请，赶快向医生咨询吧","commitTime":"2019-09-16 16:26:11","isSuggest":false,"suggest":"路我就去"},{"id":2537,"userType":1,"contentType":4,"consultContent":"医生已经接受您的咨询申请，赶快向医生咨询吧","commitTime":"2019-09-16 16:26:11","isSuggest":false,"suggest":"路我就去"},{"id":2537,"userType":1,"contentType":4,"consultContent":"医生已经接受您的咨询申请，赶快向医生咨询吧","commitTime":"2019-09-16 16:26:11","isSuggest":false,"suggest":"路我就去"}]
//     */
//
//    private int status;
//    private int page;
//    private int totalPage;
//    private List<RetValueBean> retValue;
//
//    public int getStatus() {
//        return status;
//    }
//
//    public void setStatus(int status) {
//        this.status = status;
//    }
//
//    public int getPage() {
//        return page;
//    }
//
//    public void setPage(int page) {
//        this.page = page;
//    }
//
//    public int getTotalPage() {
//        return totalPage;
//    }
//
//    public void setTotalPage(int totalPage) {
//        this.totalPage = totalPage;
//    }
//
//    public List<RetValueBean> getRetValue() {
//        return retValue;
//    }
//
//    public void setRetValue(List<RetValueBean> retValue) {
//        this.retValue = retValue;
//    }
//
//    public static class RetValueBean {
//        /**
//         * id : 2537
//         * userType : 1
//         * contentType : 4
//         * consultContent : 医生已经接受您的咨询申请，赶快向医生咨询吧
//         * commitTime : 2019-09-16 16:26:11
//         * isSuggest : false
//         * suggest : 路我就去
//         */
//
//        private int id;
//        private int userType;
//        private int contentType;
//        private String consultContent;
//        private String commitTime;
//        private boolean isSuggest;
//        private String suggest;
//
//        public int getId() {
//            return id;
//        }
//
//        public void setId(int id) {
//            this.id = id;
//        }
//
//        public int getUserType() {
//            return userType;
//        }
//
//        public void setUserType(int userType) {
//            this.userType = userType;
//        }
//
//        public int getContentType() {
//            return contentType;
//        }
//
//        public void setContentType(int contentType) {
//            this.contentType = contentType;
//        }
//
//        public String getConsultContent() {
//            return consultContent;
//        }
//
//        public void setConsultContent(String consultContent) {
//            this.consultContent = consultContent;
//        }
//
//        public String getCommitTime() {
//            return commitTime;
//        }
//
//        public void setCommitTime(String commitTime) {
//            this.commitTime = commitTime;
//        }
//
//        public boolean isIsSuggest() {
//            return isSuggest;
//        }
//
//        public void setIsSuggest(boolean isSuggest) {
//            this.isSuggest = isSuggest;
//        }
//
//        public String getSuggest() {
//            return suggest;
//        }
//
//        public void setSuggest(String suggest) {
//            this.suggest = suggest;
//        }
//    }
}
