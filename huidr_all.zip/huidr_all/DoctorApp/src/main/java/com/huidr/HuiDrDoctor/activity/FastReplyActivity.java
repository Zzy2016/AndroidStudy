package com.huidr.HuiDrDoctor.activity;

import android.graphics.Color;
import android.os.Bundle;

import androidx.recyclerview.widget.ItemTouchHelper;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.KeyEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.activeandroid.ActiveAndroid;
import com.chad.library.adapter.base.BaseQuickAdapter;
import com.chad.library.adapter.base.BaseViewHolder;
import com.chad.library.adapter.base.callback.ItemDragAndSwipeCallback;
import com.chad.library.adapter.base.listener.OnItemChildClickListener;
import com.chad.library.adapter.base.listener.OnItemDragListener;
import com.huidr.HuiDrDoctor.activity.fastReply.FastReplyAdapter;
import com.huidr.HuiDrDoctor.activity.fastReply.FastReplyContract;
import com.huidr.HuiDrDoctor.activity.fastReply.FastReplyPresenter;
import com.huidr.HuiDrDoctor.activity.fastReply.ReplyModel;
import com.huidr.HuiDrDoctor.debug.R;
import com.huidr.HuiDrDoctor.module.base.BaseMultiPageActivity;
import com.huidr.HuiDrDoctor.util.LogUtil;
import com.huidr.component.swipeRecyclerview.Closeable;
import com.huidr.component.swipeRecyclerview.OnSwipeMenuItemClickListener;
import com.huidr.component.swipeRecyclerview.SwipeMenu;
import com.huidr.component.swipeRecyclerview.SwipeMenuCreator;
import com.huidr.component.swipeRecyclerview.SwipeMenuItem;
import com.huidr.component.swipeRecyclerview.SwipeMenuRecyclerView;
import com.huidr.lib.commom.util.ScreenUtils;
import com.huidr.lib.commom.util.StringUtil;
import com.huidr.lib.commom.view.HuiDialog;
import com.huidr.lib.commom.view.MultiPageLayout;
import com.huidr.lib.commom.view.RecycleViewDivider;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;


/**
 * 快速回复
 * Created by Laiyimin on 2016/10/20.
 */
public class FastReplyActivity extends BaseMultiPageActivity implements View.OnClickListener, FastReplyContract.View {

    private FastReplyContract.Presenter mPresenter;
    private EditText et_content;
    private FastReplyAdapter mAdapter;
    private SwipeMenuRecyclerView replyList;
    private LinkedList<ReplyModel> mData;
    private boolean mAdjustSequence; //是否排序过
    private ItemTouchHelper mItemTouchHelper;
    private ItemDragAndSwipeCallback mItemDragAndSwipeCallback;

    @Override
    protected void initData() {
        setSwipeBackEnable(false);//
        mPresenter = new FastReplyPresenter(this);
        mData = new LinkedList<>();
        mAdapter = new FastReplyAdapter(mData);
    }

    @Override
    protected void initView(Bundle bundle) {
        super.initView(bundle);
        setMainContentView(R.layout.activity_fast_reply);
        setActivityTitle(R.string.me_my_fast_callback);
        setTitleRight(R.drawable.img_activity_hint).setOnClickListener(this);
        setTitleLeft(R.drawable.back).setOnClickListener(this);
        //addBackButton().setOnClickListener(this);
        findViewById(R.id.iv_enter).setOnClickListener(this);
        et_content = (EditText) findViewById(R.id.et_content);
        //禁止换行
        et_content.setOnEditorActionListener(new TextView.OnEditorActionListener() {
            @Override
            public boolean onEditorAction(TextView v, int actionId, KeyEvent event) {
                return (event.getKeyCode() == KeyEvent.KEYCODE_ENTER);
            }
        });


        replyList = (SwipeMenuRecyclerView) findViewById(R.id.replyList);
        replyList.setLayoutManager(new LinearLayoutManager(mContext));
        replyList.addOnItemTouchListener(clickListener);
        replyList.setHasFixedSize(true);// 如果Item够简单，高度是确定的，打开FixSize将提高性能。

        OnItemDragListener listener = new OnItemDragListener() {
            private int startPosition;

            @Override
            public void onItemDragStart(RecyclerView.ViewHolder viewHolder, int pos) {
                LogUtil.d(TAG, "drag start");
                this.startPosition = pos;
            }

            @Override
            public void onItemDragMoving(RecyclerView.ViewHolder source, int from, RecyclerView.ViewHolder target, int to) {
                LogUtil.d(TAG, "move from: " + source.getAdapterPosition() + " to: " + target.getAdapterPosition());
            }

            @Override
            public void onItemDragEnd(RecyclerView.ViewHolder viewHolder, int endPos) {
                LogUtil.d(TAG, "drag end");
                if (startPosition != endPos) mAdjustSequence = true;
            }
        };

        mItemDragAndSwipeCallback = new ItemDragAndSwipeCallback(mAdapter);
        mItemTouchHelper = new ItemTouchHelper(mItemDragAndSwipeCallback);
        mItemTouchHelper.attachToRecyclerView(replyList);

        replyList.addItemDecoration(new RecycleViewDivider(mContext, LinearLayoutManager.HORIZONTAL, 2, getResources().getColor(R.color.gray_line)));
        replyList.addOnScrollListener(new RecyclerView.OnScrollListener() {
            @Override
            public void onScrollStateChanged(RecyclerView recyclerView, int newState) {
                //ScreenUtils.hideKeyBoard(mContext, et_content);
            }
        });

        mAdapter.enableDragItem(mItemTouchHelper);
        mAdapter.setOnItemDragListener(listener);
        mAdapter.setSwipeMenuCreator(swipeMenuCreator);
        mAdapter.setSwipeMenuItemClickListener(swipeMenuItemClickListener);
        replyList.setAdapter(mAdapter);
    }

    @Override
    protected void setupRequest() {
        mPresenter.getList();
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.img_activity_left:
                onBackPressed();
                break;
            case R.id.img_activity_right:
                String content = "添加快捷回复，节省重复回答问题的时间；且长按内容条可调整内容排列顺序；向左滑动内容条可删除、编辑内容。";
                HuiDialog dialog = new HuiDialog(mContext);
                dialog.setTitleOneButton("说明", content).show();
                break;
            case R.id.iv_enter:
                content = et_content.getText().toString().trim();
                if (StringUtil.isEmpty(content)) {
                    toast("请输入内容", Toast.LENGTH_SHORT);
                    et_content.requestFocus();
                    return;
                }
                mPresenter.addItem(content);
                break;
        }
    }

    List<ReplyModel> originData = new ArrayList<>();

    @Override
    public void showList(List<ReplyModel> list) {
        mData.clear();
        originData.addAll(list);
        mData.addAll(list);
        mAdapter.notifyDataSetChanged();
        mMultiLayout.setStatus(MultiPageLayout.STATE_SUCCESS);
    }

    @Override
    public void addSuccess(ReplyModel model) {
        et_content.setText(null);
        mData.addFirst(model);
        mAdapter.notifyItemInserted(0);
        replyList.scrollToPosition(0);

    }

    @Override
    public void updateSuccess(int position) {
        ReplyModel model = mAdapter.getItem(position);
        BaseViewHolder holder = (BaseViewHolder) replyList.findViewHolderForAdapterPosition(position);
        holder.setVisible(R.id.iv_edit, false);
        holder.setVisible(R.id.img_edit_pen, true);
        EditText et_content = holder.getView(R.id.et_content);
        et_content.setEnabled(false);
        et_content.setClickable(false);
        model.setEdit(false);
    }

    @Override
    public void deleteSuccess(int position) {
        mAdapter.remove(position);
        replyList.smoothCloseMenu();
    }

    @Override
    public void showErrorPage() {
        mMultiLayout.setStatus(MultiPageLayout.STATE_ERROR);
    }

    @Override
    public void showNetworkPage() {
        mMultiLayout.setStatus(MultiPageLayout.STATE_NO_NETWORK);
    }


    @Override
    public void onBackPressed() {

        //判断是否保存顺序
        if (mData.size() > 0/* && mAdjustSequence*/) {

            ReplyModel.deleteAll();
            ActiveAndroid.beginTransaction();
            try {
                for (ReplyModel replyModel : mData) {
                    ReplyModel replyModel1 = new ReplyModel();
                    replyModel1.setContent(replyModel.getContent());
                    replyModel1.save();
                }

                ActiveAndroid.setTransactionSuccessful();
            } finally {
                ActiveAndroid.endTransaction();
            }
        }
        if (existEditedItem || et_content.getText().toString().length() > 0) {
            final HuiDialog dialog = new HuiDialog(mContext);
            dialog.setTitleText(R.string.prompt)
                    .setContent(R.string.back_out_comfirm_item_edit)
                    .setNegativeButton(R.string.cancel, null)
                    .setNegativeGrayColor()
                    .setPositiveButton(R.string.confirm, new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            finish();
                        }
                    }).show();

        } else {
            super.onBackPressed();
        }

    }


    boolean existEditedItem;
    private OnItemChildClickListener clickListener = new OnItemChildClickListener() {
        @Override
        public void onSimpleItemChildClick(BaseQuickAdapter baseQuickAdapter, View view, int position) {
            ReplyModel model = mAdapter.getItem(position);
            BaseViewHolder holder = (BaseViewHolder) replyList.findViewHolderForAdapterPosition(position);

            switch (view.getId()) {
                case R.id.iv_edit:
                    if (model.isEdit()) {
                        //保存

                        EditText et_content = holder.getView(R.id.et_content);
                        et_content.setClickable(true);
                        String content = et_content.getText().toString().trim();
                        if (StringUtil.isEmpty(content)) {
                            toast("请输入内容", Toast.LENGTH_SHORT);
                            et_content.requestFocus();
                            return;
                        }
                        existEditedItem = false;
                        model.setContent(content);
                        mPresenter.updateItem(model, position);
                    }
                    break;
                case R.id.img_edit_pen:
                    if (!existEditedItem) {
                        holder = (BaseViewHolder) replyList.findViewHolderForAdapterPosition(position);
                        model = mAdapter.getItem(position);
                        //置为可编辑
                        holder.setVisible(R.id.iv_edit, true);
                        holder.setVisible(R.id.img_edit_pen, false);
                        EditText et_content = holder.getView(R.id.et_content);
                        et_content.setEnabled(true);
                        et_content.setClickable(true);
                        et_content.requestFocus();
                        et_content.setSelection(et_content.length());
                        ScreenUtils.showKeyBoard(mContext, et_content);
                        model.setEdit(true);
                        existEditedItem = true;
                    }
                    break;
            }
        }

    };

    /**
     * 菜单创建器。在Item要创建菜单的时候调用。
     */
    private SwipeMenuCreator swipeMenuCreator = new SwipeMenuCreator() {
        @Override
        public void onCreateMenu(SwipeMenu swipeLeftMenu, SwipeMenu swipeRightMenu, int viewType) {
            int width = getResources().getDimensionPixelSize(R.dimen.list_menu_height);

            // MATCH_PARENT 自适应高度，保持和内容一样高；也可以指定菜单具体高度，也可以用WRAP_CONTENT。
            int height = ViewGroup.LayoutParams.MATCH_PARENT;
            SwipeMenuItem deleteItem = new SwipeMenuItem(mContext)
                    .setBackgroundDrawable(R.color.menu_del)
//                        .setImage(R.mipmap.ic_action_delete)
                    .setText("删除") // 文字，还可以设置文字颜色，大小等。。
                    .setTextColor(Color.WHITE)
                    .setWidth(width)
                    .setHeight(height);

            SwipeMenuItem editItem = new SwipeMenuItem(mContext)
                    .setBackgroundDrawable(R.color.main_blue)
//                        .setImage(R.mipmap.ic_action_delete)
                    .setText("编辑") // 文字，还可以设置文字颜色，大小等。。
                    .setTextColor(Color.WHITE)
                    .setWidth(width)
                    .setHeight(height);

            swipeRightMenu.addMenuItem(deleteItem);// 添加一个按钮到右侧侧菜单。
            // swipeRightMenu.addMenuItem(editItem);
        }
    };

    /**
     * 侧滑菜单监听
     */
    private OnSwipeMenuItemClickListener swipeMenuItemClickListener = new OnSwipeMenuItemClickListener() {

        @Override
        public void onItemClick(Closeable closeable, final int adapterPosition, int menuPosition, int direction) {
            if (menuPosition == 0) {
                //删除
                final ReplyModel model = mAdapter.getItem(adapterPosition);
                HuiDialog dialog = new HuiDialog(mContext);
                dialog.setTitleText(R.string.prompt)
                        .setContent(R.string.confirm_delete_fast_reply)
                        .setNegativeButton(R.string.cancel, new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {
                                replyList.smoothCloseMenu();
                            }
                        })
                        .setNegativeGrayColor()
                        .setPositiveButton(R.string.confirm, new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {
                                mPresenter.delItem(model.getId(), adapterPosition);
                            }
                        }).show();

            } else if (menuPosition == 1) {
                //编辑
                BaseViewHolder holder = (BaseViewHolder) replyList.findViewHolderForAdapterPosition(adapterPosition);
                ReplyModel model = mAdapter.getItem(adapterPosition);
                //置为可编辑
                holder.setVisible(R.id.iv_edit, true);
                holder.setVisible(R.id.img_edit_pen, false);
                EditText et_content = holder.getView(R.id.et_content);
                et_content.setEnabled(true);
                et_content.setClickable(true);
                et_content.requestFocus();
                et_content.setSelection(et_content.length());
                ScreenUtils.showKeyBoard(mContext, et_content);
                model.setEdit(true);
                closeable.smoothCloseRightMenu();
            }

        }
    };

    @Override
    protected void onDestroy() {
        super.onDestroy();

    }


}
