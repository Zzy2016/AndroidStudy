package com.huidr.HuiDrDoctor.module.home;

/**
 * @author: Administrator
 * @date: 2020-04-15
 */
public class QuestionDetailModel {


    /**
     * status : 0
     * retValue : {"id":3340,"chaseId":0,"problemContent":"体重魔攻魔龙龙JJ明末红","answerType":1,"userName":"周玉梅","userHospitalName":"复旦大学附属中山医院","userDepartmentName":"肝肿瘤外科","userWardName":"原肝外科十七病区","userAdmitNo":"890313","summitTime":"2019-10-11 12:40:49","isAllowAnswerOperation":false,"notAllowAnswerOperationDes":"其他医生正在回答，看一看其他问题吧~"}
     */

    private int status;
    private RetValueBean retValue;

    public int getStatus() {
        return status;
    }

    public void setStatus(int status) {
        this.status = status;
    }

    public RetValueBean getRetValue() {
        return retValue;
    }

    public void setRetValue(RetValueBean retValue) {
        this.retValue = retValue;
    }

    public static class RetValueBean {
        /**
         * id : 3340
         * chaseId : 0
         * problemContent : 体重魔攻魔龙龙JJ明末红
         * answerType : 1
         * userName : 周玉梅
         * userHospitalName : 复旦大学附属中山医院
         * userDepartmentName : 肝肿瘤外科
         * userWardName : 原肝外科十七病区
         * userAdmitNo : 890313
         * summitTime : 2019-10-11 12:40:49
         * isAllowAnswerOperation : false
         * notAllowAnswerOperationDes : 其他医生正在回答，看一看其他问题吧~
         */

        private int id;
        private int chaseId;
        private String problemContent;
        private int answerType;
        private String userName;
        private String userHospitalName;
        private String userDepartmentName;
        private String userWardName;
        private String userAdmitNo;
        private String summitTime;
        private boolean isAllowAnswerOperation;
        private String notAllowAnswerOperationDes;
        private int userSex;
        private int userAge;
        private String speechDuration;
        private String patientId;
        private String doctorId;

        public String getDoctorId() {
            return doctorId;
        }

        public void setDoctorId(String doctorId) {
            this.doctorId = doctorId;
        }

        public String getPatientId() {
            return patientId;
        }

        public void setPatientId(String patientId) {
            this.patientId = patientId;
        }

        public String getSpeechDuration() {
            return speechDuration;
        }

        public void setSpeechDuration(String speechDuration) {
            this.speechDuration = speechDuration;
        }

        public String getAnswer() {
            return answer;
        }

        public void setAnswer(String answer) {
            this.answer = answer;
        }

        private String answer;

        public int getUserSex() {
            return userSex;
        }

        public void setUserSex(int userSex) {
            this.userSex = userSex;
        }

        public int getUserAge() {
            return userAge;
        }

        public void setUserAge(int userAge) {
            this.userAge = userAge;
        }

        public boolean isAllowAnswerOperation() {
            return isAllowAnswerOperation;
        }

        public void setAllowAnswerOperation(boolean allowAnswerOperation) {
            isAllowAnswerOperation = allowAnswerOperation;
        }

        public String getDiseasePicturePaths() {
            return diseasePicturePaths;
        }

        public void setDiseasePicturePaths(String diseasePicturePaths) {
            this.diseasePicturePaths = diseasePicturePaths;
        }

        private String diseasePicturePaths;

        public int getId() {
            return id;
        }

        public void setId(int id) {
            this.id = id;
        }

        public int getChaseId() {
            return chaseId;
        }

        public void setChaseId(int chaseId) {
            this.chaseId = chaseId;
        }

        public String getProblemContent() {
            return problemContent;
        }

        public void setProblemContent(String problemContent) {
            this.problemContent = problemContent;
        }

        public int getAnswerType() {
            return answerType;
        }

        public void setAnswerType(int answerType) {
            this.answerType = answerType;
        }

        public String getUserName() {
            return userName;
        }

        public void setUserName(String userName) {
            this.userName = userName;
        }

        public String getUserHospitalName() {
            return userHospitalName;
        }

        public void setUserHospitalName(String userHospitalName) {
            this.userHospitalName = userHospitalName;
        }

        public String getUserDepartmentName() {
            return userDepartmentName;
        }

        public void setUserDepartmentName(String userDepartmentName) {
            this.userDepartmentName = userDepartmentName;
        }

        public String getUserWardName() {
            return userWardName;
        }

        public void setUserWardName(String userWardName) {
            this.userWardName = userWardName;
        }

        public String getUserAdmitNo() {
            return userAdmitNo;
        }

        public void setUserAdmitNo(String userAdmitNo) {
            this.userAdmitNo = userAdmitNo;
        }

        public String getSummitTime() {
            return summitTime;
        }

        public void setSummitTime(String summitTime) {
            this.summitTime = summitTime;
        }

        public boolean isIsAllowAnswerOperation() {
            return isAllowAnswerOperation;
        }

        public void setIsAllowAnswerOperation(boolean isAllowAnswerOperation) {
            this.isAllowAnswerOperation = isAllowAnswerOperation;
        }

        public String getNotAllowAnswerOperationDes() {
            return notAllowAnswerOperationDes;
        }

        public void setNotAllowAnswerOperationDes(String notAllowAnswerOperationDes) {
            this.notAllowAnswerOperationDes = notAllowAnswerOperationDes;
        }
    }
}
