package com.huidr.HuiDrDoctor.activity.fastReply;

import com.huidr.lib.commom.base.BasePresenter;
import com.huidr.lib.commom.base.BaseView;

import java.util.LinkedList;
import java.util.List;

/**
 * Created by Administrator on 2016/7/13.
 */
public interface FastReplyContract {

    interface View extends BaseView<Presenter> {

        /**
         * 显示List
         * @param list
         */
        void showList(List<ReplyModel> list);

        /**
         * 添加成功
         * @param replyModel
         */
        void addSuccess(ReplyModel replyModel);

        /**
         * 更新成功
         * @param position
         */
        void updateSuccess(int position);

        /**
         * 删除成功
         * @param position
         */
        void deleteSuccess(int position);

        void showErrorPage();

        void showNetworkPage();
    }


    interface Presenter extends BasePresenter {


        /**
         * 获取列表
         */
        void getList();

        /**
         * 新增
         * @param content
         */
        void addItem(String content);

        /**
         * 更新
         * @param model
         * @param position
         */
        void updateItem(ReplyModel model, int position);

        /**
         * 排序
         * @param mData
         */
        void adjustIndex(LinkedList<ReplyModel> mData);

        /**
         * 删除
         * @param id
         * @param position
         */
        void delItem(Long id, int position);
    }
}
