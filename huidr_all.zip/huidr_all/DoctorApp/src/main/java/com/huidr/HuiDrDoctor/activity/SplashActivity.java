package com.huidr.HuiDrDoctor.activity;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import androidx.annotation.NonNull;
import android.view.WindowManager;

import com.huidr.HuiDrDoctor.debug.BuildConfig;
import com.huidr.HuiDrDoctor.services.NewUpdateService;
import com.huidr.lib.commom.base.HuidrActivityManager;
import com.huidr.lib.commom.util.HbuildUtil;
import com.huidr.lib.commom.util.PermissionUtil;
import com.taobao.sophix.SophixManager;

public class SplashActivity extends Activity {
    final int REQUEST_CODE_PERMISSIONS = 1;
    final String[] PERMISSIONS = new String[]{Manifest.permission.READ_CONTACTS, Manifest.permission.GET_ACCOUNTS, Manifest.permission.RECORD_AUDIO, Manifest.permission.MODIFY_AUDIO_SETTINGS, Manifest.permission.ACCESS_COARSE_LOCATION, Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.WRITE_EXTERNAL_STORAGE,
            // Manifest.permission.MOUNT_UNMOUNT_FILESYSTEMS,
            Manifest.permission.RECORD_AUDIO, Manifest.permission.CAMERA};

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
            getWindow().addFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN);//去掉信息栏  实现全屏显示
            getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);//屏幕高亮
        }
        HuidrActivityManager.getInstance().setSplashActivity(this);
        initView();


    }

    @Override
    protected void onDestroy() {
        HuidrActivityManager.getInstance().setSplashActivity(null);
        super.onDestroy();
    }

    protected void initView() {
        PermissionUtil.checkMorePermissions(this, PERMISSIONS, new PermissionUtil.PermissionCheckCallBack() {
            @Override
            public void onHasPermission() {
                run();
            }

            @Override
            public void onUserHasAlreadyTurnedDown(String... permission) {
                showExplainDialog(permission, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        PermissionUtil.requestMorePermissions(SplashActivity.this, PERMISSIONS, REQUEST_CODE_PERMISSIONS);
                    }
                });
            }

            @Override
            public void onUserHasAlreadyTurnedDownAndDontAsk(String... permission) {
                PermissionUtil.requestMorePermissions(SplashActivity.this, PERMISSIONS, REQUEST_CODE_PERMISSIONS);
            }
        });
    }

    private void run() {
        //检查更新
        SophixManager.getInstance().queryAndLoadNewPatch();
        //复制文件
        HbuildUtil.copyApps(getApplicationContext(), BuildConfig.Version);
        //更新
//        Intent intent = new Intent(this, UpdateActivity.class);
//        Bundle bundle = new Bundle();
//        bundle.putString("updateUrl", BuildConfig.UpdateUrl);
//        bundle.putString("mainActivity", MainActivity.class.getName());
//        intent.putExtras(bundle);
//        startActivity(intent);

        //        打开检查更新服务
        Intent intent1Update = new Intent(SplashActivity.this, NewUpdateService.class);
        startService(intent1Update);

        Intent intent = new Intent(SplashActivity.this, MainActivity.class);
        startActivity(intent);
    }

    /**
     * 解释权限的dialog
     */
    private void showExplainDialog(String[] permission, DialogInterface.OnClickListener onClickListener) {
        new AlertDialog.Builder(this).setTitle("申请权限").setMessage("接下来我们需要您允许一些权限").setPositiveButton("确定", onClickListener).show();
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        switch (requestCode) {
            case REQUEST_CODE_PERMISSIONS:
                PermissionUtil.onRequestMorePermissionsResult(SplashActivity.this, PERMISSIONS, new PermissionUtil.PermissionCheckCallBack() {
                    @Override
                    public void onHasPermission() {
                        run();
                    }

                    @Override
                    public void onUserHasAlreadyTurnedDown(String... permission) {
                        run();
                    }

                    @Override
                    public void onUserHasAlreadyTurnedDownAndDontAsk(String... permission) {
                        showToAppSettingDialog();
                        run();
                    }
                });
        }
    }

    /**
     * 显示前往应用设置Dialog
     */
    private void showToAppSettingDialog() {
        new AlertDialog.Builder(SplashActivity.this).setTitle("需要权限").setMessage("我们需要相关权限，才能实现功能，点击前往，将转到应用的设置界面，请开启应用的相关权限。").setPositiveButton("前往", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                PermissionUtil.toAppSetting(SplashActivity.this);
            }
        }).setNegativeButton("取消", null).show();
    }
}

