package com.huidr.HuiDrDoctor.follow_fragment;

import android.app.Dialog;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import android.text.Html;
import android.util.Log;
import android.view.Display;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.ImageView;
import android.widget.TextView;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.chad.library.adapter.base.BaseQuickAdapter;
import com.chad.library.adapter.base.BaseViewHolder;
import com.google.gson.Gson;
import com.huidr.HuiDrDoctor.activity.WebActivity;
import com.huidr.HuiDrDoctor.activity.main.Consult.utils.PostAndGet;
import com.huidr.HuiDrDoctor.debug.BuildConfig;
import com.huidr.HuiDrDoctor.debug.R;
import com.huidr.HuiDrDoctor.module.home.AttenModel;
import com.huidr.HuiDrDoctor.util.LogUtil;
import com.huidr.HuiDrDoctor.util.ThreadPoolManager;
import com.huidr.lib.commom.base.BaseFragment;
import com.huidr.lib.commom.base.HuidrActivityManager;
import com.huidr.lib.commom.util.Toast;
import com.scwang.smartrefresh.layout.SmartRefreshLayout;
import com.scwang.smartrefresh.layout.api.RefreshLayout;
import com.scwang.smartrefresh.layout.listener.OnLoadMoreListener;
import com.scwang.smartrefresh.layout.listener.OnRefreshListener;
import com.zyao89.view.zloading.ZLoadingDialog;
import com.zyao89.view.zloading.Z_TYPE;

import java.util.ArrayList;
import java.util.List;

import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import jiguang.chat.utils.oss.SharedPreferenciesUtil;

/**
 * item
 * 头像，患者姓名，住院号，时间，状态，所匹配模板（默认显示18个端，第18个字段为省略号）
 * <p>
 * 列表显示：
 * 1.   关注患者是医生通过左划列表（任意患者列表），点击关注患者后添加到该列表
 * <p>
 * 2.   在关注了某个患者后可以通过左滑点击取消关注进行取消关注，取消后将不再该列表里显示
 * <p>
 * <p>
 * 点击查看患者信息
 * <p>
 * patient/doctorPatientMedical/getAttentionRelationshipPatients
 * <p>
 * pageIndex
 * pageSize 20
 */
public class AttentionFragment extends BaseFragment {

//    TabLayout tlTipAtten;
//    ImageView imageTip;
//    ScrollPageView vpAtten;
//
//    List<Fragment> listFragment;
//    String[] tips;
//    int[] tipTypes;
//    AttenAdapter attenAdapter;
//
//
//    @Override
//    protected View setContentView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
//        return inflater.inflate(R.layout.fragment_attention, container, false);
//    }
//
//    @Override
//    public void setUserVisibleHint(boolean isVisibleToUser) {
//        super.setUserVisibleHint(isVisibleToUser);
//
//
//        if (isVisibleToUser) {
//
//            tips = getArguments().getStringArray("tip");
//            tipTypes = getArguments().getIntArray("tipType");
//            Log.e("关注患者收到标签", tips.length + "   " + isVisibleToUser);
//            if (listFragment == null) {
//                listFragment = new ArrayList<>();
//            } else {
//                listFragment.clear();
//            }
//
//            for (int i = 0; i < tips.length; i++) {
//                GeneralAttenFragment generalAttenFragment = GeneralAttenFragment.newInstance_Fragment(tips[i],tipTypes[i]);
//                listFragment.add(generalAttenFragment);
//            }
//
//            Log.e("关注患者收到标签---》", listFragment.size() + " ");
//
//            attenAdapter.notifyDataSetChanged();
//        }
//    }
//
//    @Override
//    protected void findView(View parent) {
//        tlTipAtten = parent.findViewById(R.id.tl_tip_atten);
//        imageTip = parent.findViewById(R.id.img_tip);
//        vpAtten = parent.findViewById(R.id.vp_atten);
//
//        listFragment = new ArrayList<>();
//        attenAdapter = new AttenAdapter(getChildFragmentManager());
//        vpAtten.setAdapter(attenAdapter);
//        tlTipAtten.setupWithViewPager(vpAtten);
////        attenAdapter.notifyDataSetChanged();
//
//        imageTip.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                if (MulityClickUtils.isFastClick()) {
//                    Intent intent = new Intent(getActivity(), WebActivity.class);
//                    Bundle bundle = new Bundle();
//                    bundle.putString("url", "patientData_setTagsNew.html");
//                    intent.putExtras(bundle);
//                    startActivity(intent);
//                }
//            }
//        });
//
//        tlTipAtten.setOnTabSelectedListener(new TabLayout.OnTabSelectedListener() {
//            @Override
//            public void onTabSelected(TabLayout.Tab tab) {
//                int position = tab.getPosition();
//
//                tab.setText(tips[position]);
//            }
//
//            @Override
//            public void onTabUnselected(TabLayout.Tab tab) {
//                int position = tab.getPosition();
//                if (tips[position].length() <= 4) {
//                    tab.setText(tips[position]);
//                } else {
//                    String tip = tips[position];
//                    tip = tip.substring(0, 4);
//                    tip = tip.concat("...");
//                    tab.setText(tip);
//                }
//
//            }
//
//            @Override
//            public void onTabReselected(TabLayout.Tab tab) {
//
//            }
//        });
//
//    }
//
//    @Override
//    protected void initData() {
//
//    }
//
//    class AttenAdapter extends FragmentPagerAdapter {
//
//        public AttenAdapter(FragmentManager fm) {
//            super(fm);
//        }
//
//        @Override
//        public Fragment getItem(int i) {
//            return listFragment.get(i);
//        }
//
//        @Override
//        public int getCount() {
//            return listFragment.size();
//        }
//
//        @Nullable
//        @Override
//        public CharSequence getPageTitle(int position) {
//            if (tips[position].length() <= 4) {
//                return tips[position];
//            } else {
//                String tip = tips[position];
//                tip = tip.substring(0, 4);
//                tip = tip.concat("...");
//                return tip;
//            }
//        }
//    }


    private SmartRefreshLayout srlLayout;
    private RecyclerView rvListAtten;

    private ConstraintLayout clEmptyAtt;
    private TextView tvEmptyAtt1, tvEmptyAtt2;

    private List<AttenModel.RetValueBean> allAttent;//所有列表
    private AttenModel tempAttent;//缓存列表
    private Gson gson;
    private int currentPage = 1;
    private int totalPage = 1;
    long lastClick = 0;
    private ZLoadingDialog zLoadingDialog;

    @Override
    protected void initData() {


        Log.e("关注患者", "initData");

        gson = new Gson();
        allAttent = new ArrayList<>();
        tempAttent = new AttenModel();
        attenAdapter.setNewData(allAttent);


    }

    @Override
    public void onResume() {
        super.onResume();

    }

    @Override
    public void setUserVisibleHint(boolean isVisibleToUser) {
        super.setUserVisibleHint(isVisibleToUser);


        if (isVisibleToUser){
            zLoadingDialog = new ZLoadingDialog(HuidrActivityManager.getInstance().getCurrentActivity());
            zLoadingDialog.setLoadingBuilder(Z_TYPE.STAR_LOADING)//设置类型
                    .setLoadingColor(Color.BLUE)//颜色
                    .setHintText("正在加载,请稍候...").setHintTextSize(16) // 设置字体大小 dp
                    .setHintTextColor(Color.GRAY)  // 设置字体颜色
                    .setDurationTime(0.5) // 设置动画时间百分比 - 0.5倍
                    .setCanceledOnTouchOutside(false).setCancelable(false).show();
            Log.e("Dialog-AttentPatient","show");
            Log.e("加载数据", "关注加载数据"+isVisibleToUser);
            getDataByPage();
        }else{
            if(zLoadingDialog!=null){
                zLoadingDialog.dismiss();
            }
            attenAdapter.notifyDataSetChanged();
        }
    }

    public void getDataByPage() {
        Log.e("关注患者", "getDataByPage");
        ThreadPoolManager.getInstance().execute(new Runnable() {
            @Override
            public void run() {
                LogUtil.e("分页数据", currentPage + " ");
//                String path = BuildConfig.baseUrl + "patient/doctorPatientMedical/getAttentionRelationshipPatients?pageIndex=" + currentPage + "&pageSize=20";
                String path = BuildConfig.baseUrl + "patient/doctorPatientMedical/getAttentionRelationshipPatients?pageIndex=" + currentPage + "&pageSize=20";
                String result = PostAndGet.doGetHttp(path);
                tempAttent = new AttenModel();
//                Log.e("患者池 关注患者--->", result);
                if (result == null || result.equals("") || result.equals("网络异常")) {
                    handler.sendEmptyMessage(3);
                } else {
                    gson = new Gson();
                    tempAttent = gson.fromJson(result, AttenModel.class);
                    if (tempAttent.getStatus() == 0) {
                        totalPage = tempAttent.getTotalPage();
                        if (currentPage == 1) {
                            handler.sendEmptyMessage(1);
                        } else {
                            handler.sendEmptyMessage(2);
                        }
                    } else {
                        handler.sendEmptyMessage(3);
                    }
                }
            }
        });
    }

    @Override
    protected View setContentView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_attention, container, false);
    }

    @Override
    protected void findView(View parent) {
        Log.e("关注患者", "findView");


        srlLayout = parent.findViewById(R.id.srl_layout);

//        加载更多
        srlLayout.setOnLoadMoreListener(new OnLoadMoreListener() {
            @Override
            public void onLoadMore(@NonNull RefreshLayout refreshLayout) {
//                if (tempAttent.getRetValue().size() < 20) {
//                    srlLayout.finishLoadMore();
//                    Toast.getInstance(getContext()).show("数据加载全部", 500);
//                } else {
//                    currentPage += 1;
//                    getDataByPage();
//                }

                if (tempAttent.getRetValue().size() == 20 && currentPage < totalPage) {
                    currentPage += 1;
                    getDataByPage();
                } else {
                    srlLayout.finishLoadMore();
                    Toast.getInstance(getContext()).show("数据加载全部", 500);
                }

            }
        });
//刷新
        srlLayout.setOnRefreshListener(new OnRefreshListener() {
            @Override
            public void onRefresh(@NonNull RefreshLayout refreshLayout) {
                currentPage = 1;
                getDataByPage();
            }
        });

        srlLayout.setEnableLoadMore(true);
        srlLayout.setEnableRefresh(true);

        rvListAtten = parent.findViewById(R.id.rv_list_atten);
        rvListAtten.setAdapter(attenAdapter);
        rvListAtten.setLayoutManager(new LinearLayoutManager(getActivity()));

        clEmptyAtt = parent.findViewById(R.id.cl_empty_att);
        tvEmptyAtt1 = parent.findViewById(R.id.tv_empty_att1);
        tvEmptyAtt2 = parent.findViewById(R.id.tv_empty_att2);

//        空态页点击事件
        tvEmptyAtt2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                currentPage = 1;
                getDataByPage();
            }
        });
    }


    //    加载数据 刷新页面
    private Handler handler = new Handler() {
        @Override
        public void handleMessage(Message msg) {
            super.handleMessage(msg);

            switch (msg.what) {
                case 1:
                    if (zLoadingDialog != null) {
                        new Handler().postDelayed(new Runnable() {
                            @Override
                            public void run() {
                                zLoadingDialog.dismiss();
                                zLoadingDialog = null;
                            }
                        }, 500);
                    }
                    attenAdapter.getData().clear();
                    if (tempAttent == null || tempAttent.getRetValue() == null || tempAttent.getRetValue().size() == 0) {
                        clEmptyAtt.setVisibility(View.VISIBLE);
                        srlLayout.setVisibility(View.GONE);

                        String tip1 = "您还暂未关注患者";
                        String tip2 = "左滑患者列表即可关注";
                        tvEmptyAtt1.setText(tip1);
                        tvEmptyAtt2.setText(tip2);
                    } else {
                        clEmptyAtt.setVisibility(View.GONE);
                        srlLayout.setVisibility(View.VISIBLE);
                        attenAdapter.getData().addAll(tempAttent.getRetValue());
                        attenAdapter.notifyDataSetChanged();
                    }
                    srlLayout.finishRefresh();
                    break;
                case 2:
                    attenAdapter.getData().addAll(tempAttent.getRetValue());
                    attenAdapter.notifyDataSetChanged();
                    srlLayout.finishLoadMore();
                    break;
                case 3:

                    if(zLoadingDialog!=null){
                        zLoadingDialog.dismiss();
                    }
                    srlLayout.finishRefresh();
                    srlLayout.finishLoadMore();

                    clEmptyAtt.setVisibility(View.VISIBLE);
                    srlLayout.setVisibility(View.GONE);

                    String tip1 = "网络错误~";
                    String tip2 = "<font color='#248cfa'><u>立即刷新<u></font>";
                    tvEmptyAtt1.setText(tip1);
                    tvEmptyAtt2.setText(Html.fromHtml(tip2));

                    break;
                case 4:
//                    取消成功
                    Toast.getInstance(getContext()).show("取消成功", 500);
//                    attenAdapter.getData().remove(msg.arg1);
                    attenAdapter.remove(msg.arg1);
                    Log.e("关注患者数量", attenAdapter.getData().size() + "");
                    if (attenAdapter.getData().size() == 0) {
                        clEmptyAtt.setVisibility(View.VISIBLE);
                        srlLayout.setVisibility(View.GONE);

                        String tip3 = "您还暂未关注患者";
                        String tip4 = "左滑患者列表即可关注";
                        tvEmptyAtt1.setText(tip3);
                        tvEmptyAtt2.setText(tip4);
                    }
                    break;
                case 5:
//取消失败
                    Toast.getInstance(getContext()).show("取消失败", 500);
                    attenAdapter.notifyDataSetChanged();
                    break;
            }
        }
    };

    /*
     * 关注患者适配
     * */
    private BaseQuickAdapter<AttenModel.RetValueBean, BaseViewHolder> attenAdapter = new BaseQuickAdapter<AttenModel.RetValueBean, BaseViewHolder>(R.layout.item_patient_scroll_layout) {
        @Override
        protected void convert(final BaseViewHolder helper, final AttenModel.RetValueBean item) {


            //            头像
            ImageView imgItemHead = helper.getView(R.id.img_item_head);
            imgItemHead.setBackgroundResource(R.drawable.head_patient);
//            提醒
            ImageView imgNotice = helper.getView(R.id.img_notice);
            imgNotice.setVisibility(View.GONE);
//            姓名
            TextView tvItemName = helper.getView(R.id.tv_item_name);
            tvItemName.setText(item.getUserName());
//            住院号
            TextView tvPatientNum = helper.getView(R.id.tv_patient_num);
            tvPatientNum.setText(item.getLatelyAdmitNo());
//            日期
            TextView tvItemDate = helper.getView(R.id.tv_item_date);
            tvItemDate.setText(item.getLatelyVisitingDate());
//            状态
            TextView tvItemMsg = helper.getView(R.id.tv_item_msg);
            tvItemMsg.setText(item.getLatelyAdmissionDiagnosis());
//            模板
            TextView tvModel = helper.getView(R.id.tv_model);
            tvModel.setText(item.getFollowupName());

            TextView tvRight = helper.getView(R.id.tv_scroll_right);
            String str = "<font>取消<br>关注</font>";
            tvRight.setText(Html.fromHtml(str));
            tvRight.setBackgroundResource(R.drawable.shape_atten_gray);

            tvRight.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
//                    cancelAttent(helper.getAdapterPosition(), item.getId());
                    showCoopDialog(helper.getAdapterPosition(), item.getId());
                }
            });


            ConstraintLayout clItem = helper.getView(R.id.cl_item);
//            患者信息

            clItem.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (System.currentTimeMillis() - lastClick > 1000) {
                        JSONObject jsonObject = new JSONObject();
                        jsonObject.put("id", item.getId());
                        SharedPreferenciesUtil.putData("psearchID", jsonObject.toJSONString());
                        SharedPreferenciesUtil.putData("followDoctorId", item.getDoctorId());

                        Intent intent1 = new Intent(getActivity(), WebActivity.class);
                        Bundle bundle = new Bundle();
                        bundle.putString("url", "patientData.html");
                        intent1.putExtras(bundle);
                        startActivity(intent1);
                        lastClick = System.currentTimeMillis();
                    }
                }
            });

        }
    };

    //    取消添加协同对话框
    public void showCoopDialog(final int position, final int patientId) {

        final Dialog builder = new Dialog(getContext(), R.style.jmui_default_dialog_style);
        //final Dialog builder = new Dialog(this, R.style.jmui_default_dialog_style);
        View view = LayoutInflater.from(getContext()).inflate(R.layout.dialog_content, null);

        TextView tvTitle = view.findViewById(R.id.tv_title);
        TextView tvFooter1 = view.findViewById(R.id.tv_footer1);
        TextView tvFooter2 = view.findViewById(R.id.tv_footer2);

        tvTitle.setText("是否取消关注该患者！");


//        取消
        tvFooter1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                builder.cancel();
                attenAdapter.notifyItemChanged(position);

            }
        });
//确定
        tvFooter2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                builder.cancel();
//                modifyAttent(atten, position, patientId);
                cancelAttent(position, patientId);
//                attenAdapter.notifyDataSetChanged();
            }
        });

        builder.setContentView(view);
        //builder.setCanceledOnTouchOutside(true);
        builder.show();
        Window window = builder.getWindow();
        WindowManager.LayoutParams lp = window.getAttributes();
        WindowManager windowManager = getActivity().getWindowManager();
        Display display = windowManager.getDefaultDisplay();
        lp.width = (int) (display.getWidth() * 0.7);
//        lp.height = (int) (display.getHeight() * 0.1);
        window.setAttributes(lp);
    }

    //  根据关系类型  设置默认图片
    public void setPatientImage(ImageView image, String ship, int sex) {
        if (ship == null) {
            image.setBackgroundResource(R.drawable.head_patient);
            return;
        }
        switch (ship) {
            case "本人":
                if (sex == 1) {
                    image.setBackgroundResource(R.drawable.my_him);
                } else {
                    image.setBackgroundResource(R.drawable.my_her);
                }
                break;
            case "丈夫":
                image.setBackgroundResource(R.drawable.husband);
                break;
            case "妻子":
                image.setBackgroundResource(R.drawable.wife);
                break;
            case "爸爸":
                image.setBackgroundResource(R.drawable.papa);
                break;
            case "妈妈":
                image.setBackgroundResource(R.drawable.mama);
                break;
            case "儿子":
                image.setBackgroundResource(R.drawable.son);
                break;
            case "女儿":
                image.setBackgroundResource(R.drawable.daughter);
                break;
            case "其他":
                image.setBackgroundResource(R.drawable.head_patient);
                break;
            default:
                image.setBackgroundResource(R.drawable.head_patient);
                break;
        }
    }

    //    取消关注 从页面消失
    public void cancelAttent(final int position, final int patientId) {
        ThreadPoolManager.getInstance().execute(new Runnable() {
            @Override
            public void run() {
                String id = (String) SharedPreferenciesUtil.getData("id", "0");
                String path = BuildConfig.baseUrl + "patient/doctorPatientMedical/addRemarksAndFollow?doctorId=" + id + "&patientId=" + patientId + "&isFollow=" + false;
                String result = PostAndGet.doGetHttp(path);
                Log.e("取消关注", result);
                try {
                    JSONObject jsonObject = JSON.parseObject(result);
                    if (jsonObject.getInteger("status") != null && jsonObject.getInteger("status") == 0) {
                        Message message = new Message();
                        message.what = 4;
                        message.arg1 = position;
                        handler.sendMessage(message);
                    } else {
                        handler.sendEmptyMessage(5);
                    }
                } catch (Exception e) {
                    handler.sendEmptyMessage(5);
                }
            }
        });
    }

}
