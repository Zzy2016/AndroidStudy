package com.huidr.HuiDrDoctor.module.base;

import android.os.Bundle;

import com.huidr.HuiDrDoctor.debug.R;
import com.huidr.lib.commom.view.MultiPageLayout;


/**
 * Created by Laiyimin on 2017/2/17.
 */

public abstract class BaseMultiPageActivity extends BaseDrBackActivity {

    protected MultiPageLayout mMultiLayout;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setupRequest();
    }

    @Override
    protected void initView(Bundle bundle) {
        setContentView(R.layout.activity_multi_page);
        mMultiLayout = (MultiPageLayout) findViewById(R.id.layout_multi_page);
        mMultiLayout.setOnRetryListener(new MultiPageLayout.OnRetryListener() {
            @Override
            public void onRetry() {
                setupRequest();
            }
        });
    }


    protected void setMainContentView(int layoutRes) {
        mMultiLayout.setContentView(layoutRes);
    }


    protected abstract void setupRequest();
}
