package com.huidr.HuiDrDoctor.activity.main.Consult.utils;

import android.content.Context;
import android.content.SharedPreferences;
import android.util.Log;

import com.alibaba.fastjson.JSONObject;
import com.google.gson.Gson;
import com.huidr.HuiDrDoctor.debug.BuildConfig;
import com.huidr.HuiDrDoctor.module.consult.ConsultOrderList;
import com.huidr.HuiDrDoctor.module.consult.OrderDetail;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;

import cn.jpush.im.android.api.model.UserInfo;
import jiguang.chat.utils.oss.SharedPreferenciesUtil;

public class PostAndGet {
    public static String getTime(String sellerId, String buyerId) {
        String time = null;
        String result = null;
        StringBuffer buffer = new StringBuffer();
        String str = BuildConfig.baseUrl + "pay/orderSearch/searchOrder";
        HttpURLConnection connection = null;
        String jwt = (String) SharedPreferenciesUtil.getData("jwt", "");
        Log.e("jwt", jwt + "");
        try {
            JSONObject jsonObject = new JSONObject();
            jsonObject.put("orderStatus", 2);
            jsonObject.put("orderKind", 2);
            jsonObject.put("buyerId", buyerId);
            jsonObject.put("sellerId", sellerId);
            jsonObject.put("pageIndex", 1);
            URL url = new URL(str);
            connection = (HttpURLConnection) url.openConnection();
            connection.setRequestMethod("POST");
            connection.setRequestProperty("Charset", "UTF-8");
            connection.setRequestProperty("jwt", jwt);
            connection.setRequestProperty("accept", "application/json");
            connection.setRequestProperty("Connection", "Keep-Alive");
            connection.setRequestProperty("Content-Type", "application/json");
            connection.setDoOutput(true);
            connection.setDoInput(true);
            connection.connect();
            OutputStream outputStream = connection.getOutputStream();
            outputStream.write(jsonObject.toString().getBytes());
            outputStream.flush();
            outputStream.close();

            if (connection.getResponseCode() == 200) {
                BufferedReader reader = new BufferedReader(new InputStreamReader(connection.getInputStream()));
                String str1 = reader.readLine();

                if (str1 != null) {
                    buffer.append(str1);
                }
                result = buffer.toString();
                Log.e("订单1", buffer.toString());
                Gson gson = new Gson();
                ConsultOrderList list = gson.fromJson(result, ConsultOrderList.class);

                Log.e("需要帮之", list.getRetValue().get(0).getOrderDetails());
//            Log.e("需要帮之", list.getRetValue().getConsultOrderInfos().get(0).getOrderDetails().toString());
                OrderDetail orderDetail = gson.fromJson(list.getRetValue().get(0).getOrderDetails(), OrderDetail.class);
                Log.e("需要", orderDetail.getNeedHelp());
                time = list.getRetValue().get(0).getPayTime();
            }


        } catch (Exception e) {
            e.printStackTrace();
            result = e.toString();

        }


        return time;
    }

    /*
     * 根据地址 参数查询
     * */
    public static String doHttpPost(String path, JSONObject jsonObject) {
        String result = "";
//        String jwt="eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiIxMDAxMzciLCJleHAiOjE1ODUwMzk0NTMsImlhdCI6MTU4NDQzNDY1MywiQWNjb3VudEluZm8iOnsiaWQiOjEwMDEzNywibW9iaWxlIjoiMTM2MDAwMDAwMDMiLCJsb2dpbk5hbWUiOiI4MTc3XzEyMzEwIiwidXNlckljb24iOiIxMDAxMzcvZG9jdG9yLzE1Nzc3NzIwMjU4NTUucG5nIiwidXNlclNleCI6MSwidXNlclR5cGUiOjIsInVzZXJOYW1lIjoi5ZC05Lqm5YehIiwiaW1QYXNzd29yZCI6IjFQYzc4Mzk4MkoiLCJpc1NldExvZ2luUGFzc3dvcmQiOnRydWUsIm9zTmFtZSI6IkFuZHJvaWQiLCJsYXN0TG9naW5UaW1lIjoiMjAyMC0wMy0xNyAxNjo0NDoxMyIsInZlcnNpb24iOiIyLjAuMTUiLCJ1c2VyUm9sZSI6WyJST0xFX0RPQ1RPUiIsIlJPTEVfUEFUSUVOVCIsIlJPTEVfTUVOVEFMIl0sImlzRW5hYmxlIjpmYWxzZSwiYWRkVGltZSI6IjIwMTktMDgtMjkgMTE6MjY6NDkifX0.40zvKFVQNS5t2xdOuvQtBRHWh7bwg2m1zpMBTpSvddw";

        try {
            URL url = new URL(path);

            String jwt = (String) SharedPreferenciesUtil.getData("jwt", "");
            HttpURLConnection connection = (HttpURLConnection) url.openConnection();
            connection.setRequestMethod("POST");
            connection.setRequestProperty("Charset", "UTF-8");

            connection.setRequestProperty("jwt", jwt);
            connection.setRequestProperty("accept", "application/json");
            connection.setRequestProperty("Connection", "Keep-Alive");
            connection.setRequestProperty("Content-Type", "application/json");
            connection.setConnectTimeout(5000);
            connection.setDoOutput(true);
            connection.setDoInput(true);
            connection.connect();
            OutputStream outputStream = connection.getOutputStream();
            if (jsonObject != null) {
                outputStream.write(jsonObject.toString().getBytes());
                outputStream.flush();
            }

            outputStream.close();
            Log.e("code", connection.getResponseCode() + "  ");
            int code = connection.getResponseCode();

            if (connection.getResponseCode() == 200) {
                BufferedReader reader = new BufferedReader(new InputStreamReader(connection.getInputStream()));
                String str1;
                StringBuffer buffer = new StringBuffer();
                while ((str1 = reader.readLine()) != null) {
                    buffer.append(str1);
                }

                reader.close();
                connection.disconnect();
                result = buffer.toString();


            } else {
                result = "网络异常";

            }
        } catch (Exception e) {
//            Log.e("异常", e.toString());
            result = "网络异常";
            Log.e("异常POST", e.toString());
        }
        return result;
    }


    /*
     * 根据地址 参数查询
     * */
    public static String doGetHttp(String path) {
//        String jwt="eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiIxMDAxMzciLCJleHAiOjE1ODUwMzk0NTMsImlhdCI6MTU4NDQzNDY1MywiQWNjb3VudEluZm8iOnsiaWQiOjEwMDEzNywibW9iaWxlIjoiMTM2MDAwMDAwMDMiLCJsb2dpbk5hbWUiOiI4MTc3XzEyMzEwIiwidXNlckljb24iOiIxMDAxMzcvZG9jdG9yLzE1Nzc3NzIwMjU4NTUucG5nIiwidXNlclNleCI6MSwidXNlclR5cGUiOjIsInVzZXJOYW1lIjoi5ZC05Lqm5YehIiwiaW1QYXNzd29yZCI6IjFQYzc4Mzk4MkoiLCJpc1NldExvZ2luUGFzc3dvcmQiOnRydWUsIm9zTmFtZSI6IkFuZHJvaWQiLCJsYXN0TG9naW5UaW1lIjoiMjAyMC0wMy0xNyAxNjo0NDoxMyIsInZlcnNpb24iOiIyLjAuMTUiLCJ1c2VyUm9sZSI6WyJST0xFX0RPQ1RPUiIsIlJPTEVfUEFUSUVOVCIsIlJPTEVfTUVOVEFMIl0sImlzRW5hYmxlIjpmYWxzZSwiYWRkVGltZSI6IjIwMTktMDgtMjkgMTE6MjY6NDkifX0.40zvKFVQNS5t2xdOuvQtBRHWh7bwg2m1zpMBTpSvddw";
        String result = "";
        try {
            URL url = new URL(path);
            String jwt = (String) SharedPreferenciesUtil.getData("jwt", "");

            HttpURLConnection connection = (HttpURLConnection) url.openConnection();
            connection.setRequestProperty("jwt", jwt);
            connection.setRequestMethod("GET");
            connection.connect();

            StringBuffer buffer = new StringBuffer();
            int code = connection.getResponseCode();

            if (connection.getResponseCode() == 200) {
                BufferedReader reader = new BufferedReader(new InputStreamReader(connection.getInputStream()));
                String str1;
                while ((str1 = reader.readLine()) != null) {
                    buffer.append(str1);
                }
                result = buffer.toString();

            } else {
                result = "网络异常";
            }
        } catch (Exception e) {
            Log.e("异常", e.toString());
            result = "网络异常";
        }
        return result;
    }


    public static String getOrderID(JSONObject jsonObject) {
        String result = null;
        StringBuffer buffer = new StringBuffer();
        String str = BuildConfig.baseUrl + "pay/orderSearch/searchOrder";
        HttpURLConnection connection = null;
        String jwt = (String) SharedPreferenciesUtil.getData("jwt", "");
        int buyerId = Integer.valueOf(SharedPreferenciesUtil.getData("id", "") + "");
        try {
            URL url = new URL(str);
            connection = (HttpURLConnection) url.openConnection();
            connection.setRequestMethod("POST");
            connection.setRequestProperty("jwt", jwt);
            connection.setRequestProperty("accept", "application/json");
            connection.setRequestProperty("Connection", "Keep-Alive");
            connection.setRequestProperty("Content-Type", "application/json");
            connection.setRequestProperty("Charset", "UTF-8");
            connection.setDoOutput(true);
            connection.setDoInput(true);
            connection.connect();
            OutputStream outputStream = connection.getOutputStream();
            outputStream.write(jsonObject.toString().getBytes());
            outputStream.flush();
            outputStream.close();
            if (connection.getResponseCode() == 200) {
                BufferedReader reader = new BufferedReader(new InputStreamReader(connection.getInputStream()));
                String str1 = reader.readLine();
                while (str1 != null) {
                    buffer.append(str1);
                }
                result = buffer.toString();
                Gson gson = new Gson();
                ConsultOrderList list = gson.fromJson(result, ConsultOrderList.class);
                OrderDetail orderDetail = gson.fromJson(list.getRetValue().get(0).getOrderDetails(), OrderDetail.class);
                result = list.getRetValue().get(0).getOrderId();
            }

        } catch (Exception e) {
            e.printStackTrace();
            result = e.toString();
            Log.e("异常", e.toString());
        }
        return result;
    }


}
