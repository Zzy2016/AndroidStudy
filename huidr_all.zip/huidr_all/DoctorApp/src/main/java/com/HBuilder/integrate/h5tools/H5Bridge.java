package com.HBuilder.integrate.h5tools;


import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;

import com.activeandroid.query.Select;
import com.alibaba.fastjson.JSONObject;
import com.alibaba.sdk.android.feedback.impl.FeedbackAPI;
import com.google.gson.Gson;
import com.huidr.Feedback.HuiyiAssistantActivity;
import com.huidr.HuiDrDoctor.MainApplication;
import com.huidr.HuiDrDoctor.activity.ConsultRecordActivity;
import com.huidr.HuiDrDoctor.activity.DoctorUpdateActivity;
import com.huidr.HuiDrDoctor.activity.FastReplyActivity;
import com.huidr.HuiDrDoctor.activity.LoginActivity;
import com.huidr.HuiDrDoctor.activity.MainActivity;
import com.huidr.HuiDrDoctor.activity.MessageActivity;
import com.huidr.HuiDrDoctor.activity.WebActivity;
import com.huidr.HuiDrDoctor.activity.main.Consult.utils.PostAndGet;
import com.huidr.HuiDrDoctor.debug.BuildConfig;
import com.huidr.HuiDrDoctor.debug.R;
import com.huidr.HuiDrDoctor.module.SaveAndReadModel;
import com.huidr.HuiDrDoctor.module.home.FirstLoginModel;
import com.huidr.HuiDrDoctor.module.home.NewMessageModel;
import com.huidr.HuiDrDoctor.module.home.SimpleResultModel;
import com.huidr.HuiDrDoctor.module.model.SysMessage;
import com.huidr.HuiDrDoctor.services.UpdateService;
import com.huidr.HuiDrDoctor.util.LocalConstants;
import com.huidr.HuiDrDoctor.util.ThreadPoolManager;
import com.huidr.lib.commom.base.BaseWebActivity;
import com.huidr.lib.commom.base.HuidrActivityManager;
import com.huidr.lib.commom.oss.OssService;
import com.huidr.lib.commom.util.Toast;

import org.litepal.LitePal;

import java.util.ArrayList;
import java.util.List;

import cn.jpush.android.api.JPushInterface;
import cn.jpush.im.android.api.ContactManager;
import cn.jpush.im.android.api.JMessageClient;
import cn.jpush.im.android.api.callback.GetUserInfoCallback;
import cn.jpush.im.android.api.model.Conversation;
import cn.jpush.im.android.api.model.UserInfo;
import cn.jpush.im.api.BasicCallback;
import jiguang.chat.activity.ChatActivity;
import jiguang.chat.application.JGApplication;
import jiguang.chat.database.FriendEntry;
import jiguang.chat.pickerimage.utils.BitmapUtil;
import jiguang.chat.utils.oss.Constants;
import jiguang.chat.utils.oss.SharedPreferenciesUtil;


public class H5Bridge {
    public static String loginStatus = "0";


    private final static String TAG = H5Bridge.class.toString();

    public void OpenNewWeb(String url) {
        OpenNewWeb(url, false);
    }

    public void OpenNewWeb(String url, Boolean finish) {

        Intent intent = new Intent(HuidrActivityManager.getInstance().getCurrentActivity(), WebActivity.class);
        //用Bundle携带数据
        Bundle bundle = new Bundle();
        bundle.putString("url", url);
        intent.putExtras(bundle);
        HuidrActivityManager.getInstance().getCurrentActivity().startActivity(intent);
        if (finish) {
            HuidrActivityManager.getInstance().getCurrentActivity().finish();
        }
    }

    //  app  内打开页面
    public void openUrl(String url) {
        Intent intent = new Intent();
        intent.setData(Uri.parse(url));
        intent.setAction(Intent.ACTION_VIEW);
        HuidrActivityManager.getInstance().getCurrentActivity().startActivity(intent);
    }

    //极光IM 发送好友邀请或者开始会话
    public void imfriendaction(String str) {

        try {
            org.json.JSONObject jsonObject = new org.json.JSONObject(str);
            final String targetId = jsonObject.get("userName").toString();
            //state =0  添加联系人
            if (jsonObject.getString("state").equals("0")) {
                //  发送添加好友请求  被邀请方username 被邀请方appkey reason   callback
                ContactManager.sendInvitationRequest(jsonObject.get("userName").toString(), null, jsonObject.getString("content"), new BasicCallback() {
                    @Override
                    public void gotResult(int i, String s) {
                        if (0 == i) {
                            //好友请求发送成功
                            Toast.getInstance(HuidrActivityManager.getInstance().getCurrentActivity()).show("添加好友请求发送成功", 1);
//                            addContact(targetId);
                        } else {
                            //好友请求发送失败
                            Toast.getInstance(HuidrActivityManager.getInstance().getCurrentActivity()).show("添加好友请求发送失败", 1);

                        }
                        HuidrActivityManager.getInstance().getCurrentActivity().finish();
                    }
                });
            } else {  //开始聊天  创建单聊会话          username  appkey

                Conversation conversation = Conversation.createSingleConversation(jsonObject.get("userName").toString());
                if (conversation != null) {
                    JMessageClient.getUserInfo(jsonObject.get("userName").toString(), null, new GetUserInfoCallback() {

                        @Override
                        public void gotResult(int i, String s, UserInfo userInfo) {
                            if (i == 0) {
                                Intent intent = new Intent(HuidrActivityManager.getInstance().getCurrentActivity(), ChatActivity.class);
                                //intent.putExtra(JGApplication.CONV_TITLE, userInfo.getExtra(ModulesConstants.USER_NAME_D));
                                intent.putExtra(JGApplication.CONV_TITLE, userInfo.getUserName());
                                intent.putExtra(JGApplication.TARGET_ID, userInfo.getUserName());
                                intent.putExtra(JGApplication.TARGET_APP_KEY, userInfo.getAppKey());
                                HuidrActivityManager.getInstance().getCurrentActivity().startActivity(intent);
                                HuidrActivityManager.getInstance().getCurrentActivity().finish();
                            } else {
                                Toast.getInstance(HuidrActivityManager.getInstance().getCurrentActivity()).show("开始聊天失败", 0);
                            }
                        }
                    });

                }
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    public void SwitchTabbar(String dispatchUrl) {
        if (!(HuidrActivityManager.getInstance().getCurrentActivity() instanceof MainActivity)) {
            HuidrActivityManager.getInstance().getCurrentActivity().startActivity(new Intent(HuidrActivityManager.getInstance().getCurrentActivity(), MainActivity.class));
            HuidrActivityManager.getInstance().getCurrentActivity().finish();
        }
        if (dispatchUrl.equals("0")) {
            MainActivity.instance.changeTab(R.id.tab_message);
        } else if (dispatchUrl.equals("1")) {
            MainActivity.instance.changeTab(R.id.tab_contact);
        } else if (dispatchUrl.equals("2")) {
            MainActivity.instance.changeTab(R.id.tab_follow);
        } else if (dispatchUrl.equals("3")) {
            MainActivity.instance.changeTab(R.id.tab_me);
        }
    }


    //返回上层页面，0 上一层，1 返回根页面
    public void BackTo(String flag) {
        HuidrActivityManager.getInstance().getCurrentActivity().onBackPressed();
    }

    public void PassValue(String json) {
        Log.e(TAG, "=====================passValue" + json);
        SharedPreferenciesUtil.putData(Constants.SharedAccountConfig.USER_DOCTOR_INFO, json);
        JSONObject jsonObject = JSONObject.parseObject(json);
        JSONObject object = jsonObject.getJSONObject("value");
        SharedPreferenciesUtil.putData(Constants.SharedAccountConfig.ImPassword, object.getString("imPassword"));
        SharedPreferenciesUtil.putData(Constants.SharedAccountConfig.JWT, object.getString("jwt"));
        SharedPreferenciesUtil.putData(Constants.SharedAccountConfig.ID, object.getString("id"));

//        SharedPreferenciesUtil.putData("Doctor_dep",object.getString("hospitalDepartment"));
//        SharedPreferenciesUtil.putData("Doctor_job_num",object.getString("userJobNumber"));
//        String id = object.getString("id");
//        JPushInterface.setAlias(MainActivity.instance, 0, id);
        /**
         * 反馈参数
         */
        org.json.JSONObject jsonObject2 = new org.json.JSONObject();
        jsonObject.put("userid", object.getString("id"));
        jsonObject.put("手机号", object.getString("mobile"));
        FeedbackAPI.setAppExtInfo(jsonObject2);
        FeedbackAPI.setUserNick(object.getString("id"));
        Log.e(TAG, "=====================passValue" + json);

    }


    //登录状态，0 退出登录，1 登录成功 访问 首次登陆接口
    public void LoginState(String flag) {
        // 修改当前登录用户为null
        Log.e("登录退出", "denglu" + flag + HuidrActivityManager.getInstance().getActivityList());
        loginStatus = flag;
        if (flag.equalsIgnoreCase("0")) {
            JMessageClient.logout();  //退出登录
            Intent intent = new Intent(HuidrActivityManager.getInstance().getCurrentActivity(), LoginActivity.class);
            HuidrActivityManager.getInstance().getCurrentActivity().startActivity(intent);
            HuidrActivityManager.getInstance().finishAll();
            SharedPreferenciesUtil.putData("userIcon", "0");
            SharedPreferenciesUtil.putData("currentId",0);
        } else if (flag.equalsIgnoreCase("1")) {
            isFirstLogin();
            SharedPreferenciesUtil.putData("friendIndex", 0);
            SharedPreferenciesUtil.putData("patientIndex", 0);
            SharedPreferenciesUtil.putData("currentFragment", 0);
            Log.e("测试1", "h5");
            Intent intent = new Intent(HuidrActivityManager.getInstance().getCurrentActivity(), MainActivity.class);
            HuidrActivityManager.getInstance().getCurrentActivity().startActivity(intent);
            HuidrActivityManager.getInstance().getCurrentActivity().finish();
        }
        SharedPreferenciesUtil.putData(Constants.SharedAccountConfig.IS_LOGIN, flag);
    }

    //    首次登录  http://192.168.1.180:1189doctorUser/isFirstLogin
    public void isFirstLogin() {
//        final String path = "http://192.168.1.180:1189/doctorUser/isFirstLogin";
        final String path = BuildConfig.baseUrl + "hospital/doctorUser/isFirstLogin";
        final JSONObject jsonObject = new JSONObject();
        ThreadPoolManager.getInstance().execute(new Runnable() {
            @Override
            public void run() {
                String result = PostAndGet.doHttpPost(path, jsonObject);
                Log.e("首次登陆", result);
                if (result.equals("网络异常")) {

                } else {
                    Gson gson = new Gson();
                    FirstLoginModel firstLoginModel = gson.fromJson(result, FirstLoginModel.class);
                    if (firstLoginModel.isRetValue()) {
//                        NewMessageModel newMessageModel = new NewMessageModel();
//                        newMessageModel.setContent("1欢迎您入住荟医平台，您的加入将使荟医更美好");
//                        newMessageModel.setType("systemMessage");
//                        newMessageModel.setDate(System.currentTimeMillis());
//                        newMessageModel.setIsRead(0);
//                        newMessageModel.save();
                        SharedPreferenciesUtil.putData("firstLogin", true);
                    }

                    Log.e("测试1", "456添加消息");
                }
            }
        });

    }

    /*
     *查询本地好友
     * */
    public String getNativeValueforkey(String key) {
        List<FriendEntry> friendEntries = new ArrayList<>();
        StringBuilder stringBuilder = new StringBuilder();

        friendEntries = new Select().from(FriendEntry.class).execute();


        if (friendEntries != null && friendEntries.size() > 0) {
            for (FriendEntry friendEntry : friendEntries) {
                stringBuilder.append(friendEntry.username).append(",");
            }
            return stringBuilder.deleteCharAt(stringBuilder.length() - 1).toString();
        } else {
            return "";
        }


    }


    //    保存信息
    public void saveValue(String json) {
        Gson gson = new Gson();
        SaveAndReadModel saveAndReadModel = gson.fromJson(json, SaveAndReadModel.class);
        SharedPreferenciesUtil.putData(saveAndReadModel.getKey(), saveAndReadModel.getValue());
    }

    //    读取信息
    public String getSharekey(String key) {
        String result = "";
        if (key.equals("id")) {
            result = (int) SharedPreferenciesUtil.getData(key, 0) + "";
        } else {
            result = (String) SharedPreferenciesUtil.getData(key, "0");
        }
        return result;
    }

    /*
     *
     *
     * */
    public Object[] checkSysMessage() {
        List<SysMessage> list = LitePal.findAll(SysMessage.class);
        List<String> result = new ArrayList<>();
        for (SysMessage item : list) {
            result.add(new Gson().toJson(item));
        }
        return result.toArray();
    }


    public void OpenNativeView(String nativeUrl) {
        Log.d("nativeUrl", nativeUrl);
        if (nativeUrl.equalsIgnoreCase(LocalConstants.FEED_BACK_KIT)) {
            Intent intent = new Intent(HuidrActivityManager.getInstance().getCurrentActivity(), HuiyiAssistantActivity.class);
            HuidrActivityManager.getInstance().getCurrentActivity().startActivity(intent);
        } else if (nativeUrl.equalsIgnoreCase(LocalConstants.NoticeMainViewController)) {
            Intent intent = new Intent(MainActivity.instance, MessageActivity.class);
            HuidrActivityManager.getInstance().getCurrentActivity().startActivity(intent);
        } else if (nativeUrl.equalsIgnoreCase(LocalConstants.QuickReplyViewController)) {
            Intent intent = new Intent(MainActivity.instance, FastReplyActivity.class);
            HuidrActivityManager.getInstance().getCurrentActivity().startActivity(intent);
        } else if (nativeUrl.equalsIgnoreCase(LocalConstants.SysTableViewController)) {
            Intent intent = new Intent(MainActivity.instance, MessageActivity.class);
            HuidrActivityManager.getInstance().getCurrentActivity().startActivity(intent);
        } else if (nativeUrl.equalsIgnoreCase("ConListViewController")) {
            Intent intent = new Intent(HuidrActivityManager.getInstance().getCurrentActivity(), ConsultRecordActivity.class);
            intent.setFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT);
            HuidrActivityManager.getInstance().getCurrentActivity().startActivity(intent);
        }
    }

    /*
     *
     *
     * */
    public void ossUpfile(String urls) {
        Log.e("ossUpfile---", urls);
        String jwt = (String) SharedPreferenciesUtil.getData("jwt", "");
        OssService ossService = OssService.getInstance(BuildConfig.OssStsServer, jwt, BuildConfig.OssEndpoint, BuildConfig.OssBucket, MainApplication.getInstance());
        ossService.batchUploadImgSyc(urls);
    }

    public void CheckVer() {
//        Intent intent = new Intent(HuidrActivityManager.getInstance().getCurrentActivity(), UpdateActivity.class);
//        //用Bundle携带数据
//        Bundle bundle = new Bundle();
//        bundle.putString("updateUrl", BuildConfig.UpdateUrl);
//        bundle.putString("mainActivity", MainActivity.class.getName());
//        bundle.putInt("type",0);
//        intent.putExtras(bundle);
//        HuidrActivityManager.getInstance().getCurrentActivity().startActivity(intent);

        Intent intent1 = new Intent(HuidrActivityManager.getInstance().getCurrentActivity(), DoctorUpdateActivity.class);
        HuidrActivityManager.getInstance().getCurrentActivity().startActivity(intent1);
    }

    public String getUrlKey(String key) {
        Activity activity = HuidrActivityManager.getInstance().getCurrentActivity();
        if (activity instanceof BaseWebActivity) {
            String value = ((BaseWebActivity) activity).getUrlKey(key);
            if (value == null) {
                return "";
            } else {
                return value;
            }
        }
        return "";
    }


}
