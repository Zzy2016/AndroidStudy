该module是引用lib.5plus.base-release.aar+第三方开放平台jar的方式集成5+离线SDK的示例demo
lib.5plus.base-release.aar包含了5+SDK的基础模块，

一：

    若需要支持广告业务，须配置示例demo的入口activity为io.dcloud.PandoraEntry.java。
    另外开发者须在AndroidManifest.xml中自行配置DCLOUD_STREAMAPP_CHANNEL该字段对应value值，
    替换appid和adid为自己应用的appid和广告联盟会员id，5+APP的应用资源manifest.json中添加

     ads广告配置信息

    "plus": {
            "ads": {
                "push":"true|false",       // push推送广告
                "splash":"true|false",     // 开屏广告
                "rp":"true|false",         // 悬浮红包广告
                "spot":"true|false",      // 插屏广告
            }
            // ...
        }
    adid广告联盟会员id
    "plus": {
        "adid": "广告联盟会员id "     // 开发者向后台申请后填写
        // ...
    }





二：

    SDK_WebApp为以WebApp方式集成5+ sdk的示例，参考http://ask.dcloud.net.cn/article/81文档配置
    SDK_WebView为以webview控件方式集成5+ sdk的示例，参考http://ask.dcloud.net.cn/article/80文档配置
    这两种方式不支持广告业务。



Android Studio 版本 3.2
JDK 1.8.0_191
JRE 1.8.0_191

Gradle Version 4.6


DoctorApp  最低版本API 15 Android 4.0.3 IceCreateSandwich
PatientApp 最低版本API 20 Android 4.4W  KitKat Wear

注：
     1、CompileSdkVersion:是告诉gradle 用哪个SDK版本来编译，和运行时要求的版本号没有关系；使用任何新添加的 API 就需要使用对应 Level 的 Android SDK;
     2、buildToolsVersion: android构建工具的版本,在SDK Manager中安装选择版本，buildToolsVersion的版本需要>=CompileSdkVersion; 高版本的build-tools 可以构建低版本编译的android程序;
     3、gradle版本和com.android.tools.build:gradle配置的版本关系。
	 4、Gradle插件的配置，工程的build.gradle文件  classpath 'com.android.tools.build.gradle:4.6.0'
	 5、Gradle配置，工程的gradle文件夹-->wrapper-->gradle-wrapper.properties文件  istributionUrl=https\://services.gradle.org/distributions/gradle-4.6-all.zip
	 6、Gradle和Gradle插件不是同一个东西；
	 7、gradle-wrapper-properties文件含义：
	      zipStoreBase和zipStorePath组合在一起，是下载的gradle-4.4-all.zip所存放的位置。
          zipStorePath是zipStoreBase指定的目录下的子目录。
          distributionBase和distributionPath组合在一起，是解压gradle-4.4-all.zip之后的文件的存放位置。
          distributionPath是distributionBase指定的目录下的子目录。
          distributionUrl：Gradle下载地址
	 8、 Gradle插件和Gradle版本具有对应关系
	 9、Gradle插件和Android SDK BuildTool具有对应关系。


文件结构
huidr_all
   |--.gradle  gradle工具的各个版本
   |--.idea    开发所需的各种环境
   |--DoctorApp  医生端app
      |--build
         |--gengerated
         |--intermediates
         |--outputs
            |--apk
               |--debug   打包生成的测试app
               |--release 打包生成的现上app
            |--logs
         |--tmp
      |--libs   使用的第三方jar包，在这个文件下会被自动添加到构建路径中
      |--src
         |--androidTest  测试用例
         |--main
            |--assets  打包时的H5页面文件夹   每次打包根据需要替换www文件夹
            |--java
               |--com
                  |--HBuilder.integrate.h5tools
                     |--h5tools  原生和H5交互类 包含需要调用的方法
                  |--huidr  主要的Java类
                     |--HuiDrDoctor
                        |--activity  所有的医生端Activity
							|--Consult  图文咨询相关
							|--contact   消息
							|--ChatSettingActivity  chat设置
							|--ConsultRecordActivity  图文咨询记录页
							|--ConsultReplyActivity   图文咨询聊天页
							|--ContractSearchActivity 联系人搜索
							|--DealConsultActivity    处理咨询 接受或者拒绝
							|--DocrotUpdateActivity   设置页 检查更新
							|--FastReplyActivity      快捷回复
							|--LoginActivity          登录（H5）
							|--MainActivity           主页
							|--MessageActivity        消息
							|--PatientSearchActivity  患者搜索
							|--SearchActivity         首页搜索
							|--ShowCodeActivity       小程序二维码 在“我的”点击二维码图标显示
							|--ShowImgActivity        显示图片
							|--SplashActivity         欢迎页
							|--WebActivity            H5页面加载
                        |--contact_fragment 联系人Tab内的四个fragment子页面 主要包括 最近查看、协同医生、申请、所有联系人
							|--ApplyFragment          最近查看
							|--CoopFragment           协同医生
							|--NewConversionFragment  申请
							|--NewContactFragment     所有联系人
                        |--content_fragment 消息Tab需要使用的fragment子页面 主要包括 图文咨询、消息列表
						    |--ConListFragment        图文咨询
						    |--MsgListFragment        系统消息
                        |--customview  包含一个自定义禁止水平滑动的ViewPager
							|--ScrollPageView         禁止滑动的ViewPager 在首页的各个Tab中都有用到
                        |--follow_fragment 患者池Tab内的五个fragment子页面  包含最近查看、住院患者、随访患者、关注患者、全部患者
							|--AllPatientFragment     所有患者
							|--AttentionFragment      关注患者
							|--InhosFragment          住院患者
							|--RecentFragment         最近查看
							|--VisitFragment          随访患者
                        |--fragment  主页包含的四个Fragment子页面  包含消息、患者池、联系人、我的
							|--DoctorFragment         联系人
							|--MessageFragment        消息
							|--PatientFragment        患者池
							|--SettingFragment        我的
                        |--module  需要使用的实体类
						|--progress  自定义进度条
							|--WaterWaveAttrInit     自定义进度条属性
							|--WaterWaveProgress     自定义进度条
							|--WidgetUtil            自定义进度条属性
                        |--services  检查更新服务
							|--UpdateService          检查更新
							|--MyServiceDelete        删除联系人
							|--NewUpdateService       静默检查更新
                        |--util  使用到的工具类 包含一些数据处理、获取、线程操作
                        |--MainApplication  功能初始化 注册
                     |--jiguang.push  极光推送
            |--res  资源文件
               |--drawable  图片 shape selector
               |--layout    布局文件
               |--value     color dimen string style
               |--xml       xml配置
            |--AndroidManifest.xml配置文件
         |--test  测试用例
         |--build.gradle  此文件只对当前module有效
         |--DoctorApp.iml
         |--proguard_rules.pro
         |--Readme.txt
   |--gradle  包含了 gradle 工具的打包
      |--wrapper   wrapper 的意思就是“包装、打包”。这个目录的意义是：把项目拷贝给别人时，
                   别人电脑上可能根本没有安装 gradle 工具，为了能够使用本项目，可以使用项目中打包好的 gradle 工具。
                   在该文件夹下的gradle-wrapper.prooerties文件中可以查看当前构建代码使用的是哪个版本
   |--jichat  医生端IM  以及医生端和患者端之间的图文咨询功能
   |--Library 使用到的库文件  包含了5+SDK的基础模块 根据需要进行升级
   |--PatientApp 患者端
      |--build
         |--gengerated
         |--intermediates
         |--outputs
            |--apk
               |--debug   打包生成的测试app
               |--release 打包生成的现上app
            |--logs
         |--tmp
      |--libs 使用的第三方jar包，在这个文件下会被自动添加到构建路径中
      |--src
         |--androidTest  测试
         |--main
            |--assets 打包时的H5页面文件夹   每次打包根据需要替换www文件夹
            |--java
               |--com
                    |--HBuilder.integrate.h5tools
                        |--H5Btidge  原生和H5交互类 包含需要调用的方法
                    |--huidr.HuiDrPatient
                        |--activity    原生所有Activity
						    |--ConsultChatActivity    图文咨询咨询页
						    |--ConsultStateActivity   图文咨询状态
						    |--ConversionActivity     图文咨询列表
						    |--LoginActivity          登录
						    |--MainActivity           首页
						    |--NoticeActivity         服药提醒弹窗
							|--PatientUpdateActivity  设置页 检查更新
						    |--SelectImgActivity      选择图片
						    |--ShowAdviceActivity     显示医生建议
						    |--ShowDialogActivity     对话框
						    |--ShowImgActivity        显示图片
						    |--SplashActivity         欢迎页
						    |--WebActivity            H5加载页
                    |--Adapter     列表适配
						|--CustomAdapter 服药提醒适配
                    |--alarm       服药提醒
						|--AlarmActivity 服药提醒
                    |--Consult     图文咨询相关实体类
                    |--ConsultUtils  获取在线状态
                    |--event   EventBus
                    |--FeedBack
                    |--model  实体类
					|--progress  自定义进度条
							|--WaterWaveAttrInit     自定义进度条属性
							|--WaterWaveProgress     自定义进度条
							|--WidgetUtil            自定义进度条属性
                    |--services  更新服务
					    |--MyServiceDelete  删除服务
						|--SilenceUpdateService 静默更新
						|--UpdateService  非静默更新
                    |--sysmsg  系统消息 由三个Fragment页面组成
					    |--ConsultRecordFragment 图文咨询
						|--LogisticInfoFragment  订单
						|--SysMsgFragment        系统消息
						|--SysMsgActivity 消息Activity
                    |--utils   工具类
                    |--view   咨询页功能View
                    |--wxapi  微信支付
                    |--Constants    常量值
                    |--MainApplication  功能初始化 注册
                |--jiguang.push  极光推送
            |--res
            |--AndroidManifest.xml  app配置 组件权限等注册
         |--test         测试
      |--build.gradle
      |--PatientApp
      |--proguard-rules.pro  混淆规则
   |--reclib-qq   jichat使用到的库文件
   |--reclib-testemoticons  jichat使用到的库文件
   |--sign  //签名文件
   |--build.gradle  最顶层的构建文件，这里配置所有模块通用的配置信息。
   |--gradle.properties gradle 的相关配置。
   |--gradlew
   |--gradlew.bat windows 下的批处理文件。
   |--huiyi_all.iml  文件保存这个模块的相关信息，格式是 xml 。
   |--local.properties  保存 Android SDK 所在的路径。
   |--setting.gradle 文件在初始化过程中被执行，一个 Gradle 构建通常包括三个阶段：初始化，配置，和执行。
   |--External Libraries


     权限：
         医生端：
	         1、摄像头(CAMERA);
	         2、存储(STORAGE);
	         3、定位(LOCATION);
	         4、录音(MICROPHONE);
	         5、联系人(PHONE)。
	     患者端
	         1、摄像头(CAMERA);
		     2、录音(MICROPHONE);
		     3、存储(STORAGE);
		     4、定位(LOCATION)。
	  以上权限都属于危险权限，需要动态申请，在AndroidManifest.xml文件中也需要声明。另外还有普通权限，只需要在AndroidManifest.xml文件中声明。

     生成Apk:
         debug:
             医生端 Gradlew-->huidr_all-->DoctorApp-->Tasks-->build-->assembleDebug
             患者端 Gradlew-->huidr_all-->PatientApp-->Tasks-->build-->assembleDebug
         release：
             医生端 Gradlew-->huidr_all-->DoctorApp-->Tasks-->build-->assembleRelease
             患者端 Gradlew-->huidr_all-->PatientApp-->Tasks-->build-->assembleRelease
         需要注意：
             1、versionCode;
             2、versionName;
             3、提交审核的Apk的H5包中不能有vConsole;
             4、患者端提审需要生成荟医健康和荟医随访(应用宝、华为)两个apk，除了名字全部相同;
             5、医生端只需要生成荟医医生;
             6、提交360应用市场的apk需要使用360加固助手进行加固;
             7、提交审核需要跟前端确认 androidCheck==1;

	 dependencies：
	    DoctorApp:
	         org.litepal.android:core:2.0.0
			 com.android.support:multidex:1.0.3
        	 com.squareup.retrofit2:retrofit:2.3.0
             com.squareup.retrofit2:converter-gson:2.3.0
			 com.scwang.smartrefresh:SmartRefreshLayout:1.1.0-alpha-14
			 com.scwang.smartrefresh:SmartRefreshHeader:1.1.0-alpha-14
			 com.android.support:cardview-v7:28.0.0
			 com.github.anzaizai:EasySwipeMenuLayout:1.1.4
			 com.youth.banner:banner:1.4.10
			 com.android.volley:volley:1.1.1
			 com.google.android:flexbox:1.0.0
			 jichat
		PatientApp
			 rg.litepal.android:java:3.0.0
			 com.github.whieenz:LogCook:v1.0
			 com.scwang.smartrefresh:SmartRefreshLayout:1.1.0-alpha-14
			 com.scwang.smartrefresh:SmartRefreshHeader:1.1.0-alpha-14
			 jichat
		jichat
			 com.michaelpardo:activeandroid:3.1.0-SNAPSHOT
			 com.github.bumptech.glide:glide:3.7.0
			 com.github.chrisbanes.photoview:library:1.2.4
			 com.facebook.fresco:fresco:1.1.0
			 io.reactivex:rxandroid:1.2.1
			 com.contrarywind:Android-PickerView:3.2.4
			 cn.jiguang.sdk:jmessage:2.7.1
			 cn.jiguang.sdk:jcore:1.2.5
		Libiary
			 com.github.anzaizai:EasyRefreshLayout:1.3.1
			 com.alibaba:fastjson:1.2.54
			 com.google.code.gson:gson:2.8.5
			 com.android.support:recyclerview-v7:28.0.0
			 org.greenrobot:eventbus:3.1.1
			 in.srain.cube:ultra-ptr:1.0.11
			 com.squareup.okhttp3:logging-interceptor:3.7.0
			 com.squareup.retrofit2:converter-gson:2.3.0
			 com.squareup.retrofit2:adapter-rxjava:2.3.0
			 com.github.CymChad:BaseRecyclerViewAdapterHelper:2.9.14
			 com.github.bumptech.glide:glide:3.7.0
			 cn.jiguang.sdk:jpush:3.1.6
			 cn.jiguang.sdk:jcore:1.2.5
			 com.zyao89:zloading:1.2.0
			 com.aliyun.dpa:oss-android-sdk:+

		注：
			 1、compile被implentationh和api替换;
			 2、provided被compile only替换;
			 3、apk被runtime only替代;
			 4、implentation    仅对当前的Module提供接口。引用了当前Moudle的子Module无法引用当前Module引用的Library;
			 5、api与compile    完全相同;
			 6、compile only    只在编译时有效。不会参与打包;
			 7、runtimeOnly    只在生成apk时参与打包，编译时不会参与;
			 8、testImplentation    只在单元测试代码的编译以及最终打包测试apk时有效;
			 9、debugImplementation    只在debug模式的编译和最终的debug apk打包时有用
			 10、releaseImplementtation    只在release模式和最终的release apk打包时有用。
sign
	 D:\Android_Huiyi\huidr_all\sign  签名文件路径
	 alias password在对应的build.gradle文件（加固apk有时会用到）


访问接口
     患者端：
         1、pay/orderSearch/searchOrder
	     2、pay/orderSearch/searchOrderyByOrderId
	     3、pay/orderSearch/batchSearchOrder
	     4、patient/patientRemindTemplate/addRemindRecord
	     5、consult/consult/isConsultationToThisDoctor
	     6、consult/consult/getFirstConsultSuggestDetail
	     7、consult/consult/finishConsultOrder
	     8、consult/consult/getDoctorConsultSuggestDetail
	     9、consult/consult/getPatientConsultContentByUserId


	 医生端：
	     1、patient/patientHomepage/getPatient
	     2、patient/doctorPatientMedical/addRemarksAndFollow
	     3、patient/doctorPatientMedical/getFollowUpPoolList
	     4、patient/doctorPatientMedical/getPatientByRecently
	     5、patient/HomePage/getDoctorHomePagePng
	     6、patient/doctorPatientMedical/getAttentionRelationshipPatients
         7、patient/patientMedical/getCompleteReportTo
         8、followup/followUpService/getVisitingHandles
	     9、consult/consult/refuseOrder
	     10、consult/consult/confirmOrder
	     11、pay/orderSearch/searchOrder
	     12、pay/orderSearch/searchConsult
	     13、hospital/doctorUser/isFirstLogin
	     14、hospital/doctorUser/operationFollowup
	     15、hospital/search/searchHis
	     16、hospital/doctorSetting/updateUserIcon
	     17、hospital/doctorGroup/getAssistDoctorList
	     18、hospital/doctorGroup/removeAssistDoctor
	     19、hospital/doctorGroup/addRecentlyCheckDoctor
	     20、hospital/doctorGroup/addContacts
	     21、hospital/doctorGroup/updateContacts
	     22、hospital/doctorGroup/getApplyList
	     23、hospital/doctorGroup/getRecentlyCheckDoctor
	     24、hospital/doctorGroup/addAssistDoctor
	     25、hospital/doctorGroup/deleteContacts
	     26、hospital/doctorGroup/getContactsList
         27、hospital/followupGroupController/getFollowupGroups
         28、hospital/followupGroupController/delFollowupGroupByGroupId
         29、hospital/search/search
         30、hospital/doctorGroup/getDoctorList




project.build.gradle  插件版本

gradlew插件版本   project build.gradle
gradle 版本       gradle/wrapper/gradlew-wrapper.properties

本地gradle版本  C:/user/admin/.gradlew/wrapper/dists/.

android studio 版本对应的gradle  gradle.bat -v



MessageFragment 读取消息 红点显示
MsgListFragment 消息列表



Timer TimerTask
所有task共用一个timer。TimerTask.cancel()取消定时器，每次启动的时候，再重新new一个TimerTask。

每次使用Timer.cancel()取消定时器，每次启动的时候，再重新new一个TimerTask也要new一个Timer
方式二，不仅要调用Timer.cancel()，还需要调用Timer.purge()。






















